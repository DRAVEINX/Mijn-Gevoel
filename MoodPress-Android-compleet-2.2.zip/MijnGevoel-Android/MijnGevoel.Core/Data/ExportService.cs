using System.Text.Json;

namespace MijnGevoel.Core.Data;

/// <summary>Inzage en overdraagbaarheid (AVG art. 15 en 20): alle gegevens van de cliënt in één leesbaar JSON-bestand. Tekeningen als base64-PNG.</summary>
public static class ExportService
{
    public static void ExportAll(VaultStore store, string username, string path)
    {
        var data = new
        {
            Gebruikersnaam = username,
            Gemaakt = DateTime.Now,
            Dagboek = store.All<JournalEntry>("diary").OrderBy(e => e.Created).ToList(),
            VanMeAfschrijven = store.All<JournalEntry>("note").OrderBy(e => e.Created).ToList(),
            VierGevoelens = store.All<FourGFeelingEntry>("feeling4g").OrderBy(e => e.Created).ToList(),
            Gevoelscheckins = store.All<MoodCheckInEntry>("moodcheckin").OrderBy(e => e.Created).ToList(),
            Spraakberichten = store.All<VoiceNoteEntry>("voice-note").OrderBy(e => e.Created).ToList(),
            Stoplicht = store.All<StoplichtEntry>("light").OrderBy(e => e.Created).ToList(),
            Agenda = store.All<AgendaItem>("agenda").OrderBy(e => e.Date).ToList(),
            Tekeningen = store.All<DrawingEntry>("drawing").OrderBy(e => e.Created)
                .Select(d => new { d.Id, d.Created, d.Title, PngBase64 = Convert.ToBase64String(d.Png) }).ToList(),
            Plan = store.Load<SafetyPlan>("plan", Guid.Empty),
            Gedeeld = store.All<ShareLogEntry>("sharelog").OrderBy(e => e.Created).ToList(),
            Toestemming = store.All<ConsentRecord>("consent").OrderBy(e => e.Created).ToList(),
            Stappenplannen = store.All<Routine>("routine").OrderBy(r => r.Title).ToList(),
            RoutinesMetMelding = store.All<RoutineReminder>("routinereminder").OrderBy(r => r.Time).ToList(),
            Meters = store.All<ScaleEntry>("scale").OrderBy(e => e.Created).ToList(),
            EigenKaarten = store.All<TalkCard>("card").OrderBy(c => c.Text).ToList(),
            Gesprekskaart = store.Load<TalkPrep>("talk", Guid.Empty),
            Instellingen = store.Load<UserSettings>("settings", Guid.Empty),
        };
        var opt = new JsonSerializerOptions { WriteIndented = true, Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping };
        File.WriteAllText(path, JsonSerializer.Serialize(data, opt), new System.Text.UTF8Encoding(false));
    }
}
