using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MijnGevoel.Core.Security;

namespace MijnGevoel.Core.Data;

public record SharePackage(int Version, string From, DateTime Created, List<StoplichtEntry> Items);

/// <summary>
/// Delen met een begeleider, alleen als de cliënt dat zelf kiest: een versleuteld deelbestand (.mgdeel) met precies de gekozen meldingen.
/// Sleutel = Argon2id(deelcode). Het bestand en de code moeten via twee verschillende kanalen naar de begeleider.
/// </summary>
public static class ShareService
{
    const string Magic = "MGDEEL1";

    public static string NewShareCode()
    {
        const string a = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
        var sb = new StringBuilder();
        for (int i = 0; i < 12; i++) { if (i > 0 && i % 4 == 0) sb.Append('-'); sb.Append(a[RandomNumberGenerator.GetInt32(a.Length)]); }
        return sb.ToString();
    }

    public static byte[] Create(string from, IEnumerable<StoplichtEntry> items, string code)
    {
        var json = JsonSerializer.SerializeToUtf8Bytes(new SharePackage(1, from, DateTime.Now, items.ToList()));
        var salt = Crypto.Random(Crypto.SaltSize);
        var key = Crypto.DeriveKey(Normalize(code), salt);
        try { return [.. Encoding.ASCII.GetBytes(Magic), .. salt, .. Crypto.Seal(key, json, Magic)]; }
        finally { CryptographicOperations.ZeroMemory(key); CryptographicOperations.ZeroMemory(json); }
    }

    /// <summary>Null bij verkeerde code, beschadigd of gemanipuleerd bestand.</summary>
    public static SharePackage? Open(byte[] file, string code)
    {
        var m = Encoding.ASCII.GetBytes(Magic);
        if (file.Length < m.Length + Crypto.SaltSize + Crypto.NonceSize + Crypto.TagSize) return null;
        if (!file.AsSpan(0, m.Length).SequenceEqual(m)) return null;
        var salt = file[m.Length..(m.Length + Crypto.SaltSize)];
        var blob = file[(m.Length + Crypto.SaltSize)..];
        var key = Crypto.DeriveKey(Normalize(code), salt);
        try { return JsonSerializer.Deserialize<SharePackage>(Crypto.Open(key, blob, Magic)); }
        catch (Exception ex) when (ex is CryptographicException || ex is JsonException) { return null; }
        finally { CryptographicOperations.ZeroMemory(key); }
    }

    const string HtmlAad = "MGDEEL-HTML1";
    const int HtmlIterations = 600_000;

    /// <summary>Leesbaar voor begeleiders zonder programma: een versleutelde HTML-pagina die in elke browser opent (ook op een telefoon, ook via WhatsApp als bijlage).</summary>
    public static string CreateHtml(string from, IEnumerable<StoplichtEntry> items, string code)
    {
        var json = JsonSerializer.SerializeToUtf8Bytes(new SharePackage(1, from, DateTime.Now, items.ToList()));
        var salt = Crypto.Random(16); var nonce = Crypto.Random(12);
        var pw = Encoding.UTF8.GetBytes(Normalize(code));
        var key = Rfc2898DeriveBytes.Pbkdf2(pw, salt, HtmlIterations, HashAlgorithmName.SHA256, 32);
        var ct = new byte[json.Length]; var tag = new byte[16];
        try
        {
            using (var g = new AesGcm(key, 16)) g.Encrypt(nonce, json, ct, tag, Encoding.ASCII.GetBytes(HtmlAad));
            return ShareHtml.Template
                .Replace("{{SALT}}", Convert.ToBase64String(salt))
                .Replace("{{NONCE}}", Convert.ToBase64String(nonce))
                .Replace("{{DATA}}", Convert.ToBase64String(ct.Concat(tag).ToArray()))
                .Replace("{{ITER}}", HtmlIterations.ToString());
        }
        finally { CryptographicOperations.ZeroMemory(key); CryptographicOperations.ZeroMemory(pw); CryptographicOperations.ZeroMemory(json); }
    }

    /// <summary>Alleen voor tests en controle: leest zo'n HTML-bestand met dezelfde code (de browser doet dit normaal).</summary>
    public static SharePackage? OpenHtml(string html, string code)
    {
        string? Get(string n) { var m = System.Text.RegularExpressions.Regex.Match(html, "data-" + n + "=\"([^\"]+)\""); return m.Success ? m.Groups[1].Value : null; }
        var s = Get("s"); var nn = Get("n"); var d = Get("d"); var it = Get("i");
        if (s is null || nn is null || d is null || it is null || !int.TryParse(it, out var iter) || iter < 100_000) return null;
        try
        {
            var data = Convert.FromBase64String(d);
            if (data.Length < 16) return null;
            var key = Rfc2898DeriveBytes.Pbkdf2(Encoding.UTF8.GetBytes(Normalize(code)), Convert.FromBase64String(s), iter, HashAlgorithmName.SHA256, 32);
            var ct = data[..^16]; var tag = data[^16..]; var plain = new byte[ct.Length];
            using var g = new AesGcm(key, 16);
            g.Decrypt(Convert.FromBase64String(nn), ct, tag, plain, Encoding.ASCII.GetBytes(HtmlAad));
            return JsonSerializer.Deserialize<SharePackage>(plain);
        }
        catch (Exception ex) when (ex is CryptographicException || ex is JsonException || ex is FormatException) { return null; }
    }

    /// <summary>Gewone tekst (NIET versleuteld) om bijvoorbeeld in een chat te plakken. Alleen na uitdrukkelijke keuze van de cliënt.</summary>
    public static string PlainText(string from, IEnumerable<StoplichtEntry> items)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"MoodPress - gedeeld door {from}").AppendLine();
        foreach (var e in items.OrderBy(i => i.Colour == "Rood" ? 0 : i.Colour == "Oranje" ? 1 : 2).ThenByDescending(i => i.Created))
        {
            var em = e.Colour == "Rood" ? "🔴" : e.Colour == "Oranje" ? "🟠" : "🟢";
            sb.AppendLine($"{em} {e.Colour} - {e.Created:dd-MM-yyyy HH:mm}");
            if (e.Reasons.Length > 0) sb.AppendLine("Waarom: " + string.Join(", ", e.Reasons));
            if (e.Needs.Length > 0) sb.AppendLine("Nodig: " + string.Join(", ", e.Needs));
            if (!string.IsNullOrWhiteSpace(e.Text)) sb.AppendLine(e.Text.Trim());
            sb.AppendLine();
        }
        return sb.ToString().TrimEnd();
    }

    static string Normalize(string c) => new string(c.Where(char.IsLetterOrDigit).ToArray()).ToUpperInvariant();
}
