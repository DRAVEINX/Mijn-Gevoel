namespace MijnGevoel.AndroidApp;

/// <summary>Toont een neutraal scherm zolang de gebruiker even privacy nodig heeft.</summary>
public sealed class PrivacyCoverPage : ContentPage
{
    protected override void OnAppearing()
    {
        base.OnAppearing();
        AppSession.Touch();
    }

    public PrivacyCoverPage()
    {
        Title = "Privacyscherm";
        BackgroundColor = Color.FromArgb("#070D22");
        var restore = new Button
        {
            Text = "Tik hier om terug te gaan",
            FontSize = 22,
            TextColor = Color.FromArgb("#F4F7FF"),
            BackgroundColor = Color.FromArgb("#122852"),
            CornerRadius = 18,
            Padding = new Thickness(22, 18),
            HorizontalOptions = LayoutOptions.Center,
            VerticalOptions = LayoutOptions.Center
        };
        restore.Clicked += async (_, _) =>
        {
            if (Navigation.NavigationStack.Count > 1) await Navigation.PopAsync();
        };
        Content = new Grid
        {
            Padding = 24,
            Children =
            {
                new VerticalStackLayout
                {
                    Spacing = 18,
                    VerticalOptions = LayoutOptions.Center,
                    Children =
                    {
                        new Image { Source = "moodpress-mark.png", WidthRequest = 112, HeightRequest = 112, Aspect = Aspect.AspectFit, HorizontalOptions = LayoutOptions.Center },
                        new Label { Text = "MoodPress", FontSize = 32, FontAttributes = FontAttributes.Bold, TextColor = Color.FromArgb("#F4F7FF"), HorizontalTextAlignment = TextAlignment.Center },
                        new Label { Text = "Jouw gevoel. Jouw verhaal. Jouw app.", FontSize = 16, TextColor = Color.FromArgb("#21D4FD"), HorizontalTextAlignment = TextAlignment.Center },
                        new Label { Text = "Je scherm is even verborgen.", FontSize = 20, TextColor = Color.FromArgb("#F4F7FF"), HorizontalTextAlignment = TextAlignment.Center },
                        restore
                    }
                }
            }
        };
    }
}
