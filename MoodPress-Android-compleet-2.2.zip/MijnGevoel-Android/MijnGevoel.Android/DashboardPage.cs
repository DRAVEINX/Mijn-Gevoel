using System.Globalization;
using MijnGevoel.Core.Data;
using Microsoft.Maui.ApplicationModel.Communication;

namespace MijnGevoel.AndroidApp;

public enum FeatureKind
{
    Stoplicht, DayToday, DayTomorrow, Agenda, Timer, Routines, RoutineReminders,
    Breath, Calm, Sensory, Body, MoodHistory, FeelingWords,
    Cards, TalkPrep, StoplichtHistory, Share, SafetyPlan,
    Draw, Gallery, Notes, Journal, Privacy, Week, Settings, Help, WhoWorks, DailyCheckIn, MoodCalendar, MoodInsights
}

public sealed class DashboardPage : ContentPage
{
    bool _consentPrompted;
    static readonly (string Name, string Icon, FeatureKind Kind)[][] Groups =
    {
        new[] { ("Vandaag", "🗓️", FeatureKind.DayToday), ("Wie werkt er?", "👥", FeatureKind.WhoWorks), ("Morgen bekijken", "🌙", FeatureKind.DayTomorrow), ("Agenda", "📅", FeatureKind.Agenda), ("Timer", "⏳", FeatureKind.Timer), ("Stappenplannen", "✅", FeatureKind.Routines), ("Routines en herinneringen", "⏰", FeatureKind.RoutineReminders) },
        new[] { ("Mijn gevoel", "😊", FeatureKind.DailyCheckIn), ("Rust en ontspanning", "🌬️", FeatureKind.Breath), ("Rustplek", "🌲", FeatureKind.Calm), ("Prikkelmeter", "🎚️", FeatureKind.Sensory), ("Mijn lichaam", "🧍", FeatureKind.Body), ("Hoe voel ik me?", "📊", FeatureKind.MoodHistory), ("Gevoelswoorden", "📖", FeatureKind.FeelingWords), ("Gevoelskalender", "🗓️", FeatureKind.MoodCalendar), ("Mijn inzichten", "📈", FeatureKind.MoodInsights) },
        new[] { ("Communicatiekaarten", "💬", FeatureKind.Cards), ("Gesprekskaart", "🗣️", FeatureKind.TalkPrep), ("Mijn stoplicht", "🚦", FeatureKind.Stoplicht), ("Stoplicht-overzicht", "📊", FeatureKind.StoplichtHistory), ("Delen met mijn begeleider", "📤", FeatureKind.Share), ("Mijn helpkaart / plan", "🆘", FeatureKind.SafetyPlan) },
        new[] { ("Tekenen", "🎨", FeatureKind.Draw), ("Mijn tekeningen", "🖼️", FeatureKind.Gallery), ("Van me afschrijven", "📝", FeatureKind.Notes), ("Dagboek", "📓", FeatureKind.Journal) },
        new[] { ("Mijn privacy", "🔐", FeatureKind.Privacy), ("Weekoverzicht", "🗒️", FeatureKind.Week), ("Instellingen", "⚙️", FeatureKind.Settings), ("Hulp", "❓", FeatureKind.Help) }
    };
    static readonly string[] GroupNames = { "MIJN DAG", "RUST EN GEVOEL", "PRATEN EN DELEN", "MAKEN EN SCHRIJVEN", "MIJN GEGEVENS" };

    public DashboardPage()
    {
        Title = "MoodPress";
        BackgroundColor = AppUi.Background;
        ToolbarItems.Add(new ToolbarItem("🔒", null, async () => await ((App)Application.Current!).LockToLoginAsync("Je sessie is vergrendeld.")));
        ToolbarItems.Add(new ToolbarItem("🙈", null, async () => await Navigation.PushAsync(new PrivacyCoverPage())));
        Build();
        if (AppSession.Store is not null)
            RoutineReminderNotifications.Sync(Android.App.Application.Context, AppSession.Store.All<RoutineReminder>("routinereminder"));
    }

    void Build()
    {
        var root = new VerticalStackLayout { Padding = new Thickness(16, 12), Spacing = 13, BackgroundColor = AppUi.Background };
        var hello = new VerticalStackLayout { Spacing = 1, VerticalOptions = LayoutOptions.Center, Children = {
            AppUi.Label("Hallo,", muted: true),
            AppUi.Label("Fijn dat je er bent!", title: true)
        }};
        var top = new Grid
        {
            ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star) },
            ColumnSpacing = 12,
            Children = { new Image { Source = "moodpress_mark.png", WidthRequest = 64, HeightRequest = 64, Aspect = Aspect.AspectFit, VerticalOptions = LayoutOptions.Center }, hello }
        };
        Grid.SetColumn(hello, 1);
        root.Children.Add(top);
        var slogan = AppUi.Label("Jouw gevoel. Jouw verhaal. Jouw app.", muted: true);
        slogan.FontAttributes = FontAttributes.Italic;
        slogan.FontSize = Math.Max(13, AppUi.BaseFont * 0.72);
        root.Children.Add(slogan);

        int left = AppSession.Accounts.RecoveryCodesLeft(AppSession.Username);
        if (left <= 2)
            root.Children.Add(AppUi.Card(new VerticalStackLayout { Children = { AppUi.Label($"⚠️ Je hebt nog {left} herstelcode(s). Maak nieuwe codes bij Instellingen.") } }));

        var checkinButton = AppUi.Button("🙂   Hoe voel je je vandaag?\nKies je gevoel of druk op de knop      ›", () => Navigate(FeatureKind.DailyCheckIn));
        checkinButton.HeightRequest = 92;
        checkinButton.FontSize = Math.Max(15, AppUi.BaseFont * 0.86);
        checkinButton.BackgroundColor = Color.FromArgb("#123C80");
        checkinButton.BorderColor = Color.FromArgb("#2F71F7");
        root.Children.Add(checkinButton);

        root.Children.Add(AppUi.Label("Snelle acties", title: true));
        var quick = new Grid
        {
            ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) },
            RowDefinitions = { new RowDefinition(GridLength.Auto), new RowDefinition(GridLength.Auto) },
            ColumnSpacing = 9, RowSpacing = 9
        };
        AddQuickTile(quick, "😊\nMijn gevoel\nKies je emotie", "#294BC3", FeatureKind.DailyCheckIn, 0, 0);
        AddQuickTile(quick, "🌬️\nRust & ontspanning\nKom tot jezelf", "#087E76", FeatureKind.Breath, 1, 0);
        AddQuickTile(quick, "💬\nCommunicatie\nLaat weten wat je nodig hebt", "#A93278", FeatureKind.Cards, 0, 1);
        AddQuickTile(quick, "🗓️\nMijn dag\nOverzicht & planning", "#B96720", FeatureKind.DayToday, 1, 1);
        root.Children.Add(quick);

        root.Children.Add(AppUi.Label("Snel opslaan", title: true));
        var fastStatus = AppUi.Label("");
        var fastHelpPanel = new VerticalStackLayout { IsVisible = false, Spacing = 8, Padding = 12, BackgroundColor = AppUi.Surface };
        var fastGrid = new Grid
        {
            ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) },
            RowDefinitions = { new RowDefinition(GridLength.Auto), new RowDefinition(GridLength.Auto) },
            ColumnSpacing = 8, RowSpacing = 8
        };
        var fastFeelings = new[]
        {
            (Key: "Blij", Label: "😊  Blij", Color: "#176B60"),
            (Key: "Bedroefd", Label: "😢  Verdrietig", Color: "#244D93"),
            (Key: "Boos", Label: "😠  Boos", Color: "#8A3155"),
            (Key: "Bang", Label: "😨  Bang", Color: "#5739A6")
        };
        for (int i = 0; i < fastFeelings.Length; i++)
        {
            var feeling = fastFeelings[i];
            var button = AppUi.Button(feeling.Label, () => { _ = SaveFourGFeelingAsync(feeling.Key, fastStatus, fastHelpPanel); });
            button.HeightRequest = 58;
            button.FontSize = Math.Max(14, AppUi.BaseFont * 0.78);
            button.BackgroundColor = Color.FromArgb(feeling.Color);
            button.BorderColor = Color.FromArgb(feeling.Color);
            fastGrid.Add(button, i % 2, i / 2);
        }
        root.Children.Add(fastGrid);
        root.Children.Add(fastStatus);
        root.Children.Add(AppUi.Card(fastHelpPanel));

        root.Children.Add(AppUi.Label("Vandaag", title: true));
        var todayButton = AppUi.Button($"📅   {DateTime.Today.ToString("dddd d MMMM", CultureInfo.GetCultureInfo("nl-NL"))}\nBekijk je dag en taken                         ›", () => Navigate(FeatureKind.DayToday), quiet: true);
        todayButton.HeightRequest = 82;
        todayButton.BackgroundColor = Color.FromArgb("#102753");
        todayButton.BorderColor = Color.FromArgb("#3157A6");
        root.Children.Add(todayButton);

        root.Children.Add(AppUi.Label("Alle functies", title: true));
        for (int groupIndex = 0; groupIndex < Groups.Length; groupIndex++)
        {
            var title = AppUi.Label(GroupNames[groupIndex], muted: true);
            title.FontSize = Math.Max(12, AppUi.BaseFont * 0.72);
            title.FontAttributes = FontAttributes.Bold;
            var grid = new Grid
            {
                ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) },
                ColumnSpacing = 7, RowSpacing = 7
            };
            var items = Groups[groupIndex];
            for (int row = 0; row < (items.Length + 1) / 2; row++) grid.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
            for (int i = 0; i < items.Length; i++)
            {
                var item = items[i];
                var button = AppUi.Button($"{item.Icon}  {item.Name}", () => Navigate(item.Kind), quiet: true);
                button.FontSize = Math.Max(13, AppUi.BaseFont * 0.78);
                button.HeightRequest = 64;
                button.Padding = new Thickness(7, 8);
                button.BackgroundColor = Color.FromArgb(groupIndex % 2 == 0 ? "#0E1D40" : "#111D42");
                button.BorderColor = Color.FromArgb(groupIndex % 2 == 0 ? "#254985" : "#2D367A");
                grid.Add(button, i % 2, i / 2);
            }
            var cardStack = new VerticalStackLayout { Spacing = 5, Children = { title, grid } };
            root.Children.Add(AppUi.Card(cardStack));
        }
        root.Children.Add(AppUi.Label("Je gegevens blijven privé en versleuteld. Je kiest zelf wat je deelt.", muted: true));
        root.Children.Add(AppUi.Button("🔒 Sessie vergrendelen", async () => await ((App)Application.Current!).LockToLoginAsync(), danger: true));
        root.Children.Add(AppUi.AsyncButton("🚪 Uitloggen en sessie vergeten", async () =>
        {
            if (await DisplayAlertAsync("Uitloggen?", "Je opgeslagen sessie wordt verwijderd. Je moet daarna opnieuw inloggen met je gegevens.", "Uitloggen", "Annuleren"))
                await ((App)Application.Current!).LockToLoginAsync("Je bent uitgelogd. Log opnieuw in met je gegevens.", forgetRemembered: true);
        }, quiet: true));
        root.Children.Add(AppUi.Copyright());
        Content = AppUi.WithBottomNavigation(this, new ScrollView { Content = root, BackgroundColor = AppUi.Background }, "home");
    }

    void AddQuickTile(Grid grid, string text, string color, FeatureKind kind, int col, int row)
    {
        var button = AppUi.Button(text, () => Navigate(kind));
        button.HeightRequest = 118;
        button.FontSize = Math.Max(14, AppUi.BaseFont * 0.78);
        button.Padding = new Thickness(8, 10);
        button.CornerRadius = 19;
        button.BackgroundColor = Color.FromArgb(color);
        button.BorderColor = Color.FromArgb(color);
        Grid.SetColumn(button, col);
        Grid.SetRow(button, row);
        grid.Children.Add(button);
    }

    void Navigate(FeatureKind kind)
    {
        if (kind == FeatureKind.WhoWorks) _ = Navigation.PushAsync(new WieWerktErPage());
        else _ = Navigation.PushAsync(new FeaturePage(kind));
    }

    async Task SaveFourGFeelingAsync(string feeling, Label status, VerticalStackLayout helpPanel)
    {
        var record = new FourGFeelingEntry(Guid.NewGuid(), DateTime.Now, feeling);
        AppSession.Store!.Save("feeling4g", record.Id, record);
        status.Text = $"Opgeslagen: {FeelingEmoji(feeling)} {feeling}.";
        AppUi.Speak($"Je hebt {feeling} gekozen. Dit is opgeslagen. Er wordt niets automatisch gedeeld.");
        helpPanel.Children.Clear();
        helpPanel.Children.Add(AppUi.Title(feeling == "Blij" ? "Fijn dat je dit deelt" : "Wat kan nu helpen?"));
        if (feeling == "Blij")
        {
            helpPanel.Children.Add(AppUi.Label("Je gevoel is bewaard. Je hoeft verder niets te doen."));
            helpPanel.IsVisible = true;
            return;
        }

        var plan = AppSession.Store.Load<SafetyPlan>("plan", Guid.Empty) ?? new SafetyPlan();
        var options = plan.HelpOptions?.Where(x => !string.IsNullOrWhiteSpace(x)).Distinct().ToList() ?? new List<string>();
        if (options.Count == 0) options = new List<string> { "breath", "calm", "stressball", "walk" };
        foreach (var option in options) helpPanel.Children.Add(AppUi.AsyncButton(HelpOptionLabel(option), async () => await RunHelpOptionAsync(option), quiet: true));
        helpPanel.Children.Add(AppUi.Button("👥 Wie werkt er vandaag?", () => Navigation.PushAsync(new WieWerktErPage()), quiet: true));
        helpPanel.Children.Add(AppUi.Button("🆘 Mijn helpkaart bekijken", () => Navigate(FeatureKind.SafetyPlan), quiet: true));
        helpPanel.Children.Add(AppUi.AsyncButton("📱 Een seintje aan mijn contact voorbereiden", SendSignalAsync, quiet: true));
        helpPanel.Children.Add(AppUi.Label("Er wordt niets automatisch verzonden. Jij kiest zelf of je een bericht opent en verstuurt.", muted: true));
        helpPanel.IsVisible = true;
    }

    static string FeelingEmoji(string feeling) => feeling switch { "Blij" => "😄", "Bedroefd" => "😢", "Boos" => "😠", "Bang" => "😨", _ => "🙂" };
    static string HelpOptionLabel(string key) => key switch
    {
        "breath" => "🫁 Samen rustig ademhalen", "calm" => "🛋️ Naar mijn rustplek", "music" => "🎧 Rustige muziek luisteren",
        "stressball" => "🧸 Pak mijn stressbal", "walk" => "🚶 Even rustig wandelen", "talk" => "💬 Met iemand praten", _ => "🆘 Mijn helpkaart openen"
    };

    async Task RunHelpOptionAsync(string key)
    {
        switch (key)
        {
            case "breath": await Navigation.PushAsync(new FeaturePage(FeatureKind.Breath)); break;
            case "calm": await Navigation.PushAsync(new FeaturePage(FeatureKind.Calm)); break;
            case "music": await Navigation.PushAsync(new FeaturePage(FeatureKind.Breath)); break;
            case "walk": AppUi.Speak("Als het veilig kan, loop rustig een klein rondje. Vraag hulp als je niet alleen naar buiten kunt."); await DisplayAlertAsync("Een kleine stap", "Als het veilig kan, loop rustig een klein rondje. Vraag hulp als je niet alleen naar buiten kunt.", "OK"); break;
            case "stressball": AppUi.Speak("Pak je stressbal. Knijp rustig een paar keer en voel je voeten op de grond."); await DisplayAlertAsync("Een kleine stap", "Pak je stressbal. Knijp rustig een paar keer en voel je voeten op de grond.", "OK"); break;
            case "talk": await Navigation.PushAsync(new WieWerktErPage()); break;
            default: await Navigation.PushAsync(new FeaturePage(FeatureKind.SafetyPlan)); break;
        }
    }

    async Task SendSignalAsync()
    {
        var plan = AppSession.Store?.Load<SafetyPlan>("plan", Guid.Empty) ?? new SafetyPlan();
        var contact = plan.Contacts.FirstOrDefault(c => !string.IsNullOrWhiteSpace(c.Phone));
        if (contact is null)
        {
            await DisplayAlertAsync("Eerst een contact toevoegen", "Vul bij 'Mijn helpkaart / plan' de naam en het telefoonnummer in van iemand die je vertrouwt.", "Mijn helpkaart openen");
            await Navigation.PushAsync(new FeaturePage(FeatureKind.SafetyPlan)); return;
        }
        const string body = "Hoi, ik heb het nu moeilijk. Kun je contact met mij opnemen?";
        bool proceed = await DisplayAlertAsync("Een seintje voorbereiden", $"Er wordt een sms klaargezet voor {contact.Name}. De app verstuurt niets vanzelf. Je kunt in de Berichten-app zelf nog kiezen om te versturen.", "Sms openen", "Annuleren");
        if (!proceed) return;
        try { await Sms.Default.ComposeAsync(new SmsMessage(body, new[] { contact.Phone })); }
        catch (Exception ex) { AppLog.Write(ex); await DisplayAlertAsync("Sms niet geopend", "Je kunt je contact ook zelf bellen of een bericht sturen.", "OK"); }
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (AppSession.Store is not null) Build();
        AppSession.Touch();
        if (AppSession.Settings.Animations) { Opacity = 0; _ = this.FadeToAsync(1, 180, Easing.CubicOut); }
        if (_consentPrompted || AppSession.Store is null) return;
        if (AppSession.Store.All<ConsentRecord>("consent").Any(c => c.Version >= ConsentInfo.CurrentVersion)) { _consentPrompted = true; return; }
        _consentPrompted = true;
        const string text = "MoodPress is voor jou. Je dagboek, tekeningen, agenda en andere gegevens worden versleuteld op deze telefoon bewaard. Je begeleider ziet alleen wat jij zelf deelt. De app waarschuwt niemand en belt niemand. Je mag je gegevens meenemen of verwijderen. Vraag je begeleider wie verantwoordelijk is voor je gegevens en waar de privacyverklaring staat.";
        await DisplayAlertAsync("Voordat je begint", text, "Ik heb dit gelezen");
        var choice = await DisplayActionSheetAsync("Met wie gebruik je MoodPress?", "Nu niet", null, "Zelf", "Samen met mijn vertegenwoordiger of begeleider");
        if (choice == "Zelf" || choice == "Samen met mijn vertegenwoordiger of begeleider")
        {
            var consent = new ConsentRecord(Guid.NewGuid(), DateTime.Now, ConsentInfo.CurrentVersion, choice == "Zelf" ? "zelf" : "samen");
            AppSession.Store.Save("consent", consent.Id, consent);
        }
        else await ((App)Application.Current!).LockToLoginAsync("Je kunt later toestemming geven door opnieuw in te loggen.");
    }
}
