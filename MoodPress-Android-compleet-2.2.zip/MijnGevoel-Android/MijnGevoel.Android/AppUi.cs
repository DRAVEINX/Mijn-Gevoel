using Microsoft.Maui.ApplicationModel;
using Microsoft.Maui.Controls.Shapes;
using Microsoft.Maui.Media;
namespace MijnGevoel.AndroidApp;

internal static class AppUi
{
    static Page? ActivePage
    {
        get
        {
            var root = Application.Current?.Windows.FirstOrDefault()?.Page;
            return root is NavigationPage navigation
                ? navigation.Navigation.NavigationStack.LastOrDefault() ?? navigation
                : root;
        }
    }

    public static Color Background => AppSession.Settings.Theme switch
    {
        "Hoog contrast" => Colors.Black,
        "Donker" => Color.FromArgb("#030716"),
        _ => Color.FromArgb("#070D22")
    };
    public static Color Surface => AppSession.Settings.Theme switch
    {
        "Hoog contrast" => Colors.Black,
        "Donker" => Color.FromArgb("#0A122B"),
        _ => Color.FromArgb("#0D1B3B")
    };
    public static Color SurfaceRaised => AppSession.Settings.Theme == "Hoog contrast"
        ? Colors.Black : Color.FromArgb("#122852");
    public static Color Foreground => AppSession.Settings.Theme == "Hoog contrast"
        ? Colors.White : Color.FromArgb("#F4F7FF");
    public static Color Muted => AppSession.Settings.Theme == "Hoog contrast"
        ? Colors.White : Color.FromArgb("#A8B9DC");
    public static Color Accent => AppSession.Settings.Theme == "Hoog contrast"
        ? Colors.Yellow : Color.FromArgb("#178BFF");
    public static Color Cyan => Color.FromArgb("#21D4FD");
    public static Color Purple => Color.FromArgb("#7B4DFF");
    public static Color Border => AppSession.Settings.Theme == "Hoog contrast"
        ? Colors.White : Color.FromArgb("#244A88");
    public static double BaseFont => AppSession.Settings.TextSize switch { 0 => 16, 2 => 25, _ => 20 };
    public static double TitleFont => BaseFont * 1.28;
    public static string FontFamily => AppSession.Settings.FontName switch { "Georgia" => "serif", "Standaard" => "sans-serif", _ => "sans-serif" };

    public static void Speak(string text)
    {
        if (AppSession.Settings.ReadAloud && !string.IsNullOrWhiteSpace(text)) TextToSpeech.Default.SpeakAsync(text);
    }

    public static Label Label(string text, bool title = false, bool muted = false)
    {
        return new Label
        {
            Text = text,
            FontSize = title ? TitleFont : BaseFont,
            FontFamily = FontFamily,
            FontAttributes = title ? FontAttributes.Bold : FontAttributes.None,
            TextColor = muted ? Muted : Foreground,
            LineBreakMode = LineBreakMode.WordWrap,
            Margin = new Thickness(0, 2, 0, 2),
            LineHeight = AppSession.Settings.WideLines ? 1.5 : 1.1
        };
    }

    public static View BrandLockup(bool compact = false)
    {
        double markSize = compact ? 58 : 136;
        var brandName = new HorizontalStackLayout
        {
            Spacing = 0,
            HorizontalOptions = LayoutOptions.Center,
            Children =
            {
                new Label { Text = "Mood", FontSize = compact ? 28 : 42, FontAttributes = FontAttributes.Bold, TextColor = Foreground, VerticalTextAlignment = TextAlignment.Center },
                new Label { Text = "Press", FontSize = compact ? 28 : 42, FontAttributes = FontAttributes.Bold, TextColor = Color.FromArgb("#5787FF"), VerticalTextAlignment = TextAlignment.Center }
            }
        };
        var mark = new Image { Source = "moodpress_mark.png", WidthRequest = markSize, HeightRequest = markSize, Aspect = Aspect.AspectFit, HorizontalOptions = LayoutOptions.Center };
        var tagline = new Label
        {
            Text = compact ? "Druk op je gevoel" : "Druk op je gevoel\n\nJouw gevoel.\nJouw verhaal.\nJouw app.",
            FontSize = compact ? 13 : 19,
            TextColor = compact ? Cyan : Muted,
            FontAttributes = compact ? FontAttributes.None : FontAttributes.Italic,
            HorizontalTextAlignment = TextAlignment.Center,
            LineHeight = 1.2
        };
        return new VerticalStackLayout
        {
            Spacing = compact ? 2 : 6,
            HorizontalOptions = LayoutOptions.Center,
            Children = { mark, brandName, tagline }
        };
    }

    public static Entry Entry(string placeholder, string? value = null, Keyboard? keyboard = null, bool password = false)
    {
        var e = new Entry
        {
            Placeholder = placeholder,
            Text = value ?? "",
            FontSize = BaseFont,
            FontFamily = FontFamily,
            TextColor = Foreground,
            PlaceholderColor = Muted,
            BackgroundColor = Surface,
            ClearButtonVisibility = ClearButtonVisibility.WhileEditing,
            IsPassword = password,
            Keyboard = keyboard ?? Keyboard.Default,
            Margin = new Thickness(0, 2, 0, 6)
        };
        e.TextChanged += (_, _) => AppSession.Touch();
        return e;
    }

    public static Editor Editor(string placeholder, string? value = null, int height = 150)
    {
        var e = new Editor
        {
            Placeholder = placeholder,
            Text = value ?? "",
            FontSize = BaseFont,
            FontFamily = FontFamily,
            TextColor = Foreground,
            PlaceholderColor = Muted,
            BackgroundColor = Surface,
            AutoSize = EditorAutoSizeOption.Disabled,
            HeightRequest = height,
            Margin = new Thickness(0, 2, 0, 6)
        };
        e.TextChanged += (_, _) => AppSession.Touch();
        return e;
    }

    public static Button Button(string text, Action action, bool quiet = false, bool danger = false)
    {
        var b = new Button
        {
            Text = text,
            FontSize = BaseFont,
            FontFamily = FontFamily,
            TextColor = danger ? Colors.White : quiet ? Foreground : (AppSession.Settings.Theme == "Hoog contrast" ? Colors.Black : Colors.White),
            BackgroundColor = danger ? Color.FromArgb("#B93360") : quiet ? Surface : Accent,
            BorderColor = danger ? Color.FromArgb("#FF6B9D") : quiet ? Border : Accent,
            BorderWidth = 1,
            CornerRadius = 18,
            Padding = new Thickness(14, 12),
            HorizontalOptions = LayoutOptions.Fill,
            Margin = new Thickness(0, 2, 0, 4)
        };
        b.Clicked += (_, _) =>
        {
            AppSession.Touch();
            try { action(); }
            catch (Exception ex)
            {
                AppLog.Write(ex);
                MainThread.BeginInvokeOnMainThread(async () =>
                {
                    var page = ActivePage;
                    if (page is not null)
                        await page.DisplayAlertAsync("Er ging iets mis", "Deze actie is niet gelukt. Je gegevens zijn niet bewust gedeeld; probeer het opnieuw.", "OK");
                });
            }
        };
        return b;
    }

    public static Button AsyncButton(string text, Func<Task> action, bool quiet = false, bool danger = false)
    {
        var b = new Button
        {
            Text = text,
            FontSize = BaseFont,
            FontFamily = FontFamily,
            TextColor = danger ? Colors.White : quiet ? Foreground : (AppSession.Settings.Theme == "Hoog contrast" ? Colors.Black : Colors.White),
            BackgroundColor = danger ? Color.FromArgb("#B93360") : quiet ? Surface : Accent,
            BorderColor = danger ? Color.FromArgb("#FF6B9D") : quiet ? Border : Accent,
            BorderWidth = 1,
            CornerRadius = 18,
            Padding = new Thickness(14, 12),
            HorizontalOptions = LayoutOptions.Fill,
            Margin = new Thickness(0, 2, 0, 4)
        };
        b.Clicked += async (_, _) =>
        {
            AppSession.Touch(); b.IsEnabled = false;
            try { await action(); }
            catch (Exception ex)
            {
                AppLog.Write(ex);
                var page = ActivePage;
                if (page is not null)
                    await page.DisplayAlertAsync("Er ging iets mis", "De actie is niet gelukt. Controleer je invoer en probeer het opnieuw.", "OK");
            }
            finally { b.IsEnabled = true; }
        };
        return b;
    }

    public static Picker Picker(string title, IEnumerable<string> options, string? selected = null)
    {
        var p = new Picker { Title = title, FontSize = BaseFont, FontFamily = FontFamily, TextColor = Foreground, BackgroundColor = Surface, Margin = new Thickness(0, 2, 0, 6) };
        foreach (var option in options) p.Items.Add(option);
        if (selected is not null)
        {
            int ix = p.Items.IndexOf(selected);
            if (ix >= 0) p.SelectedIndex = ix;
        }
        p.SelectedIndexChanged += (_, _) => AppSession.Touch();
        return p;
    }

    public static VerticalStackLayout Stack(params View[] views)
    {
        var s = new VerticalStackLayout { Spacing = 12, Padding = new Thickness(18, 16), BackgroundColor = Background };
        foreach (var v in views) s.Children.Add(v);
        return s;
    }

    public static Border Card(View child)
    {
        return new Border
        {
            Content = child,
            Stroke = new SolidColorBrush(Border),
            StrokeThickness = 1,
            BackgroundColor = Surface,
            Padding = 14,
            Margin = new Thickness(0, 4),
            StrokeShape = new RoundRectangle { CornerRadius = 20 }
        };
    }

    public static Grid WithBottomNavigation(Page host, View body, string active)
    {
        var layout = new Grid
        {
            BackgroundColor = Background,
            RowSpacing = 0,
            ColumnDefinitions = { new ColumnDefinition(GridLength.Star) },
            RowDefinitions = { new RowDefinition(GridLength.Star), new RowDefinition(GridLength.Auto) }
        };
        layout.Add(body, 0, 0);

        var tabs = new Grid
        {
            Padding = new Thickness(6, 5),
            ColumnSpacing = 4,
            BackgroundColor = Color.FromArgb("#09142C"),
            ColumnDefinitions =
            {
                new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star),
                new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star)
            }
        };
        AddTab(tabs, host, "⌂\nHome", "home", active, null, 0);
        AddTab(tabs, host, "▦\nDag", "day", active, FeatureKind.DayToday, 1);
        AddTab(tabs, host, "♡\nGevoel", "feeling", active, FeatureKind.DailyCheckIn, 2);
        AddTab(tabs, host, "☰\nMeer", "more", active, FeatureKind.Settings, 3);
        layout.Add(tabs, 0, 1);
        Grid.SetRow(tabs, 1);
        return layout;
    }

    static void AddTab(Grid tabs, Page host, string text, string target, string active, FeatureKind? destination, int column)
    {
        var selected = target == active;
        var b = new Button
        {
            Text = text,
            FontSize = 12,
            FontFamily = FontFamily,
            TextColor = selected ? Color.FromArgb("#3DD6FF") : Color.FromArgb("#A8B9DC"),
            BackgroundColor = selected ? Color.FromArgb("#172F69") : Color.FromArgb("#09142C"),
            BorderColor = selected ? Color.FromArgb("#395DF5") : Color.FromArgb("#09142C"),
            BorderWidth = selected ? 1 : 0,
            CornerRadius = 14,
            Padding = new Thickness(3, 5),
            HeightRequest = 54,
            Margin = new Thickness(0)
        };
        b.Clicked += async (_, _) =>
        {
            AppSession.Touch();
            try
            {
                var navigation = host.Navigation;
                var dashboard = navigation.NavigationStack.FirstOrDefault(p => p is DashboardPage);
                if (dashboard is not null)
                {
                    while (navigation.NavigationStack.Count > 0 && navigation.NavigationStack.Last() != dashboard)
                        await navigation.PopAsync(false);
                }
                if (destination is null) return;
                if (destination == FeatureKind.Settings && host is FeaturePage fp && fp.CurrentKind == FeatureKind.Settings)
                    return;
                await navigation.PushAsync(new FeaturePage(destination.Value), false);
            }
            catch (Exception ex) { AppLog.Write(ex); }
        };
        tabs.Add(b, column, 0);
    }

    public static Label Title(string title) => Label(title, title: true);

    public static Label Copyright()
    {
        var label = Label("© 2026 Jordy Ham. Alle rechten voorbehouden.", muted: true);
        label.HorizontalTextAlignment = TextAlignment.Center;
        label.FontSize = Math.Max(12, BaseFont * 0.72);
        label.Margin = new Thickness(0, 14, 0, 8);
        return label;
    }
}
