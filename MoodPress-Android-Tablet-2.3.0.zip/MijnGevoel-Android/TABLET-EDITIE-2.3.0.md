# MoodPress Tablet 2.3.0

Dit is een aparte, tabletvriendelijke build van MoodPress. De bestaande telefoonapp en releasebestanden worden niet gewijzigd.

## Wat is anders?
- Uniek Android-package-id: `nl.mijngevoel.app.tablet`. De tableteditie installeert naast MoodPress op de telefoon en overschrijft die niet.
- App-naam in Android: MoodPress Tablet.
- Adaptieve inhoud gebruikt de beschikbare vensterbreedte; er is geen vast smal telefoonframe.
- Dashboardtegels schakelen tussen twee kolommen op smalle vensters, drie kolommen op compacte/tabletportretvensters en vier kolommen op brede tabletvensters.
- De dagschema-, gevoels- en functietegels gebruiken ruimere marges en grotere aanraakvlakken op tablets.
- Schermrotatie blijft toegestaan. De inhoud gebruikt de hele beschikbare appbreedte zonder de systeemnavigatie bewust te verbergen.

## Belangrijke datagrens
Omdat dit een aparte Android-app is met eigen package-id, heeft hij zijn eigen lokale appopslag. Gegevens worden niet automatisch tussen de telefoonapp en tabletapp gesynchroniseerd. Gebruik de bestaande versleutelde export-/ondersteuningspakketfunctie als je geselecteerde gegevens wilt overzetten.

## Build
Upload `MoodPress-Android-Tablet-2.3.0.zip` naar de hoofdmap van de GitHub-repository. Zet `android-tablet-apk-2.3.0.yml` en `android-tablet-release-2.3.0.yml` in `.github/workflows`. Deze workflowbestanden gebruiken eigen namen en artifactnamen en raken de telefoonworkflows niet.
