# MoodPress Windows — uploadpakket 2.3.0

Dit pakket voegt een **afzonderlijke Windows-buildworkflow** toe. Het wijzigt geen Android-broncode, Android-package-ID's, telefoon-workflows of tablet-workflows.

## Wat de workflow doet

1. Haalt `MoodPress-Android-compleet-2.3.0.zip` uit de hoofdmap van de repository.
2. Zoekt de bestaande `MijnGevoel.Desktop.csproj`, `MijnGevoel.Core.csproj` en `MijnGevoel.Tests.csproj`.
3. Voert de gedeelde regressie-/beveiligingstests uit.
4. Publiceert de Windows-desktopapp voor `win-x64`.
5. Bouwt het bestaande WiX `.wixproj`-installatieproject tot een MSI.
6. Publiceert het MSI-bestand, waar beschikbaar een portable ZIP en SHA-256-checksums als GitHub Actions-artifact.

## Installeren in GitHub

1. Open https://github.com/DRAVEINX/Mijn-Gevoel
2. Ga naar de map `.github/workflows`.
3. Voeg `moodpress-windows-msi-2.3.0.yml` toe aan die map. Laat de vier Android-workflows ongewijzigd.
4. Controleer dat `MoodPress-Android-compleet-2.3.0.zip` in de hoofdmap staat.
5. Open **Actions → MoodPress Windows MSI → Run workflow**.
6. Open na afloop de run en download artifact **MoodPress-Windows-2.3.0**.

## Belangrijk

De workflow bouwt alleen een MSI als het volledige bronarchief de bestaande Windows-desktopprojecten én het bestaande WiX-installerproject bevat. Als die ontbreken, stopt de workflow bewust met een duidelijke foutmelding in plaats van een nep-installatiebestand te maken.

Een groene CI-build bewijst nog niet dat alle functies op een echte Windows-pc werken. Test met testgegevens: aanmelden, 2FA/herstelcodes, automatische vergrendeling, dagboek, agenda/herinneringen, tekenen, export, versleutelde back-up herstellen, account verwijderen en de MSI-installatie/update/verwijdering. Verwijderen van het programma mag persoonlijke gegevens niet wissen.

De Windows-build is x64. De bestaande Android-telefoon-APK en tablet-APK blijven aparte pakketten.
