using UserNotifications;

namespace MijnGevoel.AndroidApp;

/// <summary>Allows MoodPress local routine reminders to be visible while the app is foregrounded.</summary>
internal sealed class MoodPressNotificationDelegate : UNUserNotificationCenterDelegate
{
    public override void WillPresentNotification(
        UNUserNotificationCenter center,
        UNNotification notification,
        Action<UNNotificationPresentationOptions> completionHandler)
    {
        completionHandler(UNNotificationPresentationOptions.Banner |
                          UNNotificationPresentationOptions.List |
                          UNNotificationPresentationOptions.Sound);
    }
}
