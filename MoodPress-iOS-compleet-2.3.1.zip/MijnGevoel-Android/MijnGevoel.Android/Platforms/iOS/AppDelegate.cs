using Microsoft.Maui;
using Microsoft.Maui.Hosting;
using Foundation;
using UIKit;
using UserNotifications;

namespace MijnGevoel.AndroidApp;

[Register("AppDelegate")]
public class AppDelegate : MauiUIApplicationDelegate
{
    static readonly UNUserNotificationCenterDelegate NotificationsDelegate = new MoodPressNotificationDelegate();

    protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();

    public override bool FinishedLaunching(UIApplication application, NSDictionary? launchOptions)
    {
        // Retain the delegate for the lifetime of the process and allow local reminders to show
        // while MoodPress is currently in the foreground.
        UNUserNotificationCenter.Current.Delegate = NotificationsDelegate;
        return base.FinishedLaunching(application, launchOptions);
    }

    public override void OnResignActivation(UIApplication application)
    {
        if (AppSession.Settings.BlockCapture) IOSPrivacyOverlay.Show();
        else IOSPrivacyOverlay.Hide();
        base.OnResignActivation(application);
    }

    public override void OnActivated(UIApplication application)
    {
        base.OnActivated(application);
        IOSPrivacyOverlay.Hide();
    }
}
