using Foundation;
using MijnGevoel.Core.Data;
using Microsoft.Maui.ApplicationModel;
using UserNotifications;

namespace MijnGevoel.AndroidApp;

/// <summary>Plant wekelijkse routineherinneringen via iOS Local Notifications.</summary>
public static class RoutineReminderNotifications
{
    const string Prefix = "moodpress-routine-";
    static readonly SemaphoreSlim SyncGate = new(1, 1);

    public static async Task<bool> EnsurePermissionAsync()
    {
        try
        {
            var center = UNUserNotificationCenter.Current;
            var tcs = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
            center.RequestAuthorization(UNAuthorizationOptions.Alert | UNAuthorizationOptions.Sound | UNAuthorizationOptions.Badge,
                (granted, error) => tcs.TrySetResult(granted && error is null));
            return await tcs.Task;
        }
        catch (Exception ex)
        {
            AppLog.Write(ex);
            return false;
        }
    }

    public static void Sync(IEnumerable<RoutineReminder> reminders)
    {
        var snapshot = reminders?.ToArray() ?? Array.Empty<RoutineReminder>();
        _ = SyncAsync(snapshot);
    }

    static async Task SyncAsync(RoutineReminder[] reminders)
    {
        await SyncGate.WaitAsync();
        try
        {
            var center = UNUserNotificationCenter.Current;
            var oldRequests = await GetPendingRequestsAsync(center);
            center.RemovePendingNotificationRequests(oldRequests
                .Select(x => x.Identifier)
                .Where(x => x.StartsWith(Prefix, StringComparison.Ordinal))
                .ToArray());

            var active = reminders.Where(x => x.Enabled && !string.IsNullOrWhiteSpace(x.Title)
                && TimeOnly.TryParse(x.Time, System.Globalization.CultureInfo.InvariantCulture, out _)
                && x.DaysMask != 0).ToArray();

            // iOS imposes a system limit on pending local notifications. Keep headroom for other notifications.
            const int maxScheduled = 60;
            int count = 0;
            foreach (var item in active)
            {
                if (!TimeOnly.TryParse(item.Time, System.Globalization.CultureInfo.InvariantCulture, out var clock)) continue;
                foreach (DayOfWeek day in Enum.GetValues(typeof(DayOfWeek)))
                {
                    if ((item.DaysMask & (1 << (int)day)) == 0) continue;
                    if (count >= maxScheduled) break;

                    var content = new UNMutableNotificationContent
                    {
                        Title = "MoodPress · herinnering",
                        Body = "Het is tijd voor je geplande routine. Open MoodPress om deze te bekijken.",
                        Sound = item.SoundEnabled ? UNNotificationSound.Default : null
                    };
                    var components = new NSDateComponents
                    {
                        Weekday = (nint)day + 1, // Foundation: Sunday = 1; System.DayOfWeek: Sunday = 0.
                        Hour = clock.Hour,
                        Minute = clock.Minute
                    };
                    var trigger = UNCalendarNotificationTrigger.CreateTrigger(components, true);
                    var identifier = $"{Prefix}{item.Id:N}-{(int)day}";
                    var request = UNNotificationRequest.FromIdentifier(identifier, content, trigger);
                    await AddRequestAsync(center, request);
                    count++;
                }
                if (count >= maxScheduled) break;
            }
        }
        catch (Exception ex)
        {
            AppLog.Write(ex);
        }
        finally
        {
            SyncGate.Release();
        }
    }

    static Task<UNNotificationRequest[]> GetPendingRequestsAsync(UNUserNotificationCenter center)
    {
        var tcs = new TaskCompletionSource<UNNotificationRequest[]>(TaskCreationOptions.RunContinuationsAsynchronously);
        center.GetPendingNotificationRequests(requests => tcs.TrySetResult(requests ?? Array.Empty<UNNotificationRequest>()));
        return tcs.Task;
    }

    static Task AddRequestAsync(UNUserNotificationCenter center, UNNotificationRequest request)
    {
        var tcs = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        center.AddNotificationRequest(request, error => tcs.TrySetResult(error is null));
        return tcs.Task;
    }
}
