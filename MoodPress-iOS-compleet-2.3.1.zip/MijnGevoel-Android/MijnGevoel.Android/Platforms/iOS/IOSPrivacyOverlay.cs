using UIKit;
using Foundation;

namespace MijnGevoel.AndroidApp;

/// <summary>Hides private app contents from the iOS app-switcher preview while MoodPress is inactive.</summary>
internal static class IOSPrivacyOverlay
{
    static UIView? _overlay;

    public static void Show()
    {
        // This only covers the app-switcher snapshot; iOS does not let apps block user screenshots.
        if (!AppSession.Settings.BlockCapture) { Hide(); return; }
        try
        {
            var window = UIApplication.SharedApplication.KeyWindow
                ?? UIApplication.SharedApplication.Windows.FirstOrDefault(x => x.IsKeyWindow);
            if (window is null || _overlay is not null) return;
            var overlay = new UIView(window.Bounds) { BackgroundColor = UIColor.FromRGB(7, 13, 34), AutoresizingMask = UIViewAutoresizing.FlexibleWidth | UIViewAutoresizing.FlexibleHeight };
            var label = new UILabel(overlay.Bounds)
            {
                Text = "MoodPress · privé",
                TextColor = UIColor.White,
                TextAlignment = UITextAlignment.Center,
                Font = UIFont.BoldSystemFontOfSize(22),
                AutoresizingMask = UIViewAutoresizing.FlexibleWidth | UIViewAutoresizing.FlexibleHeight
            };
            overlay.AddSubview(label);
            window.AddSubview(overlay);
            _overlay = overlay;
        }
        catch { /* Privacy cover must never crash app lifecycle. */ }
    }

    public static void Hide()
    {
        try
        {
            _overlay?.RemoveFromSuperview();
            _overlay?.Dispose();
        }
        catch { }
        finally { _overlay = null; }
    }
}
