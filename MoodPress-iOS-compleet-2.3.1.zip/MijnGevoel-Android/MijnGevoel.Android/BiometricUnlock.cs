#if ANDROID
using AndroidX.Biometric;
using AndroidX.Core.Content;
using AndroidX.Fragment.App;
using Microsoft.Maui.ApplicationModel;
#elif IOS
using LocalAuthentication;
#endif

namespace MijnGevoel.AndroidApp;

/// <summary>Platformeigen biometrische ontgrendeling. Bij annuleren blijft gewone login beschikbaar.</summary>
internal static class BiometricUnlock
{
    public static async Task<bool> AuthenticateAsync(string title = "Ontgrendel MoodPress")
    {
#if ANDROID
        var activity = Platform.CurrentActivity as FragmentActivity;
        if (activity is null) return false;

        var result = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        try
        {
            var executor = ContextCompat.GetMainExecutor(activity);
            if (executor is null) return false;
            _activeCallback = new Callback(result);
            _activePrompt = new BiometricPrompt(activity, executor, _activeCallback);
            var promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .SetTitle(title)
                .SetSubtitle("Gebruik de vingerafdruk of gezichtsherkenning van je telefoon")
                .SetNegativeButtonText("Gebruik wachtwoord")
                .SetAllowedAuthenticators(0x00FF)
                .Build();
            _activePrompt.Authenticate(promptInfo);
            return await result.Task;
        }
        catch (Exception ex)
        {
            AppLog.Write(ex);
            return false;
        }
        finally
        {
            _activePrompt = null;
            _activeCallback = null;
        }
#elif IOS
        try
        {
            using var context = new LAContext();
            if (!context.CanEvaluatePolicy(LAPolicy.DeviceOwnerAuthenticationWithBiometrics, out var error))
            {
                error?.Dispose();
                return false;
            }
            error?.Dispose();
            var result = await context.EvaluatePolicyAsync(LAPolicy.DeviceOwnerAuthenticationWithBiometrics, title);
            return result.Item1;
        }
        catch (Exception ex)
        {
            AppLog.Write(ex);
            return false;
        }
#else
        await Task.CompletedTask;
        return false;
#endif
    }

#if ANDROID
    static BiometricPrompt? _activePrompt;
    static Callback? _activeCallback;

    sealed class Callback(TaskCompletionSource<bool> result) : BiometricPrompt.AuthenticationCallback
    {
        public override void OnAuthenticationSucceeded(BiometricPrompt.AuthenticationResult authenticationResult)
            => result.TrySetResult(true);

        public override void OnAuthenticationError(int errorCode, Java.Lang.ICharSequence errString)
            => result.TrySetResult(false);

        public override void OnAuthenticationFailed() { }
    }
#endif
}

