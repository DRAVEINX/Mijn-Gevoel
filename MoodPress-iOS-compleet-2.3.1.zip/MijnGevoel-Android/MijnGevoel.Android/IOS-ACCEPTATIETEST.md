# MoodPress iOS 2.3.1 — acceptatietest

Voer deze test pas uit nadat de iOS Simulator-build groen is; herhaal waar nodig op een echte iPhone en iPad. Gebruik uitsluitend een testaccount en testgegevens.

## Installatie en account
- [ ] Schone installatie start zonder crash; naam, splashscreen en app-icoon zien er goed uit.
- [ ] Account maken, QR-code tonen, TOTP-account bevestigen en normaal inloggen.
- [ ] Verkeerd wachtwoord en verkeerde authenticatorcode worden veilig afgewezen.
- [ ] App sluiten/openen, vergrendelen, uitloggen en opnieuw aanmelden.
- [ ] Face ID/Touch ID werkt wanneer beschikbaar; annuleren of weigeren laat gewone login bruikbaar.
- [ ] Verwijder de app en installeer opnieuw; een oude Keychain-sessie mag niet een lege account openen.

## Functies
- [ ] Gevoelscheck-in, dagboek, notities, agenda, routines, timer en ademhalingsoefening.
- [ ] Lokale herinneringen voor één en meerdere weekdagen; toestemming toestaan/weigeren; tijdstip en geluid controleren.
- [ ] Tekenen: meerdere kleuren en pendiktes, wissen, ongedaan maken, bewaren, openen en PNG-export.
- [ ] Spraaknotitie: microfoontoestemming, opnemen, afspelen, verwijderen en app naar achtergrond brengen.
- [ ] Begeleiderfoto kiezen (ook een recente iPhone-foto), verkleinen, bewaren, weergeven en verwijderen.
- [ ] Export, versleutelde back-up, herstellen vanaf back-up en accountverwijdering.
- [ ] Toegankelijkheid: grote tekst, VoiceOver, hoog contrast, staand/liggend en kleine schermen.

## Privacy en gegevens
- [ ] Privévoorbeeld-bedekking verschijnt in de appwisselaar als de instelling aan staat en niet als deze uit staat.
- [ ] Leg vast dat screenshots die de gebruiker zelf maakt niet door iOS geblokkeerd kunnen worden.
- [ ] Gegevens zijn uitsluitend lokaal tenzij de gebruiker expliciet deelt/exporteert. Controleer dat delen alleen de geselecteerde gegevens bevat.
- [ ] Import/back-up vanaf Android testen met testgegevens; niets overschrijven zonder bevestiging.
- [ ] Wachtwoord wijzigen, herstelcodes en definitieve account-/gegevensverwijdering opnieuw testen.

## Resultaat
Noteer iPhone/iPad-model, iOS-versie, build-commit, geslaagd/mislukt per regel en reproduceerstappen bij elke fout. Geef geen productie-vrijgave alleen op basis van een groene simulatorbuild.
