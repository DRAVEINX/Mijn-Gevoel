using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using MijnGevoel.Core.Data;
using Microsoft.Maui.Media;
using Microsoft.Maui.Storage;

namespace MijnGevoel.AndroidApp;

/// <summary>Een begeleiderprofiel. Foto's worden verkleind en alleen in de versleutelde lokale kluis bewaard.</summary>
public sealed class WhoWorksCaregiver
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = "";
    public string? PhotoBase64 { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public DateTime UpdatedAt { get; set; } = DateTime.Now;
}

/// <summary>Rooster per echte kalenderweek. Zo kunnen diensten elke week verschillen.</summary>
public sealed class WhoWorksWeek
{
    public Guid Id { get; set; }
    public DateTime WeekStart { get; set; }
    public Dictionary<string, List<Guid>> Assignments { get; set; } = new();
    public DateTime UpdatedAt { get; set; } = DateTime.Now;
}

/// <summary>
/// Beheer van begeleiders en het wekelijkse rooster. Alles wordt via VaultStore versleuteld
/// opgeslagen op het huidige toestel; er wordt niets naar een server verstuurd.
/// </summary>
public sealed class WieWerktErPage : ContentPage
{
    const string CaregiverKind = "who-works-caregiver";
    const string WeekKind = "who-works-week";
    static readonly CultureInfo Dutch = CultureInfo.GetCultureInfo("nl-NL");

    DateTime _weekStart;
    List<WhoWorksCaregiver> _caregivers = new();
    WhoWorksWeek _week = new();
    VerticalStackLayout? _todaySummary;

    VaultStore Store => AppSession.Store ?? throw new InvalidOperationException("Log eerst in om het rooster te openen.");

    public WieWerktErPage()
    {
        Title = "Wie werkt er?";
        BackgroundColor = AppUi.Background;
        _weekStart = StartOfWeek(DateTime.Today);
        ReloadData();
        Build();
        ToolbarItems.Add(new ToolbarItem("🙈 Scherm verbergen", null, async () => await Navigation.PushAsync(new PrivacyCoverPage())));
        ToolbarItems.Add(new ToolbarItem("🔒 Vergrendel", null, async () => await ((App)Application.Current!).LockToLoginAsync()));
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        AppSession.Touch();
        ReloadData();
        Build();
    }

    static DateTime StartOfWeek(DateTime date)
    {
        int daysSinceMonday = ((int)date.DayOfWeek + 6) % 7;
        return date.Date.AddDays(-daysSinceMonday);
    }

    static string DateKey(DateTime date) => date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);

    static Guid WeekId(DateTime monday)
    {
        byte[] hash = SHA256.HashData(Encoding.UTF8.GetBytes($"{AppSession.Username}|who-works|{DateKey(monday)}"));
        return new Guid(hash.AsSpan(0, 16));
    }

    void ReloadData()
    {
        _caregivers = Store.All<WhoWorksCaregiver>(CaregiverKind)
            .Where(c => c.Id != Guid.Empty && !string.IsNullOrWhiteSpace(c.Name))
            .OrderBy(c => c.Name, StringComparer.CurrentCultureIgnoreCase)
            .ToList();

        Guid id = WeekId(_weekStart);
        _week = Store.Load<WhoWorksWeek>(WeekKind, id) ?? new WhoWorksWeek
        {
            Id = id,
            WeekStart = _weekStart,
            Assignments = new Dictionary<string, List<Guid>>(),
            UpdatedAt = DateTime.Now
        };
        _week.Assignments ??= new Dictionary<string, List<Guid>>();
        _week.WeekStart = _weekStart;
    }

    void PersistWeek()
    {
        _week.Id = WeekId(_weekStart);
        _week.WeekStart = _weekStart;
        _week.UpdatedAt = DateTime.Now;
        Store.Save(WeekKind, _week.Id, _week);
        AppSession.Touch();
    }

    void Build()
    {
        var root = new VerticalStackLayout
        {
            Padding = new Thickness(16),
            Spacing = 10,
            BackgroundColor = AppUi.Background
        };
        root.Children.Add(AppUi.Title("Wie werkt er?"));
        root.Children.Add(AppUi.Label("Bekijk met één druk wie er vandaag werkt. Voeg begeleiders toe en vink per dag aan wie is ingepland. Je kunt het rooster iedere week aanpassen."));
        root.Children.Add(AppUi.Label("Privacy: namen en foto's worden versleuteld op dit toestel bewaard. Voeg alleen een foto toe als je daar toestemming voor hebt.", muted: true));

        root.Children.Add(AppUi.Title("Vandaag"));
        _todaySummary = new VerticalStackLayout { Spacing = 8 };
        root.Children.Add(AppUi.Card(_todaySummary));
        RenderTodaySummary();

        root.Children.Add(AppUi.AsyncButton("➕ Begeleider toevoegen", AddCaregiverAsync));

        root.Children.Add(AppUi.Title($"Weekrooster · {_weekStart.ToString("d MMM", Dutch)} – {_weekStart.AddDays(6).ToString("d MMM yyyy", Dutch)}"));
        var navigation = new Grid
        {
            ColumnDefinitions =
            {
                new ColumnDefinition(GridLength.Star),
                new ColumnDefinition(GridLength.Star),
                new ColumnDefinition(GridLength.Star)
            },
            ColumnSpacing = 6
        };
        var previous = AppUi.Button("← Vorige", () => ChangeWeek(-1), quiet: true);
        var current = AppUi.Button("Deze week", () => ChangeToCurrentWeek(), quiet: true);
        var next = AppUi.Button("Volgende →", () => ChangeWeek(1), quiet: true);
        Grid.SetColumn(previous, 0); Grid.SetColumn(current, 1); Grid.SetColumn(next, 2);
        navigation.Children.Add(previous); navigation.Children.Add(current); navigation.Children.Add(next);
        root.Children.Add(navigation);
        root.Children.Add(AppUi.Label("Vink aan wie op welke dag werkt. Elke wijziging wordt direct opgeslagen.", muted: true));

        for (int i = 0; i < 7; i++)
        {
            DateTime day = _weekStart.AddDays(i);
            var dayContent = new VerticalStackLayout { Spacing = 8 };
            string dayName = Dutch.TextInfo.ToTitleCase(day.ToString("dddd", Dutch));
            string suffix = day.Date == DateTime.Today ? " · Vandaag" : "";
            dayContent.Children.Add(AppUi.Label($"{dayName} {day.ToString("d MMMM", Dutch)}{suffix}", title: true));

            if (_caregivers.Count == 0)
            {
                dayContent.Children.Add(AppUi.Label("Voeg eerst een begeleider toe om het rooster in te vullen.", muted: true));
            }
            else
            {
                string key = DateKey(day);
                _week.Assignments.TryGetValue(key, out var assignedIds);
                assignedIds ??= new List<Guid>();
                foreach (var caregiver in _caregivers)
                {
                    bool isAssigned = assignedIds.Contains(caregiver.Id);
                    var check = new CheckBox
                    {
                        IsChecked = isAssigned,
                        Color = AppUi.Accent,
                        VerticalOptions = LayoutOptions.Center
                    };
                    check.CheckedChanged += (_, e) => UpdateAssignment(day, caregiver.Id, e.Value);
                    var row = new HorizontalStackLayout
                    {
                        Spacing = 10,
                        VerticalOptions = LayoutOptions.Center
                    };
                    row.Children.Add(check);
                    row.Children.Add(CreateAvatar(caregiver, 44));
                    var name = AppUi.Label(caregiver.Name);
                    name.VerticalTextAlignment = TextAlignment.Center;
                    row.Children.Add(name);
                    dayContent.Children.Add(row);
                }
            }
            root.Children.Add(AppUi.Card(dayContent));
        }

        root.Children.Add(AppUi.Title("Begeleiders beheren"));
        root.Children.Add(AppUi.Label("Pas namen aan, voeg een foto toe of verwijder een begeleider. Verwijderen haalt die begeleider ook uit de roosters."));
        if (_caregivers.Count == 0)
        {
            root.Children.Add(AppUi.Card(new VerticalStackLayout
            {
                Spacing = 6,
                Children =
                {
                    AppUi.Label("Je hebt nog geen begeleiders toegevoegd."),
                    AppUi.Label("Tik op ‘Begeleider toevoegen’ om te beginnen.", muted: true)
                }
            }));
        }
        else
        {
            foreach (var caregiver in _caregivers)
                root.Children.Add(BuildCaregiverCard(caregiver));
        }

        Content = new ScrollView { Content = root };
    }

    View BuildCaregiverCard(WhoWorksCaregiver caregiver)
    {
        var card = new VerticalStackLayout { Spacing = 8 };
        var heading = new HorizontalStackLayout { Spacing = 12, VerticalOptions = LayoutOptions.Center };
        heading.Children.Add(CreateAvatar(caregiver, 68));
        var namePanel = new VerticalStackLayout { Spacing = 2, VerticalOptions = LayoutOptions.Center };
        namePanel.Children.Add(AppUi.Label(caregiver.Name, title: true));
        namePanel.Children.Add(AppUi.Label(string.IsNullOrWhiteSpace(caregiver.PhotoBase64) ? "Nog geen foto" : "Foto toegevoegd", muted: true));
        heading.Children.Add(namePanel);
        card.Children.Add(heading);
        card.Children.Add(AppUi.AsyncButton("📷 Foto toevoegen of wijzigen", () => PickPhotoAsync(caregiver.Id), quiet: true));
        if (!string.IsNullOrWhiteSpace(caregiver.PhotoBase64))
            card.Children.Add(AppUi.AsyncButton("🗑️ Alleen foto verwijderen", () => RemovePhotoAsync(caregiver.Id), quiet: true));
        card.Children.Add(AppUi.AsyncButton("✏️ Naam wijzigen", () => RenameCaregiverAsync(caregiver.Id), quiet: true));
        card.Children.Add(AppUi.AsyncButton("Verwijderen", () => DeleteCaregiverAsync(caregiver.Id), quiet: true, danger: true));
        return AppUi.Card(card);
    }

    View CreateAvatar(WhoWorksCaregiver caregiver, double size)
    {
        if (!string.IsNullOrWhiteSpace(caregiver.PhotoBase64))
        {
            try
            {
                byte[] bytes = Convert.FromBase64String(caregiver.PhotoBase64);
                return new Image
                {
                    Source = ImageSource.FromStream(() => new MemoryStream(bytes)),
                    WidthRequest = size,
                    HeightRequest = size,
                    Aspect = Aspect.AspectFill,
                    BackgroundColor = AppUi.Surface,
                    VerticalOptions = LayoutOptions.Center
                };
            }
            catch { /* Toon een neutrale avatar als een oude foto niet kan worden gelezen. */ }
        }

        return new Border
        {
            WidthRequest = size,
            HeightRequest = size,
            BackgroundColor = AppUi.Surface,
            Stroke = new SolidColorBrush(AppUi.Border),
            StrokeThickness = 1,
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = 12 },
            Content = new Label
            {
                Text = "👤",
                FontSize = size * 0.48,
                HorizontalTextAlignment = TextAlignment.Center,
                VerticalTextAlignment = TextAlignment.Center,
                HorizontalOptions = LayoutOptions.Fill,
                VerticalOptions = LayoutOptions.Fill,
                TextColor = AppUi.Foreground
            }
        };
    }

    void RenderTodaySummary()
    {
        if (_todaySummary is null) return;
        _todaySummary.Children.Clear();
        if (_weekStart != StartOfWeek(DateTime.Today))
        {
            // Het scherm mag op een andere week staan; de bovenste kaart blijft bewust de echte dag tonen.
            var todayId = WeekId(StartOfWeek(DateTime.Today));
            var todayWeek = Store.Load<WhoWorksWeek>(WeekKind, todayId);
            var todayIds = new List<Guid>();
            if (todayWeek is not null && todayWeek.Assignments is not null &&
                todayWeek.Assignments.TryGetValue(DateKey(DateTime.Today), out var savedIds))
                todayIds = savedIds;
            AddTodayProfiles(_caregivers.Where(c => todayIds.Contains(c.Id)).ToList());
            return;
        }
        _week.Assignments.TryGetValue(DateKey(DateTime.Today), out var assignedIds);
        assignedIds ??= new List<Guid>();
        AddTodayProfiles(_caregivers.Where(c => assignedIds.Contains(c.Id)).ToList());
    }

    void AddTodayProfiles(IReadOnlyCollection<WhoWorksCaregiver> profiles)
    {
        if (profiles.Count == 0)
        {
            _todaySummary!.Children.Add(AppUi.Label("Nog niemand ingevuld voor vandaag. Vul hieronder het rooster in."));
            return;
        }
        foreach (var caregiver in profiles)
        {
            var row = new HorizontalStackLayout { Spacing = 10, VerticalOptions = LayoutOptions.Center };
            row.Children.Add(CreateAvatar(caregiver, 56));
            var name = AppUi.Label(caregiver.Name, title: true);
            name.VerticalTextAlignment = TextAlignment.Center;
            row.Children.Add(name);
            _todaySummary!.Children.Add(row);
        }
    }

    void UpdateAssignment(DateTime day, Guid caregiverId, bool isAssigned)
    {
        try
        {
            string key = DateKey(day);
            if (!_week.Assignments.TryGetValue(key, out var ids))
            {
                ids = new List<Guid>();
                _week.Assignments[key] = ids;
            }
            if (isAssigned)
            {
                if (!ids.Contains(caregiverId)) ids.Add(caregiverId);
            }
            else
            {
                ids.Remove(caregiverId);
                if (ids.Count == 0) _week.Assignments.Remove(key);
            }
            PersistWeek();
            RenderTodaySummary();
        }
        catch
        {
            MainThread.BeginInvokeOnMainThread(async () => await DisplayAlertAsync("Niet opgeslagen", "De wijziging is niet opgeslagen. Probeer het opnieuw.", "OK"));
        }
    }

    async Task AddCaregiverAsync()
    {
        string? name = await DisplayPromptAsync("Begeleider toevoegen", "Vul de naam in:", "Opslaan", "Annuleren", maxLength: 80, keyboard: Keyboard.Default);
        if (string.IsNullOrWhiteSpace(name)) return;
        name = name.Trim();
        var caregiver = new WhoWorksCaregiver { Id = Guid.NewGuid(), Name = name, CreatedAt = DateTime.Now, UpdatedAt = DateTime.Now };
        Store.Save(CaregiverKind, caregiver.Id, caregiver);
        ReloadData();
        Build();
        var answer = await DisplayActionSheetAsync($"Wil je een foto toevoegen aan {name}?", "Later", null, "Foto kiezen");
        if (answer == "Foto kiezen") await PickPhotoAsync(caregiver.Id);
    }

    async Task RenameCaregiverAsync(Guid id)
    {
        var caregiver = _caregivers.FirstOrDefault(c => c.Id == id);
        if (caregiver is null) return;
        string? name = await DisplayPromptAsync("Naam wijzigen", "Vul de nieuwe naam in:", "Opslaan", "Annuleren", maxLength: 80, initialValue: caregiver.Name);
        if (string.IsNullOrWhiteSpace(name)) return;
        caregiver.Name = name.Trim();
        caregiver.UpdatedAt = DateTime.Now;
        Store.Save(CaregiverKind, caregiver.Id, caregiver);
        ReloadData();
        Build();
    }

    async Task PickPhotoAsync(Guid id)
    {
        var caregiver = _caregivers.FirstOrDefault(c => c.Id == id);
        if (caregiver is null) return;
        var pickedPhotos = await MediaPicker.Default.PickPhotosAsync(new MediaPickerOptions
        {
            Title = "Kies een foto van de begeleider",
            SelectionLimit = 1,
            MaximumWidth = 1024,
            MaximumHeight = 1024,
            CompressionQuality = 85,
            RotateImage = true,
            PreserveMetaData = false
        });
        FileResult? picked = pickedPhotos.FirstOrDefault();
        if (picked is null) return;

        byte[] compressedBytes;
        await using (var input = await picked.OpenReadAsync())
        using (var original = Android.Graphics.BitmapFactory.DecodeStream(input))
        {
            if (original is null)
            {
                await DisplayAlertAsync("Foto niet gelezen", "Kies een gewone JPG- of PNG-foto en probeer het opnieuw.", "OK");
                return;
            }

            const int maxDimension = 512;
            double ratio = Math.Min(1d, (double)maxDimension / Math.Max(original.Width, original.Height));
            int width = Math.Max(1, (int)Math.Round(original.Width * ratio));
            int height = Math.Max(1, (int)Math.Round(original.Height * ratio));
            using var output = new MemoryStream();
            bool compressed;
            if (width == original.Width && height == original.Height)
            {
                compressed = original.Compress(Android.Graphics.Bitmap.CompressFormat.Jpeg!, 78, output);
            }
            else
            {
                using var scaled = Android.Graphics.Bitmap.CreateScaledBitmap(original, width, height, true);
                compressed = scaled.Compress(Android.Graphics.Bitmap.CompressFormat.Jpeg!, 78, output);
            }
            if (!compressed)
            {
                await DisplayAlertAsync("Foto niet opgeslagen", "De foto kon niet worden verkleind. Probeer een andere foto.", "OK");
                return;
            }
            compressedBytes = output.ToArray();
        }

        caregiver.PhotoBase64 = Convert.ToBase64String(compressedBytes);
        caregiver.UpdatedAt = DateTime.Now;
        Store.Save(CaregiverKind, caregiver.Id, caregiver);
        ReloadData();
        Build();
        await DisplayAlertAsync("Foto opgeslagen", "De foto is verkleind en versleuteld op dit toestel opgeslagen.", "OK");
    }

    async Task RemovePhotoAsync(Guid id)
    {
        var caregiver = _caregivers.FirstOrDefault(c => c.Id == id);
        if (caregiver is null || string.IsNullOrWhiteSpace(caregiver.PhotoBase64)) return;
        bool confirm = await DisplayAlertAsync("Foto verwijderen", $"Wil je alleen de foto van {caregiver.Name} verwijderen? De naam en het rooster blijven staan.", "Foto verwijderen", "Annuleren");
        if (!confirm) return;
        caregiver.PhotoBase64 = null;
        caregiver.UpdatedAt = DateTime.Now;
        Store.Save(CaregiverKind, caregiver.Id, caregiver);
        ReloadData();
        Build();
    }

    async Task DeleteCaregiverAsync(Guid id)
    {
        var caregiver = _caregivers.FirstOrDefault(c => c.Id == id);
        if (caregiver is null) return;
        bool confirm = await DisplayAlertAsync("Begeleider verwijderen", $"Wil je {caregiver.Name} en de foto verwijderen? Deze persoon wordt ook uit alle opgeslagen weekroosters gehaald.", "Verwijderen", "Annuleren");
        if (!confirm) return;

        Store.Delete(CaregiverKind, caregiver.Id);
        foreach (var roster in Store.All<WhoWorksWeek>(WeekKind))
        {
            bool changed = false;
            roster.Assignments ??= new Dictionary<string, List<Guid>>();
            foreach (var key in roster.Assignments.Keys.ToList())
            {
                var ids = roster.Assignments[key];
                if (ids.Remove(id)) changed = true;
                if (ids.Count == 0) roster.Assignments.Remove(key);
            }
            if (changed) Store.Save(WeekKind, roster.Id, roster);
        }
        ReloadData();
        Build();
    }

    void ChangeWeek(int weeks)
    {
        _weekStart = _weekStart.AddDays(weeks * 7).Date;
        ReloadData();
        Build();
    }

    void ChangeToCurrentWeek()
    {
        _weekStart = StartOfWeek(DateTime.Today);
        ReloadData();
        Build();
    }
}
