# Nieuwe functie: Wie werkt er? (Mijn Gevoel 1.0.6)

## Wat doet het?

- Op het beginscherm staat de knop **Wie werkt er?**.
- De bovenste kaart toont wie er voor vandaag is ingepland.
- Voeg begeleiders toe met een naam en optioneel een foto uit de fotogalerij.
- Vink per dag van een gekozen week aan wie er werkt. De planning wordt direct opgeslagen; gebruik Vorige/Volgende om andere weken te beheren.
- Een begeleidersfoto kan worden gewijzigd of apart verwijderd. Een begeleider verwijderen haalt die persoon ook uit alle opgeslagen roosters.
- Namen, foto's en roosters worden via de bestaande versleutelde lokale kluis van Mijn Gevoel opgeslagen. Er wordt niets naar een server gestuurd.

## Gebruik

1. Open Mijn Gevoel en tik op **Wie werkt er?**.
2. Tik op **Begeleider toevoegen**, vul de naam in en kies desgewenst een foto.
3. Vink in het weekrooster de begeleiders aan die op elke dag werken.
4. Open de functie later opnieuw om met één druk de planning van vandaag te bekijken.
5. Gebruik **Vorige** en **Volgende** om de planning voor andere weken te bekijken en te wijzigen.

## Privacy

Voeg alleen foto's toe met toestemming van de persoon op de foto of de bevoegde vertegenwoordiger. Gegevens zijn alleen beschikbaar in de ingelogde lokale appkluis op dit toestel. Het rooster wordt niet automatisch bijgewerkt vanuit een zorgorganisatie; iemand moet de veranderingen handmatig invoeren. Verwijder geen bestaande app-installatie zonder back-up, want gegevens kunnen dan verloren gaan.
