# LVB-vriendelijke functies en beveiligde toegang (Android 1.0.7)

## Directe, visuele invoer

- Het beginscherm toont vier grote keuzes: Blij, Bedroefd, Boos en Bang.
- De gekozen stemming wordt privé en versleuteld opgeslagen.
- Bij een moeilijk gevoel verschijnen alleen de acties die in Mijn plan zijn aangevinkt. Als er nog niets is ingesteld, verschijnt een eenvoudige veilige basisset.

## Hulp en delen

- De cliënt kan via Mijn plan een contact met telefoonnummer instellen.
- “Een seintje voorbereiden” vraagt om bevestiging en opent vervolgens de sms-app. Mijn Gevoel verstuurt zelf geen sms, en waarschuwt geen begeleider automatisch.
- De cliënt kan in “Wie werkt er?” de naam en de optionele foto van begeleiders zien. Foto’s en roosters zijn lokaal en versleuteld.

## Voorlezen en spraaknotities

- Uitleg bij functies kan worden voorgelezen met de knop bovenaan een scherm; deze knop volgt de instelling “Voorlezen beschikbaar maken”.
- In Dagboek en Van me afschrijven kunnen korte spraaknotities van maximaal 60 seconden worden opgenomen, teruggeluisterd en verwijderd.
- Spraakopnames blijven lokaal in de versleutelde kluis. Ze worden niet automatisch gedeeld. Een leesbare JSON-export bevat ook de spraaknotities en is niet versleuteld; de app waarschuwt de gebruiker vóór export.
- WAV/PCM-opname is gekozen voor compatibiliteit met oudere Android-versies. De microfoon wordt alleen na gebruikersactie en toestemming gebruikt.

## Ademhalen en rustige interface

- De ademhalingshulp toont een cirkel die bij in- en uitademen groter en kleiner wordt, een aftelling, en optionele lokale achtergrondmuziek.
- De app maakt geen onverwachte agenda-pop-upvensters; geplande activiteiten staan in de agenda en het weekoverzicht.
- Er blijft een automatische sessievergrendeling instelbaar. “Ingelogd blijven” is optioneel. Na vergrendeling vraagt de app om telefoonbiometrie als die beschikbaar is; anders blijft reguliere login beschikbaar.

## Biometrie en privacy

- Alleen de reeds geverifieerde kluissleutel wordt via Android SecureStorage bewaard; wachtwoord en authenticatorcode worden niet bewaard.
- De beveiligde opslag wordt pas hersteld nadat de systeem-prompt voor biometrie geslaagd is.
- Deze implementatie voegt een appniveau biometrische toegangspoort toe, maar bindt de opgeslagen sleutel niet cryptografisch rechtstreeks aan een biometrische hardware-sleutel. Zet “ingelogd blijven” daarom alleen aan op een eigen toestel met schermvergrendeling.
- Uitloggen en sessie vergeten, wachtwoord wijzigen en account verwijderen wissen de opgeslagen herstelsessie.

## Rapportage en toekomstige uitbreidingen

Deze versie gebruikt een eenvoudig weekoverzicht met kleurblokken en kan een tekstoverzicht delen na een expliciete handeling. Een opgemaakt PDF-rapport, eigen avatars en een formele zorgorganisatie-synchronisatie zijn niet in deze update opgenomen. Voor synchronisatie is expliciete toestemming, toegangsbeheer en een apart beveiligd serverontwerp nodig.
