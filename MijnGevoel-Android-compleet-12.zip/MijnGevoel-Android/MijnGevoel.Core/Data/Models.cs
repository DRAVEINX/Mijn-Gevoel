namespace MijnGevoel.Core.Data;

/// <summary>Dagboek (Mood 1-5, 0 = geen) en "van me afschrijven"-briefjes.</summary>
public record JournalEntry(Guid Id, DateTime Created, int Mood, string Text);
/// <summary>De vier herkenbare gevoelens voor snelle, visuele invoer.</summary>
public record FourGFeelingEntry(Guid Id, DateTime Created, string Feeling);
/// <summary>Een korte gesproken notitie; AudioData wordt uitsluitend binnen de versleutelde VaultStore bewaard.</summary>
public record VoiceNoteEntry(Guid Id, DateTime Created, string Context, byte[] AudioData);
public record DrawingEntry(Guid Id, DateTime Created, string Title, byte[] Isf, byte[] Png);
public record AgendaItem(Guid Id, DateTime Date, string Time, string Title, string Icon, bool Done);

public class UserSettings
{
    public int TextSize { get; set; } = 1;            // 0 normaal, 1 groot, 2 extra groot
    public string Theme { get; set; } = "Rustig";     // Rustig, Donker, Hoog contrast
    public int AutoLockMinutes { get; set; } = 5;
    public bool ReadAloud { get; set; } = true;
    public bool Animations { get; set; } = true;
    public string FontName { get; set; } = "Standaard";   // Standaard, Verdana, Arial, Georgia
    public bool WideLines { get; set; }                  // ruime regelafstand
    public bool BlockCapture { get; set; }               // schermopname/screenshot van het venster blokkeren
    public bool RoutinesSeeded { get; set; }
}

/// <summary>Stoplicht: Colour = Groen | Oranje | Rood. Reasons/Needs zijn de gekozen pictogram-teksten.</summary>
public record StoplichtEntry(Guid Id, DateTime Created, string Colour, string[] Reasons, string[] Needs, string Text);
public record ContactPerson(string Name, string Phone);
public class SafetyPlan
{
    public List<ContactPerson> Contacts { get; set; } = new();
    public string Helps { get; set; } = "";
    /// <summary>Vooraf gekozen, concrete helpstappen. Oude bestanden zonder dit veld blijven geldig.</summary>
    public List<string> HelpOptions { get; set; } = new();
}
public record ShareLogEntry(Guid Id, DateTime Created, int Count);

/// <summary>Toestemming van de cliënt voor het gebruik van de app (Mode: "zelf" of "samen" met een vertegenwoordiger/begeleider).</summary>
public record ConsentRecord(Guid Id, DateTime Created, int Version, string Mode);
public static class ConsentInfo { public const int CurrentVersion = 1; }

/// <summary>Stappenplan (routine): een titel, een plaatje en stappen.</summary>
public record Routine(Guid Id, string Title, string Icon, string[] Steps);
/// <summary>Prikkelmeter en lichaam: Kind = Hoofd | Omgeving | Lichaam. Bij Lichaam is Note bijvoorbeeld "Buik: spanning".</summary>
public record ScaleEntry(Guid Id, DateTime Created, string Kind, int Level, string Note);
/// <summary>Eigen kaart om te laten zien ("Ik wil even rust").</summary>
public record TalkCard(Guid Id, string Emoji, string Text);
/// <summary>Gesprekskaart: voorbereiden wat je wilt zeggen.</summary>
public class TalkPrep { public string Tell { get; set; } = ""; public string Ask { get; set; } = ""; public string Want { get; set; } = ""; }
