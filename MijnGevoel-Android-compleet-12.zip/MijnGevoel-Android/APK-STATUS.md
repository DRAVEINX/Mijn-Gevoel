# Status APK-build — Mijn Gevoel

## Eerlijke status

In deze werkomgeving is geen .NET SDK, MAUI Android-workload, Android SDK of Gradle aanwezig. De netwerkverbinding kan de benodigde SDK niet downloaden. Daardoor kon hier geen APK worden gecompileerd of op een Android-apparaat worden getest. De bestanden in dit pakket zijn dus **broncode**, geen kant-en-klare APK. Het lokale bouwscript is geprobeerd en stopt direct met exitcode 2 doordat `dotnet` ontbreekt; er is in deze map geen `.apk` aangetroffen.

## Wat wél gecontroleerd is

De projectbestanden, XAML, manifesten en SVG-bestanden zijn als XML geparseerd; alle 35 C#-bestanden zijn op gebalanceerde blok-/haakstructuur gecontroleerd; de workflow-YAML is syntactisch geparseerd; en de 25 dashboardfuncties zijn nagelopen op afhandeling in de mobiele interface. Dit zijn statische controles, géén vervanging voor compileren, uitvoeren of testen op een telefoon. De C#-compiler en de beveiligingstests konden hier niet draaien.

## APK laten bouwen

1. Plaats de volledige inhoud van deze projectmap in een GitHub-repository.
2. Open **Actions** en kies **Mijn Gevoel Android APK**.
3. Klik op **Run workflow** en wacht tot de workflow groen is.
4. Open de geslaagde workflowrun en download het artifact `MijnGevoel-Android-debug-apk`.
5. Controleer de checksum met `SHA256SUMS.txt` en installeer de APK op een testtelefoon.

Je kunt lokaal bouwen op een machine met .NET 8, de MAUI Android-workload, Java 17 en de Android SDK door `scripts/build-android.sh` uit te voeren.

## Wanneer is de app echt klaar?

Een geslaagde compileeractie is slechts de eerste stap. Voer daarna ook de acceptatietest uit in `ANDROID-ACCEPTATIETEST.md` op een echte Android-telefoon. Besteed extra aandacht aan account aanmaken, authenticatorcode, eenmalige herstelcodes, automatisch vergrendelen, gegevens verwijderen, back-up herstellen, schermopnameblokkering en delen met een begeleider. Gebruik geen echte gevoelige gegevens tot die tests geslaagd zijn.

## Ondertekening

De workflow maakt een debug-APK voor installatie en testen. Voor openbare verspreiding moet de release-build met een eigen, veilig bewaarde Android-keystore worden ondertekend. Commit nooit een keystore of wachtwoord in de repository.


## Voorbereide update 1.0.7 (versionCode 8)

De update voegt LVB-vriendelijke vier-gevoelensknoppen, instelbare helpopties, beveiligde spraaknotities, eenvoudige weekkleurblokken, biometrische heropening van een optioneel bewaarde sessie en een AAB-output voor Google Play-testen toe. De APK/AAB moet nog door GitHub Actions worden gebouwd; wacht op een groene Debug- én Release-workflow voordat je deze versie verspreidt.
