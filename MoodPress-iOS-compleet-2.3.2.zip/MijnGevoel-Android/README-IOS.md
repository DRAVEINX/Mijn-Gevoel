# MoodPress voor iPhone en iPad — iOS 2.3.2

Deze broncode voegt een iOS-target toe naast het bestaande Android-project. De gedeelde MAUI-schermen, Core-beveiligingslaag en lokaal versleutelde gegevenslaag blijven gedeeld. Android-projectbestand en Android-workflows zijn niet vervangen.

## Wat zit erin

- `MijnGevoel.Android/MoodPress.iOS.csproj` voor `net10.0-ios` (iOS/iPadOS 15 of hoger).
- Native iOS-startbestanden, Info.plist-permissieteksten en app-switcher-privacybedekking.
- Face ID/Touch ID via Apple's LocalAuthentication; bij mislukken blijft gewone login beschikbaar. Op iOS wordt de sessiesleutel bij achtergrondgaan direct uit het geheugen gewist; als bewaren aanstaat, vraagt terugkeren eerst Face ID/Touch ID.
- Lokale wekelijkse herinneringen via UserNotifications, ook zichtbaar als ze afgaan terwijl MoodPress open is.
- Rustgevende audio via Plugin.Maui.Audio.
- Foto's verkleinen met SkiaSharp zonder Android Bitmap API.
- Guard tegen het herstellen van oude iOS Keychain-sessies wanneer de accountbestanden ontbreken (zoals na verwijderen/herinstalleren).
- Een GitHub Actions-workflow voor een ongetekende iOS Simulator-build én tests van de gedeelde Core-projecten.

## Wat is nog niet bevestigd

Deze omgeving heeft geen Xcode/.NET iOS-workload en heeft de app niet echt gecompileerd. Er is geen iPhone- of iPad-test uitgevoerd. De broncode is voorbereid en statisch gecontroleerd; de macOS-build moet nog slagen voordat we de app als compileerbaar kunnen aanmerken.

De Simulator-artifact is alleen voor technische controle. Het is geen installeerbare iPhone-IPA en kan niet naar TestFlight/App Store worden geüpload. Voor een echte toestelbuild en distributie zijn een Mac/macOS-runner met Xcode plus Apple signing certificate en provisioning profile nodig. Voor TestFlight/App Store-distributie is een Apple Developer Program-account vereist.

## Privacy en verschillen per platform

- iOS herinnert routines via lokale meldingen; de app vraagt het systeem om meldingen ook op de voorgrond te tonen. Toestemming en gedrag moeten op een echt toestel getest worden.
- De instelling voor privacy verbergt op iOS alleen de appinhoud in de appwisselaar. iOS biedt geen ondersteunde manier om door de gebruiker gemaakte schermafbeeldingen te blokkeren.
- iOS Keychain-data kan na het verwijderen van een app blijven bestaan. Het hervatten van een bewaarde sessie wordt daarom geweigerd als accountbestand of versleutelde gegevensmap ontbreekt.
- Data en SecureStorage migreren niet automatisch van Android naar iOS. Test herstel via de ingebouwde versleutelde back-up met een testaccount.
- App Store Connect kan aanvullende export-compliancevragen stellen omdat de app gebruikersgegevens zelf versleutelt. Beantwoord die op basis van de uiteindelijke implementatie.

## GitHub-build starten

1. Upload `MoodPress-iOS-compleet-2.3.2.zip` naar de hoofdmap van `DRAVEINX/Mijn-Gevoel`. Pak deze ZIP niet uit.
2. Maak `.github/workflows/moodpress-ios-build.yml` aan met de inhoud uit `moodpress-ios-build.yml` die in het uploadpakket zit.
3. Commit de bestanden en open GitHub Actions. Start `MoodPress iOS - simulator build`.
4. Bij een groene run download je `MoodPress-iOS-Simulator-2.3.2` onder Artifacts. Dat bevestigt de simulatorbuild, niet de werking op een echte iPhone.
5. Doorloop daarna `IOS-ACCEPTATIETEST.md` op een iPhone en iPad voordat de app met echte persoonlijke gegevens wordt gebruikt.
