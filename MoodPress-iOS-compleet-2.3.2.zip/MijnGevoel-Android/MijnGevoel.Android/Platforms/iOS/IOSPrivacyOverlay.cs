using UIKit;
using Foundation;

namespace MijnGevoel.AndroidApp;

/// <summary>Hides private app contents from the iOS app-switcher preview while MoodPress is inactive.</summary>
internal static class IOSPrivacyOverlay
{
    static UIView? _overlay;

    public static void Show()
    {
        // This only covers the app-switcher snapshot; iOS does not let apps block user screenshots.
        if (!AppSession.Settings.BlockCapture) { Hide(); return; }
        try
        {
            // Resolve the active scene's own window rather than querying UIApplication-wide
            // KeyWindow/Windows APIs, which are deprecated and ambiguous with multiple scenes.
            var window = UIApplication.SharedApplication.ConnectedScenes
                .OfType<UIWindowScene>()
                .Where(scene => scene.ActivationState == UISceneActivationState.ForegroundActive)
                .SelectMany(scene => scene.Windows)
                .FirstOrDefault(candidate => candidate.IsKeyWindow);
            if (window is null || _overlay is not null) return;
            var overlay = new UIView(window.Bounds) { BackgroundColor = UIColor.FromRGB(7, 13, 34), AutoresizingMask = UIViewAutoresizing.FlexibleWidth | UIViewAutoresizing.FlexibleHeight };
            var label = new UILabel(overlay.Bounds)
            {
                Text = "MoodPress · privé",
                TextColor = UIColor.White,
                TextAlignment = UITextAlignment.Center,
                AutoresizingMask = UIViewAutoresizing.FlexibleWidth | UIViewAutoresizing.FlexibleHeight
            };
            // UIKit's font factory is nullable in its bindings; keep UILabel's built-in
            // font as a fallback if the bold system font cannot be created.
            var boldFont = UIFont.BoldSystemFontOfSize(22);
            if (boldFont is not null) label.Font = boldFont;
            overlay.AddSubview(label);
            window.AddSubview(overlay);
            _overlay = overlay;
        }
        catch { /* Privacy cover must never crash app lifecycle. */ }
    }

    public static void Hide()
    {
        try
        {
            _overlay?.RemoveFromSuperview();
            _overlay?.Dispose();
        }
        catch { }
        finally { _overlay = null; }
    }
}
