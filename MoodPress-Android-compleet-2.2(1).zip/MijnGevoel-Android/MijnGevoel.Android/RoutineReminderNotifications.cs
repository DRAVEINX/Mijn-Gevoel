using System.Text.Json;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Media;
using Android.OS;
using Android.Security.Keystore;
using Javax.Crypto;
using Javax.Crypto.Spec;
using MijnGevoel.Core.Data;
using Microsoft.Maui.ApplicationModel;
using Microsoft.Maui.Storage;

namespace MijnGevoel.AndroidApp;

/// <summary>Schedules private local reminders. Schedule metadata is encrypted with a key in Android Keystore.</summary>
public static class RoutineReminderNotifications
{
    const string KeyAlias = "mijngevoel-routine-schedule-v1";
    const string ScheduleFile = "routine-reminders.enc";
    const string SoundChannel = "mijngevoel-routines-sound-v1";
    const string QuietChannel = "mijngevoel-routines-quiet-v1";

    public static async Task<bool> EnsurePermissionAsync()
    {
        if (Build.VERSION.SdkInt < BuildVersionCodes.Tiramisu) return true;
        var status = await Permissions.RequestAsync<RoutineNotificationPermission>();
        return status == PermissionStatus.Granted;
    }

    public static void Sync(Context context, IEnumerable<RoutineReminder> reminders)
    {
        var active = reminders.Where(x => x.Enabled && !string.IsNullOrWhiteSpace(x.Title) && IsValidTime(x.Time) && x.DaysMask != 0).ToList();
        var old = LoadStored(context);
        var activeIds = active.Select(x => x.Id).ToHashSet();
        foreach (var item in old) Cancel(context, item.Id, clearNotification: !activeIds.Contains(item.Id));
        SaveStored(context, active);
        EnsureChannels(context);
        foreach (var item in active) ScheduleNext(context, item, DateTime.Now);
    }

    internal static void RestoreAfterBoot(Context context)
    {
        EnsureChannels(context);
        foreach (var item in LoadStored(context)) ScheduleNext(context, item, DateTime.Now);
    }

    internal static void ScheduleNext(Context context, RoutineReminder item, DateTime after)
    {
        if (!item.Enabled || !IsValidTime(item.Time) || item.DaysMask == 0) return;
        var next = NextOccurrence(item, after);
        if (next is null) return;
        var alarmManager = context.GetSystemService(Context.AlarmService) as AlarmManager;
        if (alarmManager is null) return;
        var intent = MakeIntent(context, item);
        var pending = PendingIntent.GetBroadcast(context, RequestCode(item.Id), intent, PendingIntentFlags.UpdateCurrent | PendingIntentFlags.Immutable);
        alarmManager.SetAndAllowWhileIdle(AlarmType.RtcWakeup, new DateTimeOffset(next.Value).ToUnixTimeMilliseconds(), pending);
    }

    internal static void ShowNotificationAndRepeat(Context context, Intent? intent)
    {
        if (intent is null) return;
        var idString = intent.GetStringExtra("routineId");
        if (!Guid.TryParse(idString, out var id)) return;
        var title = intent.GetStringExtra("title") ?? "Mijn routine";
        var icon = intent.GetStringExtra("icon") ?? "⏰";
        var time = intent.GetStringExtra("time") ?? "08:00";
        int daysMask = intent.GetIntExtra("daysMask", 127);
        bool enabled = intent.GetBooleanExtra("enabled", true);
        bool sound = intent.GetBooleanExtra("sound", true);
        var picture = intent.GetStringExtra("picture");
        var item = new RoutineReminder(id, title, icon, time, daysMask, enabled, picture, sound);

        try
        {
            EnsureChannels(context);
            var manager = context.GetSystemService(Context.NotificationService) as NotificationManager;
            if (manager is not null && (Build.VERSION.SdkInt < BuildVersionCodes.Tiramisu || context.CheckSelfPermission(Android.Manifest.Permission.PostNotifications) == Permission.Granted))
            {
                var channel = sound ? SoundChannel : QuietChannel;
                var openIntent = new Intent(context, typeof(MainActivity));
                openIntent.SetFlags(ActivityFlags.ClearTop | ActivityFlags.SingleTop | ActivityFlags.NewTask);
                var openPending = PendingIntent.GetActivity(context, RequestCode(id) + 700000, openIntent, PendingIntentFlags.UpdateCurrent | PendingIntentFlags.Immutable);
                var builder = new Notification.Builder(context, channel)
                    .SetSmallIcon(Resource.Drawable.routine_notification)
                    .SetContentTitle($"{icon}  {title}")
                    .SetContentText("Het is tijd voor jouw routine.")
                    .SetStyle(new Notification.BigTextStyle().BigText($"Het is tijd voor: {title}. Open MoodPress als je de routine wilt bekijken."))
                    .SetCategory(Notification.CategoryReminder)
                    .SetVisibility((int)NotificationVisibility.Private)
                    .SetAutoCancel(true)
                    .SetContentIntent(openPending)
                    .SetPriority((int)NotificationPriority.High);
                if (!string.IsNullOrWhiteSpace(picture))
                {
                    try
                    {
                        var bytes = Convert.FromBase64String(picture);
                        var bitmap = Android.Graphics.BitmapFactory.DecodeByteArray(bytes, 0, bytes.Length);
                        if (bitmap is not null) builder.SetLargeIcon(bitmap);
                    }
                    catch { /* A damaged optional picture must not suppress the reminder. */ }
                }
                manager.Notify(RequestCode(id), builder.Build());
            }
        }
        catch (Java.Lang.SecurityException) { /* Notifications permission may have been revoked in Settings. */ }
        catch (Exception ex) { Android.Util.Log.Warn("MijnGevoelRoutines", $"Reminder could not be displayed: {ex.GetType().Name}"); }

        // Schedule the next allowed day immediately; Android keeps the alarm when the app process exits.
        ScheduleNext(context, item, DateTime.Now.AddSeconds(1));
    }

    internal static void Cancel(Context context, Guid id, bool clearNotification = true)
    {
        var alarmManager = context.GetSystemService(Context.AlarmService) as AlarmManager;
        if (alarmManager is null) return;
        var intent = new Intent(context, typeof(RoutineReminderReceiver));
        intent.SetAction($"nl.mijngevoel.routine.{id:N}");
        var pending = PendingIntent.GetBroadcast(context, RequestCode(id), intent, PendingIntentFlags.NoCreate | PendingIntentFlags.Immutable);
        if (pending is not null) { alarmManager.Cancel(pending); pending.Cancel(); }
        if (clearNotification)
        {
            var manager = context.GetSystemService(Context.NotificationService) as NotificationManager;
            manager?.Cancel(RequestCode(id));
        }
    }

    static Intent MakeIntent(Context context, RoutineReminder item)
    {
        var intent = new Intent(context, typeof(RoutineReminderReceiver));
        intent.SetAction($"nl.mijngevoel.routine.{item.Id:N}");
        intent.PutExtra("routineId", item.Id.ToString("N"));
        intent.PutExtra("title", item.Title);
        intent.PutExtra("icon", item.Icon);
        intent.PutExtra("time", item.Time);
        intent.PutExtra("daysMask", item.DaysMask);
        intent.PutExtra("enabled", item.Enabled);
        intent.PutExtra("sound", item.SoundEnabled);
        if (!string.IsNullOrWhiteSpace(item.PictureBase64)) intent.PutExtra("picture", item.PictureBase64);
        return intent;
    }

    static DateTime? NextOccurrence(RoutineReminder item, DateTime after)
    {
        if (!TimeOnly.TryParse(item.Time, System.Globalization.CultureInfo.InvariantCulture, out var clock)) return null;
        for (int offset = 0; offset <= 7; offset++)
        {
            var date = after.Date.AddDays(offset);
            if ((item.DaysMask & (1 << (int)date.DayOfWeek)) == 0) continue;
            var candidate = date.Add(clock.ToTimeSpan());
            if (candidate > after.AddSeconds(1)) return candidate;
        }
        return null;
    }

    static bool IsValidTime(string? time) => TimeOnly.TryParse(time, System.Globalization.CultureInfo.InvariantCulture, out _);
    static int RequestCode(Guid id) => (BitConverter.ToInt32(id.ToByteArray(), 0) & 0x3fffffff) + 1;

    static void EnsureChannels(Context context)
    {
        if (Build.VERSION.SdkInt < BuildVersionCodes.O) return;
        var manager = context.GetSystemService(Context.NotificationService) as NotificationManager;
        if (manager is null) return;
        if (manager.GetNotificationChannel(SoundChannel) is null)
        {
            var channel = new NotificationChannel(SoundChannel, "Routineherinneringen met geluid", NotificationImportance.High)
            { Description = "Tijdige meldingen voor zelf ingestelde routines." };
            channel.EnableVibration(true);
            var attributes = new AudioAttributes.Builder().SetUsage(AudioUsageKind.Notification).SetContentType(AudioContentType.Sonification).Build();
            channel.SetSound(RingtoneManager.GetDefaultUri(RingtoneType.Notification), attributes);
            manager.CreateNotificationChannel(channel);
        }
        if (manager.GetNotificationChannel(QuietChannel) is null)
        {
            var channel = new NotificationChannel(QuietChannel, "Routineherinneringen zonder geluid", NotificationImportance.High)
            { Description = "Visuele meldingen voor routines zonder geluid." };
            channel.SetSound(null, null);
            channel.EnableVibration(false);
            manager.CreateNotificationChannel(channel);
        }
    }

    static List<RoutineReminder> LoadStored(Context context)
    {
        try
        {
            var file = Path.Combine(context.FilesDir!.AbsolutePath!, ScheduleFile);
            if (!File.Exists(file)) return new List<RoutineReminder>();
            var blob = File.ReadAllBytes(file);
            if (blob.Length < 13) return new List<RoutineReminder>();
            var key = GetOrCreateKey();
            using var cipher = Cipher.GetInstance("AES/GCM/NoPadding");
            var iv = blob[..12];
            cipher.Init(CipherMode.DecryptMode, key, new GCMParameterSpec(128, iv));
            var plain = cipher.DoFinal(blob[12..]);
            try { return JsonSerializer.Deserialize<List<RoutineReminder>>(plain) ?? new List<RoutineReminder>(); }
            finally { Array.Clear(plain); }
        }
        catch (Exception ex)
        {
            Android.Util.Log.Warn("MijnGevoelRoutines", $"Encrypted reminder schedule could not be read: {ex.GetType().Name}");
            return new List<RoutineReminder>();
        }
    }

    static void SaveStored(Context context, List<RoutineReminder> reminders)
    {
        var file = Path.Combine(context.FilesDir!.AbsolutePath!, ScheduleFile);
        var json = JsonSerializer.SerializeToUtf8Bytes(reminders);
        try
        {
            var key = GetOrCreateKey();
            using var cipher = Cipher.GetInstance("AES/GCM/NoPadding");
            cipher.Init(CipherMode.EncryptMode, key);
            var encrypted = cipher.DoFinal(json);
            var iv = cipher.GetIV()!;
            var blob = new byte[iv.Length + encrypted.Length];
            Buffer.BlockCopy(iv, 0, blob, 0, iv.Length);
            Buffer.BlockCopy(encrypted, 0, blob, iv.Length, encrypted.Length);
            var temp = file + ".tmp";
            File.WriteAllBytes(temp, blob);
            File.Move(temp, file, true);
            Array.Clear(encrypted); Array.Clear(blob);
        }
        finally { Array.Clear(json); }
    }

    static Java.Security.IKey GetOrCreateKey()
    {
        var store = Java.Security.KeyStore.GetInstance("AndroidKeyStore");
        store.Load(null);
        var key = store.GetKey(KeyAlias, null);
        if (key is not null) return key;
        var generator = KeyGenerator.GetInstance(KeyProperties.KeyAlgorithmAes, "AndroidKeyStore");
        var spec = new KeyGenParameterSpec.Builder(KeyAlias, KeyStorePurpose.Encrypt | KeyStorePurpose.Decrypt)
            .SetBlockModes(KeyProperties.BlockModeGcm)
            .SetEncryptionPaddings(KeyProperties.EncryptionPaddingNone)
            .SetRandomizedEncryptionRequired(true)
            .Build();
        generator.Init(spec);
        generator.GenerateKey();
        store.Load(null);
        return store.GetKey(KeyAlias, null) ?? throw new InvalidOperationException("Android Keystore could not create reminder key.");
    }
}

public sealed class RoutineNotificationPermission : Permissions.BasePlatformPermission
{
    public override (string[] androidPermissions, bool[] shouldShowRationale) RequiredPermissions =>
        (new[] { Android.Manifest.Permission.PostNotifications }, new[] { false });
}

[BroadcastReceiver(Enabled = true, Exported = false)]
public sealed class RoutineReminderReceiver : BroadcastReceiver
{
    public override void OnReceive(Context? context, Intent? intent)
    {
        if (context is null || intent is null) return;
        RoutineReminderNotifications.ShowNotificationAndRepeat(context, intent);
    }
}

[BroadcastReceiver(Enabled = true, Exported = false)]
[IntentFilter(new[] { Intent.ActionBootCompleted, "android.intent.action.MY_PACKAGE_REPLACED" })]
public sealed class RoutineReminderBootReceiver : BroadcastReceiver
{
    public override void OnReceive(Context? context, Intent? intent)
    {
        if (context is null || intent is null) return;
        RoutineReminderNotifications.RestoreAfterBoot(context);
    }
}
