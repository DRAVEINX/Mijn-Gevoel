# Mijn Gevoel

Windows 11-programma (WPF, .NET 8) waarmee cliënten kunnen tekenen, van zich afschrijven, dagboek bijhouden en hun agenda beheren.
Alle gegevens blijven lokaal en zijn versleuteld.

## Bouwen en installeren (MSI)
1. Installeer de .NET 8 SDK (https://dotnet.microsoft.com/download) op Windows 11 en zorg dat je internet hebt.
2. Dubbelklik `bouwen.bat`. Dat draait de tests, bouwt `publish\MijnGevoel.exe` en maakt **`MijnGevoel-installatie.msi`** (WiX 5).
3. Installeren: dubbelklik de .msi (administratorrechten nodig) of stil: `msiexec /i MijnGevoel-installatie.msi /qn`.
   Het programma komt in `C:\Program Files\Mijn Gevoel` met snelkoppelingen in het startmenu en op het bureaublad.
4. Updaten: een nieuwe .msi met hoger versienummer (`installer\Package.wxs`) vervangt de oude automatisch. Verwijderen kan via Instellingen > Apps; de gegevens van cliënten blijven dan staan.
5. Voor uitrol: teken `.exe` en `.msi` met een code-signing-certificaat (signtool), anders waarschuwt Windows SmartScreen.
Zonder installeren starten kan ook: `dotnet run --project MijnGevoel.Desktop`.

## Mappen
- `MijnGevoel.Core` - beveiliging (Argon2id, AES-256-GCM, TOTP, herstelcodes), versleutelde opslag, back-up
- `MijnGevoel.Desktop` - het programma zelf (inloggen, home, tekenen, schrijven, dagboek, agenda, gevoelsoverzicht, instellingen, hulp)
- `MijnGevoel.Tests` - tests (o.a. RFC 6238-testvectoren, versleuteling, blokkade, herstel)

## Beveiliging in het kort
- Wachtwoord -> Argon2id (64 MB, 3 rondes) -> sleutel die de willekeurige 256-bit gegevenssleutel ontgrendelt; wachtwoord zelf wordt nergens opgeslagen.
- Inloggen vereist wachtwoord + TOTP-code (RFC 6238); een code werkt maar één keer.
- Elk dagboekstuk, elke tekening en elke agenda-afspraak is een apart AES-256-GCM-bestand, gebonden aan soort + id.
- Herstelcodes (8, eenmalig); blokkade met oplopende wachttijd; automatisch vergrendelen; sleutel wordt bij vergrendelen/afsluiten uit het geheugen gewist.
- Gegevens staan in `%LocalAppData%\MijnGevoel\` (accounts\ en data\).

## Nog te doen vóór echt gebruik met cliënten
- Externe security-review/pentest en een DPIA (AVG: het zijn gezondheidsgerelateerde persoonsgegevens).
- Programma code-signen en een installer maken (MSIX of Inno Setup).
- Testen met cliënten en begeleiders (taalniveau, pictogrammen, prikkels) en aanpassen op hun feedback.
- Optioneel: synchronisatie of meekijken door begeleider (vraagt server, toestemming en aparte beveiliging).

## Documenten (map `docs`)
1. Opdracht externe beveiligingstoets (dreigingsmodel, scope, bekende beperkingen)
2. DPIA-concept (door organisatie/FG vast te stellen)
3. Testplan met cliënten en begeleiders
4. Herstelbeleid voor herstelcodes
5. Delen met begeleiders: nu en later (server-ontwerp)

## Nieuw in deze versie
Stoplicht (groen/oranje/rood met reden en behoefte), Mijn plan, delen via versleuteld deelbestand (+ begeleiderscherm), herstelcodes printen/vernieuwen met waarschuwing.

## Documenten (aanvulling)
6. Wetgeving: AVG en andere regels, nu en in 2027 (met status per 5 oktober 2026)
7. Modellen voor de organisatie: register, toestemming, datalek, verzoeken, verwerkersovereenkomst, bewaartermijnen

Nieuw in versie 1.0.3: modern uiterlijk (kaarten, verlopen, zachte bewegingen, logo), leesbaar deelbestand (.html) voor begeleiders, optionele tekst-kopie, toestemmingsscherm, "Mijn privacy" met export. Voorbeeld van het deelbestand: `MijnGevoel-voorbeeld-deelbestand.html` (code: DEMO-2027-TEST).

Versie 1.0.4: beginscherm in groepen, Mijn dag, timer, stappenplannen, ademhalen, rustplek, prikkelmeter, lichaam, gevoelswoorden, kaarten, gesprekskaart, weekoverzicht, snel verbergen, lettertype/regelafstand, schermopname blokkeren. Zie `FUNCTIES.md` voor wat er wel en bewust niet in zit.

Versie 1.0.5: foutlogboek (zonder persoonlijke gegevens) in `%LocalAppData%\MijnGevoel\log.txt`, acceptatietest (`docs/8-ACCEPTATIETEST.md`) en opleverplan (`OPLEVERING.md`).

Versie 1.0.6: bouwfout opgelost (System.IO in het WPF-project) en leesbaar bouwlog (UTF-8).
