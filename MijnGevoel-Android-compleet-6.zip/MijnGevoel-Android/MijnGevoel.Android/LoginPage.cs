using Microsoft.Maui.Storage;
using Microsoft.Maui.Media;
using Microsoft.Maui.ApplicationModel.DataTransfer;
using MijnGevoel.Core.Security;
using MijnGevoel.Core.Data;

namespace MijnGevoel.AndroidApp;

public sealed class LoginPage : ContentPage
{
    Entry _username = null!, _password = null!, _totp = null!;
    Label _status = null!;
    string? _pendingUser, _pendingPassword;

    public LoginPage()
    {
        Title = "Mijn Gevoel";
        BackgroundColor = AppUi.Background;
        ShowLogin();
    }

    public void ShowLoginMessage(string? message)
    {
        ShowLogin(message);
    }

    void ShowLogin(string? message = null)
    {
        Title = "Mijn Gevoel";
        _username = AppUi.Entry("Gebruikersnaam");
        _password = AppUi.Entry("Wachtwoord", password: true);
        _totp = AppUi.Entry("6-cijferige authenticatorcode", keyboard: Keyboard.Numeric);
        _totp.MaxLength = 6;
        var show = new CheckBox();
        show.CheckedChanged += (_, e) => _password.IsPassword = !e.Value;
        _status = AppUi.Label(message ?? "Je gegevens blijven op dit apparaat en worden versleuteld opgeslagen.");

        var content = AppUi.Stack(
            new Image { Source = "logo.png", HeightRequest = 90, WidthRequest = 90, Aspect = Aspect.AspectFit, HorizontalOptions = LayoutOptions.Center },
            AppUi.Title("Mijn Gevoel"),
            AppUi.Label("Een rustige plek om bij te houden hoe het met je gaat.", muted: true),
            AppUi.Label("Inloggen", title: true),
            _username,
            _password,
            new HorizontalStackLayout { Spacing = 8, Children = { show, AppUi.Label("Wachtwoord laten zien") } },
            _totp,
            AppUi.AsyncButton("🔐 Inloggen", LoginAsync),
            _status,
            AppUi.Button("➕ Nieuw account maken", ShowRegister),
            AppUi.Button("🔑 Ik ben mijn wachtwoord/telefoon kwijt", ShowRecovery, quiet: true),
            AppUi.AsyncButton("📦 Back-up terugzetten op deze telefoon", RestoreBackupAsync, quiet: true),
            AppUi.Button("📂 Deelbestand van een begeleider openen", () => Navigation.PushAsync(new ShareOpenPage()), quiet: true),
            AppUi.Label("Tip: je hebt je authenticator-app nodig. Bewaar je herstelcodes op een veilige plek.", muted: true));
        Content = new ScrollView { Content = content };
    }

    async Task LoginAsync()
    {
        var user = _username.Text?.Trim() ?? "";
        var password = _password.Text ?? "";
        var code = _totp.Text ?? "";
        if (user.Length == 0 || password.Length == 0 || code.Length != 6)
        {
            _status.Text = "Vul je gebruikersnaam, wachtwoord en de 6-cijferige code in.";
            return;
        }
        try
        {
            _status.Text = "Bezig met veilig inloggen…";
            var result = await Task.Run(() => AppSession.Accounts.Login(user, password, code));
            if (!result.Success || result.VaultKey is null)
            {
                _status.Text = result.Message;
                return;
            }
            AppSession.Start(user, result.VaultKey);
            await Navigation.PushAsync(new DashboardPage());
        }
        catch (Exception ex)
        {
            _status.Text = "Inloggen lukte niet. Controleer je gegevens en probeer opnieuw.";
            AppLog.Write(ex);
        }
    }

    async Task RestoreBackupAsync()
    {
        var picked = await FilePicker.Default.PickAsync(new PickOptions { PickerTitle = "Kies je versleutelde Mijn Gevoel-back-up (.zip)" });
        if (picked is null) return;
        var temp = Path.Combine(FileSystem.CacheDirectory, "mg-login-restore-" + Guid.NewGuid().ToString("N") + ".zip");
        try
        {
            await using (var source = await picked.OpenReadAsync())
            await using (var target = File.Create(temp)) await source.CopyToAsync(target);
            var count = await Task.Run(() => BackupService.Restore(AppSession.Accounts, temp));
            _status.Text = count > 0 ? "Back-up teruggezet. Je kunt nu inloggen met het herstelde account." : "Er zijn geen nieuwe bestanden teruggezet. Controleer of je de juiste back-up kiest of dat het account al bestaat.";
            await DisplayAlertAsync("Back-up terugzetten", _status.Text, "OK");
        }
        catch (Exception ex)
        {
            AppLog.Write(ex);
            _status.Text = "Terugzetten is niet gelukt. Kies een geldige Mijn Gevoel-back-up.";
            await DisplayAlertAsync("Back-up niet verwerkt", _status.Text, "OK");
        }
        finally { try { File.Delete(temp); } catch { } }
    }

    void ShowRegister()
    {
        Title = "Account aanmaken";
        var username = AppUi.Entry("Kies een gebruikersnaam (minimaal 3 tekens)");
        var password = AppUi.Entry("Kies een sterk wachtwoord (minimaal 10 tekens)", password: true);
        var password2 = AppUi.Entry("Herhaal het wachtwoord", password: true);
        var status = AppUi.Label("Na het aanmaken koppel je een authenticator-app en bewaar je de herstelcodes.");
        Content = new ScrollView { Content = AppUi.Stack(
            AppUi.Title("Nieuw account"),
            AppUi.Label("Gebruik een wachtwoord dat je niet op andere plekken gebruikt."),
            username, password, password2,
            AppUi.AsyncButton("Account aanmaken en authenticator koppelen", async () =>
            {
                var u = username.Text?.Trim() ?? "";
                var p = password.Text ?? "";
                if (p != password2.Text) { status.Text = "De wachtwoorden zijn niet gelijk."; return; }
                try
                {
                    status.Text = "Account veilig aanmaken…";
                    var registration = await Task.Run(() => AppSession.Accounts.Register(u, p));
                    _pendingUser = u; _pendingPassword = p;
                    ShowRegistration(registration, u, p, "Bewaar de herstelcodes. Elke code werkt één keer.");
                }
                catch (Exception ex) { status.Text = ex.Message; }
            }),
            status,
            AppUi.Button("← Terug naar inloggen", () => ShowLogin())) };
    }

    void ShowRecovery()
    {
        Title = "Toegang herstellen";
        var username = AppUi.Entry("Gebruikersnaam");
        var code = AppUi.Entry("Een ongebruikte herstelcode");
        var newPassword = AppUi.Entry("Nieuw wachtwoord (minimaal 10 tekens)", password: true);
        var newPassword2 = AppUi.Entry("Herhaal het nieuwe wachtwoord", password: true);
        var status = AppUi.Label("Met een herstelcode wordt je authenticator opnieuw gekoppeld. Je oude herstelcodes vervallen.");
        Content = new ScrollView { Content = AppUi.Stack(
            AppUi.Title("Toegang herstellen"), username, code, newPassword, newPassword2,
            AppUi.AsyncButton("Herstellen en opnieuw koppelen", async () =>
            {
                var u = username.Text?.Trim() ?? "";
                var p = newPassword.Text ?? "";
                if (p != newPassword2.Text) { status.Text = "De wachtwoorden zijn niet gelijk."; return; }
                try
                {
                    var registration = await Task.Run(() => AppSession.Accounts.RecoverAccess(u, code.Text ?? "", p));
                    if (registration is null) { status.Text = "Herstellen lukte niet. Controleer de gebruikersnaam en herstelcode."; return; }
                    _pendingUser = u; _pendingPassword = p;
                    ShowRegistration(registration, u, p, "Je toegang wordt hersteld. Bewaar de nieuwe codes; de oude werken niet meer.");
                }
                catch (Exception ex) { status.Text = ex.Message; }
            }),
            status,
            AppUi.Button("← Terug naar inloggen", () => ShowLogin())) };
    }

    void ShowRegistration(Registration registration, string username, string password, string lead)
    {
        Title = "Authenticator koppelen";
        var otp = AppUi.Entry("Eerste 6-cijferige code uit je authenticator", keyboard: Keyboard.Numeric);
        otp.MaxLength = 6;
        var codes = string.Join("\n", registration.RecoveryCodes);
        var status = AppUi.Label(lead);
        var qrBytes = registration.QrPng;
        var qr = new Image
        {
            Source = ImageSource.FromStream(() => new MemoryStream(qrBytes)),
            HeightRequest = 230,
            WidthRequest = 230,
            Aspect = Aspect.AspectFit,
            HorizontalOptions = LayoutOptions.Center
        };
        var secret = AppUi.Label("Lukt scannen niet? Voer deze sleutel handmatig in:\n" + registration.SecretForManualEntry);
        var recovery = AppUi.Card(AppUi.Label(codes));
        Content = new ScrollView { Content = AppUi.Stack(
            AppUi.Title("Koppel je authenticator"),
            AppUi.Label("1. Open Google Authenticator, Microsoft Authenticator of een andere TOTP-app.\n2. Scan de QR-code.\n3. Typ de actuele code hieronder om de koppeling te bevestigen."),
            qr, secret,
            AppUi.Title("Bewaar deze herstelcodes"),
            AppUi.Label("Bewaar ze buiten deze telefoon. Iedere code werkt één keer; deel ze met niemand."),
            recovery,
            AppUi.AsyncButton("📋 Herstelcodes kopiëren", async () => { await Clipboard.Default.SetTextAsync(codes); await DisplayAlertAsync("Gekopieerd", "Bewaar de codes op een veilige plek buiten deze telefoon.", "OK"); }),
            otp,
            AppUi.AsyncButton("Authenticator bevestigen", async () =>
            {
                var ok = await Task.Run(() => AppSession.Accounts.ConfirmRegistration(username, password, otp.Text ?? ""));
                if (!ok) { status.Text = "De code klopt niet. Controleer of de tijd op je telefoon goed staat en probeer een nieuwe code."; return; }
                await DisplayAlertAsync("Account klaar", "Je account is aangemaakt. Log nu in met je wachtwoord en authenticatorcode.", "Naar inloggen");
                ShowLogin("Account ingesteld. Je kunt nu inloggen.");
            }),
            status,
            AppUi.Button("Annuleren en terug", () => ShowLogin())) };
    }
}

internal static class AppLog
{
    public static void Write(Exception ex)
    {
        try
        {
            var path = Path.Combine(FileSystem.AppDataDirectory, "log.txt");
            var fi = new FileInfo(path);
            if (fi.Exists && fi.Length > 200_000) fi.Delete();
            File.AppendAllText(path, $"{DateTime.UtcNow:O} {ex.GetType().FullName}\n{ex.StackTrace}\n\n");
        }
        catch { }
    }
}
