using System.Globalization;
using System.Text;
using System.Text.Json;
using MijnGevoel.Core.Data;
using MijnGevoel.Core.Security;
using SkiaSharp;
using Microsoft.Maui.ApplicationModel.DataTransfer;
using Microsoft.Maui.Storage;
using Microsoft.Maui.Media;
using Microsoft.Maui.Controls.Shapes;
using PointF = Microsoft.Maui.Graphics.PointF;

namespace MijnGevoel.AndroidApp;

/// <summary>Mobiele schermen voor de volledige kernfunctionaliteit. Gegevens lopen altijd via de versleutelde VaultStore.</summary>
public sealed partial class FeaturePage : ContentPage
{
    readonly FeatureKind _kind;
    readonly Guid? _targetShareId;
    readonly VerticalStackLayout _root;
    IDispatcherTimer? _timer;
    int _timerRemaining;
    int _timerTotal;
    IDispatcherTimer? _breathTimer;
    bool _breathIn = true;
    int _calmTipIndex;
    Routine? _runningRoutine;
    int _routineStep;
    Guid? _editingRoutineId;
    Entry? _routineName, _routineIcon;
    Editor? _routineSteps;
    readonly List<List<PointF>> _strokes = new();
    List<PointF>? _activeStroke;
    GraphicsView? _drawingView;
    readonly List<CheckBox> _shareChecks = new();

    static readonly (string Emoji, string Name, string Hex)[] Moods =
    {
        ("😄", "Blij", "#8FD694"), ("🙂", "Goed", "#C5E384"), ("😐", "Gaat wel", "#F4E285"),
        ("😟", "Niet fijn", "#F5B971"), ("😢", "Verdrietig", "#E88B8B")
    };
    static readonly (string Emoji, string Text)[] Reasons =
    {
        ("😴", "Ik ben moe"), ("😠", "Ik ben boos"), ("😢", "Ik ben verdrietig"), ("😨", "Ik ben bang"),
        ("👥", "Iets met andere mensen"), ("🏫", "School, werk of dagbesteding"), ("🏠", "Thuis of waar ik woon"),
        ("🤕", "Pijn of ziek"), ("🌀", "Te veel drukte of lawaai"), ("🤷", "Ik weet het niet")
    };
    static readonly (string Emoji, string Text)[] Needs =
    {
        ("💬", "Ik wil praten met iemand"), ("🤫", "Ik wil rust"), ("🎨", "Ik wil iets leuks doen"),
        ("🚶", "Ik wil even naar buiten"), ("🆘", "Ik wil nu hulp"), ("🤷", "Ik weet het niet")
    };
    static readonly (string Emoji, string Name, string Description)[] FeelingWords =
    {
        ("😊", "Blij", "Je voelt je fijn. Je hebt zin in dingen."), ("😌", "Rustig", "Je lijf en je hoofd zijn kalm. Je hoeft niets."),
        ("🥳", "Trots", "Je hebt iets gedaan wat je moeilijk vond, en het is gelukt."), ("😢", "Verdrietig", "Je voelt je zwaar of leeg. Soms moet je huilen."),
        ("😠", "Boos", "Je voelt je warm en gespannen. Je vindt iets niet eerlijk."), ("😨", "Bang", "Je denkt dat er iets ergs gebeurt. Je hart gaat snel."),
        ("😬", "Zenuwachtig", "Je buik kriebelt. Er komt iets spannends aan."), ("🥺", "Eenzaam", "Je wilt graag bij iemand zijn, maar je voelt je alleen."),
        ("😴", "Moe", "Je hebt weinig energie. Je wilt rusten."), ("🤯", "Overprikkeld", "Er komt te veel tegelijk binnen: geluid, licht of mensen."),
        ("😞", "Teleurgesteld", "Je had iets anders verwacht en het ging anders."), ("😳", "Beschaamd", "Je wilt even niet bekeken worden."),
        ("😕", "Verward", "Je snapt het even niet. Je weet niet wat je moet doen."), ("😮‍💨", "Opgelucht", "Iets spannends is voorbij. Je mag ontspannen."),
        ("🙏", "Dankbaar", "Je vindt het fijn dat iemand iets goeds voor je deed."), ("😒", "Jaloers", "Een ander heeft iets wat jij ook graag zou willen.")
    };
    static readonly (string Emoji, string Text)[] BasicCards =
    {
        ("🤫", "Ik wil even rust"), ("🙋", "Ik heb hulp nodig"), ("❓", "Ik snap het niet"), ("🔁", "Kun je het nog een keer zeggen?"),
        ("🐢", "Kun je langzamer praten?"), ("🚻", "Ik moet naar de wc"), ("🥤", "Ik heb dorst"), ("🍽️", "Ik heb honger"),
        ("🔇", "Het is te druk of te hard"), ("✋", "Ik wil niet aangeraakt worden"), ("💬", "Ik wil praten"), ("🏠", "Ik wil naar huis")
    };
    static readonly (string Emoji, string Name)[] AgendaIcons =
    {
        ("🏥", "Dokter"), ("👥", "Afspraak"), ("💊", "Medicijnen"), ("🍽️", "Eten"), ("🚌", "Reizen"),
        ("🏃", "Sporten"), ("📞", "Bellen"), ("🎉", "Feest"), ("⭐", "Anders")
    };
    static readonly string[] CalmTips =
    {
        "Je bent veilig. Je hoeft nu niets.", "Kijk om je heen. Noem 3 dingen die je ziet.", "Voel je voeten op de grond.",
        "Adem rustig in en uit.", "Drink een slokje water.", "Dit gevoel gaat voorbij. Het blijft niet zo."
    };

    public FeaturePage(FeatureKind kind, Guid? targetShareId = null)
    {
        _kind = kind;
        _targetShareId = targetShareId;
        Title = TitleFor(kind);
        BackgroundColor = AppUi.Background;
        _root = new VerticalStackLayout { Padding = new Thickness(16), Spacing = 10, BackgroundColor = AppUi.Background };
        Content = new ScrollView { Content = _root };
        Build();
        if (_kind == FeatureKind.Draw)
            Content = CreateDrawingPageLayout();
        ToolbarItems.Add(new ToolbarItem("🙈 Scherm verbergen", null, async () => await Navigation.PushAsync(new PrivacyCoverPage())));
        ToolbarItems.Add(new ToolbarItem("🔒 Vergrendel", null, async () => await ((App)Application.Current!).LockToLoginAsync()));
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        AppSession.Touch();
        if (AppSession.Settings.Animations)
        {
            Opacity = 0;
            _ = this.FadeToAsync(1, 180, Easing.CubicOut);
        }
    }

    protected override void OnDisappearing()
    {
        // Timers horen niet op de achtergrond door te lopen als de gebruiker van scherm wisselt.
        _timer?.Stop();
        _breathTimer?.Stop();
        base.OnDisappearing();
    }

    static string TitleFor(FeatureKind kind) => kind switch
    {
        FeatureKind.Stoplicht => "Mijn stoplicht", FeatureKind.DayToday => "Vandaag", FeatureKind.DayTomorrow => "Morgen",
        FeatureKind.Agenda => "Agenda", FeatureKind.Timer => "Timer", FeatureKind.Routines => "Stappenplannen",
        FeatureKind.Breath => "Ademhalen", FeatureKind.Calm => "Rustplek", FeatureKind.Sensory => "Prikkelmeter",
        FeatureKind.Body => "Mijn lichaam", FeatureKind.MoodHistory => "Hoe voel ik me?", FeatureKind.FeelingWords => "Gevoelswoorden",
        FeatureKind.Cards => "Kaarten om te laten zien", FeatureKind.TalkPrep => "Gesprekskaart", FeatureKind.StoplichtHistory => "Stoplicht-overzicht",
        FeatureKind.Share => "Delen met mijn begeleider", FeatureKind.SafetyPlan => "Mijn plan", FeatureKind.Draw => "Tekenen",
        FeatureKind.Gallery => "Mijn tekeningen", FeatureKind.Notes => "Van me afschrijven", FeatureKind.Journal => "Dagboek",
        FeatureKind.Privacy => "Mijn privacy", FeatureKind.Week => "Weekoverzicht", FeatureKind.Settings => "Instellingen", _ => "Hulp"
    };

    void Build()
    {
        _root.Children.Clear();
        switch (_kind)
        {
            case FeatureKind.Stoplicht: BuildStoplicht(); break;
            case FeatureKind.DayToday: BuildDay(DateTime.Today); break;
            case FeatureKind.DayTomorrow: BuildDay(DateTime.Today.AddDays(1)); break;
            case FeatureKind.Agenda: BuildAgenda(); break;
            case FeatureKind.Timer: BuildTimer(); break;
            case FeatureKind.Routines: BuildRoutines(); break;
            case FeatureKind.Breath: BuildBreath(); break;
            case FeatureKind.Calm: BuildCalm(); break;
            case FeatureKind.Sensory: BuildSensory(); break;
            case FeatureKind.Body: BuildBody(); break;
            case FeatureKind.MoodHistory: BuildMoodHistory(); break;
            case FeatureKind.FeelingWords: BuildFeelingWords(); break;
            case FeatureKind.Cards: BuildCards(); break;
            case FeatureKind.TalkPrep: BuildTalkPrep(); break;
            case FeatureKind.StoplichtHistory: BuildStoplichtHistory(); break;
            case FeatureKind.Share: BuildShare(); break;
            case FeatureKind.SafetyPlan: BuildSafetyPlan(); break;
            case FeatureKind.Draw: BuildDraw(); break;
            case FeatureKind.Gallery: BuildGallery(); break;
            case FeatureKind.Notes: BuildJournal(false); break;
            case FeatureKind.Journal: BuildJournal(true); break;
            case FeatureKind.Privacy: BuildPrivacy(); break;
            case FeatureKind.Week: BuildWeek(); break;
            case FeatureKind.Settings: BuildSettings(); break;
            default: BuildHelp(); break;
        }
    }

    void Header(string title, string description)
    {
        _root.Children.Add(AppUi.Title(title));
        _root.Children.Add(AppUi.Label(description));
    }

    void Add(View view) => _root.Children.Add(view);
    void AddLabel(string text, bool title = false, bool muted = false) => Add(AppUi.Label(text, title, muted));
    void AddButton(string text, Action action, bool quiet = false, bool danger = false) => Add(AppUi.Button(text, action, quiet, danger));
    void AddAsyncButton(string text, Func<Task> action, bool quiet = false, bool danger = false) => Add(AppUi.AsyncButton(text, action, quiet, danger));
    void AddField(string label, View control) { Add(AppUi.Label(label)); Add(control); }
    VaultStore Store => AppSession.Store ?? throw new InvalidOperationException("Sessie is vergrendeld.");

    // ---------- Stoplicht ----------
    void BuildStoplicht()
    {
        Header("Hoe is het nu?", "Kies de kleur die bij jou past. Dit wordt niet automatisch naar iemand gestuurd.");
        var colour = AppUi.Picker("Kies een kleur", new[] { "Groen", "Oranje", "Rood" }, "Groen");
        AddField("Mijn kleur", colour);
        AddLabel("Waarom? Je mag meer dan één ding kiezen.", title: true);
        var reasonChecks = new List<(string Text, CheckBox Box)>();
        foreach (var item in Reasons)
        {
            var cb = new CheckBox { Color = AppUi.Accent };
            cb.CheckedChanged += (_, _) => AppSession.Touch();
            reasonChecks.Add((item.Text, cb));
            Add(new HorizontalStackLayout { Spacing = 8, Children = { cb, AppUi.Label(item.Emoji + "  " + item.Text) } });
        }
        AddLabel("Wat heb ik nodig?", title: true);
        var needChecks = new List<(string Text, CheckBox Box)>();
        foreach (var item in Needs)
        {
            var cb = new CheckBox { Color = AppUi.Accent };
            cb.CheckedChanged += (_, _) => AppSession.Touch();
            needChecks.Add((item.Text, cb));
            Add(new HorizontalStackLayout { Spacing = 8, Children = { cb, AppUi.Label(item.Emoji + "  " + item.Text) } });
        }
        var note = AppUi.Editor("Wil je er iets bij schrijven? (mag leeg blijven)", height: 130);
        AddField("Extra tekst", note);
        AddAsyncButton("💾 Stoplicht opslaan", async () =>
        {
            var c = colour.SelectedItem?.ToString() ?? "Groen";
            var entry = new StoplichtEntry(Guid.NewGuid(), DateTime.Now, c,
                reasonChecks.Where(x => x.Box.IsChecked).Select(x => x.Text).ToArray(),
                needChecks.Where(x => x.Box.IsChecked).Select(x => x.Text).ToArray(), note.Text ?? "");
            Store.Save("light", entry.Id, entry);
            var message = c == "Rood"
                ? "Je hebt rood gekozen. Je hoeft dit niet alleen te doen. Mijn Gevoel waarschuwt niemand automatisch. Vertel iemand die je vertrouwt dat je hulp nodig hebt. Bij direct gevaar bel je 112. Je kunt ook 113 Zelfmoordpreventie bellen op 0800-0113."
                : c == "Oranje" ? "Je hebt oranje gekozen. Je kunt even rust nemen, je plan bekijken of dit delen met iemand die je vertrouwt." : "Fijn dat het groen gaat.";
            await DisplayAlertAsync("Stoplicht opgeslagen", message, "OK");
            Build();
        });
        AddButton("📤 Dit delen met mijn begeleider", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Share)), quiet: true);
        AddButton("🆘 Mijn plan bekijken", () => Navigation.PushAsync(new FeaturePage(FeatureKind.SafetyPlan)), quiet: true);
    }

    void BuildStoplichtHistory()
    {
        Header("Mijn stoplicht-overzicht", "Je eerdere meldingen. Alleen jij ziet deze gegevens totdat je zelf iets deelt.");
        AddButton("🚦 Nieuwe stoplicht-melding", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Stoplicht)));
        AddButton("📤 Delen met mijn begeleider", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Share)), quiet: true);
        var logs = Store.All<ShareLogEntry>("sharelog").OrderByDescending(x => x.Created).ToList();
        AddLabel(logs.Count == 0 ? "Je hebt nog niets gedeeld." : $"Je hebt {logs.Count} keer gedeeld. Laatste keer: {logs[0].Created:dd-MM-yyyy HH:mm}.", muted: true);
        var items = Store.All<StoplichtEntry>("light").OrderByDescending(x => x.Created).ToList();
        if (items.Count == 0) AddLabel("Je hebt nog niets ingevuld.", muted: true);
        foreach (var e in items)
        {
            var colour = e.Colour switch { "Rood" => "🔴", "Oranje" => "🟠", _ => "🟢" };
            var layout = new VerticalStackLayout { Spacing = 5 };
            layout.Children.Add(AppUi.Label($"{colour} {e.Colour} — {e.Created:dddd d MMMM yyyy HH:mm}", title: true));
            if (e.Reasons.Length > 0) layout.Children.Add(AppUi.Label("Waarom: " + string.Join(", ", e.Reasons)));
            if (e.Needs.Length > 0) layout.Children.Add(AppUi.Label("Nodig: " + string.Join(", ", e.Needs)));
            if (!string.IsNullOrWhiteSpace(e.Text)) layout.Children.Add(AppUi.Label(e.Text));
            layout.Children.Add(AppUi.Button("📤 Dit delen", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Share, e.Id)), quiet: true));
            layout.Children.Add(AppUi.Button("🗑 Weggooien", async () =>
            {
                if (await DisplayAlertAsync("Weggooien?", "Deze melding definitief verwijderen?", "Verwijderen", "Annuleren")) { Store.Delete("light", e.Id); Build(); }
            }, danger: true));
            Add(AppUi.Card(layout));
        }
    }

    // ---------- Dagboek en briefjes ----------
    void BuildJournal(bool withMood)
    {
        string kind = withMood ? "diary" : "note";
        Header(withMood ? "Dagboek" : "Van me afschrijven", withMood
            ? "Hoe was je dag? Kies eventueel een gezichtje en schrijf wat je wilt."
            : "Schrijf op wat je dwarszit. Je kunt het bewaren of weer weggooien.");
        var mood = AppUi.Picker("Hoe voel ik me?", new[] { "Geen gezichtje", "😄 Blij", "🙂 Goed", "😐 Gaat wel", "😟 Niet fijn", "😢 Verdrietig" }, "Geen gezichtje");
        if (withMood) AddField("Gevoel", mood);
        var text = AppUi.Editor("Schrijf hier…", height: 180);
        AddField("Tekst", text);
        var status = AppUi.Label("");
        Guid? current = null;
        void ReloadList(VerticalStackLayout list)
        {
            list.Children.Clear();
            var entries = Store.All<JournalEntry>(kind).OrderByDescending(x => x.Created).ToList();
            if (entries.Count == 0) list.Children.Add(AppUi.Label("Nog niets opgeschreven.", muted: true));
            foreach (var e in entries)
            {
                string snip = e.Text.Replace('\n', ' ').Replace('\r', ' ');
                if (snip.Length > 56) snip = snip[..56] + "…";
                var emoji = e.Mood > 0 ? Moods[e.Mood - 1].Emoji + " " : "";
                list.Children.Add(AppUi.Button($"{e.Created:dd-MM-yyyy HH:mm}  {emoji}{(snip.Length == 0 ? "(alleen gevoel)" : snip)}", () =>
                {
                    current = e.Id; text.Text = e.Text;
                    if (withMood) mood.SelectedIndex = e.Mood;
                    status.Text = "Geselecteerd om te bekijken of aan te passen.";
                }, quiet: true));
            }
        }
        var list = new VerticalStackLayout { Spacing = 4 };
        AddAsyncButton("💾 Bewaren", async () =>
        {
            int mv = withMood ? Math.Clamp(mood.SelectedIndex, 0, 5) : 0;
            if (string.IsNullOrWhiteSpace(text.Text) && mv == 0) { status.Text = "Schrijf eerst iets op of kies een gezichtje."; return; }
            JournalEntry? old = current is Guid id ? Store.Load<JournalEntry>(kind, id) : null;
            var entry = old is null ? new JournalEntry(Guid.NewGuid(), DateTime.Now, mv, text.Text ?? "") : old with { Mood = mv, Text = text.Text ?? "" };
            Store.Save(kind, entry.Id, entry); current = entry.Id; status.Text = "Opgeslagen ✔"; ReloadList(list);
        });
        AddButton("✨ Nieuw", () => { current = null; text.Text = ""; if (withMood) mood.SelectedIndex = 0; status.Text = ""; }, quiet: true);
        AddAsyncButton("🗑 Geselecteerde verwijderen", async () =>
        {
            if (current is not Guid id) { status.Text = "Kies eerst een eerder stukje."; return; }
            if (await DisplayAlertAsync("Definitief verwijderen?", "Deze tekst kan niet worden teruggehaald.", "Verwijderen", "Annuleren")) { Store.Delete(kind, id); current = null; text.Text = ""; status.Text = "Verwijderd."; ReloadList(list); }
        }, danger: true);
        AddButton("🔊 Voorlezen", () => { if (!string.IsNullOrWhiteSpace(text.Text)) AppUi.Speak(text.Text); }, quiet: true);
        Add(status);
        AddLabel("Eerder opgeschreven", title: true);
        Add(list);
        ReloadList(list);
    }

    // ---------- Dag en agenda ----------
    void BuildAgenda()
    {
        Header("Agenda", "Plan afspraken en activiteiten. Je kunt elke taak afvinken wanneer die klaar is.");
        var date = new DatePicker { Date = DateTime.Today, FontSize = AppUi.BaseFont, TextColor = AppUi.Foreground, BackgroundColor = AppUi.Surface };
        var title = AppUi.Entry("Wat ga je doen?");
        var time = AppUi.Entry("Hoe laat? Bijvoorbeeld 14:30 (mag leeg blijven)", keyboard: Keyboard.Text);
        var iconPicker = AppUi.Picker("Plaatje kiezen", AgendaIcons.Select(x => x.Emoji + " " + x.Name), "⭐ Anders");
        var status = AppUi.Label("");
        var list = new VerticalStackLayout { Spacing = 6 };
        void Reload()
        {
            list.Children.Clear();
            var items = Store.All<AgendaItem>("agenda").Where(a => a.Date.Date == (date.Date ?? DateTime.Today).Date).OrderBy(a => a.Time).ToList();
            if (items.Count == 0) list.Children.Add(AppUi.Label("Niets gepland voor deze dag.", muted: true));
            foreach (var item in items)
            {
                var cb = new CheckBox { IsChecked = item.Done, Color = AppUi.Accent, VerticalOptions = LayoutOptions.Center };
                cb.CheckedChanged += (_, e) => { Store.Save("agenda", item.Id, item with { Done = e.Value }); AppSession.Touch(); Reload(); };
                var label = AppUi.Label($"{item.Icon} {(item.Time.Length > 0 ? item.Time + "  " : "")}{item.Title}" + (item.Done ? "  ✔" : ""));
                var row = new HorizontalStackLayout { Spacing = 8, Children = { cb, label } };
                var wrap = new VerticalStackLayout { Children = { row, AppUi.Button("🗑 Verwijderen", async () => { if (await DisplayAlertAsync("Verwijderen?", "Deze afspraak weghalen?", "Verwijderen", "Annuleren")) { Store.Delete("agenda", item.Id); Reload(); } }, quiet: true) } };
                list.Children.Add(AppUi.Card(wrap));
            }
        }
        date.DateSelected += (_, _) => Reload();
        AddField("Dag", date); AddField("Activiteit", title); AddField("Tijd", time); AddField("Plaatje", iconPicker);
        AddAsyncButton("➕ Toevoegen", async () =>
        {
            var t = title.Text?.Trim() ?? "";
            if (t.Length == 0) { status.Text = "Schrijf eerst op wat je gaat doen."; return; }
            string timeText = (time.Text ?? "").Trim().Replace('.', ':');
            if (timeText.Length > 0 && !TimeOnly.TryParse(timeText, CultureInfo.InvariantCulture, DateTimeStyles.None, out _)) { status.Text = "Gebruik bijvoorbeeld 14:30 als tijd."; return; }
            var icon = AgendaIcons[Math.Clamp(iconPicker.SelectedIndex, 0, AgendaIcons.Length - 1)].Emoji;
            var agendaId = Guid.NewGuid();
            Store.Save("agenda", agendaId, new AgendaItem(agendaId, date.Date ?? DateTime.Today, timeText, t, icon, false));
            title.Text = ""; time.Text = ""; status.Text = "Toegevoegd ✔"; Reload();
        });
        Add(status); AddLabel("Activiteiten op deze dag", title: true); Add(list); Reload();
    }

    void BuildDay(DateTime day)
    {
        Header(day.Date == DateTime.Today ? "Vandaag" : "Morgen bekijken", "Eerst-dan overzicht. Je kunt alvast zien wat er op de planning staat.");
        var items = Store.All<AgendaItem>("agenda").Where(a => a.Date.Date == day.Date).OrderBy(a => a.Time.Length == 0 ? "99:99" : a.Time).ToList();
        AddLabel(day.ToString("dddd d MMMM yyyy", CultureInfo.GetCultureInfo("nl-NL")), title: true);
        var next = items.FirstOrDefault(x => !x.Done);
        Add(AppUi.Card(new VerticalStackLayout { Children = {
            AppUi.Label("Eerst", title: true), AppUi.Label(next is null ? "Er staat geen volgende activiteit gepland." : $"{next.Icon} {(next.Time.Length > 0 ? next.Time + "  " : "")}{next.Title}"),
            AppUi.Label("Daarna", title: true), AppUi.Label(items.FirstOrDefault(x => !x.Done && x.Id != next?.Id) is { } second ? $"{second.Icon} {second.Title}" : "Je volgende stap verschijnt hier als je agenda is ingevuld.")
        } }));
        foreach (var item in items)
        {
            var cb = new CheckBox { IsChecked = item.Done, Color = AppUi.Accent };
            cb.CheckedChanged += (_, e) => { Store.Save("agenda", item.Id, item with { Done = e.Value }); AppSession.Touch(); };
            Add(AppUi.Card(new HorizontalStackLayout { Spacing = 8, Children = { cb, AppUi.Label($"{item.Icon} {(item.Time.Length > 0 ? item.Time + "  " : "")}{item.Title}") } }));
        }
        AddButton("📅 Agenda openen", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Agenda)));
        AddButton("✅ Stappenplannen", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Routines)), quiet: true);
        AddButton("⏳ Timer", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Timer)), quiet: true);
    }

    // ---------- Stappenplannen ----------
    void SeedRoutines()
    {
        if (AppSession.Settings.RoutinesSeeded) return;
        foreach (var r in new[]
        {
            new Routine(Guid.NewGuid(), "Ochtend", "☀️", new[] { "Opstaan", "Naar de wc", "Gezicht wassen", "Tanden poetsen", "Aankleden", "Ontbijten" }),
            new Routine(Guid.NewGuid(), "Tanden poetsen", "🦷", new[] { "Tandpasta op de tandenborstel", "Boven poetsen", "Onder poetsen", "Tong poetsen", "Mond spoelen" }),
            new Routine(Guid.NewGuid(), "Avond", "🌙", new[] { "Tas voor morgen klaarzetten", "Tanden poetsen", "Pyjama aan", "Licht uit" })
        }) Store.Save("routine", r.Id, r);
        AppSession.Settings.RoutinesSeeded = true; AppSession.SaveSettings();
    }

    void BuildRoutines()
    {
        SeedRoutines();
        Header("Stappenplannen", "Doe iets stap voor stap. Je kunt bestaande plannen aanpassen of je eigen plan maken.");
        var list = new VerticalStackLayout { Spacing = 6 };
        void Reload()
        {
            list.Children.Clear();
            foreach (var r in Store.All<Routine>("routine").OrderBy(x => x.Title))
            {
                var routine = r;
                var row = new VerticalStackLayout { Spacing = 4, Children =
                {
                    AppUi.Button($"{routine.Icon} {routine.Title} ({routine.Steps.Length} stappen)", () => { _runningRoutine = routine; _routineStep = 0; ShowRoutineRun(); }),
                    new HorizontalStackLayout { Children =
                    {
                        AppUi.Button("✏️ Aanpassen", () => FillRoutineEditor(routine), quiet: true),
                        AppUi.Button("🗑", async () => { if (await DisplayAlertAsync("Verwijderen?", "Dit stappenplan weggooien?", "Verwijderen", "Annuleren")) { Store.Delete("routine", routine.Id); Reload(); } }, quiet: true)
                    } }
                } };
                list.Children.Add(AppUi.Card(row));
            }
        }
        Add(list); Reload();
        AddLabel("Stappenplan maken of aanpassen", title: true);
        _routineName = AppUi.Entry("Naam van het stappenplan"); _routineIcon = AppUi.Entry("Emoji (bijvoorbeeld ✅", "📝"); _routineSteps = AppUi.Editor("Elke stap op een nieuwe regel", height: 140);
        AddField("Naam", _routineName); AddField("Plaatje", _routineIcon); AddField("Stappen", _routineSteps);
        AddAsyncButton("💾 Stappenplan bewaren", async () =>
        {
            var name = _routineName.Text?.Trim() ?? "";
            var steps = (_routineSteps.Text ?? "").Split('\n').Select(x => x.Trim()).Where(x => x.Length > 0).ToArray();
            if (name.Length == 0 || steps.Length == 0) { await DisplayAlertAsync("Niet compleet", "Vul een naam en minstens één stap in.", "OK"); return; }
            var r = new Routine(_editingRoutineId ?? Guid.NewGuid(), name, string.IsNullOrWhiteSpace(_routineIcon.Text) ? "📝" : _routineIcon.Text.Trim(), steps);
            Store.Save("routine", r.Id, r); _editingRoutineId = null; _routineName.Text = ""; _routineIcon.Text = "📝"; _routineSteps.Text = ""; Reload();
        });
    }

    void FillRoutineEditor(Routine r)
    {
        _editingRoutineId = r.Id;
        if (_routineName is not null) _routineName.Text = r.Title;
        if (_routineIcon is not null) _routineIcon.Text = r.Icon;
        if (_routineSteps is not null) _routineSteps.Text = string.Join("\n", r.Steps);
    }

    void ShowRoutineRun()
    {
        var routine = _runningRoutine;
        if (routine is null) return;
        _root.Children.Clear();
        Header($"{routine.Icon} {routine.Title}", $"Stap {_routineStep + 1} van {routine.Steps.Length}");
        Add(AppUi.Card(new VerticalStackLayout { VerticalOptions = LayoutOptions.Center, MinimumHeightRequest = 190, Children = {
            AppUi.Label(routine.Steps[Math.Clamp(_routineStep, 0, routine.Steps.Length - 1)], title: true)
        } }));
        var buttons = new HorizontalStackLayout { Spacing = 8 };
        buttons.Children.Add(AppUi.Button("← Vorige", () => { if (_routineStep > 0) _routineStep--; ShowRoutineRun(); }, quiet: true));
        buttons.Children.Add(AppUi.Button(_routineStep == routine.Steps.Length - 1 ? "Klaar ✔" : "Volgende →", async () =>
        {
            if (_routineStep >= routine.Steps.Length - 1) { await DisplayAlertAsync("Goed gedaan", "Je hebt alle stappen gedaan.", "Klaar"); _runningRoutine = null; Build(); }
            else { _routineStep++; ShowRoutineRun(); }
        }));
        Add(buttons);
        AddButton("Stoppen en terug", () => { _runningRoutine = null; Build(); }, quiet: true);
    }

    // ---------- Timer, ademhalen, rustplek ----------
    void BuildTimer()
    {
        Header("Timer", "Gebruik een rustige timer voor een taak of pauze.");
        var minutes = AppUi.Picker("Hoeveel minuten?", new[] { "1", "2", "3", "5", "10", "15", "20", "30" }, "5");
        var display = AppUi.Title("05:00"); display.HorizontalTextAlignment = TextAlignment.Center; display.FontSize = AppUi.TitleFont * 1.6;
        var status = AppUi.Label("Kies de tijd en druk op start.");
        _timer?.Stop(); _timer = null;
        void Render() => display.Text = $"{_timerRemaining / 60:00}:{_timerRemaining % 60:00}";
        AddField("Tijd", minutes); Add(display); Add(status);
        AddButton("▶ Start / pauze", () =>
        {
            if (_timer is { IsRunning: true }) { _timer.Stop(); status.Text = "Gepauzeerd."; return; }
            if (_timer is null || _timerRemaining <= 0)
            {
                _timerTotal = int.Parse(minutes.SelectedItem?.ToString() ?? "5") * 60;
                _timerRemaining = _timerTotal;
                _timer = Dispatcher.CreateTimer(); _timer.Interval = TimeSpan.FromSeconds(1);
                _timer.Tick += (_, _) => { _timerRemaining--; Render(); if (_timerRemaining <= 0) { _timer?.Stop(); status.Text = "⏰ De tijd is om!"; AppUi.Speak("De tijd is om."); } };
            }
            _timer.Start(); status.Text = "De timer loopt."; Render();
        });
        AddButton("↻ Opnieuw", () => { _timer?.Stop(); _timer = null; _timerRemaining = int.Parse(minutes.SelectedItem?.ToString() ?? "5") * 60; Render(); status.Text = "Klaar om te starten."; }, quiet: true);
    }

    void BuildBreath()
    {
        Header("Samen rustig ademhalen", "Adem gewoon rustig in en uit. Houd je adem niet vast. Stop als je duizelig wordt of het onprettig voelt.");
        var phase = AppUi.Title("Druk op Start als je er klaar voor bent"); phase.HorizontalTextAlignment = TextAlignment.Center; phase.FontSize = AppUi.TitleFont;
        var countdown = AppUi.Title(""); countdown.HorizontalTextAlignment = TextAlignment.Center;
        var start = AppUi.Button("▶ Start rustig ritme", () =>
        {
            _breathTimer?.Stop(); _breathIn = true; int count = 4;
            phase.Text = "Adem rustig in"; countdown.Text = count.ToString();
            _breathTimer = Dispatcher.CreateTimer(); _breathTimer.Interval = TimeSpan.FromSeconds(1);
            _breathTimer.Tick += (_, _) =>
            {
                count--; countdown.Text = count > 0 ? count.ToString() : "";
                if (count <= 0) { _breathIn = !_breathIn; count = 4; phase.Text = _breathIn ? "Adem rustig in" : "Adem rustig uit"; countdown.Text = "4"; }
            };
            _breathTimer.Start();
        });
        Add(phase); Add(countdown); Add(start);
        AddButton("■ Stop", () => { _breathTimer?.Stop(); _breathTimer = null; phase.Text = "Neem de tijd die je nodig hebt."; countdown.Text = ""; }, quiet: true);
        AddButton("🌿 Naar de rustplek", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Calm)));
    }

    void BuildCalm()
    {
        Header("Rustplek", "Kies een kleine stap om even te landen. Je hoeft niets perfect te doen.");
        var tip = AppUi.Label(CalmTips[0], title: true); tip.HorizontalTextAlignment = TextAlignment.Center;
        Add(AppUi.Card(new VerticalStackLayout { Padding = 18, MinimumHeightRequest = 150, VerticalOptions = LayoutOptions.Center, Children = { tip } }));
        AddButton("Volgende rusttip", () => { _calmTipIndex = (_calmTipIndex + 1) % CalmTips.Length; tip.Text = CalmTips[_calmTipIndex]; });
        AddButton("🫁 Samen ademhalen", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Breath)));
        AddButton("🚦 Mijn stoplicht invullen", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Stoplicht)), quiet: true);
        AddButton("🆘 Mijn plan bekijken", () => Navigation.PushAsync(new FeaturePage(FeatureKind.SafetyPlan)), quiet: true);
        var plan = Store.Load<SafetyPlan>("plan", Guid.Empty) ?? new SafetyPlan();
        AddLabel("Wat kan mij helpen?", title: true);
        AddLabel(string.IsNullOrWhiteSpace(plan.Helps) ? "Je hebt nog niets ingevuld bij Mijn plan." : plan.Helps);
        foreach (var contact in plan.Contacts.Where(x => !string.IsNullOrWhiteSpace(x.Name))) AddLabel($"📞 {contact.Name} {contact.Phone}");
    }

    // ---------- Prikkels, lichaam en gevoelswoorden ----------
    void BuildSensory()
    {
        Header("Prikkelmeter", "Hoe druk is het in mijn hoofd en om me heen? Kies een cijfer van 1 (rustig) tot 5 (veel te druk).");
        var head = new Slider { Minimum = 1, Maximum = 5, Value = 3, ThumbColor = AppUi.Accent, MinimumTrackColor = AppUi.Accent };
        var room = new Slider { Minimum = 1, Maximum = 5, Value = 3, ThumbColor = AppUi.Accent, MinimumTrackColor = AppUi.Accent };
        bool headTouched = false, roomTouched = false;
        var headLabel = AppUi.Label("3 — Gaat wel (raak de schuif aan om op te slaan)"); var roomLabel = AppUi.Label("3 — Gaat wel (raak de schuif aan om op te slaan)");
        string[] levels = { "", "Heel rustig", "Rustig", "Gaat wel", "Druk", "Veel te druk" };
        head.ValueChanged += (_, e) => { headTouched = true; headLabel.Text = $"{(int)Math.Round(e.NewValue)} — {levels[(int)Math.Round(e.NewValue)]}"; AppSession.Touch(); };
        room.ValueChanged += (_, e) => { roomTouched = true; roomLabel.Text = $"{(int)Math.Round(e.NewValue)} — {levels[(int)Math.Round(e.NewValue)]}"; AppSession.Touch(); };
        AddLabel("In mijn hoofd", title: true); Add(head); Add(headLabel);
        AddLabel("Om me heen (geluid, licht, mensen)", title: true); Add(room); Add(roomLabel);
        var status = AppUi.Label(""); Add(status);
        AddAsyncButton("💾 Metingen opslaan", async () =>
        {
            if (!headTouched && !roomTouched) { status.Text = "Raak eerst minstens één schuif aan."; return; }
            int h = (int)Math.Round(head.Value), r = (int)Math.Round(room.Value);
            if (headTouched) { var headId = Guid.NewGuid(); Store.Save("scale", headId, new ScaleEntry(headId, DateTime.Now, "Hoofd", h, "")); }
            if (roomTouched) { var roomId = Guid.NewGuid(); Store.Save("scale", roomId, new ScaleEntry(roomId, DateTime.Now, "Omgeving", r, "")); }
            status.Text = "Opgeslagen ✔";
            if ((headTouched && h >= 4) || (roomTouched && r >= 4)) await DisplayAlertAsync("Veel prikkels", "Misschien helpt het om naar de Rustplek te gaan of iemand te vertellen wat je nodig hebt.", "OK");
        });
        AddButton("🌿 Naar de rustplek", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Calm)), quiet: true);
    }

    void BuildBody()
    {
        Header("Mijn lichaam", "Waar merk je iets in je lijf? Kies een plek, beschrijf het kort en sla het op.");
        var area = AppUi.Picker("Waar voel ik iets?", new[] { "Hoofd", "Schouders", "Borst", "Buik", "Hart", "Handen", "Benen", "Hele lichaam", "Anders" }, "Buik");
        var feeling = AppUi.Picker("Wat merk ik?", new[] { "Spanning", "Pijn", "Onrust", "Warmte", "Koude", "Tintelingen", "Rust", "Anders" }, "Spanning");
        var level = AppUi.Picker("Hoe sterk?", new[] { "1 — Heel weinig", "2 — Een beetje", "3 — Gemiddeld", "4 — Veel", "5 — Heel veel" }, "3 — Gemiddeld");
        var note = AppUi.Editor("Extra uitleg (mag leeg blijven)", height: 90);
        var status = AppUi.Label("");
        AddField("Plek", area); AddField("Gevoel", feeling); AddField("Sterkte", level); AddField("Notitie", note); Add(status);
        AddAsyncButton("💾 Opslaan", async () =>
        {
            var n = $"{area.SelectedItem}: {feeling.SelectedItem}" + (string.IsNullOrWhiteSpace(note.Text) ? "" : " — " + note.Text.Trim());
            var id = Guid.NewGuid();
            Store.Save("scale", id, new ScaleEntry(id, DateTime.Now, "Lichaam", Math.Clamp(level.SelectedIndex + 1, 1, 5), n));
            status.Text = "Opgeslagen ✔";
            await Task.CompletedTask;
        });
    }

    void BuildMoodHistory()
    {
        Header("Hoe voel ik me?", "Een rustig overzicht van de laatste 14 dagen. Dit is geen oordeel en geen diagnose.");
        var entries = Store.All<JournalEntry>("diary").Where(e => e.Mood > 0).ToList();
        for (int d = 13; d >= 0; d--)
        {
            var day = DateTime.Today.AddDays(-d);
            var list = entries.Where(e => e.Created.Date == day).ToList();
            if (list.Count == 0) Add(AppUi.Card(AppUi.Label(day.ToString("ddd d MMM", CultureInfo.GetCultureInfo("nl-NL")) + "   —")));
            else
            {
                double avg = list.Average(e => e.Mood);
                int mood = Math.Clamp((int)Math.Round(avg), 1, 5);
                Add(AppUi.Card(AppUi.Label($"{day.ToString("ddd d MMM", CultureInfo.GetCultureInfo("nl-NL"))}   {Moods[mood - 1].Emoji} {Moods[mood - 1].Name}   ({list.Count} keer)")));
            }
        }
        AddLabel("Een lange balk betekent niet automatisch dat alles goed is; kijk vooral wat jij zelf herkent.", muted: true);
        AddButton("📖 Naar mijn dagboek", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Journal)), quiet: true);
    }

    void BuildFeelingWords()
    {
        Header("Gevoelswoorden", "Hier lees je wat gevoelens kunnen betekenen. Kies woorden die bij je passen.");
        foreach (var w in FeelingWords)
        {
            var item = w;
            Add(AppUi.Card(new VerticalStackLayout { Spacing = 5, Children = {
                AppUi.Label($"{item.Emoji} {item.Name}", title: true), AppUi.Label(item.Description),
                AppUi.Button("🔊 Voorlezen", () => AppUi.Speak(item.Name + ". " + item.Description), quiet: true)
            } }));
        }
    }

    // ---------- Kaarten, gesprekskaart, veiligheidsplan ----------
    void BuildCards()
    {
        Header("Kaarten om te laten zien", "Tik op een kaart om de tekst groot op het scherm te tonen. Handig als praten lastig is.");
        foreach (var c in BasicCards) Add(AppUi.Button($"{c.Emoji}   {c.Text}", async () => await ShowBigCard(c.Emoji, c.Text), quiet: true));
        AddLabel("Mijn eigen kaarten", title: true);
        foreach (var card in Store.All<TalkCard>("card").OrderBy(x => x.Text))
        {
            var c = card;
            Add(AppUi.Card(new VerticalStackLayout { Children = {
                AppUi.Button($"{c.Emoji}   {c.Text}", async () => await ShowBigCard(c.Emoji, c.Text)),
                AppUi.Button("🗑 Verwijderen", async () => { if (await DisplayAlertAsync("Verwijderen?", "Deze kaart weggooien?", "Verwijderen", "Annuleren")) { Store.Delete("card", c.Id); Build(); } }, quiet: true)
            } }));
        }
        var emoji = AppUi.Entry("Emoji", "💬"); var text = AppUi.Entry("Tekst op de kaart");
        AddLabel("Eigen kaart maken", title: true); AddField("Plaatje", emoji); AddField("Tekst", text);
        AddAsyncButton("➕ Kaart toevoegen", async () =>
        {
            if (string.IsNullOrWhiteSpace(text.Text))
            {
                await DisplayAlertAsync("Tekst ontbreekt", "Vul eerst tekst in voor de kaart.", "OK");
                return;
            }
            var id = Guid.NewGuid();
            Store.Save("card", id, new TalkCard(id, string.IsNullOrWhiteSpace(emoji.Text) ? "💬" : emoji.Text.Trim(), text.Text.Trim()));
            Build();
        });
    }

    async Task ShowBigCard(string emoji, string text)
    {
        var page = new ContentPage { Title = "Kaart", BackgroundColor = AppUi.Background };
        var label = AppUi.Label(text, title: true); label.FontSize = AppUi.TitleFont * 1.6; label.HorizontalTextAlignment = TextAlignment.Center; label.VerticalTextAlignment = TextAlignment.Center;
        var em = AppUi.Label(emoji, title: true); em.FontSize = AppUi.TitleFont * 3; em.HorizontalTextAlignment = TextAlignment.Center;
        page.Content = new ScrollView { Content = AppUi.Stack(em, label, AppUi.Button("🔊 Voorlezen", () => AppUi.Speak(text)), AppUi.Button("Terug", async () => await Navigation.PopAsync(), quiet: true)) };
        await Navigation.PushAsync(page);
    }

    void BuildTalkPrep()
    {
        Header("Gesprekskaart", "Een gesprek met je begeleider of dokter? Schrijf van tevoren op wat je wilt zeggen.");
        var current = Store.Load<TalkPrep>("talk", Guid.Empty) ?? new TalkPrep();
        var tell = AppUi.Editor("Wat wil ik vertellen?", current.Tell, 100);
        var ask = AppUi.Editor("Wat wil ik vragen?", current.Ask, 100);
        var want = AppUi.Editor("Wat wil ik dat er gebeurt?", current.Want, 100);
        var status = AppUi.Label("");
        string Compose() => $"Ik wil vertellen:\n{tell.Text?.Trim()}\n\nIk wil vragen:\n{ask.Text?.Trim()}\n\nIk wil dat:\n{want.Text?.Trim()}";
        AddField("Wat wil ik vertellen?", tell); AddField("Wat wil ik vragen?", ask); AddField("Wat wil ik dat er gebeurt?", want);
        AddButton("💾 Bewaren", () => { Store.Save("talk", Guid.Empty, new TalkPrep { Tell = tell.Text ?? "", Ask = ask.Text ?? "", Want = want.Text ?? "" }); status.Text = "Opgeslagen ✔"; });
        AddButton("👀 Laat dit zien", async () => await ShowBigCard("🗣️", Compose()), quiet: true);
        AddButton("🔊 Voorlezen", () => AppUi.Speak(Compose()), quiet: true);
        AddButton("📤 Delen…", async () => await Share.Default.RequestAsync(new ShareTextRequest { Title = "Mijn gesprekskaart", Text = Compose() }), quiet: true);
        AddButton("🧹 Leegmaken", () => { tell.Text = ""; ask.Text = ""; want.Text = ""; status.Text = "Niet opgeslagen."; }, quiet: true);
        Add(status);
    }

    void BuildSafetyPlan()
    {
        Header("Mijn plan", "Wie kan ik bellen of aanspreken? Wat helpt mij? Je plan wordt getoond als je oranje of rood kiest.");
        var plan = Store.Load<SafetyPlan>("plan", Guid.Empty) ?? new SafetyPlan();
        var contactsText = AppUi.Editor("Eén contact per regel, in dit formaat: Naam | telefoonnummer", string.Join("\n", plan.Contacts.Select(x => x.Name + " | " + x.Phone)), 120);
        var helps = AppUi.Editor("Wat helpt mij? (bijvoorbeeld rustige plek, water, muziek of wandelen)", plan.Helps, 150);
        var status = AppUi.Label("");
        AddField("Contactpersonen", contactsText); AddField("Wat helpt mij", helps);
        AddButton("💾 Plan bewaren", () =>
        {
            var contacts = contactsText.Text!.Split('\n').Select(line => line.Trim()).Where(line => line.Length > 0).Select(line =>
            {
                var parts = line.Split('|', 2);
                return new ContactPerson(parts[0].Trim(), parts.Length > 1 ? parts[1].Trim() : "");
            }).ToList();
            Store.Save("plan", Guid.Empty, new SafetyPlan { Contacts = contacts, Helps = helps.Text ?? "" });
            status.Text = "Opgeslagen ✔";
        });
        Add(status);
        AddLabel("Belangrijk", title: true);
        AddLabel("Mijn Gevoel waarschuwt niemand en belt niemand automatisch. Vertel zelf aan iemand dat je hulp nodig hebt. Bij direct gevaar bel je 112. In Nederland kun je ook 113 Zelfmoordpreventie bellen op 0800-0113.");
    }

    // ---------- Delen met begeleider ----------
    void BuildShare()
    {
        Header("Delen met mijn begeleider", "Jij kiest wat je deelt. Deel het bestand en de code via verschillende kanalen. Deelcodes zijn geen wachtwoorden van je account.");
        var all = Store.All<StoplichtEntry>("light").OrderByDescending(x => x.Created).Take(40).ToList();
        if (all.Count == 0) { AddLabel("Je hebt nog geen stoplicht-meldingen om te delen."); return; }
        var checks = new List<(StoplichtEntry Entry, CheckBox Check)>();
        foreach (var item in all)
        {
            var cb = new CheckBox { IsChecked = _targetShareId is Guid id && id == item.Id, Color = AppUi.Accent };
            cb.CheckedChanged += (_, _) => AppSession.Touch();
            checks.Add((item, cb));
            var sub = string.Join(", ", item.Reasons);
            Add(AppUi.Card(new HorizontalStackLayout { Spacing = 8, Children = {
                cb,
                new VerticalStackLayout { Spacing = 2, Children = {
                    AppUi.Label($"{(item.Colour == "Rood" ? "🔴" : item.Colour == "Oranje" ? "🟠" : "🟢")} {item.Colour} — {item.Created:dd-MM-yyyy HH:mm}", title: true),
                    AppUi.Label(string.IsNullOrWhiteSpace(sub) ? (item.Text.Length > 0 ? item.Text : "Geen extra tekst") : sub, muted: true)
                } }
            } }));
        }
        var format = AppUi.Picker("Bestandsvorm", new[] { "Versleuteld deelbestand (.mgdeel)", "Versleutelde HTML-pagina", "Gewone tekst (niet versleuteld)" }, "Versleuteld deelbestand (.mgdeel)");
        var codeEntry = AppUi.Entry("Eigen deelcode (leeg = automatisch maken)");
        var status = AppUi.Label("");
        AddField("Hoe wil je delen?", format);
        AddField("Deelcode", codeEntry);
        AddLabel("Bij gewone tekst kan iedereen de inhoud lezen. Gebruik dat alleen als je dit echt wilt.", muted: true);
        Add(status);
        AddAsyncButton("📤 Geselecteerde meldingen delen", async () =>
        {
            var selected = checks.Where(x => x.Check.IsChecked).Select(x => x.Entry).ToList();
            if (selected.Count == 0) { status.Text = "Kies eerst minstens één melding."; return; }
            int f = Math.Max(0, format.SelectedIndex);
            if (f == 2 && !await DisplayAlertAsync("Let op: gewone tekst", "Dit bestand is niet versleuteld. Iedereen die het bestand krijgt kan het lezen. Wil je doorgaan?", "Delen", "Annuleren")) return;
            string code = (codeEntry.Text ?? "").Trim();
            if (f < 2 && string.IsNullOrWhiteSpace(code)) code = ShareService.NewShareCode();
            string path;
            if (f == 0)
            {
                path = System.IO.Path.Combine(FileSystem.CacheDirectory, $"MijnGevoel-deel-{DateTime.Now:yyyyMMdd-HHmmss}.mgdeel");
                await File.WriteAllBytesAsync(path, ShareService.Create(AppSession.Username, selected, code));
            }
            else if (f == 1)
            {
                path = System.IO.Path.Combine(FileSystem.CacheDirectory, $"MijnGevoel-deel-{DateTime.Now:yyyyMMdd-HHmmss}.html");
                await File.WriteAllTextAsync(path, ShareService.CreateHtml(AppSession.Username, selected, code), new UTF8Encoding(false));
            }
            else
            {
                path = System.IO.Path.Combine(FileSystem.CacheDirectory, $"MijnGevoel-deel-{DateTime.Now:yyyyMMdd-HHmmss}.txt");
                await File.WriteAllTextAsync(path, ShareService.PlainText(AppSession.Username, selected), new UTF8Encoding(false));
            }
            var log = new ShareLogEntry(Guid.NewGuid(), DateTime.Now, selected.Count);
            Store.Save("sharelog", log.Id, log);
            await Share.Default.RequestAsync(new ShareFileRequest { Title = "Mijn Gevoel delen", File = new ShareFile(path) });
            if (f < 2)
            {
                await Clipboard.Default.SetTextAsync(code);
                await DisplayAlertAsync("Deelcode", $"De deelcode is gekopieerd naar je klembord:\n\n{code}\n\nStuur de code via een ander kanaal dan het bestand. Deel deze code niet met anderen.", "OK");
            }
            else status.Text = "Het tekstbestand is gedeeld. Onthoud dat het niet versleuteld is.";
        });
        AddButton("Selecteer alles", () => { foreach (var c in checks) c.Check.IsChecked = true; }, quiet: true);
        AddButton("Selecteer niets", () => { foreach (var c in checks) c.Check.IsChecked = false; }, quiet: true);
    }

    // GraphicsView inside a ScrollView can lose DragInteraction events on Android.
    // For the drawing screen, place the canvas directly in a Grid star row so the parent
    // scroll container cannot steal the finger drag and the canvas adapts to screen height.
    View CreateDrawingPageLayout()
    {
        var children = _root.Children.ToList();
        _root.Children.Clear();
        var grid = new Grid
        {
            Padding = new Thickness(16),
            RowSpacing = 8,
            BackgroundColor = AppUi.Background,
            ColumnDefinitions = { new ColumnDefinition(GridLength.Star) }
        };

        for (int i = 0; i < children.Count; i++)
        {
            // The canvas itself gets the remaining height; buttons stay in Auto rows.
            bool isDrawingCanvas = ReferenceEquals(children[i], _drawingView);
            grid.RowDefinitions.Add(isDrawingCanvas
                ? new RowDefinition(new GridLength(1, GridUnitType.Star))
                : new RowDefinition(GridLength.Auto));
            // The Grid.Add overload assigns the cell without relying on attached
            // static properties (which don't accept a generic IView in MAUI 10).
            grid.Add(children[i], 0, i);
        }

        if (_drawingView is not null)
        {
            _drawingView.HeightRequest = -1;
            _drawingView.VerticalOptions = LayoutOptions.Fill;
        }
        return grid;
    }

    // ---------- Tekenen en galerij ----------
    void BuildDraw()
    {
        Header("Tekenen", "Teken met je vinger in het witte vlak. Geef je tekening een naam en bewaar hem privé.");
        var title = AppUi.Entry("Naam van de tekening", "Mijn tekening");
        _strokes.Clear(); _activeStroke = null;
        _drawingView = new GraphicsView
        {
            Drawable = new FreeDrawDrawable(_strokes),
            MinimumHeightRequest = 160,
            BackgroundColor = Colors.White,
            HorizontalOptions = LayoutOptions.Fill,
            VerticalOptions = LayoutOptions.Fill
        };
        _drawingView.StartInteraction += (_, e) =>
        {
            var touches = e.Touches.ToArray();
            if (touches.Length == 0) return;
            var p = touches[0];
            _activeStroke = new List<PointF> { new((float)p.X, (float)p.Y) };
            _strokes.Add(_activeStroke);
            _drawingView.Invalidate(); AppSession.Touch();
        };
        _drawingView.DragInteraction += (_, e) =>
        {
            if (_activeStroke is null) return;
            foreach (var p in e.Touches) _activeStroke.Add(new PointF((float)p.X, (float)p.Y));
            _drawingView.Invalidate(); AppSession.Touch();
        };
        _drawingView.EndInteraction += (_, _) => { _activeStroke = null; _drawingView?.Invalidate(); };
        _drawingView.CancelInteraction += (_, _) => { _activeStroke = null; _drawingView?.Invalidate(); };
        AddField("Naam", title); Add(_drawingView);
        AddButton("↶ Alles wissen", () => { _strokes.Clear(); _activeStroke = null; _drawingView?.Invalidate(); }, quiet: true);
        AddAsyncButton("💾 Tekening bewaren", async () =>
        {
            if (_strokes.Count == 0) { await DisplayAlertAsync("Leeg tekenvlak", "Teken eerst iets in het witte vlak.", "OK"); return; }
            var name = string.IsNullOrWhiteSpace(title.Text) ? "Mijn tekening" : title.Text.Trim();
            var data = JsonSerializer.SerializeToUtf8Bytes(_strokes.Select(s => s.Select(p => new[] { p.X, p.Y }).ToArray()).ToArray());
            byte[] png = CreateDrawingPng(_strokes, Math.Max(1, (float)(_drawingView?.Width ?? 320)), Math.Max(1, (float)(_drawingView?.Height ?? 360)));
            var item = new DrawingEntry(Guid.NewGuid(), DateTime.Now, name, data, png);
            Store.Save("drawing", item.Id, item);
            await DisplayAlertAsync("Bewaard", "Je tekening is versleuteld opgeslagen.", "OK");
            _strokes.Clear(); _drawingView?.Invalidate(); title.Text = "Mijn tekening";
        });
        AddButton("🖼️ Mijn tekeningen bekijken", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Gallery)), quiet: true);
    }

    static byte[] CreateDrawingPng(List<List<PointF>> strokes, float viewWidth, float viewHeight)
    {
        using var bitmap = new SKBitmap(900, 1000);
        using var canvas = new SKCanvas(bitmap);
        canvas.Clear(SKColors.White);
        using var paint = new SKPaint { Color = SKColors.Black, StrokeWidth = 7, IsAntialias = true, Style = SKPaintStyle.Stroke, StrokeCap = SKStrokeCap.Round, StrokeJoin = SKStrokeJoin.Round };
        float sx = 900f / viewWidth, sy = 1000f / viewHeight;
        foreach (var stroke in strokes)
        {
            if (stroke.Count == 1) { canvas.DrawCircle(stroke[0].X * sx, stroke[0].Y * sy, 3.5f, paint); continue; }
            for (int i = 1; i < stroke.Count; i++) canvas.DrawLine(stroke[i - 1].X * sx, stroke[i - 1].Y * sy, stroke[i].X * sx, stroke[i].Y * sy, paint);
        }
        using var image = SKImage.FromBitmap(bitmap);
        using var data = image.Encode(SKEncodedImageFormat.Png, 95);
        return data.ToArray();
    }

    void BuildGallery()
    {
        Header("Mijn tekeningen", "Je tekeningen staan privé op je telefoon. Tik op een tekening om hem groter te bekijken.");
        var items = Store.All<DrawingEntry>("drawing").OrderByDescending(x => x.Created).ToList();
        if (items.Count == 0) AddLabel("Je hebt nog geen tekeningen.");
        foreach (var drawing in items)
        {
            var d = drawing;
            var wrap = new VerticalStackLayout { Spacing = 6, Children = { AppUi.Label($"{d.Title} — {d.Created:dd-MM-yyyy HH:mm}", title: true) } };
            if (d.Png is { Length: > 0 })
            {
                var png = d.Png;
                wrap.Children.Add(new Image { Source = ImageSource.FromStream(() => new MemoryStream(png)), Aspect = Aspect.AspectFit, HeightRequest = 240, BackgroundColor = Colors.White });
            }
            wrap.Children.Add(AppUi.Button("🗑 Verwijderen", async () => { if (await DisplayAlertAsync("Verwijderen?", "Deze tekening definitief verwijderen?", "Verwijderen", "Annuleren")) { Store.Delete("drawing", d.Id); Build(); } }, danger: true));
            Add(AppUi.Card(wrap));
        }
        AddButton("✏️ Nieuwe tekening maken", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Draw)));
    }

    sealed class FreeDrawDrawable : IDrawable
    {
        readonly List<List<PointF>> _strokes;
        public FreeDrawDrawable(List<List<PointF>> strokes) => _strokes = strokes;
        public void Draw(ICanvas canvas, RectF dirtyRect)
        {
            canvas.FillColor = Colors.White; canvas.FillRectangle(dirtyRect);
            canvas.StrokeColor = Colors.Black; canvas.StrokeSize = 4; canvas.StrokeLineCap = LineCap.Round;
            foreach (var stroke in _strokes)
            {
                if (stroke.Count == 1) { canvas.FillColor = Colors.Black; canvas.FillCircle(stroke[0].X, stroke[0].Y, 2); continue; }
                for (int i = 1; i < stroke.Count; i++) canvas.DrawLine(stroke[i - 1].X, stroke[i - 1].Y, stroke[i].X, stroke[i].Y);
            }
        }
    }

    // ---------- Privacy, weekoverzicht, instellingen, hulp ----------
    void BuildPrivacy()
    {
        Header("Mijn privacy", "Je kunt zien wat er bewaard is, je gegevens meenemen of je account en gegevens verwijderen.");
        var consent = Store.All<ConsentRecord>("consent").OrderByDescending(x => x.Created).FirstOrDefault();
        var counts = new[]
        {
            $"Dagboek: {Store.All<JournalEntry>("diary").Count} stukjes",
            $"Van me afschrijven: {Store.All<JournalEntry>("note").Count} briefjes",
            $"Stoplicht: {Store.All<StoplichtEntry>("light").Count} meldingen",
            $"Tekeningen: {Store.All<DrawingEntry>("drawing").Count}",
            $"Agenda: {Store.All<AgendaItem>("agenda").Count} activiteiten",
            $"Stappenplannen: {Store.All<Routine>("routine").Count}",
            $"Meters: {Store.All<ScaleEntry>("scale").Count} metingen",
            $"Eigen kaarten: {Store.All<TalkCard>("card").Count}",
            $"Delen met begeleider: {Store.All<ShareLogEntry>("sharelog").Count} keer"
        };
        Add(AppUi.Card(AppUi.Label(string.Join("\n", counts))));
        AddLabel(consent is null ? "Er is nog geen toestemming vastgelegd." : $"Toestemming: {consent.Created:dd-MM-yyyy} ({(consent.Mode == "samen" ? "samen met een vertegenwoordiger/begeleider" : "zelf")}).", muted: true);
        AddLabel("Je gegevens worden versleuteld opgeslagen in de privé-appmap van Android. Als je de app verwijdert, kan Android die map verwijderen. Maak eerst een back-up als je gegevens wilt bewaren.");
        AddAsyncButton("📥 Mijn gegevens exporteren (leesbaar JSON-bestand)", ExportDataAsync, quiet: true);
        AddAsyncButton("💾 Versleutelde back-up maken", CreateBackupAsync, quiet: true);
        AddAsyncButton("📦 Back-up terugzetten", RestoreBackupAsync, quiet: true);
        AddButton("⚙️ Account- en privacy-instellingen", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Settings)));
        AddAsyncButton("Toestemming opnieuw lezen", async () =>
        {
            await DisplayAlertAsync("Toestemming", "Je dagboek, tekeningen, agenda en andere gegevens worden versleuteld op dit apparaat opgeslagen. Je begeleider ziet alleen wat jij zelf deelt. Mijn Gevoel waarschuwt niemand automatisch. Je kunt je gegevens exporteren of verwijderen.", "Begrepen");
        }, quiet: true);
        AddLabel("Vragen of klachten? Vraag je begeleider wie verantwoordelijk is voor je gegevens en waar de privacyverklaring staat. Je kunt ook informatie vinden bij de Autoriteit Persoonsgegevens: autoriteitpersoonsgegevens.nl.");
    }

    void BuildWeek()
    {
        Header("Mijn week", "Een overzicht van wat je de afgelopen zeven dagen hebt bijgehouden. Er is geen goed of fout.");
        var since = DateTime.Today.AddDays(-6);
        var lights = Store.All<StoplichtEntry>("light").Where(x => x.Created.Date >= since).ToList();
        var moods = Store.All<JournalEntry>("diary").Where(x => x.Created.Date >= since && x.Mood > 0).ToList();
        var agenda = Store.All<AgendaItem>("agenda").Where(x => x.Date.Date >= since && x.Date.Date <= DateTime.Today).ToList();
        var most = moods.Count == 0 ? "nog niets gekozen" : Moods[moods.GroupBy(m => m.Mood).OrderByDescending(g => g.Count()).First().Key - 1].Name;
        var lines = new[]
        {
            $"🟢 Groen: {lights.Count(x => x.Colour == "Groen")}     🟠 Oranje: {lights.Count(x => x.Colour == "Oranje")}     🔴 Rood: {lights.Count(x => x.Colour == "Rood")}",
            $"Gezichtjes gekozen: {moods.Count}. Het meest gekozen: {most}.",
            $"Agenda: {agenda.Count(x => x.Done)} van {agenda.Count} afgevinkt.",
            $"Dagboek: {Store.All<JournalEntry>("diary").Count(x => x.Created.Date >= since && x.Text.Length > 0)} keer geschreven.",
            $"Van me afschrijven: {Store.All<JournalEntry>("note").Count(x => x.Created.Date >= since)} briefjes.",
            $"Tekeningen gemaakt: {Store.All<DrawingEntry>("drawing").Count(x => x.Created.Date >= since)}.",
            $"Prikkelmeter en lichaam: {Store.All<ScaleEntry>("scale").Count(x => x.Created.Date >= since)} keer ingevuld."
        };
        Add(AppUi.Card(AppUi.Label(string.Join("\n\n", lines))));
        AddLabel($"Periode: {since:dd MMMM} t/m {DateTime.Today:dd MMMM}. Dit overzicht blijft van jou, tenzij je zelf iets deelt.", muted: true);
        AddAsyncButton("📤 Mijn overzicht delen", async () => await Share.Default.RequestAsync(new ShareTextRequest { Title = "Mijn Gevoel - weekoverzicht", Text = string.Join("\n\n", lines) }), quiet: true);
    }

    void BuildSettings()
    {
        Header("Instellingen", "Pas de app aan zodat hij prettig voor jou werkt. Vergrendelen wist je gegevens niet.");
        var size = AppUi.Picker("Lettergrootte", new[] { "Normaal", "Groot", "Extra groot" }, new[] { "Normaal", "Groot", "Extra groot" }[Math.Clamp(AppSession.Settings.TextSize, 0, 2)]);
        var theme = AppUi.Picker("Kleuren", new[] { "Rustig", "Donker", "Hoog contrast" }, AppSession.Settings.Theme);
        var autoLockOptions = new[] { "1 minuut", "5 minuten", "10 minuten", "30 minuten" };
        var selectedAutoLock = AppSession.Settings.AutoLockMinutes switch { 1 => "1 minuut", 10 => "10 minuten", 30 => "30 minuten", _ => "5 minuten" };
        var autoLock = AppUi.Picker("Automatisch vergrendelen na", autoLockOptions, selectedAutoLock);
        var font = AppUi.Picker("Lettertype", new[] { "Standaard", "Verdana", "Arial", "Georgia" }, AppSession.Settings.FontName);
        var wide = new Switch { IsToggled = AppSession.Settings.WideLines, OnColor = AppUi.Accent };
        var read = new Switch { IsToggled = AppSession.Settings.ReadAloud, OnColor = AppUi.Accent };
        var anim = new Switch { IsToggled = AppSession.Settings.Animations, OnColor = AppUi.Accent };
        var capture = new Switch { IsToggled = AppSession.Settings.BlockCapture, OnColor = AppUi.Accent };
        wide.Toggled += (_, _) => AppSession.Touch();
        read.Toggled += (_, _) => AppSession.Touch();
        anim.Toggled += (_, _) => AppSession.Touch();
        capture.Toggled += (_, _) => AppSession.Touch();
        AddField("Lettergrootte", size); AddField("Kleuren", theme); AddField("Automatisch vergrendelen", autoLock); AddField("Lettertype", font);
        Add(new HorizontalStackLayout { Spacing = 8, Children = { wide, AppUi.Label("Ruime regelafstand") } });
        Add(new HorizontalStackLayout { Spacing = 8, Children = { read, AppUi.Label("Voorlezen beschikbaar maken") } });
        Add(new HorizontalStackLayout { Spacing = 8, Children = { anim, AppUi.Label("Animaties toestaan") } });
        Add(new HorizontalStackLayout { Spacing = 8, Children = { capture, AppUi.Label("Schermafbeeldingen blokkeren") } });
        AddLabel("Op Android voorkomt deze optie de meeste screenshots en schermopnames via de beveiligde vensterinstelling. Een tweede camera kan dit niet voorkomen.", muted: true);
        AddAsyncButton("💾 Instellingen toepassen", async () =>
        {
            AppSession.Settings.TextSize = Math.Clamp(size.SelectedIndex, 0, 2);
            AppSession.Settings.Theme = theme.SelectedItem?.ToString() ?? "Rustig";
            AppSession.Settings.AutoLockMinutes = new[] { 1, 5, 10, 30 }[Math.Clamp(autoLock.SelectedIndex, 0, 3)];
            AppSession.Settings.FontName = font.SelectedItem?.ToString() ?? "Standaard";
            AppSession.Settings.WideLines = wide.IsToggled;
            AppSession.Settings.ReadAloud = read.IsToggled;
            AppSession.Settings.Animations = anim.IsToggled;
            AppSession.Settings.BlockCapture = capture.IsToggled;
            AppSession.SaveSettings(); AndroidScreenPrivacy.Apply(capture.IsToggled);
            BackgroundColor = AppUi.Background; _root.BackgroundColor = AppUi.Background;
            Build();
            await DisplayAlertAsync("Opgeslagen", "Je instellingen zijn opgeslagen en toegepast.", "OK");
        });

        AddLabel("Wachtwoord wijzigen", title: true);
        var oldPassword = AppUi.Entry("Huidig wachtwoord", password: true);
        var newPassword = AppUi.Entry("Nieuw wachtwoord (minimaal 10 tekens)", password: true);
        var newPassword2 = AppUi.Entry("Nieuw wachtwoord herhalen", password: true);
        var pwStatus = AppUi.Label("");
        AddField("Huidig wachtwoord", oldPassword); AddField("Nieuw wachtwoord", newPassword); AddField("Herhaal nieuw wachtwoord", newPassword2); Add(pwStatus);
        AddAsyncButton("Wachtwoord wijzigen", async () =>
        {
            if (newPassword.Text != newPassword2.Text) { pwStatus.Text = "De nieuwe wachtwoorden zijn niet gelijk."; return; }
            bool ok = await Task.Run(() => AppSession.Accounts.ChangePassword(AppSession.Username, oldPassword.Text ?? "", newPassword.Text ?? ""));
            pwStatus.Text = ok ? "Wachtwoord gewijzigd ✔" : "Niet gelukt. Controleer je huidige wachtwoord en gebruik minimaal 10 tekens.";
            if (ok) { oldPassword.Text = ""; newPassword.Text = ""; newPassword2.Text = ""; }
        });

        AddLabel("Herstelcodes", title: true);
        AddLabel($"Je hebt nog {AppSession.Accounts.RecoveryCodesLeft(AppSession.Username)} herstelcode(s). Maak nieuwe codes als je er weinig over hebt. Oude codes vervallen.");
        var recoveryPassword = AppUi.Entry("Wachtwoord om herstelcodes te vernieuwen", password: true);
        AddField("Bevestig met wachtwoord", recoveryPassword);
        AddAsyncButton("🔑 Nieuwe herstelcodes maken", async () =>
        {
            var codes = await Task.Run(() => AppSession.Accounts.RegenerateRecoveryCodes(AppSession.Username, recoveryPassword.Text ?? ""));
            if (codes is null) { await DisplayAlertAsync("Niet gelukt", "Controleer je wachtwoord en probeer opnieuw.", "OK"); return; }
            string all = string.Join("\n", codes);
            await Clipboard.Default.SetTextAsync(all);
            await DisplayAlertAsync("Nieuwe herstelcodes", all + "\n\nDe codes zijn ook naar je klembord gekopieerd. Bewaar ze veilig, buiten deze telefoon.", "OK");
            recoveryPassword.Text = "";
        }, quiet: true);

        AddLabel("Back-up en gegevens", title: true);
        AddAsyncButton("💾 Versleutelde back-up maken", CreateBackupAsync, quiet: true);
        AddAsyncButton("📦 Back-up terugzetten", RestoreBackupAsync, quiet: true);
        AddAsyncButton("📥 Leesbare gegevens exporteren", ExportDataAsync, quiet: true);
        AddLabel("Account verwijderen", title: true);
        var deletePassword = AppUi.Entry("Wachtwoord om definitief te verwijderen", password: true);
        AddField("Bevestig met wachtwoord", deletePassword);
        AddAsyncButton("🗑 Mijn account en alle gegevens verwijderen", async () =>
        {
            if (!await DisplayAlertAsync("Alles verwijderen?", "Je account, dagboek, tekeningen, agenda en andere gegevens worden definitief verwijderd. Maak eerst een back-up als je iets wilt bewaren.", "Verwijderen", "Annuleren")) return;
            if (!await DisplayAlertAsync("Weet je het zeker?", "Dit kan niet ongedaan worden gemaakt.", "Ja, definitief verwijderen", "Annuleren")) return;
            var ok = await Task.Run(() => AppSession.Accounts.DeleteAccount(AppSession.Username, deletePassword.Text ?? ""));
            if (ok) await ((App)Application.Current!).LockToLoginAsync("Je account is verwijderd.");
            else await DisplayAlertAsync("Niet gelukt", "Het account is niet verwijderd. Controleer je wachtwoord.", "OK");
        }, danger: true);
    }

    async Task CreateBackupAsync()
    {
        var path = System.IO.Path.Combine(FileSystem.CacheDirectory, $"MijnGevoel-backup-{DateTime.Now:yyyy-MM-dd-HHmm}.zip");
        await Task.Run(() => BackupService.Create(AppSession.Accounts, AppSession.Username, path));
        await Share.Default.RequestAsync(new ShareFileRequest { Title = "Bewaar je versleutelde Mijn Gevoel-back-up", File = new ShareFile(path) });
        await DisplayAlertAsync("Back-up gemaakt", "De bestanden in de back-up zijn al versleuteld. Bewaar het zipbestand op een veilige plek.", "OK");
    }

    async Task RestoreBackupAsync()
    {
        var result = await FilePicker.Default.PickAsync(new PickOptions { PickerTitle = "Kies een Mijn Gevoel-back-up (.zip)" });
        if (result is null) return;
        var temp = System.IO.Path.Combine(FileSystem.CacheDirectory, "mg-restore-" + Guid.NewGuid().ToString("N") + ".zip");
        await using (var src = await result.OpenReadAsync())
        await using (var dst = File.Create(temp)) await src.CopyToAsync(dst);
        int count = await Task.Run(() => BackupService.Restore(AppSession.Accounts, temp));
        try { File.Delete(temp); } catch { }
        await DisplayAlertAsync("Back-up verwerkt", $"Er zijn {count} nieuwe bestanden teruggezet. Bestaande bestanden zijn niet overschreven. Mogelijk moet je uitloggen en opnieuw inloggen om een teruggezet account te gebruiken.", "OK");
    }

    async Task ExportDataAsync()
    {
        if (!await DisplayAlertAsync("Leesbaar bestand", "Het JSON-exportbestand is niet versleuteld. Iedereen die het opent kan je persoonlijke gegevens lezen. Wil je doorgaan?", "Exporteren", "Annuleren")) return;
        var path = System.IO.Path.Combine(FileSystem.CacheDirectory, $"Mijn-gegevens-{DateTime.Now:yyyy-MM-dd-HHmm}.json");
        await Task.Run(() => ExportService.ExportAll(Store, AppSession.Username, path));
        await Share.Default.RequestAsync(new ShareFileRequest { Title = "Bewaar of exporteer je Mijn Gevoel-gegevens", File = new ShareFile(path) });
    }

    void BuildHelp()
    {
        Header("Hulp", "Wat kun je doen in Mijn Gevoel?");
        AddLabel("🚦 Stoplicht: laat zien hoe het met je gaat en waarom. De app waarschuwt niemand automatisch.");
        AddLabel("🗓️ Mijn dag: bekijk vandaag of morgen, plan activiteiten en gebruik een timer of stappenplan.");
        AddLabel("🌿 Rust en gevoel: ademhalen, rusttips, prikkelmeter, lichaam en gevoelswoorden.");
        AddLabel("💬 Praten en delen: laat een kaart zien, bereid een gesprek voor of deel geselecteerde meldingen.");
        AddLabel("🎨 Maken en schrijven: teken, schrijf van je af of houd een dagboek bij.");
        AddLabel("🔐 Privacy: gegevens staan versleuteld op dit apparaat. Maak een back-up voordat je de app verwijdert of je account wist.");
        AddLabel("Als je je heel erg slecht voelt of zorgen hebt over jezelf, praat dan met iemand die je vertrouwt, zoals een begeleider, familielid of huisarts. In Nederland kun je gratis bellen met 113 Zelfmoordpreventie: 0800-0113, dag en nacht. Is er direct gevaar? Bel 112.");
        AddButton("Mijn privacy bekijken", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Privacy)));
    }
}
