namespace MijnGevoel.Core.Data;

/// <summary>Normalizeert optionele extra doelstappen en houdt invoer begrensd.</summary>
public static class GoalStepService
{
    public const int MaximumSteps = 20;
    public const int MaximumStepLength = 500;

    public static string[] Parse(string? multiline)
    {
        var steps = (multiline ?? string.Empty)
            .Split(new[] { "\r\n", "\n", "\r" }, StringSplitOptions.None)
            .Select(x => x.Trim())
            .Where(x => x.Length > 0)
            .ToArray();
        if (steps.Length > MaximumSteps) throw new ArgumentException($"Gebruik maximaal {MaximumSteps} extra stappen.", nameof(multiline));
        if (steps.Any(x => x.Length > MaximumStepLength)) throw new ArgumentException($"Elke extra stap mag maximaal {MaximumStepLength} tekens bevatten.", nameof(multiline));
        return steps;
    }
}
