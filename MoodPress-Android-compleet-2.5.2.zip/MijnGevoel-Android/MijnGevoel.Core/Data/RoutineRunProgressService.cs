namespace MijnGevoel.Core.Data;

/// <summary>Validates and updates saved progress for a step-by-step routine.</summary>
public static class RoutineRunProgressService
{
    public static int ResumeStep(RoutineRunProgress? progress, int stepCount)
    {
        if (stepCount <= 0 || progress is null || progress.Completed)
            return 0;

        return Math.Clamp(progress.CurrentStep, 0, stepCount - 1);
    }

    public static RoutineRunProgress AtStep(Guid routineId, int step, int stepCount, DateTime now) =>
        new(routineId, stepCount <= 0 ? 0 : Math.Clamp(step, 0, stepCount - 1), false, now);

    public static RoutineRunProgress Complete(Guid routineId, int step, int stepCount, DateTime now) =>
        new(routineId, stepCount <= 0 ? 0 : Math.Clamp(step, 0, stepCount - 1), true, now);
}
