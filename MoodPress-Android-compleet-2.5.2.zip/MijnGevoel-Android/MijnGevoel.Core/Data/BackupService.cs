using System.IO.Compression;
using System.Text.RegularExpressions;
using MijnGevoel.Core.Security;

namespace MijnGevoel.Core.Data;

/// <summary>Backups contain the existing encrypted account and vault files.</summary>
public static class BackupService
{
    const int MaxEntries = 20_000;
    const long MaxEntryBytes = 64L * 1024 * 1024;
    const long MaxAccountBytes = 2L * 1024 * 1024;
    const long MaxTotalBytes = 512L * 1024 * 1024;

    static readonly Regex AccountPath = new(@"^accounts/([A-Fa-f0-9]{64})\.json$", RegexOptions.Compiled | RegexOptions.CultureInvariant);
    static readonly Regex DataPath = new(@"^data/([A-Fa-f0-9]{64})/([a-z0-9][a-z0-9-]*-[A-Fa-f0-9]{32})\.mg$", RegexOptions.Compiled | RegexOptions.CultureInvariant);
    static readonly Regex DirectoryPath = new(@"^(accounts|data|data/[A-Fa-f0-9]{64})/$", RegexOptions.Compiled | RegexOptions.CultureInvariant);

    public static void Create(AccountService acc, string username, string zipPath)
    {
        var accountPath = acc.AccountFilePath(username);
        if (!File.Exists(accountPath)) throw new FileNotFoundException("Het accountbestand voor deze back-up bestaat niet.");
        var dataDirectory = acc.DataFolder(username);
        var destination = Path.GetFullPath(zipPath);
        Directory.CreateDirectory(Path.GetDirectoryName(destination)!);
        var temporary = destination + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            if (File.Exists(temporary)) File.Delete(temporary);
            using (var zip = ZipFile.Open(temporary, ZipArchiveMode.Create))
            {
                zip.CreateEntryFromFile(accountPath, "accounts/" + Path.GetFileName(accountPath), CompressionLevel.Optimal);
                if (Directory.Exists(dataDirectory))
                {
                    foreach (var file in Directory.GetFiles(dataDirectory, "*.mg"))
                        zip.CreateEntryFromFile(file, "data/" + Path.GetFileName(dataDirectory) + "/" + Path.GetFileName(file), CompressionLevel.Optimal);
                }
            }
            File.Move(temporary, destination, true);
        }
        finally { try { if (File.Exists(temporary)) File.Delete(temporary); } catch { } }
    }

    /// <summary>
    /// Validates the complete archive before writing anything. Only files created by this app are accepted;
    /// traversal paths, mismatched account folders, duplicate names, oversized archives and unknown payloads are rejected.
    /// Existing files are never overwritten. Returns the number of new files restored.
    /// </summary>
    public static int Restore(AccountService acc, string zipPath)
    {
        var baseDir = Path.GetFullPath(acc.BaseFolder);
        using var zip = ZipFile.OpenRead(zipPath);
        if (zip.Entries.Count == 0 || zip.Entries.Count > MaxEntries)
            throw new InvalidDataException("Dit is geen geldige MoodPress-back-up of het bestand bevat te veel onderdelen.");

        var validated = new List<(ZipArchiveEntry Entry, string RelativePath)>();
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        string? accountHash = null;
        long totalBytes = 0;

        foreach (var entry in zip.Entries)
        {
            var name = entry.FullName;
            if (string.IsNullOrWhiteSpace(name) || name.Contains('\\') || name.StartsWith('/') ||
                name.Split('/').Any(part => part is "." or ".."))
                throw new InvalidDataException("De back-up bevat een onveilige bestandsnaam en is geweigerd.");

            if (name.EndsWith('/'))
            {
                if (!DirectoryPath.IsMatch(name))
                    throw new InvalidDataException("De back-up bevat een onverwachte mapstructuur.");
                continue;
            }

            if (!seen.Add(name)) throw new InvalidDataException("De back-up bevat dubbele bestandsnamen.");
            totalBytes = checked(totalBytes + entry.Length);
            if (totalBytes > MaxTotalBytes) throw new InvalidDataException("De back-up is groter dan 512 MB en is geweigerd.");

            var accountMatch = AccountPath.Match(name);
            var dataMatch = DataPath.Match(name);
            if (accountMatch.Success)
            {
                if (entry.Length > MaxAccountBytes) throw new InvalidDataException("Het accountbestand in de back-up is te groot.");
                var hash = accountMatch.Groups[1].Value;
                if (accountHash is not null && !string.Equals(accountHash, hash, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("De back-up bevat bestanden van meerdere accounts.");
                accountHash = hash;
                validated.Add((entry, name));
            }
            else if (dataMatch.Success)
            {
                if (entry.Length > MaxEntryBytes) throw new InvalidDataException("Een gegevensbestand in de back-up is groter dan 64 MB.");
                var hash = dataMatch.Groups[1].Value;
                if (accountHash is not null && !string.Equals(accountHash, hash, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("De back-up bevat gegevens van een ander account.");
                // Data entries may appear before the account entry; consistency is checked after the loop as well.
                validated.Add((entry, name));
            }
            else
            {
                throw new InvalidDataException("De back-up bevat een onbekend bestand. Er is niets teruggezet.");
            }
        }

        var accountEntries = validated.Where(x => AccountPath.IsMatch(x.RelativePath)).ToList();
        if (accountEntries.Count != 1)
            throw new InvalidDataException("De back-up moet precies één accountbestand bevatten.");
        accountHash = AccountPath.Match(accountEntries[0].RelativePath).Groups[1].Value;
        foreach (var item in validated.Where(x => DataPath.IsMatch(x.RelativePath)))
        {
            var hash = DataPath.Match(item.RelativePath).Groups[1].Value;
            if (!string.Equals(accountHash, hash, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("De back-up bevat gegevens die niet bij het accountbestand horen.");
        }

        // Stage every new file first. If validation, decompression, or a write fails, no account data is partially restored.
        var stagingRoot = Path.Combine(baseDir, ".moodpress-restore-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(stagingRoot);
        var stagedFiles = new List<(string Target, string Staged)>();
        try
        {
            foreach (var item in validated)
            {
                var target = SafeCombine(baseDir, item.RelativePath);
                if (File.Exists(target)) continue;

                var stagedPath = SafeCombine(stagingRoot, item.RelativePath);
                Directory.CreateDirectory(Path.GetDirectoryName(stagedPath)!);
                using var source = item.Entry.Open();
                using var destination = new FileStream(stagedPath, FileMode.CreateNew, FileAccess.Write, FileShare.None, 81920, FileOptions.WriteThrough);
                var buffer = new byte[81920];
                long copied = 0;
                int read;
                while ((read = source.Read(buffer, 0, buffer.Length)) > 0)
                {
                    copied = checked(copied + read);
                    if (copied > item.Entry.Length || copied > MaxEntryBytes)
                        throw new InvalidDataException("De inhoud van een back-upbestand wijkt af van de opgegeven lengte.");
                    destination.Write(buffer, 0, read);
                }
                if (copied != item.Entry.Length)
                    throw new InvalidDataException("Een back-upbestand is onvolledig. Er is niets teruggezet.");
                destination.Flush(flushToDisk: true);
                stagedFiles.Add((target, stagedPath));
            }

            // Commit by same-volume rename without overwrite. Roll back files added by this transaction if a later move fails.
            var committed = new List<string>();
            try
            {
                foreach (var item in stagedFiles)
                {
                    if (File.Exists(item.Target)) continue;
                    Directory.CreateDirectory(Path.GetDirectoryName(item.Target)!);
                    try
                    {
                        File.Move(item.Staged, item.Target, overwrite: false);
                        committed.Add(item.Target);
                    }
                    catch (IOException) when (File.Exists(item.Target))
                    {
                        // Another local operation created the file after preflight. Never overwrite it.
                    }
                }
                return committed.Count;
            }
            catch
            {
                foreach (var path in committed)
                {
                    try { VaultStore.SecureDelete(path); } catch { /* preserve the original restore failure */ }
                }
                throw;
            }
        }
        finally
        {
            try { if (Directory.Exists(stagingRoot)) Directory.Delete(stagingRoot, recursive: true); } catch { }
        }
    }

    static string SafeCombine(string root, string relativePath)
    {
        var fullRoot = Path.GetFullPath(root);
        var target = Path.GetFullPath(Path.Combine(fullRoot, relativePath.Replace('/', Path.DirectorySeparatorChar)));
        var relative = Path.GetRelativePath(fullRoot, target);
        if (Path.IsPathRooted(relative) || relative == ".." || relative.StartsWith(".." + Path.DirectorySeparatorChar, StringComparison.Ordinal))
            throw new InvalidDataException("De back-up probeert buiten de gegevensmap te schrijven.");
        return target;
    }
}
