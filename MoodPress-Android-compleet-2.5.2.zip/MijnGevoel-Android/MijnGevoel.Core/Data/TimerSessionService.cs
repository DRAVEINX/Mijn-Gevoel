namespace MijnGevoel.Core.Data;

/// <summary>
/// Pure state transitions for the durable focus/pause timer. The target end time,
/// rather than a screen tick counter, is the source of truth across navigation or process restarts.
/// </summary>
public static class TimerSessionService
{
    public sealed record ReconcileResult(TimerSessionState State, bool CompletedNow);

    public static TimerSessionState CreateIdle(int totalSeconds)
    {
        var duration = Math.Clamp(totalSeconds, 1, 24 * 60 * 60);
        return new TimerSessionState(duration, duration, null, false, null);
    }

    public static TimerSessionState Start(TimerSessionState? current, int selectedSeconds, DateTime now)
    {
        var selected = Math.Clamp(selectedSeconds, 1, 24 * 60 * 60);
        var state = current ?? CreateIdle(selected);

        // A completed timer, empty timer, or untouched idle timer uses the duration selected now.
        // A paused timer keeps its remaining time so Start resumes instead of resetting it.
        var isFresh = state.CompletedAt is not null || state.RemainingSeconds <= 0 ||
            (!state.IsRunning && state.RemainingSeconds == state.TotalSeconds && state.TotalSeconds != selected);
        var total = isFresh ? selected : Math.Clamp(state.TotalSeconds, 1, 24 * 60 * 60);
        var remaining = isFresh ? selected : Math.Clamp(state.RemainingSeconds, 1, total);

        return new TimerSessionState(total, remaining, now.AddSeconds(remaining), true, null);
    }

    public static ReconcileResult Reconcile(TimerSessionState? current, DateTime now)
    {
        if (current is null)
            return new ReconcileResult(CreateIdle(300), false);

        var state = current;
        var total = Math.Clamp(state.TotalSeconds, 1, 24 * 60 * 60);
        if (!state.IsRunning || state.EndsAt is null)
        {
            var remainingIdle = Math.Clamp(state.RemainingSeconds, 0, total);
            return new ReconcileResult(state with
            {
                TotalSeconds = total,
                RemainingSeconds = remainingIdle,
                EndsAt = null
            }, false);
        }

        var remaining = (int)Math.Ceiling((state.EndsAt.Value - now).TotalSeconds);
        if (remaining <= 0)
        {
            var completedNow = state.CompletedAt is null;
            return new ReconcileResult(state with
            {
                TotalSeconds = total,
                RemainingSeconds = 0,
                EndsAt = null,
                IsRunning = false,
                CompletedAt = state.CompletedAt ?? now
            }, completedNow);
        }

        return new ReconcileResult(state with
        {
            TotalSeconds = total,
            RemainingSeconds = Math.Min(remaining, total)
        }, false);
    }

    public static TimerSessionState Pause(TimerSessionState current, DateTime now)
    {
        var reconciled = Reconcile(current, now);
        if (!reconciled.State.IsRunning)
            return reconciled.State;

        return reconciled.State with
        {
            EndsAt = null,
            IsRunning = false,
            CompletedAt = null
        };
    }

    public static TimerSessionState Reset(int totalSeconds) => CreateIdle(totalSeconds);
}
