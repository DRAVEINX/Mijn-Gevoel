namespace MijnGevoel.Core.Data;

/// <summary>Beschrijft welke velden zijn veranderd, zonder persoonlijke notities in logging te plaatsen.</summary>
public static class AgendaChangeService
{
    public static string[] DescribeChanges(AgendaItem? previous, AgendaItem current)
    {
        if (previous is null) return Array.Empty<string>();
        var changes = new List<string>();
        if (previous.Date.Date != current.Date.Date) changes.Add($"Datum: {previous.Date:dd-MM-yyyy} → {current.Date:dd-MM-yyyy}");
        var oldTime = (previous.Time ?? string.Empty).Trim();
        var newTime = (current.Time ?? string.Empty).Trim();
        if (!string.Equals(oldTime, newTime, StringComparison.Ordinal)) changes.Add($"Tijd: {(oldTime.Length == 0 ? "geen tijd" : oldTime)} → {(newTime.Length == 0 ? "geen tijd" : newTime)}");
        if (!string.Equals(previous.Title ?? string.Empty, current.Title ?? string.Empty, StringComparison.Ordinal)) changes.Add("Titel aangepast");
        if (!string.Equals(previous.Icon ?? string.Empty, current.Icon ?? string.Empty, StringComparison.Ordinal)) changes.Add("Pictogram aangepast");
        if (!string.Equals(previous.Location ?? string.Empty, current.Location ?? string.Empty, StringComparison.Ordinal)) changes.Add("Locatie aangepast");
        if (!string.Equals(previous.Note ?? string.Empty, current.Note ?? string.Empty, StringComparison.Ordinal)) changes.Add("Notitie aangepast");
        return changes.ToArray();
    }
}
