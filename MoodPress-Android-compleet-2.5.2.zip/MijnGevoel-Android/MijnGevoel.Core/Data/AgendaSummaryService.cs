using System.Globalization;

namespace MijnGevoel.Core.Data;

/// <summary>
/// Pure planning helpers for the Home screen. Keeps sorting rules testable
/// without UI or device dependencies.
/// </summary>
public static class AgendaSummaryService
{
    private sealed record Candidate(AgendaItem Item, TimeOnly? Time);

    /// <summary>
    /// Finds the next unfinished activity from today onward.
    /// Timed activities earlier today are skipped. Activities without a valid
    /// time remain visible as unscheduled items rather than silently disappearing.
    /// </summary>
    public static AgendaItem? FindNext(IEnumerable<AgendaItem>? activities, DateTime now)
    {
        if (activities is null)
            return null;

        var today = now.Date;
        var currentTime = TimeOnly.FromDateTime(now);

        return activities
            .Where(item => AgendaStatusService.IsActive(item) && item.Date.Date >= today)
            .Select(item => new Candidate(item, ParseTime(item.Time)))
            .Where(candidate =>
                candidate.Item.Date.Date > today ||
                candidate.Time is null ||
                candidate.Time.Value > currentTime)
            .OrderBy(candidate => candidate.Item.Date.Date)
            .ThenBy(candidate => candidate.Time ?? TimeOnly.MaxValue)
            .Select(candidate => candidate.Item)
            .FirstOrDefault();
    }

    /// <summary>Parses the time formats accepted by the agenda, including legacy dot separators.</summary>
    private static TimeOnly? ParseTime(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return null;

        var normalized = value.Trim().Replace('.', ':');
        return TimeOnly.TryParse(normalized, CultureInfo.InvariantCulture, DateTimeStyles.None, out var time)
            ? time
            : null;
    }
}
