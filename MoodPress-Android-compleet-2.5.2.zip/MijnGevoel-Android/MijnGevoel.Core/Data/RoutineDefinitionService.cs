namespace MijnGevoel.Core.Data;

/// <summary>Validates and normalizes user-created routine definitions before persisting them.</summary>
public static class RoutineDefinitionService
{
    public const int MaximumTitleLength = 120;
    public const int MaximumIconLength = 16;
    public const int MaximumSteps = 50;
    public const int MaximumStepLength = 500;
    public const int MaximumTotalStepCharacters = 12_000;

    public static Routine Create(Guid id, string? title, string? icon, string? rawSteps)
    {
        if (id == Guid.Empty) throw new ArgumentException("Dit stappenplan mist een geldig kenmerk.", nameof(id));

        var normalizedTitle = (title ?? string.Empty).Trim();
        if (normalizedTitle.Length < 2)
            throw new ArgumentException("Gebruik een naam van minimaal 2 tekens.", nameof(title));
        if (normalizedTitle.Length > MaximumTitleLength)
            throw new ArgumentException($"De naam mag maximaal {MaximumTitleLength} tekens bevatten.", nameof(title));

        var normalizedIcon = (icon ?? string.Empty).Trim();
        if (normalizedIcon.Length == 0) normalizedIcon = "📝";
        if (normalizedIcon.Length > MaximumIconLength)
            throw new ArgumentException($"Het pictogramveld mag maximaal {MaximumIconLength} tekens bevatten.", nameof(icon));

        var steps = (rawSteps ?? string.Empty)
            .Split(new[] { "\r\n", "\n", "\r" }, StringSplitOptions.None)
            .Select(line => line.Trim())
            .Where(line => line.Length > 0)
            .ToArray();

        if (steps.Length == 0)
            throw new ArgumentException("Voeg minimaal één stap toe, met één stap per regel.", nameof(rawSteps));
        if (steps.Length > MaximumSteps)
            throw new ArgumentException($"Een stappenplan mag maximaal {MaximumSteps} stappen bevatten.", nameof(rawSteps));
        if (steps.Any(step => step.Length > MaximumStepLength))
            throw new ArgumentException($"Elke stap mag maximaal {MaximumStepLength} tekens bevatten.", nameof(rawSteps));
        if (steps.Sum(step => step.Length) > MaximumTotalStepCharacters)
            throw new ArgumentException("Het stappenplan is te lang. Kort de stappen in en probeer opnieuw.", nameof(rawSteps));

        return new Routine(id, normalizedTitle, normalizedIcon, steps);
    }
}
