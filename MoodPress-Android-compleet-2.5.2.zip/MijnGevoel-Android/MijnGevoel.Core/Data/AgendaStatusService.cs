namespace MijnGevoel.Core.Data;

/// <summary>Normalizes agenda status across old and new saved records.</summary>
public static class AgendaStatusService
{
    public static readonly string[] Statuses = { "Gepland", "Bezig", "Afgerond", "Uitgesteld", "Gewijzigd", "Geannuleerd" };

    public static string Normalize(string? status, bool done = false)
    {
        if (done) return "Afgerond";
        return Statuses.Contains(status, StringComparer.Ordinal) ? status! : "Gepland";
    }

    public static AgendaItem WithStatus(AgendaItem item, string? status)
    {
        var normalized = Normalize(status, done: false);
        return item with { Status = normalized, Done = normalized == "Afgerond" };
    }

    public static bool IsActive(AgendaItem item) =>
        Normalize(item.Status, item.Done) is "Gepland" or "Bezig" or "Uitgesteld" or "Gewijzigd";
}
