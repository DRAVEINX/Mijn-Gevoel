namespace MijnGevoel.Core.Data;

/// <summary>Validates optional self-reported wellbeing notes without drawing medical conclusions.</summary>
public static class WellbeingEntryService
{
    public static WellbeingEntry Create(
        Guid id, DateTime created,
        bool includeSleep, int sleepQuality,
        bool includeMovement, int movementMinutes,
        bool includeEnergy, int energyLevel,
        string? note)
    {
        if (includeSleep && sleepQuality is < 1 or > 5)
            throw new ArgumentOutOfRangeException(nameof(sleepQuality), "Slaapkwaliteit moet tussen 1 en 5 liggen.");
        if (includeMovement && movementMinutes is < 0 or > 1440)
            throw new ArgumentOutOfRangeException(nameof(movementMinutes), "Beweging moet tussen 0 en 1440 minuten liggen.");
        if (includeEnergy && energyLevel is < 1 or > 5)
            throw new ArgumentOutOfRangeException(nameof(energyLevel), "Energie moet tussen 1 en 5 liggen.");

        var safeNote = (note ?? string.Empty).Trim();
        if (safeNote.Length > 1000) throw new ArgumentException("Een welzijnsnotitie mag maximaal 1000 tekens bevatten.", nameof(note));
        if (!includeSleep && !includeMovement && !includeEnergy && safeNote.Length == 0)
            throw new ArgumentException("Kies minstens één onderdeel of schrijf een korte notitie.");

        return new WellbeingEntry(id, created, includeSleep ? sleepQuality : 0, includeMovement ? movementMinutes : -1, includeEnergy ? energyLevel : 0, safeNote);
    }
}
