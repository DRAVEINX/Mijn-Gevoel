using System.Security.Cryptography;
using System.Text.Json;
using MijnGevoel.Core.Security;

namespace MijnGevoel.Core.Data;

/// <summary>Elk item is een eigen AES-256-GCM-versleuteld bestand. Soort + id zijn aan de versleuteling gebonden:
/// bestanden kunnen dus niet stiekem worden verwisseld of aangepast zonder dat het opvalt.</summary>
public sealed class VaultStore : IDisposable
{
    /// <summary>Matches the restore limit so an item cannot be saved but then rejected by backup recovery.</summary>
    public const long MaxRecordBytes = 64L * 1024 * 1024;
    readonly byte[] _key; readonly string _dir;
    int _readErrorCount;

    /// <summary>Number of non-sensitive read failures in this session. The counter contains no record names or content.</summary>
    public int ReadErrorCount => System.Threading.Volatile.Read(ref _readErrorCount);

    void RecordReadError() => System.Threading.Interlocked.Increment(ref _readErrorCount);

    public VaultStore(byte[] key, string dir)
    {
        ArgumentNullException.ThrowIfNull(key);
        if (key.Length != Crypto.KeySize) throw new ArgumentException("De kluissleutel heeft een ongeldige lengte.", nameof(key));
        if (string.IsNullOrWhiteSpace(dir)) throw new ArgumentException("Een gegevensmap is verplicht.", nameof(dir));
        _key = key;
        _dir = Path.GetFullPath(dir);
        Directory.CreateDirectory(_dir);
    }

    static void ValidateKind(string kind)
    {
        if (string.IsNullOrEmpty(kind) || kind.Length > 64 ||
            !((kind[0] >= 'a' && kind[0] <= 'z') || (kind[0] >= '0' && kind[0] <= '9')) ||
            kind.Any(c => !((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '-')))
            throw new ArgumentException("Een gegevenssoort moet uit maximaal 64 kleine letters, cijfers of koppeltekens bestaan.", nameof(kind));
    }

    string FileFor(string kind, Guid id)
    {
        ValidateKind(kind);
        return Path.Combine(_dir, $"{kind}-{id:N}.mg");
    }

    public void Save<T>(string kind, Guid id, T item)
    {
        var path = FileFor(kind, id);
        Directory.CreateDirectory(_dir);
        var temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        byte[]? json = null;
        byte[]? blob = null;
        try
        {
            json = JsonSerializer.SerializeToUtf8Bytes(item);
            if (json.LongLength > MaxRecordBytes)
                throw new InvalidDataException("Dit gegeven is te groot om veilig lokaal op te slaan.");
            blob = Crypto.Seal(_key, json, $"{kind}:{id:N}");
            if (blob.LongLength > MaxRecordBytes)
                throw new InvalidDataException("Dit versleutelde bestand is groter dan de opslaglimiet.");
            using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None, 4096, FileOptions.WriteThrough))
            {
                stream.Write(blob, 0, blob.Length);
                stream.Flush(flushToDisk: true);
            }
            File.Move(temp, path, overwrite: true);
        }
        finally
        {
            if (json is not null) CryptographicOperations.ZeroMemory(json);
            if (blob is not null) CryptographicOperations.ZeroMemory(blob);
            try { if (File.Exists(temp)) File.Delete(temp); } catch (IOException) { }
        }
    }

    public T? Load<T>(string kind, Guid id)
    {
        var path = FileFor(kind, id);
        if (!File.Exists(path)) return default;
        // Bound the read using the opened stream (not only FileInfo) to avoid a size-check/read race.
        byte[]? blob = null;
        byte[]? plain = null;
        try
        {
            using (var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                var length = stream.Length;
                if (length <= 0 || length > MaxRecordBytes)
                {
                    RecordReadError();
                    return default;
                }

                blob = new byte[checked((int)length)];
                var offset = 0;
                while (offset < blob.Length)
                {
                    var read = stream.Read(blob, offset, blob.Length - offset);
                    if (read <= 0)
                    {
                        RecordReadError(); // file shortened while being read
                        return default;
                    }
                    offset += read;
                }
                if (stream.ReadByte() != -1)
                {
                    RecordReadError(); // file grew beyond the checked size while being read
                    return default;
                }
            }

            plain = Crypto.Open(_key, blob, $"{kind}:{id:N}");
            try { return JsonSerializer.Deserialize<T>(plain); }
            catch (JsonException) { RecordReadError(); return default; }
        }
        catch (FileNotFoundException) { return default; } // The record may have been removed by another local action.
        catch (CryptographicException) { RecordReadError(); return default; }
        catch (IOException) { RecordReadError(); return default; }
        catch (UnauthorizedAccessException) { RecordReadError(); return default; }
        catch (OverflowException) { RecordReadError(); return default; }
        finally
        {
            if (plain is not null) CryptographicOperations.ZeroMemory(plain);
            if (blob is not null) CryptographicOperations.ZeroMemory(blob);
        }
    }

    public List<T> All<T>(string kind)
    {
        ValidateKind(kind);
        var list = new List<T>();
        string[] files;
        try { files = Directory.GetFiles(_dir, kind + "-*.mg"); }
        catch (DirectoryNotFoundException) { RecordReadError(); return list; }
        catch (IOException) { RecordReadError(); return list; }
        catch (UnauthorizedAccessException) { RecordReadError(); return list; }

        foreach (var file in files)
        {
            var name = Path.GetFileNameWithoutExtension(file);
            if (!Guid.TryParseExact(name[(kind.Length + 1)..], "N", out var id)) continue;
            var value = Load<T>(kind, id);
            if (value is not null) list.Add(value);
        }
        return list;
    }

    public void Delete(string kind, Guid id) => SecureDelete(FileFor(kind, id));

    /// <summary>Overschrijft het bestand met willekeurige data en verwijdert het (beperkt effect op SSD's, maar de inhoud is toch al versleuteld).</summary>
    public static void SecureDelete(string path)
    {
        try
        {
            if (!File.Exists(path)) return;
            long len = new FileInfo(path).Length;
            using (var fs = new FileStream(path, FileMode.Open, FileAccess.Write, FileShare.None))
            {
                var buf = Crypto.Random((int)Math.Min(len, 1 << 20));
                try
                {
                    long w = 0;
                    while (w < len)
                    {
                        int n = (int)Math.Min(buf.Length, len - w);
                        if (n == 0) break;
                        fs.Write(buf, 0, n);
                        w += n;
                    }
                    fs.Flush(flushToDisk: true);
                }
                finally { CryptographicOperations.ZeroMemory(buf); }
            }
        }
        catch (IOException) { }
        File.Delete(path);
    }

    public void Dispose() => CryptographicOperations.ZeroMemory(_key);
}
