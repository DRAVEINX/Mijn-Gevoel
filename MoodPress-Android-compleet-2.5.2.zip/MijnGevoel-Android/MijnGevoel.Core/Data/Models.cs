namespace MijnGevoel.Core.Data;

/// <summary>Dagboek (Mood 1-5, 0 = geen) en "van me afschrijven"-briefjes.</summary>
public record JournalEntry(Guid Id, DateTime Created, int Mood, string Text);
/// <summary>De vier herkenbare gevoelens voor snelle, visuele invoer.</summary>
public record FourGFeelingEntry(Guid Id, DateTime Created, string Feeling);
/// <summary>Uitgebreide dagelijkse check-in. De gegevens worden via VaultStore versleuteld opgeslagen.</summary>
public record MoodCheckInEntry(Guid Id, DateTime Created, string Feeling, int Intensity, string Reason, string Note);
/// <summary>Een korte gesproken notitie; AudioData wordt uitsluitend binnen de versleutelde VaultStore bewaard.</summary>
public record VoiceNoteEntry(Guid Id, DateTime Created, string Context, byte[] AudioData);
public record DrawingEntry(Guid Id, DateTime Created, string Title, byte[] Isf, byte[] Png);
public record AgendaItem(Guid Id, DateTime Date, string Time, string Title, string Icon, bool Done, string? Status = null)
{
    /// <summary>Legacy records without Status remain compatible; Done maps to Afgerond.</summary>
    public string CurrentStatus => AgendaStatusService.Normalize(Status, Done);
    /// <summary>Optionele locatie. Ontbreekt bij oudere JSON-records en blijft dan leeg.</summary>
    public string Location { get; init; } = "";
    /// <summary>Optionele privé-notitie die alleen lokaal in de versleutelde kluis wordt bewaard.</summary>
    public string Note { get; init; } = "";
    /// <summary>Menselijk leesbare beschrijving van wijzigingen aan datum, tijd of inhoud.</summary>
    public string ChangeSummary { get; init; } = "";
}
/// <summary>Persistente timerstatus; opgeslagen via VaultStore zodat hij per gebruiker veilig blijft.</summary>
public record TimerSessionState(int TotalSeconds, int RemainingSeconds, DateTime? EndsAt, bool IsRunning, DateTime? CompletedAt);
/// <summary>Checklistvoortgang per routine en dag voor het kindvriendelijke visuele dagschema.</summary>
public record RoutineProgress(Guid Id, DateTime Day, Guid RoutineId, int[] CompletedSteps);
/// <summary>Voortgang van het aparte stappenplan dat stap voor stap wordt uitgevoerd.</summary>
public record RoutineRunProgress(Guid RoutineId, int CurrentStep, bool Completed, DateTime UpdatedAt);

public class UserSettings
{
    public int TextSize { get; set; } = 1;            // 0 normaal, 1 groot, 2 extra groot
    public string Theme { get; set; } = "Rustig";     // Rustig, Donker, Hoog contrast
    public int AutoLockMinutes { get; set; } = 5;
    public bool ReadAloud { get; set; } = true;
    public bool Animations { get; set; } = true;
    public string FontName { get; set; } = "Standaard";   // Standaard, Verdana, Arial, Georgia
    public bool WideLines { get; set; }                  // ruime regelafstand
    public bool SimplifiedMode { get; set; }              // alleen kerningangen tonen op Home
    public bool BlockCapture { get; set; }               // schermopname/screenshot van het venster blokkeren
    public bool RoutinesSeeded { get; set; }
    /// <summary>False means legacy/default behaviour: every feature is visible.</summary>
    public bool FeatureVisibilityConfigured { get; set; }
    /// <summary>FeatureKind names the user has chosen to keep visible. Empty is valid after configuration.</summary>
    public List<string> EnabledFeatures { get; set; } = new();
    /// <summary>Optional Home shortcuts, saved as feature keys. Empty is allowed after explicit configuration.</summary>
    public List<string> HomeShortcuts { get; set; } = new();
    /// <summary>False for older settings records: use the original default Home shortcuts.</summary>
    public bool HomeShortcutsConfigured { get; set; }
    /// <summary>Persoonlijk interfaceprofiel: Kind, Jongere, Volwassene of Algemeen.</summary>
    public string AudienceProfile { get; set; } = "Algemeen";
}

/// <summary>Stoplicht: Colour = Groen | Oranje | Rood. Reasons/Needs zijn de gekozen pictogram-teksten.</summary>
public record StoplichtEntry(Guid Id, DateTime Created, string Colour, string[] Reasons, string[] Needs, string Text);
public record ContactPerson(string Name, string Phone);
public class SafetyPlan
{
    public List<ContactPerson> Contacts { get; set; } = new();
    public string Helps { get; set; } = "";
    /// <summary>Vooraf gekozen, concrete helpstappen. Oude bestanden zonder dit veld blijven geldig.</summary>
    public List<string> HelpOptions { get; set; } = new();
    // Extra, optionele velden voor de ondersteuningskaart. Oude back-ups blijven compatibel.
    public string PersonName { get; set; } = "";
    public string EarlySigns { get; set; } = "";
    public string Avoid { get; set; } = "";
    public string Communication { get; set; } = "";
    public string SupportSteps { get; set; } = "";
    public string Goals { get; set; } = "";
    public string RoutineNotes { get; set; } = "";
}

/// <summary>Privé-check-in voor kinderen en jongeren; opgeslagen in de versleutelde gebruikerskluis.</summary>
public record YouthSupportEntry(Guid Id, DateTime Created, string Situation, int StressLevel, string Need, string Note);
/// <summary>Privé-afspraken voor omgaan met online pesten of een onveilige situatie.</summary>
public class YouthSafetyPlan
{
    public string TrustedPerson { get; set; } = "";
    public string SafePlace { get; set; } = "";
    public string NextStep { get; set; } = "";
    public string OnlineSteps { get; set; } = "";
}
/// <summary>Eigen doel voor school, werk, dagbesteding, thuis of sociale contacten.</summary>
public record AdultGoal(Guid Id, DateTime Created, string Area, string Title, string FirstStep, DateTime? TargetDate, bool Done)
{
    /// <summary>Vrijwillige positieve terugblik; geen score of ranglijst. Oudere opgeslagen doelen blijven compatibel.</summary>
    public string Reflection { get; init; } = "";
    /// <summary>Extra kleine stappen; oudere doelen zonder Steps laden als een lege lijst.</summary>
    public string[] Steps { get; init; } = Array.Empty<string>();
}
/// <summary>Zelfgekozen rustoptie; titel en notitie zijn privé en worden via VaultStore versleuteld opgeslagen.</summary>
public record CalmOptionEntry(Guid Id, string Title, string Note, DateTime Created, DateTime Updated);
/// <summary>Privé-energiemeting; geen diagnose en niet automatisch gedeeld.</summary>
public record EnergyEntry(Guid Id, DateTime Created, string Context, int EnergyLevel, string Note);
/// <summary>Optionele welzijnsnotitie; waarden zijn zelfrapportage en geen medische meting.</summary>
public record WellbeingEntry(Guid Id, DateTime Created, int SleepQuality, int MovementMinutes, int EnergyLevel, string Note);
/// <summary>Een routinevoorstel dat de ontvanger eerst expliciet moet goedkeuren.</summary>
public record RoutineSuggestion(Guid Id, string Title, string Icon, string[] Steps, DateTime Created, string From);
/// <summary>Bewijs van de categorieën die de gebruiker bewust heeft geselecteerd voor één deelpakket.</summary>
public record ShareConsentRecord(Guid Id, DateTime Created, string RecipientLabel, string[] Categories, int StoplightCount, int RoutineCount)
{
    public int MoodCheckInCount { get; init; }
    public int YouthCheckInCount { get; init; }
    public string[] SelectedItemLabels { get; init; } = Array.Empty<string>();
}
/// <summary>Lokale gebeurtenis op het apparaat van de ondersteuner; geen online toegangslog.</summary>
public record SupportAuditEntry(Guid Id, DateTime Created, string Action, string Summary);
public record ShareLogEntry(Guid Id, DateTime Created, int Count);

/// <summary>Toestemming van de cliënt voor het gebruik van de app (Mode: "zelf" of "samen" met een vertegenwoordiger/begeleider).</summary>
public record ConsentRecord(Guid Id, DateTime Created, int Version, string Mode);
public static class ConsentInfo { public const int CurrentVersion = 1; }

/// <summary>Stappenplan (routine): een titel, een plaatje en stappen.</summary>
public record Routine(Guid Id, string Title, string Icon, string[] Steps);
/// <summary>Een persoonlijke dagelijkse/wekelijkse routineherinnering met lokaal gekozen pictogram.</summary>
public record RoutineReminder(
    Guid Id,
    string Title,
    string Icon,
    string Time,
    int DaysMask,
    bool Enabled,
    string? PictureBase64 = null,
    bool SoundEnabled = true);
/// <summary>Prikkelmeter en lichaam: Kind = Hoofd | Omgeving | Lichaam. Bij Lichaam is Note bijvoorbeeld "Buik: spanning".</summary>
public record ScaleEntry(Guid Id, DateTime Created, string Kind, int Level, string Note);
/// <summary>Eigen kaart om te laten zien ("Ik wil even rust").</summary>
public record TalkCard(Guid Id, string Emoji, string Text);
/// <summary>Gesprekskaart: voorbereiden wat je wilt zeggen.</summary>
public class TalkPrep { public string Tell { get; set; } = ""; public string Ask { get; set; } = ""; public string Want { get; set; } = ""; }
