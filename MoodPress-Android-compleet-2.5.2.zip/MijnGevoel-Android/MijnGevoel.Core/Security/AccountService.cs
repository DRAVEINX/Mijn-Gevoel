using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using QRCoder;

namespace MijnGevoel.Core.Security;

public sealed record Registration(string OtpAuthUri, byte[] QrPng, string SecretForManualEntry, IReadOnlyList<string> RecoveryCodes);
public sealed record LoginResult(bool Success, string Message, byte[]? VaultKey = null);

/// <summary>
/// Ontwerp: een willekeurige 256-bit 'vaultsleutel' versleutelt alle gegevens (dagboek, tekeningen, agenda).
/// Die sleutel wordt nooit leesbaar opgeslagen, alleen 'ingepakt' met (a) een sleutel uit het wachtwoord (Argon2id)
/// en (b) per herstelcode. Wachtwoord veranderen = opnieuw inpakken. Inloggen = wachtwoord goed + authenticatiecode goed.
/// </summary>
public sealed class AccountService
{
    internal sealed class AccountFile
    {
        public int Version { get; set; } = 1;
        public string Username { get; set; } = "";
        public bool Active { get; set; }                       // pas actief na eerste goede authenticatiecode
        public byte[] PasswordSalt { get; set; } = [];
        public byte[] WrappedByPassword { get; set; } = [];
        public byte[] EncTotpSecret { get; set; } = [];
        public long LastTotpStep { get; set; }
        public List<RecoverySlot> Recovery { get; set; } = [];
        public int Failures { get; set; }
        public DateTimeOffset LockedUntil { get; set; }
    }
    internal sealed class RecoverySlot { public byte[] Salt { get; set; } = []; public byte[] Wrapped { get; set; } = []; }

    const string Generic = "Inloggen is niet gelukt. Controleer je gegevens en probeer het opnieuw.";
    const int MinPasswordLength = 10, RecoveryCodeCount = 8;
    readonly string _root;

    public AccountService(string? root = null) =>
        _root = root ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MijnGevoel", "accounts");

    // ---------- Registreren ----------
    public Registration Register(string username, string password)
    {
        username = ValidateUsername(username);
        if (password.Length < MinPasswordLength) throw new ArgumentException($"Wachtwoord is te kort (minimaal {MinPasswordLength} tekens).", nameof(password));
        if (Load(username) is { Active: true }) throw new InvalidOperationException("Deze gebruikersnaam is al in gebruik.");

        var vaultKey = Crypto.Random(Crypto.KeySize);
        try { return Build(new AccountFile { Username = username }, vaultKey, password); }
        finally { CryptographicOperations.ZeroMemory(vaultKey); }
    }

    Registration Build(AccountFile acc, byte[] vaultKey, string password)
    {
        acc.PasswordSalt = Crypto.Random(Crypto.SaltSize);
        var kek = Crypto.DeriveKey(password, acc.PasswordSalt);
        acc.WrappedByPassword = Crypto.Seal(kek, vaultKey, "vault-key");
        CryptographicOperations.ZeroMemory(kek);

        var secret = Totp.NewSecret();
        acc.EncTotpSecret = Crypto.Seal(vaultKey, secret, "totp");
        acc.Active = false; acc.LastTotpStep = 0;

        var codes = new List<string>();
        acc.Recovery = [];
        for (int i = 0; i < RecoveryCodeCount; i++)
        {
            var code = NewRecoveryCode(); codes.Add(code);
            var salt = Crypto.Random(Crypto.SaltSize);
            var k = Crypto.DeriveKey(NormalizeCode(code), salt);
            acc.Recovery.Add(new RecoverySlot { Salt = salt, Wrapped = Crypto.Seal(k, vaultKey, "vault-key") });
            CryptographicOperations.ZeroMemory(k);
        }
        Save(acc);

        var uri = Totp.OtpAuthUri(acc.Username, secret);
        var qr = new PngByteQRCode(new QRCodeGenerator().CreateQrCode(uri, QRCodeGenerator.ECCLevel.M)).GetGraphic(10);
        var manual = Totp.ToBase32(secret);
        CryptographicOperations.ZeroMemory(secret);
        return new Registration(uri, qr, manual, codes);
    }

    /// <summary>Stap 2 van registreren: cliënt voert de eerste code uit de authenticator in.</summary>
    public bool ConfirmRegistration(string username, string password, string code)
    {
        var acc = Load(username); if (acc is null || acc.Active) return false;
        byte[]? vk = null, secret = null;
        try
        {
            vk = OpenWithPassword(acc, password);
            secret = Crypto.Open(vk, acc.EncTotpSecret, "totp");
            var step = Totp.Verify(secret, code);
            if (step is null) return false;
            acc.Active = true; acc.Failures = 0; Save(acc); return true;
        }
        catch (CryptographicException) { return false; }
        finally { Wipe(vk); Wipe(secret); }
    }

    // ---------- Inloggen ----------
    public LoginResult Login(string username, string password, string code)
    {
        var acc = Load(username);
        if (acc is null)
        {
            // Keep the unknown-user timing path comparable, and wipe the dummy derived key immediately.
            var dummyKey = Crypto.DeriveKey(password, new byte[Crypto.SaltSize]);
            CryptographicOperations.ZeroMemory(dummyKey);
            return new(false, Generic);
        }
        if (acc.LockedUntil > DateTimeOffset.UtcNow)
            return new(false, $"Te vaak geprobeerd. Wacht even en probeer het over {Math.Ceiling((acc.LockedUntil - DateTimeOffset.UtcNow).TotalMinutes)} minuut/minuten opnieuw.");

        byte[]? vk = null, secret = null;
        try
        {
            vk = OpenWithPassword(acc, password);
            secret = Crypto.Open(vk, acc.EncTotpSecret, "totp");
            var step = acc.Active ? Totp.Verify(secret, code) : null;
            if (step is null || step.Value <= acc.LastTotpStep) return Fail(acc);
            acc.LastTotpStep = step.Value; acc.Failures = 0; acc.LockedUntil = default; Save(acc);
            var result = new LoginResult(true, "Welkom!", (byte[])vk.Clone());
            return result;
        }
        catch (CryptographicException) { return Fail(acc); }
        finally { Wipe(vk); Wipe(secret); }
    }

    LoginResult Fail(AccountFile acc)
    {
        acc.Failures++;
        if (acc.Failures >= 5)   // 5 fouten: 30s, 1m, 2m, 4m ... max 1 uur
            acc.LockedUntil = DateTimeOffset.UtcNow.AddSeconds(Math.Min(3600, 30 * Math.Pow(2, acc.Failures - 5)));
        Save(acc);
        return new(false, Generic);
    }

    // ---------- Herstel (telefoon of wachtwoord kwijt) ----------
    /// <summary>Met een herstelcode: nieuw wachtwoord + nieuwe authenticator-koppeling. De code vervalt na gebruik.</summary>
    public Registration? RecoverAccess(string username, string recoveryCode, string newPassword)
    {
        var acc = Load(username);
        if (acc is null || newPassword.Length < MinPasswordLength || acc.LockedUntil > DateTimeOffset.UtcNow) return null;
        var norm = NormalizeCode(recoveryCode);
        foreach (var slot in acc.Recovery.ToList())
        {
            byte[]? k = null, vk = null;
            try
            {
                k = Crypto.DeriveKey(norm, slot.Salt);
                vk = Crypto.Open(k, slot.Wrapped, "vault-key");
                acc.Recovery.Remove(slot);                  // eenmalig
                acc.Failures = 0; acc.LockedUntil = default;
                return Build(acc, vk, newPassword);         // nieuwe salt, nieuw TOTP-geheim, nieuwe herstelcodes
            }
            catch (CryptographicException) { }
            finally { Wipe(k); Wipe(vk); }
        }
        Fail(acc);
        return null;
    }

    // ---------- Herstelcodes vernieuwen ----------
    public int RecoveryCodesLeft(string username) => Load(username)?.Recovery.Count ?? 0;

    /// <summary>Maakt 8 nieuwe herstelcodes (wachtwoord nodig). De oude codes werken daarna niet meer.</summary>
    public IReadOnlyList<string>? RegenerateRecoveryCodes(string username, string password)
    {
        var acc = Load(username);
        if (acc is null || acc.LockedUntil > DateTimeOffset.UtcNow) return null;
        byte[]? vk = null;
        try
        {
            vk = OpenWithPassword(acc, password);
            var codes = new List<string>(); acc.Recovery = [];
            for (int i = 0; i < RecoveryCodeCount; i++)
            {
                var code = NewRecoveryCode(); codes.Add(code);
                var salt = Crypto.Random(Crypto.SaltSize);
                var k = Crypto.DeriveKey(NormalizeCode(code), salt);
                acc.Recovery.Add(new RecoverySlot { Salt = salt, Wrapped = Crypto.Seal(k, vk, "vault-key") });
                CryptographicOperations.ZeroMemory(k);
            }
            acc.Failures = 0; Save(acc); return codes;
        }
        catch (CryptographicException) { Fail(acc); return null; }
        finally { Wipe(vk); }
    }

    // ---------- Beheer ----------
    public string BaseFolder => Path.GetDirectoryName(_root)!;
    public string AccountFilePath(string username) => PathFor(username);
    public string DataFolder(string username) =>
        Path.Combine(BaseFolder, "data", Path.GetFileNameWithoutExtension(PathFor(username)));

    public bool ChangePassword(string username, string oldPassword, string newPassword)
    {
        var acc = Load(username);
        if (acc is null || newPassword.Length < MinPasswordLength) return false;
        byte[]? vk = null;
        try
        {
            vk = OpenWithPassword(acc, oldPassword);
            acc.PasswordSalt = Crypto.Random(Crypto.SaltSize);
            var kek = Crypto.DeriveKey(newPassword, acc.PasswordSalt);
            acc.WrappedByPassword = Crypto.Seal(kek, vk, "vault-key");
            CryptographicOperations.ZeroMemory(kek);
            Save(acc); return true;
        }
        catch (CryptographicException) { return false; }
        finally { Wipe(vk); }
    }

    /// <summary>Verwijdert account en alle gegevens definitief (recht op vergetelheid).</summary>
    public bool DeleteAccount(string username, string password)
    {
        var acc = Load(username); if (acc is null) return false;
        byte[]? vk = null;
        try { vk = OpenWithPassword(acc, password); }
        catch (CryptographicException) { return false; }
        finally { Wipe(vk); }
        var dir = DataFolder(username);
        if (Directory.Exists(dir))
        {
            foreach (var f in Directory.GetFiles(dir)) Data.VaultStore.SecureDelete(f);
            Directory.Delete(dir, true);
        }
        Data.VaultStore.SecureDelete(PathFor(username));
        return true;
    }

    // ---------- Hulpfuncties ----------
    static byte[] OpenWithPassword(AccountFile acc, string password)
    {
        var kek = Crypto.DeriveKey(password, acc.PasswordSalt);
        try { return Crypto.Open(kek, acc.WrappedByPassword, "vault-key"); }
        finally { CryptographicOperations.ZeroMemory(kek); }
    }

    static string NewRecoveryCode()
    {
        const string a = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";   // zonder verwarrende tekens (0/O, 1/I/L)
        var sb = new StringBuilder();
        for (int i = 0; i < 12; i++) { if (i > 0 && i % 4 == 0) sb.Append('-'); sb.Append(a[RandomNumberGenerator.GetInt32(a.Length)]); }
        return sb.ToString();
    }
    static string NormalizeCode(string c) => new string(c.Where(char.IsLetterOrDigit).ToArray()).ToUpperInvariant();
    static void Wipe(byte[]? b) { if (b is not null) CryptographicOperations.ZeroMemory(b); }

    public static string ValidateUsername(string? username)
    {
        var normalized = (username ?? string.Empty).Trim();
        if (normalized.Length < 3) throw new ArgumentException("Gebruikersnaam is te kort (minimaal 3 tekens).", nameof(username));
        if (normalized.Length > 64) throw new ArgumentException("Een gebruikersnaam mag maximaal 64 tekens bevatten.", nameof(username));
        if (normalized.Any(char.IsControl)) throw new ArgumentException("Een gebruikersnaam mag geen regeleinden of besturingstekens bevatten.", nameof(username));
        return normalized;
    }

    string PathFor(string username)
    {
        var normalized = ValidateUsername(username);
        return Path.Combine(_root, Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(normalized.ToLowerInvariant()))) + ".json");
    }

    AccountFile? Load(string username)
    {
        var p = PathFor(username);
        if (!File.Exists(p)) return null;
        // Deserialize directly from a byte buffer so the temporary plaintext can be cleared afterwards.
        // Format errors deliberately reach the UI's generic error handling instead of silently creating a new account.
        var json = File.ReadAllBytes(p);
        try { return JsonSerializer.Deserialize<AccountFile>(json); }
        finally { CryptographicOperations.ZeroMemory(json); }
    }

    void Save(AccountFile acc)
    {
        Directory.CreateDirectory(_root);
        var p = PathFor(acc.Username);
        var tmp = p + "." + Guid.NewGuid().ToString("N") + ".tmp";
        byte[]? json = null;
        try
        {
            json = JsonSerializer.SerializeToUtf8Bytes(acc);
            using (var stream = new FileStream(tmp, FileMode.CreateNew, FileAccess.Write, FileShare.None, 4096, FileOptions.WriteThrough))
            {
                stream.Write(json, 0, json.Length);
                stream.Flush(flushToDisk: true);
            }
            File.Move(tmp, p, overwrite: true); // atomisch vervangen: geen half accountbestand bij onderbreking
        }
        finally
        {
            if (json is not null) CryptographicOperations.ZeroMemory(json);
            try { if (File.Exists(tmp)) File.Delete(tmp); } catch (IOException) { }
        }
    }
}
