# MoodPress Android 2.3.2 — acceptatietest

Voer deze test uit met de APK van de groene 2.3.2-debugbuild. Voer daarna de kernpunten met de ondertekende release-APK uit.

## Vooraf
- [ ] Maak een back-up/export volgens de bestaande appmogelijkheden.
- [ ] Installeer over een bestaande 2.3.0-installatie en controleer dat inloggen nog lukt.
- [ ] Controleer dat opgeslagen gegevens na de update nog aanwezig zijn.
- [ ] Noteer toestelmodel, Android-versie en appversie bij elke foutmelding.

## Timer
- [ ] Start een timer van 3 minuten; de weergave begint af te tellen.
- [ ] Navigeer naar een ander scherm, wacht ten minste 30 seconden en open Timer opnieuw; de resterende tijd is afgenomen.
- [ ] Pauzeer de timer, wacht 30 seconden en hervat; de timer loopt verder vanaf de resterende tijd.
- [ ] Zet de app op de achtergrond, wacht tot na het einde en open opnieuw; de app laat zien dat de tijd om is.
- [ ] Sluit de app volledig terwijl een timer loopt, open de app en bezoek Timer; controleer dat de eindtijd wordt herberekend.
- [ ] Start na afloop een nieuwe timer met een andere duur.
- [ ] Controleer dat de status eerlijk blijft: een achtergrondmelding wordt niet gegarandeerd door deze versie.

## Agenda
- [ ] Voeg een activiteit met datum, tijd en pictogram toe.
- [ ] Pas titel, datum, tijd en pictogram aan; controleer dat precies dezelfde activiteit wordt bijgewerkt.
- [ ] Markeer de activiteit als afgerond, open Bewerken en sla een wijziging op; controleer dat afgerond behouden blijft.
- [ ] Start bewerken en kies Annuleren; controleer dat de opgeslagen activiteit niet verandert.
- [ ] Test een lege tijd en een ongeldige tijd; de invoer moet begrijpelijk worden uitgelegd.
- [ ] Verwijder een activiteit pas na de bevestigingsvraag.

## Stappenplannen
- [ ] Start een stappenplan, ga naar de volgende stap en druk op Stoppen en terug.
- [ ] Open hetzelfde stappenplan opnieuw; de laatst opgeslagen stap wordt getoond.
- [ ] Gebruik Vorige en Volgende; controleer dat de voortgang steeds wordt bewaard.
- [ ] Rond het stappenplan af; open het opnieuw en controleer dat het vanaf stap 1 begint.
- [ ] Pas een stappenplan aan of verwijder het; oude voortgang mag niet onverwacht worden hergebruikt.

## Gevoelscheck-ins
- [ ] Maak een check-in met gevoel, intensiteit, aanleiding en notitie.
- [ ] Open de gevoelskalender, kies de check-in en pas gevoel en notitie aan.
- [ ] Controleer dat de oorspronkelijke datum/tijd niet verandert na een bewerking.
- [ ] Verwijder een check-in via de bevestigingsvraag; controleer dat deze niet meer in kalender/inzichten staat.
- [ ] Controleer toegang tot oudere check-ins ouder dan 30 dagen.
- [ ] Controleer dat niets automatisch gedeeld wordt.

## Algemene update, privacy en toegankelijkheid
- [ ] Vergrendelen en opnieuw inloggen blijven werken.
- [ ] Dagboek, tekeningen, agenda en andere bestaande gegevens blijven aanwezig.
- [ ] Test grotere tekst, hoog contrast, liggende stand en een kleiner/groter scherm.
- [ ] Gebruik alle drie de hoofdschermen met TalkBack of een andere schermlezer.
- [ ] Controleer dat geen gevoelige tekst in meldingen of logs verschijnt.
- [ ] Noteer elke fout, de reproduceerstappen en een screenshot zonder privégegevens.

**Acceptatie:** alleen 'geslaagd' afvinken na uitvoering op een echt apparaat. Een groene workflow is nodig, maar vervangt deze apparaattest niet.
