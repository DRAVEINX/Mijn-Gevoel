# MoodPress Android 2.4.0 — complete acceptatietest

**Voorwaarde:** voer de test uit met de debug-APK van de groene GitHub Actions build. Daarna controleer je de kernpunten met de signed release. Noteer toestelmodel, Android-versie en appversie. Gebruik geen echte, gevoelige notities in screenshots.

## 0. Voorbereiden en upgraden
- [ ] Exporteer of maak een privéback-up van de bestaande app.
- [ ] Installeer de debugversie over een geldige installatie met dezelfde app-ID en controleer dat inloggen werkt.
- [ ] Controleer dat dagboek, agenda, tekeningen, check-ins, routines en instellingen blijven bestaan.
- [ ] Vergrendel de app, ontgrendel opnieuw, gebruik verkeerde code/wachtwoord en controleer begrijpelijke foutmelding.
- [ ] Controleer dat de tabletapp 2.3.0 een aparte installatie blijft en niet vervangen wordt.

## 1. Home en instellingen
- [ ] Start Home met lege en volle gegevens.
- [ ] Controleer dat de eerstvolgende activiteit klopt, verlopen afspraken van vandaag worden overgeslagen en geannuleerde activiteiten niet als volgende activiteit verschijnen.
- [ ] Verberg één functie; controleer dat de tegel weg is maar data niet is verwijderd. Maak die functie daarna opnieuw zichtbaar.
- [ ] Schakel vereenvoudigde startpagina aan/uit; instellingen blijven bereikbaar.
- [ ] Test normale/grote/extra grote tekst, lettertype, thema, hoog contrast, regelafstand, voorlezen en scherm verbergen.

## 2. Dag, agenda, routines, timer, herinneringen
- [ ] Voeg activiteit toe met optionele locatie en notitie; controleer dat lege waarden toegestaan zijn.
- [ ] Wijzig titel/datum/tijd/pictogram/locatie/notitie, sla op en controleer dat dezelfde record is bijgewerkt.
- [ ] Controleer dat bij bewerken alleen gewijzigde velden in een menselijke samenvatting getoond worden; notitie-inhoud wordt niet in samenvattingen of logregels opgenomen.
- [ ] Test alle statussen: Gepland, Bezig, Afgerond, Uitgesteld, Gewijzigd en Geannuleerd; controleer Home en Vandaag.
- [ ] Test leeg/ongeldig tijdveld en verwijder een activiteit pas na bevestiging.
- [ ] Maak eigen stappenplan, wijzig stappen, voer een stap uit, verlaat het scherm en open opnieuw; controleer voortgang.
- [ ] Rond routine af, open opnieuw en controleer dat een nieuwe uitvoering bij stap 1 begint.
- [ ] Start timer van 3 minuten, navigeer weg, open terug en controleer resterende tijd.
- [ ] Pauzeer, wacht, hervat en controleer dat hij verdergaat vanaf resterende tijd.
- [ ] Sluit app volledig/zet toestel op achtergrond en test eindtijd; schakel testmelding aan/uit en controleer foutuitleg.
- [ ] Test timer na apparaatherstart; herhaal met geweigerde meldingsrechten en batterijbesparing.
- [ ] Maak routineherinnering voor gekozen tijd/dag; test melding, herhalen, uitschakelen, reboot en geweigerde machtigingen.

## 3. Gevoel, dagboek, rust en wellbeing
- [ ] Maak check-in zonder intensiteit, met intensiteit, met notitie en via “Overslaan — niets opslaan”.
- [ ] Open een oudere check-in; bekijk, wijzig en verwijder die met bevestiging. Controleer oorspronkelijke datum en tijd.
- [ ] Controleer dat overslaan niets nieuws opslaat en dat intensiteit 0 niet als 0/10 of medische score wordt gepresenteerd.
- [ ] Schrijf/bewerk/verwijder een dagboeknotitie; controleer na herstart.
- [ ] Voeg een persoonlijke rustoptie toe, pas titel/notitie aan en verwijder deze; herstart de app en controleer dat de lijst behouden is.
- [ ] Controleer dat persoonlijke rustopties in de leesbare export voorkomen en niet automatisch gedeeld worden.
- [ ] Gebruik ademhalingsoefening, prikkelmeter, signaleringsplan en stoplicht; controleer dat alles zelfrapportage is.
- [ ] Maak welzijnsnotitie met alleen slaapkwaliteit, alleen beweging, alleen energie en alleen tekst; test 0 minuten en ongeldige waarden.
- [ ] Bewerk en verwijder een welzijnsregistratie; controleer dat gegevens lokaal blijven.

## 4. Communicatie, zelfstandigheid, steun
- [ ] Toon basiscommunicatiekaart groot en gebruik voorlezen.
- [ ] Maak eigen kaart, wijzig kaarttekst, en verwijder met bevestiging.
- [ ] Vul een eigen veiligheidsplan en contactpersoon in; klik “Open telefoon” en controleer dat alleen de telefoon-app opent na jouw bewuste actie.
- [ ] Maak een doel met één eerste stap en meerdere vervolgstappen, sluit het scherm en controleer dat alle stappen terugkomen.
- [ ] Pas daarna het doel, de eerste stap, vervolgstappen, gebied en streefdatum aan; controleer dat hetzelfde doel wordt bijgewerkt.
- [ ] Test terugblik, afronden/heropenen en verwijderen van doelen.
- [ ] Test kind-, jongeren-, volwassen- en algemeen profiel; controleer dat er geen automatische diagnose of verborgen deling plaatsvindt.
- [ ] Test pakket delen met de bedoelde selectie, onjuist deelwachtwoord en zichtbare toestemming; verzend niets onbedoeld.
- [ ] Controleer dat de app nergens beweert dat begeleider/noodhulp automatisch gealarmeerd wordt.

## 5. Export, back-up, privacy en beveiliging
- [ ] Maak back-up en controleer dat de melding zegt dat het ZIP-bestand zelf geen apart wachtwoord heeft; bewaar het bestand privé.
- [ ] Herstel op een lege testinstallatie en controleer account- en data-integriteit.
- [ ] Herstel dezelfde back-up opnieuw; bestaande bestanden worden niet overschreven.
- [ ] Test een ongeldig ZIP-bestand en controleer dat niets gedeeltelijk wordt teruggezet.
- [ ] Exporteer leesbare JSON, lees eerst waarschuwing over onversleutelde persoonlijke data en controleer of nieuwe velden worden meegenomen.
- [ ] Controleer de delen-/sharegeschiedenis, account verwijderen met wachtwoord, tweevoudige bevestiging en opnieuw inloggen/registreren.
- [ ] Controleer meldingen/logs op persoonlijke notities; deel geen gevoelige gegevens in openbaar issue/screenshots.

## 6. Toegankelijkheid, foutscenario’s en release
- [ ] Doorloop Home, dag, gevoelscheck-in, routine en instellingen met TalkBack.
- [ ] Test liggende stand, klein scherm, groot lettertype, tablet en voldoende aanraakvlakken.
- [ ] Test lege lijsten, ontbrekende verplichte invoer, ongeldige datum/tijd, opslagfout en geweigerde rechten.
- [ ] Laat ten minste één beoogde gebruiker de hoofdtaken proberen, zonder druk en met toestemming.
- [ ] APK workflow en alle automatische tests zijn groen; bewaar run-link.
- [ ] Release workflow is groen; APK/AAB/checksums zijn downloadbaar en SHA256 komt overeen.
- [ ] Update de openbare downloadasset pas na tests; houd de vorige werkende versie als terugvaloptie.

**Niet aftekenen op basis van alleen een groene build.** Noteer per mislukte stap de exacte handeling, foutmelding, toestel en Android-versie.
