# MoodPress Android 2.4.0 — kandidaat-release notes

## Functionele uitbreidingen
- Agenda met de statussen Gepland, Bezig, Afgerond, Uitgesteld, Gewijzigd en Geannuleerd.
- Agenda-afspraken toevoegen, aanpassen en verwijderen; optionele locatie en notitie; bewaarde samenvatting van gewijzigde velden.
- Timerstatus op basis van eindtijd, met lokale notificatieplanning en herstelpoging na apparaatherstart. Android kan meldingen door instellingen, machtigingen of batterijbeheer uitstellen of blokkeren.
- Routine-uitvoering kan na verlaten van het scherm worden hervat.
- Gevoelscheck-ins: intensiteit en notitie zijn optioneel; overslaan slaat niets op; historische items kunnen worden aangepast en verwijderd.
- Eigen rustlijst met toevoegen, aanpassen en verwijderen; items zijn privé in de versleutelde lokale opslag en komen mee in de persoonlijke export.
- Persoonlijke doelen: meerdere vervolgstappen toevoegen, doel aanpassen, afronden/heropenen en vrijwillige positieve terugblik.
- Eigen communicatiekaarten, functiezichtbaarheid, vereenvoudigde startpagina en persoonlijke welzijnsregistratie.
- Lokale data-export bevat welzijn, timer-/routinevoortgang, persoonlijke rustopties en doelen.
- Back-upherstel valideert de hele ZIP vóór het terugzetten, weigert traversal/duplicaten/ongeldige payloads en overschrijft bestaande bestanden niet.
- Nieuwe tests voor legacy JSON, agendawijzigingen, doelstappen en rustopties.

## Compatibiliteit
- Android package ID blijft `nl.mijngevoel.app`.
- Displayversie `2.4.0`, Android versionCode `30`.
- Oude JSON-records zonder de nieuwe optionele velden blijven compatibel volgens de bijgevoegde unit tests.
- De bestaande telefoonversie 2.3.0 en de aparte tablet-app zijn niet overschreven.

## Status en blokkades
- Dit is een broncodekandidaat. In deze werkomgeving was geen .NET SDK beschikbaar; compile, `dotnet test` en Android-build zijn dus nog niet lokaal uitgevoerd.
- Voer de meegeleverde GitHub Actions APK-workflow uit. Als die groen is, installeer de debug-APK en vul de acceptatietest in.
- De signed-releaseworkflow mag pas worden uitgevoerd na de benodigde tests en vereist bestaande repository-secrets: `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_PASSWORD` en `ANDROID_KEY_ALIAS`.
- Echte tests op toestel, upgrade met behoud van data, meldingen na reboot/doze, TalkBack, schermformaten en doelgroepfeedback zijn niet vervangen door een groene build.
- Onafhankelijke securityreview en formele AVG/DPIA-beoordeling zijn nog nodig voordat brede zorgtoepassing wordt overwogen.
- Geen cloudsync, live begeleidersportaal, medische diagnose of automatische noodmelding wordt beloofd.
