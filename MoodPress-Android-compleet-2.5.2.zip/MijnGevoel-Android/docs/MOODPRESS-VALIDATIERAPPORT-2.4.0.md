# MoodPress 2.4.0 — validatierapport vóór upload

**Peildatum:** 14 oktober 2026  
**Status:** broncodekandidaat; niet publiceren vóór groene CI én relevante apparaattests.

## Statische controles uitgevoerd in deze werkomgeving

- De oorspronkelijke projectstructuur .NET MAUI/C# is behouden. Het package ID blijft `nl.mijngevoel.app`.
- De broncodekandidaat bundelt timer-eindtijd en notification restore, routine-voortgang, agenda-statussen, optionele agenda-locatie/notitie en gewijzigde-velden-samenvatting, edit/delete check-ins, persoonlijke rustlijst CRUD, doelen met meerdere stappen/bewerken, welzijn, functiezichtbaarheid, export en veilig back-upherstel.
- Unit tests zijn toegevoegd voor timerstatus, statuslogica, zichtbare functies, welzijn, agenda legacy JSON, agendawijzigingen, begrenzing van doelstappen, legacy goal JSON, rustopties en export.
- De GitHub Actions-workflows bevatten expliciete statische checks voor de versie, vereiste bestanden, services, schermbedrading en testbestanden.
- Beide ZIP-archieven zijn gecontroleerd met `unzip -t`; er zijn geen beschadigde entries aangetroffen.
- De Android-, Core- en Tests-projectbestanden zijn als XML geparseerd.
- Beide workflows zijn als YAML geparseerd; alle ingebedde Bash-scripts zijn met `bash -n` gecontroleerd.
- De statische preflight-checks uit zowel APK- als releaseworkflow zijn lokaal uitgevoerd tegen de daadwerkelijk uitgepakte broncode en slaagden.
- De uit de workflow verwachte broncodepaden en versiegegevens zijn gecontroleerd: package ID `nl.mijngevoel.app`, displayversie `2.4.0`, versionCode `30`.
- SHA-256-hashes van de geneste broncode-ZIP en beide workflowbestanden staan in `SHA256SUMS.txt`.

## Niet uitgevoerd / niet bewezen

- Er is geen .NET SDK in deze werkomgeving. `dotnet restore`, `dotnet test`, `dotnet publish` en de Android compile zijn niet lokaal uitgevoerd.
- Pas een groene GitHub Actions-run bewijst dat exact geüploade broncode build en tests heeft doorlopen.
- Er is geen APK opgenomen in het uploadpakket; GitHub Actions moet deze genereren.
- Installatie/update op echte telefoon en tablet, behoud van bestaande gebruikersdata, meldingen na reboot/Doze/batterijbesparing, TalkBack, groter lettertype, contrast, schermformaten en vrijwillige doelgroepfeedback moeten handmatig worden uitgevoerd.
- Een onafhankelijke security review en formele DPIA-/AVG-beoordeling zijn geen onderdeel van een statische codecontrole.

## Release gates

1. APK-workflow volledig groen, inclusief alle unit tests.
2. Debug-APK installeren en acceptatietest uitvoeren, inclusief de nieuw toegevoegde agenda-locatie/notitie, rustlijst en meerdere doelstappen.
3. Blokkerende fouten oplossen en workflow opnieuw uitvoeren.
4. Signed release workflow alleen daarna uitvoeren met de bestaande signing secrets.
5. Controlesommen vergelijken en de release-installatie op echt toestel testen.
6. Openbare release-asset pas bijwerken na acceptatie; 2.3.0 behouden als terugvaloptie.
