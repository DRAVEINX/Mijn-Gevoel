# MoodPress 2.4.0 — integrale status tegenover het volledige ontwikkelplan

**Peildatum:** 14 oktober 2026  
**Kandidaat:** 2.4.0 · Android `versionCode` 30 · app-ID `nl.mijngevoel.app`  
**Technologie:** bestaande .NET MAUI/C#-oplossing met gedeelde Core en tests. Dit pakket migreert niet naar Flutter en overschrijft de stabiele 2.3.0-telefoonapp of de aparte tabletapp niet.

## Samenvatting

Deze kandidaat bundelt de implementeerbare, lokale kernfuncties uit het plan in één broncodepakket. De laatste auditverbeteringen in deze bundel voegen toe:

- Agenda-activiteiten met optionele locatie en notitie. Bij aanpassen wordt een leesbare samenvatting bewaard van de veranderde velden. Oude records zonder deze optionele eigenschappen blijven compatibel.
- Een persoonlijke rustlijst met toevoegen, aanpassen en verwijderen. Deze items blijven in de bestaande versleutelde lokale kluis en worden in de data-export opgenomen.
- Persoonlijke doelen met meerdere vervolgstappen, bewerken, afronden/heropenen en een vrijwillige positieve terugblik. Oudere doelen zonder het nieuwe `Steps`-veld blijven leesbaar.
- Testen voor legacy JSON, agendasamenvattingen, begrenzing en normalisatie van doelstappen, rustopties en de opname in export.
- Timer-eindtijd en hervatbare voortgang in stappenplannen, statusbeheer, optionele gevoelscheck-ins, aanpasbare communicatiekaarten, welzijnsregistratie, functiezichtbaarheid en gecontroleerd back-upherstel uit de vorige codekandidaat.

**Belangrijk:** dit is een broncodekandidaat, geen al gebouwde en op Android geaccepteerde release. De .NET-compile/test moet door GitHub Actions worden uitgevoerd en de handmatige tests moeten op echte apparaten worden afgenomen. Een groene build alleen bewijst niet dat alle gebruiksscenario’s werken.

## Controle van alle 18 hoofdstukken

| # | Hoofdstuk uit het plan | Status in kandidaat | Wat valt hieronder / wat resteert |
|---:|---|---|---|
| 1 | Doel en uitgangspunten | In code, menselijk testen open | Bestaande app wordt uitgebreid; geen nepnoodmelding; eenvoudige taal en lokale opslag; vrijwillige gebruikerstests blijven nodig. |
| 2 | Productvisie en doelgroep | Gedeeltelijk | Profielen Kind/Jongere/Volwassene/Algemeen en begrijpelijke schermen bestaan; toegankelijkheid testen met verschillende gebruikers is open. |
| 3 | Functieoverzicht | Veel lokale functies in code | Dag, gevoel, rust, zelfstandigheid, communicatie, welzijn, steun en profiel zijn vertegenwoordigd. Spraak-naar-tekst, cloudsync en online begeleidersportaal zijn niet in deze kandidaat geïmplementeerd. |
| 4 | Schermen en gebruikersroutes | In code, route-tests open | Hoofdnavigatie en onderdelen bestaan; de volledige routes moeten op toestel worden doorlopen, ook lege/toestandsfoutscenario’s. |
| 5 | Functionele eisen | Grotendeels in code; CI/UX open | Agenda met statussen, optionele locatie/notitie en samenvatting van wijzigingen; routinevoortgang; duurzame timer; check-ins beheren; eigen rustopties; doelen met stappen; communicatiekaarten; welzijn. De acceptatietest blijft vereist. |
| 6 | Toegankelijkheid en begrijpelijke taal | In code, apparaattest open | Instelbare tekstgrootte, lettertype, thema, contrastinstelling, regelafstand, vereenvoudigde home, voorlezen, grote knoppen en semantic labels; TalkBack/contrast/schermformaten moeten echt worden getest. |
| 7 | Technische keuzes | In code | Bestaande .NET MAUI/C# en `net10.0-android` zijn behouden; geen onnodige frameworkmigratie. |
| 8 | Projectstructuur | Gedeeltelijk | Core/data/services/tests zijn gescheiden; de grote `FeaturePage.cs` is onderhoudsschuld. Opsplitsen zonder regressies kan in een vervolgende refactor, maar is niet als veilig te wijzigen bewezen door een lokale compiler in deze omgeving. |
| 9 | Gegevensmodellen | In code, oude installaties testen | Nieuwe eigenschappen hebben defaults zodat legacy JSON wordt ondersteund; tests toegevoegd voor oude doelen en agenda-items. Echte upgrade op geïnstalleerde 2.3.0-data moet nog worden getest. |
| 10 | Gegevensopslag en privacy | Gedeeltelijk | Kluisgegevens worden per item met AES-GCM versleuteld opgeslagen; back-upvalidatie voorkomt onveilige paden/overschrijven; export JSON is bewust leesbaar en vraagt om zorgvuldig delen. De back-up-ZIP heeft geen apart wachtwoord en moet privé worden bewaard. Hersteltest op toestel blijft nodig. |
| 11 | Bouwvolgorde | In één kandidaat gebundeld | Relevante lokale verbeteringen zijn samengebracht. Validatie blijft in volgorde: CI → debug-APK → apparaatstest → signed release. |
| 12 | Testplan | Tests toegevoegd; CI-status onbekend | Core-unit/securitytests en workflow zijn opgenomen. De echte .NET restore/test/build is pas bewezen na een groene GitHub Actions-run van exact deze ZIP. |
| 13 | Beveiliging en verantwoord gebruik | Gedeeltelijk | Lokale versleuteling, bewuste deelacties en veilige back-upvalidatie bestaan; onafhankelijke securityreview, DPIA-/AVG-beoordeling en veilige praktijktest zijn externe activiteiten. |
| 14 | Release en onderhoud | Workflow voorbereid | APK- en signed APK/AAB-workflows zijn toegevoegd; release-assets mogen pas na groene CI én relevante handmatige acceptatietests worden bijgewerkt. |
| 15 | Werkplanning en prioriteiten | Kern-prioriteiten samengebracht | Kernfuncties en privacy zijn opgenomen; resterende aandacht: apparaattests, toegankelijkheid, herstel, doelgroepevaluatie, onderhoud. Cloudfuncties alleen na apart ontwerp. |
| 16 | Definition of Done | Nog niet gehaald voor release | Build, alle tests, echt toestel, upgrade, meldingen, TalkBack, toegankelijkheid en privacychecks moeten afgerond zijn. Niet aftekenen op alleen broncodecontrole. |
| 17 | Eerste programmeersessie | Uitgevoerd als codewerk | Bestaande oplossing bestudeerd, code uitgebreid, tests en workflow toegevoegd, status en acceptatietests bijgewerkt. Lokale .NET-compile is hier niet beschikbaar. |
| 18 | Eindchecklist | Gedeeltelijk | De complete checklist in `ANDROID-ACCEPTATIETEST-2.4.0.md` moet stap voor stap worden ingevuld met toestel, Android-versie, resultaat en eventuele foutmelding. |

## Bewust niet als afgerond gepresenteerd

- **CI-build/tests:** moeten nog draaien tegen de geüploade broncode-ZIP.
- **Apparaat-/upgrade-test:** moet op echte Android-telefoon en tablet; controleren dat bestaande gebruikersdata blijven bestaan.
- **Meldingen:** Android/OEM-batterijbeheer, Doze, machtigingen en herstart kunnen de aflevering beïnvloeden; dat vereist echte tests en is niet gegarandeerd door enkel de code.
- **Toegankelijkheid:** TalkBack, kleine schermen, liggende stand, grote tekst en voldoende contrast vereisen menselijk testen.
- **Doelgroep:** er moeten vrijwillige gebruikerstests met toestemming worden uitgevoerd.
- **Privacy en beveiliging:** formele DPIA/AVG-beoordeling en onafhankelijke securityreview kunnen niet door code of unit tests worden vervangen.
- **Cloudsync, serverportaal en automatische noodmeldingen:** niet inbegrepen; hiervoor zijn een backend, authenticatie, autorisatie, beveiligde werking en apart getest ontwerp nodig. De app doet niet alsof deze functies bestaan.
- **Back-upcontainer:** data-items zijn versleuteld; de ZIP-container zelf heeft geen apart wachtwoord. De leesbare export is eveneens gevoelig.

## Go/no-go voor release

1. Upload de nested broncode-ZIP en beide workflowbestanden uit het uploadpakket.
2. Run `MoodPress 2.4.0 - Android APK`; controleer dat alle unit tests en Android-build slagen.
3. Installeer de debug-APK op een echt toestel en voer de acceptatietest uit.
4. Los alle blokkades op; voer de APK-workflow opnieuw uit na wijzigingen.
5. Run pas dan de signed-releaseworkflow met de bestaande Android signing secrets.
6. Controleer APK, AAB en `SHA256SUMS.txt`; test de release-installatie/update.
7. Update openbare assets pas nadat de acceptatietests klaar zijn. Houd 2.3.0 en de aparte tabletversie als terugvaloptie.
