# MoodPress Android 2.3.2 — kandidaat-release

## Wijzigingen

- **Timer bewaart nu een eindtijd en status via de versleutelde VaultStore.** De timer telt daardoor door als de gebruiker naar een ander scherm gaat of de app later opnieuw opent. De eindtijd wordt herberekend bij terugkomst, in plaats van alleen seconden af te trekken zolang een timerpagina open is.
- **Agenda-afspraken aanpassen.** Een bestaande activiteit kan titel, datum, tijd en pictogram wijzigen. Bestaande status 'afgerond' blijft behouden. Annuleren verandert niets.
- **Gevoelscheck-ins beheren.** In de gevoelskalender kunnen check-ins worden bekeken, aangepast en na bevestiging verwijderd. Ook registraties ouder dan 30 dagen zijn via de sectie 'Oudere check-ins' bereikbaar.
- **Stappenplannen hervatten.** De voortgang van het gewone stap-voor-stap-stappenplan wordt nu versleuteld bewaard. Terugkeer start op de laatst opgeslagen stap; een afgerond plan start de volgende keer weer vanaf het begin. Aangepaste of verwijderde plannen krijgen geen oude voortgang mee.
- **Nieuwe Core-tests** voor timer starten, pauzeren, hervatten, verlopen en opnieuw starten, en voor hervatten/afronden van stappenplannen.
- Android-versie verhoogd naar 2.3.2 / versionCode 29. De app-ID blijft `nl.mijngevoel.app` voor een normale update van de bestaande telefoonapp.

## Bekende beperking

De timerstatus blijft lopen en de verstreken tijd wordt berekend op basis van de opgeslagen eindtijd. Deze wijziging plant nog geen gegarandeerde Android-systeemmelding wanneer de app gesloten of op de achtergrond is. De timer meldt het einde in de app wanneer de timer actief is of wanneer de timerpagina opnieuw wordt geopend. Vertrouw voor cruciale zorg- of medicatieherinneringen niet uitsluitend op deze timer.

## Validatiestatus

Deze broncodekandidaat is lokaal statisch gecontroleerd op ZIP-integriteit en delimiter-balans van de gewijzigde C#-bestanden. De .NET SDK was niet beschikbaar in de huidige bewerkingsomgeving; een succesvolle `dotnet test`, APK-build, ondertekende release en apparaattest zijn dus nog niet bevestigd. Voer eerst de meegeleverde GitHub Actions APK-workflow uit en ga pas na een groene build door naar de releaseworkflow.
