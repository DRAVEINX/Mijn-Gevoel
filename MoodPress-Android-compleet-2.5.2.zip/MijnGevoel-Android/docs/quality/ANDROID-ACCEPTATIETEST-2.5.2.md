# MoodPress Android 2.5.2 — acceptatietest

Vul per test **PASS / FAIL / NVT** in, samen met apparaatmodel, Android-versie, kandidaatbuildnummer, datum en eventuele schermafbeelding zonder persoonsgegevens. Test uitsluitend met een nieuw demo-account en fictieve informatie.

## Testomgeving

- Build-run-URL: ______________________________
- APK-bestandsnaam + SHA-256: ______________________________
- Telefoon/model/Android: ______________________________
- Tablet/model/Android: ______________________________
- Tester/datum: ______________________________

## A. Installatie en update

- [ ] PASS / [ ] FAIL APK installeert schoon; start zonder crash.
- [ ] PASS / [ ] FAIL Release build kan worden geïnstalleerd zonder debug-handtekeningconflict.
- [ ] PASS / [ ] FAIL Update vanaf de huidige ondersteunde release behoudt account en testgegevens zoals ontworpen.
- [ ] PASS / [ ] FAIL Installatie naast de afzonderlijke Tablet-app resulteert niet in pakket-id-conflict.
- [ ] PASS / [ ] FAIL App kan opnieuw geopend worden na geforceerd sluiten en telefoonherstart.

## B. Navigatie en logisch ontwerp

- [ ] PASS / [ ] FAIL Home / Dag / Gevoel / Meer openen de verwachte gebieden; actieve tab is herkenbaar.
- [ ] PASS / [ ] FAIL Meer groepeert functies logisch en zoekopdracht levert resultaten/duidelijke lege toestand.
- [ ] PASS / [ ] FAIL Home toont maximaal vier geselecteerde snelkoppelingen.
- [ ] PASS / [ ] FAIL De vereenvoudigde startpagina toont maximaal twee shortcuts zonder de opgeslagen selectie te wissen.
- [ ] PASS / [ ] FAIL Snelkoppelingen kunnen in instellingen geordend en opgeslagen worden; dubbele keuzes worden geweigerd.
- [ ] PASS / [ ] FAIL Een snelkoppeling blijft ook bereikbaar in Meer; verborgen functies worden niet onbedoeld onvindbaar.
- [ ] PASS / [ ] FAIL Terugknop, scrollen en navigeren vanuit onderliggende pagina's verliezen geen niet-opgeslagen invoer zonder waarschuwing.

## C. Gevoel en dagboek

- [ ] PASS / [ ] FAIL Gevoel zonder intensiteit/notitie opslaan werkt indien velden optioneel zijn.
- [ ] PASS / [ ] FAIL Check-in is zichtbaar in de geschiedenis na heropenen.
- [ ] PASS / [ ] FAIL Eerdere registratie aanpassen en verwijderen werken met bevestiging waar nodig.
- [ ] PASS / [ ] FAIL Dagboeknotitie kan bekeken/verwijderd worden; gevoelige tekst verschijnt niet op Home of in meldingen.
- [ ] PASS / [ ] FAIL Inzichten/kalender trekken geen diagnose of automatische medische conclusie.

## D. Mijn dag, routines en timer

- [ ] PASS / [ ] FAIL Activiteit toevoegen, wijzigen, verwijderen en status veranderen werken.
- [ ] PASS / [ ] FAIL Datum/tijd/locatie/notitie zijn optioneel/valide volgens de UI; gewijzigde planning is duidelijk.
- [ ] PASS / [ ] FAIL Lege agenda toont rustige lege toestand met duidelijke actie.
- [ ] PASS / [ ] FAIL Routines en stappenplannen bewaren voortgang na navigeren/sluiten/herstarten.
- [ ] PASS / [ ] FAIL Timer blijft juiste resterende tijd tonen na van scherm wisselen en app sluiten/heropenen.
- [ ] PASS / [ ] FAIL Meldingen zijn getest met recht toegestaan én geweigerd; app claimt geen melding als die niet ingepland is.
- [ ] PASS / [ ] FAIL Timer/routines over middernacht, pauze, stoppen en hervatten geven juiste resultaten.

## E. Rust, communicatie, doelen en welzijn

- [ ] PASS / [ ] FAIL Rustlijst eigen item toevoegen/wijzigen/verwijderen werkt.
- [ ] PASS / [ ] FAIL Ademhaling/pauze kan op elk moment gestopt worden.
- [ ] PASS / [ ] FAIL Prikkelmeter gebruikt tekst/labels en niet alleen kleur.
- [ ] PASS / [ ] FAIL Praatkaarten tonen tekst met pictogram; delen gebeurt alleen op expliciete gebruikersactie.
- [ ] PASS / [ ] FAIL Eigen doelen met stappen bewaren voortgang, wijzigingen en verwijdering.
- [ ] PASS / [ ] FAIL Welzijnsgegevens zijn optioneel en kunnen worden verwijderd; geen diagnose of behandeladvies.

## F. Privacy, account en data

- [ ] PASS / [ ] FAIL Verkeerd wachtwoord/TOTP wordt veilig afgewezen en lockoutgedrag is begrijpelijk.
- [ ] PASS / [ ] FAIL Auto-lock en handmatig vergrendelen beschermen het scherm; vergrendelen wist geen data.
- [ ] PASS / [ ] FAIL Export bevat verwachte gegevens van demo-account en wordt op een door gebruiker gekozen locatie opgeslagen.
- [ ] PASS / [ ] FAIL Back-up wordt gemaakt, hersteld in een schone testomgeving en bestaande bestanden worden niet overschreven.
- [ ] PASS / [ ] FAIL Een beschadigde of kwaadwillige back-up wordt geweigerd zonder gedeeltelijk herstel.
- [ ] PASS / [ ] FAIL Account verwijderen wist bijbehorende lokale data volgens de uitleg; opnieuw registreren/inloggen is getest.
- [ ] PASS / [ ] FAIL Screenshots blokkeren doet wat de instelling belooft; beperkte werking (andere camera) is duidelijk uitgelegd.
- [ ] PASS / [ ] FAIL Logs bevatten geen notities, wachtwoorden, OTP's, herstelsleutels of volledige gevoelige exports.
- [ ] PASS / [ ] FAIL Er is geen onbedoelde synchronisatie, automatische contactmelding of verborgen begeleiderstoegang.

## G. Toegankelijkheid en responsiviteit

- [ ] PASS / [ ] FAIL Android systeemtekst op standaard/groot/zeer groot; tekst, buttons en picker blijven bedienbaar.
- [ ] PASS / [ ] FAIL TalkBack leest tabs, snelkoppelingen, zoekveld, invoervelden en foutmeldingen begrijpelijk voor.
- [ ] PASS / [ ] FAIL Kleurcontrast is voldoende in Rustig, Donker en Hoog contrast; kleur staat nooit op zichzelf.
- [ ] PASS / [ ] FAIL Touch targets kunnen zonder nauwkeurig mikken gebruikt worden; focus is zichtbaar.
- [ ] PASS / [ ] FAIL Telefoon portret en landscape: geen overlap, tekstafkapping of horizontaal scrollen zonder reden.
- [ ] PASS / [ ] FAIL Tablet portrait/landscape: inhoud benut beschikbare breedte, kolommen hebben bruikbare breedte, er blijft geen telefoonformaatkaart gecentreerd.
- [ ] PASS / [ ] FAIL Toestelrotatie tijdens formulier leidt niet tot onverwacht gegevensverlies.

## H. Demo- en releaseklaar

- [ ] PASS / [ ] FAIL Demo-account bevat uitsluitend fictieve gegevens.
- [ ] PASS / [ ] FAIL APK handtekening en SHA-256 corresponderen met de juiste artifact-run.
- [ ] PASS / [ ] FAIL Versienummer/application id zijn gecontroleerd voor phone en tablet.
- [ ] PASS / [ ] FAIL Foutlogs zijn doorgenomen en bekende beperkingen staan vermeld.
- [ ] PASS / [ ] FAIL De demo is gerepeteerd vanaf start tot afronding, inclusief fout-/herstelpad.
- [ ] PASS / [ ] FAIL Verantwoordelijke heeft privacy/security review en publicatiebesluit vastgelegd.

## Resultaat

- Blockerende FAILs: ______________________________
- OPEN/NVT met motivatie: ______________________________
- Go/no-go-besluit: ______________________________
- Akkoord tester/owner: ______________________________
