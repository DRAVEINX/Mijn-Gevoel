# MoodPress 2.5.2 — demonstratiescript voor stakeholders

## Voorbereiding (dag vóór de demo)

1. Gebruik uitsluitend de exacte APK uit de groene release-artifact van de getoonde build; noteer build-run-ID en SHA-256.
2. Installeer op een echte telefoon en, indien relevant, de aparte tabletvariant. Controleer koud starten en openen na toestelherstart.
3. Maak een demo-account met fictieve gebruikersnaam en fictieve data. Gebruik geen zorgdossiers, echte contactgegevens, echte namen of echte gevoelsteksten.
4. Zet vooraf 3–4 snelkoppelingen in Home, voeg fictieve afspraken, een gevoelssessie, één routine, twee communicatietegels en een persoonlijk doel toe.
5. Zet het toestel op Niet storen, maar controleer dat dit de demo van de lokale app niet verbergt. Maak screenshots alleen met toestemming en zonder gevoelige data.
6. Leg de bekende grenzen klaar: dit is geen medisch diagnosemiddel; geen automatische noodmelding; geen bevestigde cloudsync of live begeleidersportal.

## Demo in circa 8–10 minuten

1. **Home (1 min):** laat de vier of minder snelkoppelingen, eerstvolgende activiteit en rustige lege toestand zien. Toon dat keuze in Instellingen aangepast kan worden.
2. **Navigatie (1 min):** Home / Dag / Gevoel / Meer; zoek in Meer naar “rust” en open de relevante kaart.
3. **Mijn dag (2 min):** voeg een fictieve afspraak toe, wijzig tijd/locatie, markeer uitgesteld/afgerond en toon verschil/status.
4. **Mijn gevoel (1 min):** voer een check-in uit met optionele notitie, wijzig die in de geschiedenis en verwijder een testregistratie.
5. **Rust/communicatie (1 min):** start en stop de ademhalingsoefening, open een praatkaart, toon dat delen een expliciete keuze is.
6. **Routines/doel (1 min):** vink een stap af, navigeer weg, keer terug en toon hervatten.
7. **Privacy (1–2 min):** toon auto-lock/privacyuitleg, expliciete export en welke data niet online gedeeld wordt. Doe geen destructieve verwijderactie tijdens de live demo; toon desnoods de testprocedure.
8. **Kwaliteitsbewijs (1 min):** laat de groene test-APK-workflow, Core-testresultaat en SHA-256 zien zodra deze aanwezig zijn; benoem expliciet welke fysieke acceptatietests zijn uitgevoerd.

## Afsluiting

Vraag feedback op begrijpelijkheid, navigatie, toegankelijkheid en vertrouwen. Noteer één eigenaar, prioriteit en hertoestmoment per issue. Presenteer de app niet als productie-gecertificeerd zolang open quality gates of onafhankelijke privacybeoordeling nog ontbreken.
