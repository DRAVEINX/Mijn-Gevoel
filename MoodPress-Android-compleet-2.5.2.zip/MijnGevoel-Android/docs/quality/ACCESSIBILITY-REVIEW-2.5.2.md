# MoodPress 2.5.2 — toegankelijkheidscontrole

## Automatisch in code

- Schermlabels/hints en stabiele, unieke `AutomationId` op primaire Home-tegels, de afzonderlijke `Openen`-knop van elke Meer-kaart, zoekveld, keuzelijsten en onderste navigatie. Meer-kaarten zijn niet afhankelijk van een verborgen tap-gesture.
- Tekst kan worden vergroot; meerdere thema's en ruimere regelafstand zijn instelbaar.
- Tekstlabels naast pictogrammen; functies worden in gegroepeerde lijst getoond; zoekresultaten hebben een lege toestand.
- Home/Meer kolommen passen zich aan beschikbare breedte aan. Vereenvoudigde startpagina toont maximaal twee snelkoppelingen.
- Interactieve controls hebben ingestelde minimumhoogtes/padding in gedeelde UI-componenten.

## Handmatige checks die nog noodzakelijk zijn

- TalkBack-volgorde, namen en hints; geen dubbele of nutteloze aankondigingen.
- 200% systeemlettergrootte en display size: geen afgeknotte knoppen/knoppen onderaan verborgen achter het toetsenbord.
- Contrastmeting in alle thema's, ook disabled/pressed/focus states.
- Landschap, split-screen, tablets en foldables: geen rare lege kolommen of onbruikbaar smalle tegels.
- Bevestigen dat status/fouten nooit uitsluitend met kleur worden gemeld.
- Test met gebruikers met uiteenlopende leesvaardigheid en motorische/visuele behoeften. Verzamel feedback met toestemming, zo min mogelijk persoonsgegevens.

De code-inventaris is geen formele WCAG-conformiteitsverklaring; de echte Android Accessibility Scanner/TalkBack en gebruikersproef leveren bewijs.
