# MoodPress 2.5.2 — release quality gates

Een groene build is noodzakelijk, maar niet voldoende voor een professionele demonstratie of publieke release.

## Gate-matrix

| Gate | Vereist bewijs | Status voordat CI draait |
|---|---|---|
| G1 Broncodepakket | ZIP-integriteit, paden aanwezig, juiste application id en versionCode | Lokale statische controle wordt uitgevoerd bij pakketbouw |
| G2 Core-regressies | `dotnet test` slaagt zonder test failures | OPEN tot workflowresultaat |
| G3 Android compile | Debug Android APK gebouwd in clean GitHub runner | OPEN tot workflowresultaat |
| G4 Release-signing | APK signatures verifieren; AAB-signature verifieerbaar; checksums opgeslagen | OPEN tot signed releaseworkflow |
| G5 Installatie/update | Installeert schoon; update over compatibele vorige release behoudt data | OPEN — fysieke telefoon/tablet vereist |
| G6 Basisfunctionaliteit | Navigatie, invoer, edit/delete, opslag, export/import/back-up, account lock/delete | OPEN — acceptatietest uitvoeren |
| G7 Herstel en privacy | Back-up herstellen in schone testinstallatie; geen data lekken in log/melding/screenshot | OPEN — fysieke test + privacyreview |
| G8 Toegankelijkheid | TalkBack, grote systeemtekst, hoog contrast, font scaling, touch targets | OPEN — apparaat- en gebruikerstest |
| G9 Responsiviteit | Portret/landscape, telefoon/tablet/venstergrootte, geen afgeknotte tekst | OPEN — apparaten/emulatoren |
| G10 Demo-proof | Geen echte cliëntdata; demo-account; appstatus/versie bekend; stabiele wifi-onafhankelijkheid waar beloofd | OPEN — demo-repetitie |
| G11 Privacy/security review | DPIA en onafhankelijke code-/security review waar gepast | OPEN — niet af te leiden uit CI |

## Beslisregel

- Alle tests en G1–G4 moeten slagen voordat de kandidaat-APK naar menselijke acceptatie gaat.
- G5–G10 moeten PASS hebben met bewijs voor de exacte releasecandidate.
- G11 moet door de verantwoordelijke eigenaar beoordeeld zijn vóór breed gebruik met gevoelige zorggegevens.
- Elke FAIL blokkeert release; elke OPEN wordt niet als PASS gepresenteerd.
