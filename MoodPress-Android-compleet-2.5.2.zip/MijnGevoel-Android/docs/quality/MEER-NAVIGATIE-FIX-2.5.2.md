# MoodPress 2.5.2 — herstel van Meer-navigatie

## Probleem
De knoppen **Meer** en **Bekijk alle functies** konden bij openen de algemene melding “Er ging iets mis” tonen. De eerdere code bouwde de volledige lijst bedieningselementen al tijdens de constructor van `MorePage` en de startschermknoppen startten navigatie als niet-afgewachte taak. De precieze apparaatexceptie is niet rechtstreeks uit de app van de gebruiker uitgelezen; daarom is de fix defensief ontworpen en logt hij eventuele resterende runtimefouten.

## Wijzigingen
- `MorePage` bouwt de functielijst pas wanneer de pagina zichtbaar wordt.
- Opbouwen van de functielijst is afgeschermd met foutafhandeling en een zichtbare knop **Opnieuw proberen**.
- De twee startschermacties wachten nu op navigatie zodat uitzonderingen netjes worden afgehandeld.
- De onderste navigatie toont een begrijpelijke melding bij een navigatiefout in plaats van deze stil te verbergen.
- De actieknoppen in Meer wachten op het openen van hun bestemmingspagina.

## Acceptatiecriteria
1. Tik op de onderste tab **Meer**; de functielijst moet openen.
2. Ga terug naar Home en tik op **Bekijk alle functies**; hetzelfde scherm moet openen.
3. Zoek op `agenda`, wis het zoekveld en controleer dat de groepen terugkomen.
4. Open `Agenda` en keer terug naar Meer.
5. Test ook met grotere tekst en in landschapsstand.
6. Als een lijst niet kan renderen, moet de pagina bruikbaar blijven en moet **Opnieuw proberen** beschikbaar zijn; een exception wordt naar het lokale logboek geschreven.

## Status
Broncodewijziging is voorbereid. De GitHub-build en apparaattest van deze 2.5.2-hotfix moeten nog slagen voordat dit als opgelost kan worden beschouwd.
