# MoodPress Android 2.4.1

- Rustiger startscherm met maximaal vier primaire snelkoppelingen.
- Vaste navigatie Home / Dag / Gevoel / Meer.
- Zoekbare More-pagina met onderwerpen en functiebeschrijvingen.
- Eén catalogus voor de functielijst en zichtbaarheid-instellingen.
- Snel opslaan van een eenvoudig gevoel blijft mogelijk binnen Mijn gevoel.
- Behoud van app-ID voor update-test met bestaande telefooninstallatie.

Dit is een kandidaatversie. Eerst GitHub-build en acceptatietests uitvoeren.
