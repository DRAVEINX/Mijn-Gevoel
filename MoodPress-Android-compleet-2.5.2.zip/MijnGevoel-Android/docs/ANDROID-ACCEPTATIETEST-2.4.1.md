# MoodPress 2.4.1 — acceptatietest navigatie

## Automatisch
- [ ] APK-workflow groen: herstel, compile, unit tests en debug-APK.
- [ ] Release-workflow groen: tests, ondertekende APK, AAB en checksums.

## Logische indeling
- [ ] Onderste navigatie toont Home / Dag / Gevoel / Meer.
- [ ] Home heeft maximaal vier grote primaire snelkoppelingen.
- [ ] Home toont datum/dagoverzicht en eerstvolgende agenda-activiteit, of een rustige lege toestand.
- [ ] De volledige lijst met functies verschijnt niet op Home.
- [ ] Meer heeft zes herkenbare categorieën en zoekresultaten.
- [ ] Elke functie is bereikbaar via de juiste categorie of zoekterm.
- [ ] Verbergen van een functie verbergt deze in Meer en instellingenschermen, zonder gegevens te verwijderen.
- [ ] Instellingen blijft bereikbaar en de gebruiker kan verborgen functies weer tonen.
- [ ] Tabnavigatie stapelt geen duplicaten en brengt gebruiker naar het juiste scherm.
- [ ] Vier-keuze-gevoel opslaan is beschikbaar onder Mijn gevoel.

## Toegankelijkheid en apparaten
- [ ] Telefoon met breedte circa 360 dp.
- [ ] Grotere telefoon; langere labels breken correct af.
- [ ] Tablet gebruikt bruikbare breedte en presenteert geen smal gecentreerd telefoonpaneel.
- [ ] Systeemtekst en app-tekst op alle niveaus.
- [ ] TalkBack leest knop/kaartnaam en beschrijving begrijpelijk voor.
- [ ] Alle interactiekaarten zijn goed aan te tikken.

## Gegevens en privacy
- [ ] Eerder opgeslagen agenda- en gevoelsgegevens blijven na update aanwezig.
- [ ] Veranderen van navigatie deelt geen gegevens.
- [ ] Scherm verbergen en sessie vergrendelen werken.
- [ ] Achtergrondtimer- en herinneringsgedrag is getest met Android-meldingsrechten aan/uit.

Noteer apparaatmodel, Android-versie en resultaten. Een niet-geteste controle niet als geslaagd markeren.
