# MoodPress Android 2.3.1 — acceptatietest

Voer uit nadat de APK via GitHub Actions is gebouwd. De groene build is noodzakelijk, maar vervangt de toesteltest niet.

## Home — nieuwe activiteitssamenvatting

- [ ] Met een afspraak later vandaag toont Home de naam en het juiste tijdstip.
- [ ] Bij meerdere open afspraken wordt de vroegste toekomstige afspraak getoond.
- [ ] Een afspraak waarvan de tijd vandaag voorbij is, wordt niet als eerstvolgende getoond.
- [ ] Een afgeronde afspraak wordt overgeslagen.
- [ ] Als er vandaag geen open activiteit meer is maar er morgen wel een staat, wordt de eerstvolgende toekomstige activiteit getoond.
- [ ] Een activiteit zonder tijd verdwijnt niet; de samenvatting zegt `tijd niet ingesteld`.
- [ ] Bij een lege agenda verschijnt `Er staat nog niets gepland`.
- [ ] De knop `Activiteit toevoegen` / `Agenda bekijken` opent de agenda.
- [ ] De tekst blijft leesbaar bij normale, grote en extra grote tekst.

## Regressiecontrole bestaande kernfuncties

- [ ] Inloggen, automatisch vergrendelen en opnieuw ontgrendelen.
- [ ] Agenda-item toevoegen, wijzigen via afvinken, verwijderen en opnieuw openen.
- [ ] Gevoel opslaan en eerdere registratie bekijken.
- [ ] Tekenen, opslaan en tekening opnieuw openen.
- [ ] Routine afvinken en herinnering controleren.
- [ ] Privacy-informatie openen en gegevens exporteren/back-up herstellen.
- [ ] Delen/ontvangen blijft handmatig, expliciet en versleuteld.
- [ ] App verwijderen en opnieuw installeren; bevestig vooraf welk lokaal dataverlies kan optreden.

Noteer toestelmodel, Android-versie, testdatum en eventuele foutmeldingen. Deel geen echte gevoelige cliëntgegevens in bugrapporten.
