# MoodPress navigation 2.4.1

## Primary navigation
1. **Home** — a calm landing screen with at most four large shortcut cards, a date/day link and next-activity summary.
2. **Dag** — today's planning and day tools.
3. **Gevoel** — feeling check-in, feeling history, calendar, insights and feeling words.
4. **Meer** — secondary features, grouped by topic and searchable by feature name/group/description.

## Groups under Meer
- Mijn dag en planning
- Mijn gevoel en rust
- Communicatie en steun
- Doelen en zelfstandigheid
- Creatief en dagboek
- Profiel, privacy en hulp

## Behaviour
- Home never displays the full all-features directory.
- Search filters the grouped feature list.
- Feature visibility settings and the directory use the same catalog, preventing labels/grouping from drifting apart.
- Settings is always accessible; hiding other features doesn't lock a user out of settings.
- App logout/session lock remain under Meer, and privacy cover is available in the toolbar.
- One-tap feeling entries are retained within Mijn gevoel instead of appearing as a separate block on Home.

## Manual usability checks still required
Test on small phone, large phone and tablet; enlarged text; TalkBack; hidden-feature setting; empty agenda; a full agenda; and navigation back from specialized pages.
