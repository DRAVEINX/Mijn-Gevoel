# MoodPress Android — status ontwikkelplan 2.4.1

## Verwerkt in deze kandidaat
- Hoofdnavigatie geordend als Home / Dag / Gevoel / Meer.
- Home teruggebracht tot vier of minder grote primaire snelkoppelingen; het volledige functieoverzicht is er niet meer.
- Home toont de datum en, indien agenda-functies aanstaan, de eerstvolgende activiteit of een lege toestand.
- Meer is doorzoekbaar en groepeert functies op onderwerp.
- Functiecatalogus is één bron voor de Meer-pagina en zichtbaarheid-instellingen.
- Instellingen blijft toegankelijk, ook als de gebruiker overige functies verbergt.
- De één-tik-gevoelssnelkeuze is onder Mijn gevoel behouden.
- Versie 2.4.1, Android versionCode 31; application id blijft nl.mijngevoel.app.

## Wat is nog niet als bewezen af te vinken
- .NET MAUI/C# compile en automatische tests moeten door GitHub Actions worden uitgevoerd.
- Werkelijke installatie en upgrade van een bestaande 2.3.x-app op fysieke Android-telefoons.
- Schermlezer/TalkBack-test, grotere tekst, contrast en toegankelijkheid.
- Breedte-/lay-outtest op telefoon en tablet.
- Onafhankelijke privacy- en beveiligingsbeoordeling.
- Gebruikerstest met mensen uit de doelgroep.

## Technische grenzen
Cloudsynchronisatie, een live begeleidersportaal of automatische noodmeldingen worden niet geclaimd. Zulke functies vereisen aparte, veilige serverinfrastructuur en expliciete toestemming.
