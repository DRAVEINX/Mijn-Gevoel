# MoodPress Android 2.3.1 — eerste stap van het volledige ontwikkelplan

## Wat is aangepast

- Het startscherm toont nu de eerstvolgende niet-afgeronde agenda-activiteit die nog relevant is: later vandaag of op een toekomstige dag.
- Activiteiten met een tijdstip dat vandaag al voorbij is, worden overgeslagen.
- Afgeronde activiteiten worden niet als volgende activiteit getoond.
- Activiteiten zonder geldige of ingevulde tijd blijven zichtbaar als niet ingepland, zodat ze niet stil verdwijnen.
- Als er geen activiteit beschikbaar is, verschijnt een rustige lege toestand met een knop om een activiteit toe te voegen.
- De sorteervoorwaarden zijn ondergebracht in een aparte Core-service en krijgen regressietests.
- Android-versie verhoogd van 2.3.0 (versionCode 27) naar 2.3.1 (versionCode 28), zodat de kandidaat niet dezelfde versionCode heeft als de bestaande 2.3.0-installatie.

## Wat dit niet betekent

Dit is de eerste kleine, gecontroleerde stap van het aangeleverde volledige ontwikkelplan. Het betekent niet dat alle punten uit de 18 hoofdstukken al afgerond zijn. Bestaande functies worden gefaseerd geïnventariseerd en getest. GitHub Actions moet de code nog compileren en de tests uitvoeren; daarna zijn tests op echte Android-apparaten nodig.

De app blijft .NET MAUI/C#. Er wordt niet gemigreerd naar Flutter of een andere technologie.
