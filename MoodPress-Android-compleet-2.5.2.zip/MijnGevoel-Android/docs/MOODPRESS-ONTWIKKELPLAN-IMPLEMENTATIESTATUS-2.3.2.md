# MoodPress — status tegenover het volledige Android-ontwikkelplan

Peildatum: 14 oktober 2026 · Kandidaatversie: 2.3.2 · Android `versionCode` 29.

Deze status maakt onderscheid tussen broncodeaanwezigheid en bewijs door test. `Aanwezig` betekent dat er passende code is aangetroffen; het is geen bewijs dat elke route foutloos werkt op alle toestellen. De nieuwe 2.3.2-code moet nog door CI en apparaattests.

## Werk aan de huidige kandidaat

- Timer: de eindtijd en status worden per gebruiker in de versleutelde VaultStore bewaard. Timerstatus wordt herberekend bij terugkeer; lokale scherm-ticks zijn alleen voor de zichtbare weergave. Nog geen gegarandeerde Android-notificatie bij afloop op de achtergrond.
- Agenda: bestaande activiteit aanpassen en annuleren toegevoegd; datum/tijd/titel/pictogram worden bijgewerkt en `Done` blijft behouden.
- Gevoelscheck-ins: bekijken, aanpassen en met bevestiging verwijderen toegevoegd; oudere registraties blijven via de kalender bereikbaar.
- Er zijn vijf Core-unit-tests voor timerstatus en vijf voor voortgang van stappenplannen toegevoegd; bestaande tests voor agenda-samenvatting en beveiliging blijven in het testproject.

## Hoofdstukken uit het aangeleverde 18-hoofdstukkenplan

1. **Doel en uitgangspunten — gedeeltelijk.** Privacy, begrijpelijke taal en bestaand project behouden zijn leidend. Vrijwillige doelgroepfeedback moet nog worden uitgevoerd.
2. **Productvisie en doelgroep — gedeeltelijk.** Profielen Kind/Jongere/Volwassene/Algemeen bestaan. Validatie met uiteenlopende cliënten is nog niet aangetoond.
3. **Functieoverzicht — gedeeltelijk.** Dag, gevoel, rust, zelfstandigheid, communicatie, welzijn, steun en profiel zijn in verschillende vorm aanwezig; sommige subfuncties en beheeracties zijn incompleet.
4. **Schermen en gebruikersroutes — gedeeltelijk.** Hoofdnavigatie en kernschermen bestaan. Een volledige scherm-voor-scherm routecheck is nog open.
5. **Functionele eisen — gedeeltelijk.** Deze release pakt agenda bewerken, check-in beheer, duurzame timerstatus en voortgang van stap-voor-stap-routines aan. Uitgebreidere agenda-statussen blijven open.
6. **Toegankelijkheid — gedeeltelijk.** Tekstgrootte, thema, regelafstand en voorlezen bestaan; daadwerkelijke TalkBack/contrast/schermformaat-tests moeten nog worden uitgevoerd.
7. **Technische keuzes — aanwezig.** Huidige Android-technologie is .NET MAUI/C# op `net10.0-android`, met gedeelde Core en tests op .NET 8; geen Flutter-migratie.
8. **Projectstructuur — gedeeltelijk.** Core/data/security zijn gescheiden, maar `FeaturePage.cs` is groot en verdient later gecontroleerde opsplitsing met regressietests.
9. **Gegevensmodellen — gedeeltelijk.** Modellen voor activiteiten, gevoelens, routines, doelen en instellingen bestaan. Agenda-status ondersteunt nog hoofdzakelijk gepland/afgerond.
10. **Opslag en privacy — gedeeltelijk.** Items worden per bestand versleuteld in de lokale `VaultStore` opgeslagen; export/back-up bestaan. Herstelgedrag en migratie bij updates moeten op apparaten worden getest.
11. **Bouwvolgorde — actief.** Er wordt voortgebouwd in aparte kandidaatversies met afzonderlijke workflow en terugval naar 2.3.0.
12. **Testplan — gedeeltelijk.** Geautomatiseerde Core-/securitytests bestaan; CI en echte-toesteltest voor 2.3.2 zijn nog vereist.
13. **Beveiliging en verantwoord gebruik — gedeeltelijk.** Lokale encryptie en expliciet delen bestaan; onafhankelijke beveiligings/privacybeoordeling ontbreekt. App is geen noodmeldingssysteem of zorgvervanger.
14. **Release en onderhoud — gedeeltelijk.** Bestaande signed-releaseworkflows bestaan. Nieuwe 2.3.2 release nog niet gebouwd; openbare downloadasset en upgradeprocedure moeten worden gecontroleerd.
15. **Werkplanning — actief.** Prioriteit ligt bij gegevensbeheer, timers, agenda en kritieke fouten voor verdere uitbreidingen.
16. **Definition of Done — nog niet overal gehaald.** Veel functies missen aantoonbare foutscenario- en toegankelijkheidstests op echte apparaten.
17. **Eerste programmeersessie — grotendeels uitgevoerd.** Bestaande .NET MAUI-architectuur geïnventariseerd, broncodevariant gemaakt en beperkte wijzigingen doorgevoerd; lokale .NET-build is niet uitgevoerd.
18. **Eindchecklist — gedeeltelijk.** Niet afvinken zonder de teststappen en privacycontrole werkelijk uit te voeren.

## Nog open — volgende prioriteiten

1. CI bouwen en alle tests laten slagen; anders compile- of regressiefouten fixen voordat release.
2. De 2.3.2 acceptatietest uitvoeren op een echte telefoon, inclusief upgrade-dataretentie, timer terugkeer/herstart, agenda wijzigen en check-in verwijderen.
3. Stappenplan hervatten op echte apparaten testen (de persistente voortgang is in deze kandidaat toegevoegd).
4. Agenda-status uitbreiden naar uitgesteld/gewijzigd/geannuleerd, zonder oude data te verliezen.
5. Instellingen en functiekeuze aanvullen; TalkBack/contrast/schermformaten systematisch toetsen.
6. Herstel/back-up, lokale ondersteunerstoegang en export-/verwijderproces verder auditen.
7. Grote UI-bestanden pas opsplitsen als er regressietests voor de betrokken functionaliteit zijn.
8. Online synchronisatie of begeleidersportaal vereist een backend met server-side authenticatie/rechten; lokale delen is geen live toegang en geen noodservice.

## Bewijsstatus

- Bron-ZIP-integriteit: gecontroleerd.
- Delimiter-balans van de gewijzigde C#-bestanden: gecontroleerd met statische scanner.
- Lokale .NET build/test: niet uitgevoerd; .NET SDK ontbreekt in deze omgeving.
- GitHub Actions build/tests voor 2.3.2: wachten op upload en workflow-run.
- Installatie/apparaattest: wacht op test op echte Android-telefoon.
