# Status Android-release — MoodPress 2.0

## Status

Dit pakket bevat de **broncode voor Android 2.0**, niet een kant-en-klare APK. In deze werkomgeving is de .NET SDK niet geïnstalleerd. Daardoor kon ik geen C#-compilatie, Android-package-build of fysieke toesteltest uitvoeren. De release-status blijft dus **nog niet gebouwd / nog niet toestelgetest** totdat GitHub Actions succesvol is afgerond en de acceptatietests zijn uitgevoerd.

## Wat in de broncode is bijgewerkt

- Appweergaveversie `2.0`, Android version code `20`.
- Dagelijkse check-in met gevoel, intensiteit, aanleiding en optionele notitie.
- Gevoelskalender met de laatste 30 dagen.
- Inzichten voor de laatste 7 en 30 dagen.
- Tekenhulpmiddelen voor kleur, pendikte, ongedaan maken en alles wissen.
- Check-ins in weekoverzicht, privacytelling en leesbare JSON-export.
- Releaseworkflow selecteert expliciet `MijnGevoel-Android-compleet-2.0.zip` en controleert de versie.
- Debugworkflow en lokaal bouwscript gebruiken `net10.0-android`.
- Exporttest controleert opslag en export van check-ins.

## Een debug-APK bouwen

Op een computer met .NET 10 SDK, MAUI Android-workload, Java 17 en Android SDK:

```bash
dotnet workload restore MijnGevoel.Android/MijnGevoel.Android.csproj
dotnet restore MijnGevoel.Tests/MijnGevoel.Tests.csproj
dotnet test MijnGevoel.Tests/MijnGevoel.Tests.csproj --configuration Release
dotnet publish MijnGevoel.Android/MijnGevoel.Android.csproj --configuration Debug --framework net10.0-android -p:AndroidPackageFormat=apk
```

Of voer `scripts/build-android.sh` uit.

## Release-APK en Google Play AAB via GitHub

1. Upload de projectinhoud en `MijnGevoel-Android-compleet-2.0.zip` naar de hoofdmap van de repository.
2. Kopieer `android-release.yml` naar `.github/workflows/android-release.yml`.
3. Controleer dat de bestaande GitHub Secrets voor de release-keystore zijn ingesteld. Deel of commit nooit een keystore of wachtwoord.
4. Start **Actions → MoodPress 2.0 - Android Release → Run workflow**.
5. Download alleen bij succes het artifact met APK, AAB en `SHA256SUMS.txt`.

## Vóór gebruik met echte gegevens

Doorloop `ANDROID-ACCEPTATIETEST.md` op een testtelefoon, waaronder accountregistratie, authenticator en herstelcodes, automatisch vergrendelen, biometrische toegang indien aangezet, back-up/terugzetten, export, verwijdering van gegevens, check-ins en tekeningen. Een groene CI-build is op zichzelf geen bewijs dat iedere functie op elk apparaat werkt.

## Ontwikkelkandidaat 2.3.1 — 14 oktober 2026

- Eerste stap van het volledige Android-ontwikkelplan: Home toont de eerstvolgende niet-afgeronde toekomstige agenda-activiteit, met een lege toestand en een directe knop naar Agenda.
- Nieuwe Core-sorteerservice en regressietests toegevoegd.
- VersionCode verhoogd naar 28.
- Status: broncode voorbereid; GitHub Actions en echte Android-toesteltest moeten de wijziging nog bevestigen.


## MoodPress Android 2.4.0 — integrale kandidaat

Deze kandidaat bundelt de uitvoerbare lokale functies uit het volledige ontwikkelplan. De broncode is aangepast, maar moet eerst door de aparte 2.4.0 GitHub Actions-workflows worden gebouwd en getest. Een .NET SDK was niet beschikbaar in de voorbereidende werkomgeving; er is daarom geen lokale C#-compile of Android-build als geslaagd gepresenteerd.

Voor de volledige hoofdstukstatus, checks en open acceptatiepunten zie `docs/MOODPRESS-ONTWIKKELPLAN-STATUS-2.4.0.md`, `docs/MOODPRESS-VALIDATIERAPPORT-2.4.0.md` en `docs/ANDROID-ACCEPTATIETEST-2.4.0.md`. De stabiele 2.3.0-telefoonrelease en aparte tabletapp blijven beschikbaar als terugvaloptie.
