# MoodPress Android 2.5.0 — release candidate

MoodPress is een bestaande .NET MAUI/C#-app met gedeelde Core-logica en geautomatiseerde tests. Deze kandidaat verbetert onder andere Home-snelkoppelingen, breedteafhankelijke indeling, schermlezerlabels en veilige bestandsafhandeling.

## Projectonderdelen

- Android UI: `MijnGevoel.Android/MijnGevoel.Android.csproj` (`net10.0-android`)
- Gegevens- en beveiligingslaag: `MijnGevoel.Core/MijnGevoel.Core.csproj` (`net8.0`)
- Automatische tests: `MijnGevoel.Tests/MijnGevoel.Tests.csproj` (`net8.0`)
- Windows-project: `MijnGevoel.Desktop/MijnGevoel.Desktop.csproj`

## Wat deze kandidaat toevoegt

- Home met maximaal vier instelbare snelkoppelingen; de vereenvoudigde startpagina toont er maximaal twee.
- Een aparte, kortere pagina om de Home-volgorde te kiezen.
- Zoekbare functiegroepen op Meer en responsive grids voor verschillende vensterbreedtes.
- Schermlezerlabels en stabiele AutomationId's voor navigatie en tegels.
- Extra Core-tests voor snelkoppelingen, accountnaamvalidatie, opslagintegriteit en bestandsbeveiliging.
- Account-JSON wordt via tijdelijke bytebuffers gelezen/geschreven die na gebruik worden gewist; lokale vaultbestanden blijven versleuteld.
- Back-upherstel valideert eerst het volledige archief, schrijft naar een staging-map en rolt terug bij een fout.

## Kwaliteitsstatus — lees dit voor een demo

Dit is een **release candidate**, geen door deze werkomgeving bewezen productie-release. De repository-workflows moeten de C#-tests en Android-compilatie daadwerkelijk uitvoeren. Daarna moeten upgrade/installatie, TalkBack, grotere tekst, contrast, timer-/meldingsgedrag en telefoon/tablet-weergave op echte apparaten worden getest. De hoofdstukken `docs/quality/` bevatten de traceability, privacygrenzen en acceptatieprocedure.

Cloudsynchronisatie, een live begeleidersportaal en automatische noodmeldingen worden niet geclaimd. Ze vereisen een afzonderlijke beveiligde backend, expliciete toestemming en aanvullende tests.

## Bouwen

Voor lokale tests: installeer de .NET 8 SDK. Voor Android: .NET 10 SDK, MAUI Android-workload en Java 17. Zie `docs/quality/RELEASE-RUNBOOK-2.5.0.md` en `docs/quality/ANDROID-ACCEPTATIETEST-2.5.0.md`.
