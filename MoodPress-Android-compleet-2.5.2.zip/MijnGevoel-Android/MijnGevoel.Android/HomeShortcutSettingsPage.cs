using MijnGevoel.Core.Data;

namespace MijnGevoel.AndroidApp;

/// <summary>Focused settings screen for choosing and ordering up to four Home shortcuts.</summary>
public sealed class HomeShortcutSettingsPage : ContentPage
{
    private const string EmptySelection = "(Geen snelkoppeling)";
    private readonly FeatureCatalogItem[] _features;
    private readonly string[] _labels;
    private readonly string[] _keys;
    private readonly Picker[] _pickers = new Picker[HomeShortcutService.MaximumShortcuts];
    private readonly VerticalStackLayout _root;

    public HomeShortcutSettingsPage()
    {
        Title = "Home-snelkoppelingen";
        BackgroundColor = AppUi.Background;
        _features = FeatureCatalog.All.ToArray();
        _labels = new[] { EmptySelection }.Concat(_features.Select(x => x.Icon + " " + x.Label)).ToArray();
        _keys = new[] { string.Empty }.Concat(_features.Select(x => x.Kind.ToString())).ToArray();

        _root = new VerticalStackLayout
        {
            Padding = new Thickness(16, 14, 16, 28),
            Spacing = 12,
            BackgroundColor = AppUi.Background,
            Children =
            {
                AppUi.Title("Kies jouw startscherm"),
                AppUi.Label("Kies maximaal vier functies. Snelkoppeling 1 staat linksboven; snelkoppeling 2 staat daarnaast. In de vereenvoudigde modus worden alleen de eerste twee getoond."),
                AppUi.Label("Een snelkoppeling verwijdert niets uit je gegevens. Je kunt de keuze later weer aanpassen.", muted: true)
            }
        };

        var configured = HomeShortcutService.GetConfiguredOrDefault(
            AppSession.Settings, _features.Select(x => x.Kind.ToString())).ToArray();
        for (int i = 0; i < _pickers.Length; i++)
        {
            var selected = i < configured.Length ? FindLabel(configured[i]) : EmptySelection;
            var picker = AppUi.Picker($"Snelkoppeling {i + 1}", _labels, selected);
            picker.AutomationId = $"home_shortcut_picker_{i + 1}";
            SemanticProperties.SetDescription(picker, $"Keuze voor snelkoppeling {i + 1} op Home");
            _pickers[i] = picker;
            _root.Children.Add(AppUi.Label($"Snelkoppeling {i + 1}", title: true));
            _root.Children.Add(picker);
        }

        _root.Children.Add(AppUi.Button("Herstel de standaardindeling", ApplyDefaults, quiet: true));
        _root.Children.Add(AppUi.AsyncButton("💾 Snelkoppelingen opslaan", SaveAsync));
        _root.Children.Add(AppUi.Button("Annuleren", async () => await Navigation.PopAsync(), quiet: true));
        _root.Children.Add(AppUi.Copyright());
        Content = AppUi.WithBottomNavigation(this,
            new ScrollView { Content = _root, BackgroundColor = AppUi.Background }, "more");
        ToolbarItems.Add(new ToolbarItem("🔒", null, async () => await ((App)Application.Current!).LockToLoginAsync("Je sessie is vergrendeld.")));
        ToolbarItems.Add(new ToolbarItem("🙈", null, async () => await Navigation.PushAsync(new PrivacyCoverPage())));
    }

    string FindLabel(string kindKey)
    {
        var item = _features.FirstOrDefault(x => x.Kind.ToString() == kindKey);
        return item is null ? EmptySelection : item.Icon + " " + item.Label;
    }

    void ApplyDefaults()
    {
        var defaults = HomeShortcutService.Defaults;
        for (int i = 0; i < _pickers.Length; i++)
            _pickers[i].SelectedItem = i < defaults.Count ? FindLabel(defaults[i]) : EmptySelection;
    }

    async Task SaveAsync()
    {
        var selected = _pickers
            .Where(p => p.SelectedIndex > 0)
            .Select(p => _keys[p.SelectedIndex])
            .ToArray();
        if (selected.Distinct(StringComparer.Ordinal).Count() != selected.Length)
        {
            await DisplayAlertAsync("Dubbele snelkoppeling", "Kies voor elke plek een andere functie. Kies '(Geen snelkoppeling)' als je een plek leeg wilt laten.", "OK");
            return;
        }

        var known = _features.Select(x => x.Kind.ToString()).ToArray();
        var normalized = HomeShortcutService.Normalize(selected, known);
        AppSession.Settings.HomeShortcuts = normalized.ToList();
        AppSession.Settings.HomeShortcutsConfigured = true;

        // If feature filtering has already been configured, keep all pinned shortcuts available from More too.
        if (AppSession.Settings.FeatureVisibilityConfigured)
        {
            AppSession.Settings.EnabledFeatures = FeatureVisibilityService.NormalizeEnabled(
                (AppSession.Settings.EnabledFeatures ?? new List<string>()).Concat(normalized), known);
        }

        AppSession.SaveSettings();
        await DisplayAlertAsync("Opgeslagen", "Je Home-indeling is opgeslagen. Ga terug naar Home om de nieuwe snelkoppelingen te zien.", "OK");
        await Navigation.PopAsync();
    }
}
