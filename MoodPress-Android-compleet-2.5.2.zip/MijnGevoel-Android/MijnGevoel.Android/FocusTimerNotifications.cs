using System.Runtime.Versioning;
using Android.App;
using Android.Content;
using Android.Media;
using Android.OS;
using Android.Security.Keystore;
using Javax.Crypto;
using Javax.Crypto.Spec;
using MijnGevoel.Core.Data;

namespace MijnGevoel.AndroidApp;

/// <summary>
/// Schedules a one-shot local timer notification independently of the visible page.
/// Only the end timestamp is stored, encrypted with an Android Keystore AES-GCM key.
/// Android battery rules and user notification settings may delay or suppress delivery.
/// </summary>
public static class FocusTimerNotifications
{
    const string KeyAlias = "moodpress-focus-timer-v1";
    const string ScheduleFile = "focus-timer.enc";
    const string ChannelId = "moodpress-focus-timer-v1";
    const int RequestCode = 763019;

    public static void SyncFromState(Context context, TimerSessionState? state)
    {
        if (state?.IsRunning == true && state.EndsAt is DateTime endAt) Schedule(context, endAt);
        else Cancel(context, clearNotification: false);
    }

    public static void Schedule(Context context, DateTime endsAt)
    {
        try
        {
            long endMillis = new DateTimeOffset(endsAt).ToUnixTimeMilliseconds();
            SaveEndMillis(context, endMillis);
            ScheduleAlarm(context, endMillis);
            EnsureChannel(context);
        }
        catch (Exception ex)
        {
            Android.Util.Log.Warn("MoodPressTimer", $"Timer reminder could not be scheduled: {ex.GetType().Name}");
        }
    }

    public static void Cancel(Context context, bool clearNotification = true)
    {
        try
        {
            var manager = context.GetSystemService(Context.AlarmService) as AlarmManager;
            var intent = new Intent(context, typeof(FocusTimerReceiver));
            intent.SetAction("nl.mijngevoel.focus-timer.finished");
            var pending = PendingIntent.GetBroadcast(context, RequestCode, intent,
                PendingIntentFlags.NoCreate | PendingIntentFlags.Immutable);
            if (pending is not null)
            {
                manager?.Cancel(pending);
                pending.Cancel();
            }
            if (clearNotification)
                (context.GetSystemService(Context.NotificationService) as NotificationManager)?.Cancel(RequestCode);
            var file = GetSchedulePath(context);
            if (File.Exists(file)) File.Delete(file);
        }
        catch (Exception ex)
        {
            Android.Util.Log.Warn("MoodPressTimer", $"Timer reminder could not be cancelled: {ex.GetType().Name}");
        }
    }

    internal static void RestoreAfterBoot(Context context)
    {
        try
        {
            var endMillis = LoadEndMillis(context);
            if (endMillis is null) return;
            if (endMillis.Value <= DateTimeOffset.UtcNow.ToUnixTimeMilliseconds())
                ShowFinishedNotification(context);
            else
                ScheduleAlarm(context, endMillis.Value);
        }
        catch (Exception ex)
        {
            Android.Util.Log.Warn("MoodPressTimer", $"Timer reminder could not be restored: {ex.GetType().Name}");
        }
    }

    internal static void OnAlarm(Context context)
    {
        try
        {
            var endMillis = LoadEndMillis(context);
            if (endMillis is null) return;
            if (endMillis.Value > DateTimeOffset.UtcNow.ToUnixTimeMilliseconds())
            {
                // SetAndAllowWhileIdle may run early on some devices; re-arm if the target time has not arrived.
                ScheduleAlarm(context, endMillis.Value);
                return;
            }
            ShowFinishedNotification(context);
        }
        catch (Exception ex)
        {
            Android.Util.Log.Warn("MoodPressTimer", $"Timer alarm could not be processed: {ex.GetType().Name}");
            try { var file = GetSchedulePath(context); if (File.Exists(file)) File.Delete(file); } catch { }
        }
    }

    static void ScheduleAlarm(Context context, long endMillis)
    {
        var manager = context.GetSystemService(Context.AlarmService) as AlarmManager;
        if (manager is null) return;
        var intent = new Intent(context, typeof(FocusTimerReceiver));
        intent.SetAction("nl.mijngevoel.focus-timer.finished");
        var pending = PendingIntent.GetBroadcast(context, RequestCode, intent,
            PendingIntentFlags.UpdateCurrent | PendingIntentFlags.Immutable);
        if (pending is null) return;
        manager.SetAndAllowWhileIdle(AlarmType.RtcWakeup, endMillis, pending);
    }

    static void ShowFinishedNotification(Context context)
    {
        try
        {
            EnsureChannel(context);
            var manager = context.GetSystemService(Context.NotificationService) as NotificationManager;
            bool allowed = !OperatingSystem.IsAndroidVersionAtLeast(33) ||
                context.CheckSelfPermission("android.permission.POST_NOTIFICATIONS") == Android.Content.PM.Permission.Granted;
            if (manager is not null && allowed)
            {
                var openIntent = new Intent(context, typeof(MainActivity));
                openIntent.SetFlags(ActivityFlags.ClearTop | ActivityFlags.SingleTop | ActivityFlags.NewTask);
                var openPending = PendingIntent.GetActivity(context, RequestCode + 1, openIntent,
                    PendingIntentFlags.UpdateCurrent | PendingIntentFlags.Immutable);
                Notification.Builder builder = OperatingSystem.IsAndroidVersionAtLeast(26)
                    ? OreoBuilder(context)
                    : new Notification.Builder(context);
                builder.SetSmallIcon(Resource.Drawable.routine_notification);
                builder.SetContentTitle("⏰ De tijd is om");
                builder.SetContentText("Je timer is afgelopen. Open MoodPress als je verder wilt.");
                builder.SetStyle(new Notification.BigTextStyle().BigText("Je timer is afgelopen. Je kunt nu stoppen, pauze nemen of verdergaan wanneer jij er klaar voor bent."));
                builder.SetCategory(Notification.CategoryAlarm);
                builder.SetVisibility((int)NotificationVisibility.Private);
                builder.SetAutoCancel(true);
                if (openPending is not null) builder.SetContentIntent(openPending);
                if (!OperatingSystem.IsAndroidVersionAtLeast(26)) builder.SetPriority((int)NotificationPriority.High);
                var notification = builder.Build();
                if (notification is not null) manager.Notify(RequestCode, notification);
            }
        }
        catch (Java.Lang.SecurityException) { /* Notification permission may be denied or revoked. */ }
        catch (Exception ex) { Android.Util.Log.Warn("MoodPressTimer", $"Finished timer notification failed: {ex.GetType().Name}"); }
        finally { try { var file = GetSchedulePath(context); if (File.Exists(file)) File.Delete(file); } catch { } }
    }

    static void EnsureChannel(Context context)
    {
        if (OperatingSystem.IsAndroidVersionAtLeast(26)) EnsureChannelOreo(context);
    }

    [SupportedOSPlatform("android26.0")]
    static Notification.Builder OreoBuilder(Context context) => new Notification.Builder(context, ChannelId);

    [SupportedOSPlatform("android26.0")]
    static void EnsureChannelOreo(Context context)
    {
        var manager = context.GetSystemService(Context.NotificationService) as NotificationManager;
        if (manager is null || manager.GetNotificationChannel(ChannelId) is not null) return;
        var channel = new NotificationChannel(ChannelId, "Timer van MoodPress", NotificationImportance.High)
        {
            Description = "Een privé-melding wanneer je zelf ingestelde timer afloopt."
        };
        channel.EnableVibration(true);
        manager.CreateNotificationChannel(channel);
    }

    static string GetSchedulePath(Context context) => Path.Combine(context.FilesDir!.AbsolutePath!, ScheduleFile);

    static void SaveEndMillis(Context context, long timestamp)
    {
        var plain = System.Text.Encoding.UTF8.GetBytes(timestamp.ToString(System.Globalization.CultureInfo.InvariantCulture));
        try
        {
            var key = GetOrCreateKey();
            using var cipher = Cipher.GetInstance("AES/GCM/NoPadding") ?? throw new InvalidOperationException("AES-GCM unavailable.");
            cipher.Init(CipherMode.EncryptMode, key);
            var encrypted = cipher.DoFinal(plain) ?? throw new InvalidOperationException("Timer schedule encryption failed.");
            var iv = cipher.GetIV() ?? throw new InvalidOperationException("Timer schedule IV missing.");
            var blob = new byte[iv.Length + encrypted.Length];
            Buffer.BlockCopy(iv, 0, blob, 0, iv.Length);
            Buffer.BlockCopy(encrypted, 0, blob, iv.Length, encrypted.Length);
            var path = GetSchedulePath(context);
            var temp = path + ".tmp";
            File.WriteAllBytes(temp, blob);
            File.Move(temp, path, true);
            Array.Clear(encrypted, 0, encrypted.Length);
            Array.Clear(blob, 0, blob.Length);
        }
        finally { Array.Clear(plain, 0, plain.Length); }
    }

    static long? LoadEndMillis(Context context)
    {
        var path = GetSchedulePath(context);
        if (!File.Exists(path)) return null;
        var blob = File.ReadAllBytes(path);
        if (blob.Length < 13) return null;
        using var cipher = Cipher.GetInstance("AES/GCM/NoPadding") ?? throw new InvalidOperationException("AES-GCM unavailable.");
        cipher.Init(CipherMode.DecryptMode, GetOrCreateKey(), new GCMParameterSpec(128, blob[..12]));
        var plain = cipher.DoFinal(blob[12..]) ?? throw new InvalidOperationException("Timer schedule decryption failed.");
        try
        {
            return long.TryParse(System.Text.Encoding.UTF8.GetString(plain), System.Globalization.NumberStyles.None,
                System.Globalization.CultureInfo.InvariantCulture, out var timestamp) ? timestamp : null;
        }
        finally { Array.Clear(plain, 0, plain.Length); Array.Clear(blob, 0, blob.Length); }
    }

    static Java.Security.IKey GetOrCreateKey()
    {
        var store = Java.Security.KeyStore.GetInstance("AndroidKeyStore") ?? throw new InvalidOperationException("Android Keystore unavailable.");
        store.Load(null);
        var existing = store.GetKey(KeyAlias, null);
        if (existing is not null) return existing;
        var generator = KeyGenerator.GetInstance(KeyProperties.KeyAlgorithmAes, "AndroidKeyStore") ?? throw new InvalidOperationException("AES key generation unavailable.");
        var spec = new KeyGenParameterSpec.Builder(KeyAlias, KeyStorePurpose.Encrypt | KeyStorePurpose.Decrypt)
            .SetBlockModes(KeyProperties.BlockModeGcm)
            .SetEncryptionPaddings(KeyProperties.EncryptionPaddingNone)
            .SetRandomizedEncryptionRequired(true)
            .Build();
        generator.Init(spec);
        generator.GenerateKey();
        store.Load(null);
        return store.GetKey(KeyAlias, null) ?? throw new InvalidOperationException("Android Keystore key unavailable.");
    }
}

[BroadcastReceiver(Enabled = true, Exported = false)]
public sealed class FocusTimerReceiver : BroadcastReceiver
{
    public override void OnReceive(Context? context, Intent? intent)
    {
        if (context is null || intent is null || intent.Action != "nl.mijngevoel.focus-timer.finished") return;
        FocusTimerNotifications.OnAlarm(context);
    }
}
