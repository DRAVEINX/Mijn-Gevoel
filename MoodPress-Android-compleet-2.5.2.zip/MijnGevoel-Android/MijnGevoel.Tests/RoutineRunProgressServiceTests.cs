using MijnGevoel.Core.Data;
using Xunit;

public sealed class RoutineRunProgressServiceTests
{
    [Fact]
    public void MissingProgressStartsAtFirstStep()
    {
        Assert.Equal(0, RoutineRunProgressService.ResumeStep(null, 4));
    }

    [Fact]
    public void IncompleteProgressResumesAtSavedStep()
    {
        var progress = new RoutineRunProgress(Guid.NewGuid(), 2, false, DateTime.UtcNow);
        Assert.Equal(2, RoutineRunProgressService.ResumeStep(progress, 4));
    }

    [Fact]
    public void ProgressIsClampedWhenRoutineHasFewerSteps()
    {
        var progress = new RoutineRunProgress(Guid.NewGuid(), 6, false, DateTime.UtcNow);
        Assert.Equal(1, RoutineRunProgressService.ResumeStep(progress, 2));
    }

    [Fact]
    public void CompletedRoutineStartsOverAtFirstStep()
    {
        var progress = new RoutineRunProgress(Guid.NewGuid(), 3, true, DateTime.UtcNow);
        Assert.Equal(0, RoutineRunProgressService.ResumeStep(progress, 4));
    }

    [Fact]
    public void NewStepProgressIsNotCompletedAndClamped()
    {
        var id = Guid.NewGuid();
        var progress = RoutineRunProgressService.AtStep(id, 99, 3, DateTime.UtcNow);
        Assert.Equal(id, progress.RoutineId);
        Assert.Equal(2, progress.CurrentStep);
        Assert.False(progress.Completed);
    }
}
