using MijnGevoel.Core.Data;
using Xunit;

public sealed class HomeShortcutServiceTests
{
    static readonly string[] Known =
    {
        "DailyCheckIn", "Calm", "Cards", "DayToday", "Agenda", "Timer", "Settings"
    };

    [Fact]
    public void OlderSettingsReceiveCompatibleDefaults()
    {
        var settings = new UserSettings();
        Assert.Equal(new[] { "DailyCheckIn", "Calm", "Cards", "DayToday" },
            HomeShortcutService.GetConfiguredOrDefault(settings, Known));
    }

    [Fact]
    public void ConfiguredSelectionIsNormalizedAndLimitedToFour()
    {
        var result = HomeShortcutService.Normalize(
            new[] { "Agenda", "Timer", "Agenda", "not-a-feature", "Settings", "Calm", "Cards" }, Known);
        Assert.Equal(new[] { "Agenda", "Timer", "Settings", "Calm" }, result);
    }

    [Fact]
    public void SimplifiedModeReducesVisibleShortcutsWithoutChangingSavedSelection()
    {
        var settings = new UserSettings
        {
            HomeShortcutsConfigured = true,
            HomeShortcuts = new() { "Agenda", "Timer", "Settings", "Calm" },
            SimplifiedMode = true
        };
        Assert.Equal(new[] { "Agenda", "Timer" }, HomeShortcutService.GetVisible(settings, Known));
        Assert.Equal(4, settings.HomeShortcuts.Count);
    }

    [Fact]
    public void ExplicitlyEmptySelectionStaysEmpty()
    {
        var settings = new UserSettings { HomeShortcutsConfigured = true, HomeShortcuts = new() };
        Assert.Empty(HomeShortcutService.GetConfiguredOrDefault(settings, Known));
    }

    [Fact]
    public void UnknownSavedKeysAreIgnored()
    {
        var settings = new UserSettings
        {
            HomeShortcutsConfigured = true,
            HomeShortcuts = new() { "Agenda", "Unknown", "Timer" }
        };
        Assert.Equal(new[] { "Agenda", "Timer" }, HomeShortcutService.GetConfiguredOrDefault(settings, Known));
    }
}
