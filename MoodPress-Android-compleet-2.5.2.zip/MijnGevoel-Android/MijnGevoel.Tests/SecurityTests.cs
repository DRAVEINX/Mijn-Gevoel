using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MijnGevoel.Core.Data;
using MijnGevoel.Core.Security;
using Xunit;

public class TotpTests
{
    static readonly byte[] Rfc = Encoding.ASCII.GetBytes("12345678901234567890");   // testgeheim uit RFC 6238

    [Theory]
    [InlineData(59L, "287082")]
    [InlineData(1111111109L, "081804")]
    [InlineData(1234567890L, "005924")]
    public void KlopptMetRfc6238(long unix, string expected) => Assert.Equal(expected, Totp.Code(Rfc, unix / 30));

    [Fact]
    public void VerwerptVerkeerdeCode() => Assert.Null(Totp.Verify(Rfc, "000000", DateTimeOffset.FromUnixTimeSeconds(59)));
}

public class CryptoTests
{
    [Fact]
    public void RoundTrip()
    {
        var key = Crypto.Random(32);
        Assert.Equal("hoi"u8.ToArray(), Crypto.Open(key, Crypto.Seal(key, "hoi"u8.ToArray(), "x"), "x"));
    }

    [Fact]
    public void ManipulatieEnVerkeerdeContextWordenGeweigerd()
    {
        var key = Crypto.Random(32);
        var blob = Crypto.Seal(key, "geheim"u8.ToArray(), "a");
        Assert.ThrowsAny<CryptographicException>(() => Crypto.Open(key, blob, "b"));
        blob[15] ^= 1;
        Assert.ThrowsAny<CryptographicException>(() => Crypto.Open(key, blob, "a"));
    }
}

public class AccountTests : IDisposable
{
    readonly string _base = Path.Combine(Path.GetTempPath(), "mg-test-" + Guid.NewGuid());
    readonly AccountService _acc;
    public AccountTests() => _acc = new AccountService(Path.Combine(_base, "accounts"));
    public void Dispose() { try { Directory.Delete(_base, true); } catch { } }

    static byte[] FromBase32(string s)
    {
        const string a = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
        var o = new List<byte>(); int buf = 0, bits = 0;
        foreach (var ch in s) { buf = (buf << 5) | a.IndexOf(ch); bits += 5; if (bits >= 8) { o.Add((byte)(buf >> (bits - 8))); bits -= 8; } }
        return o.ToArray();
    }
    static string NowCode(Registration r) => Totp.Code(FromBase32(r.SecretForManualEntry), Totp.CurrentStep());

    Registration Setup(string user = "sam", string pw = "een goed wachtwoord")
    {
        var r = _acc.Register(user, pw);
        Assert.True(_acc.ConfirmRegistration(user, pw, NowCode(r)));
        return r;
    }

    [Fact] public void RegistrerenEnInloggen()
    {
        var r = Setup();
        var res = _acc.Login("SAM", "een goed wachtwoord", NowCode(r));   // hoofdletters maken niet uit
        Assert.True(res.Success); Assert.Equal(32, res.VaultKey!.Length);
    }

    [Fact] public void VerkeerdWachtwoordWordtGeweigerd()
    {
        var r = Setup(); Assert.False(_acc.Login("sam", "fout wachtwoord!!", NowCode(r)).Success);
    }

    [Fact] public void CodeKanNietTweeKeerGebruiktWorden()
    {
        var r = Setup(); var code = NowCode(r);
        Assert.True(_acc.Login("sam", "een goed wachtwoord", code).Success);
        Assert.False(_acc.Login("sam", "een goed wachtwoord", code).Success);
    }

    [Fact] public void BlokkadeNaVijfFouten()
    {
        var r = Setup();
        for (int i = 0; i < 5; i++) _acc.Login("sam", "fout wachtwoord!!", "000000");
        var res = _acc.Login("sam", "een goed wachtwoord", NowCode(r));
        Assert.False(res.Success); Assert.Contains("Wacht", res.Message);
    }

    [Fact] public void HerstelcodeWerktEenKeer()
    {
        var r = Setup(); var code = r.RecoveryCodes[0];
        var nieuw = _acc.RecoverAccess("sam", code, "nieuw wachtwoord 123");
        Assert.NotNull(nieuw);
        Assert.True(_acc.ConfirmRegistration("sam", "nieuw wachtwoord 123", NowCode(nieuw!)));
        Assert.True(_acc.Login("sam", "nieuw wachtwoord 123", NowCode(nieuw!)).Success);
        Assert.Null(_acc.RecoverAccess("sam", code, "weer een ander wachtwoord"));   // oude code is vervallen
    }

    [Fact] public void GegevensZijnVersleuteldEnTerugTeLezen()
    {
        var r = Setup(); var res = _acc.Login("sam", "een goed wachtwoord", NowCode(r));
        using var store = new VaultStore(res.VaultKey!, _acc.DataFolder("sam"));
        var e = new JournalEntry(Guid.NewGuid(), DateTime.Now, 2, "supergeheim dagboek");
        store.Save("diary", e.Id, e);
        Assert.Equal("supergeheim dagboek", store.Load<JournalEntry>("diary", e.Id)!.Text);
        var raw = File.ReadAllBytes(Directory.GetFiles(_acc.DataFolder("sam"), "diary-*.mg")[0]);
        Assert.DoesNotContain("supergeheim", Encoding.UTF8.GetString(raw));
    }

    [Fact] public void NieuweHerstelcodesVervangenDeOude()
    {
        var r = Setup(); var oud = r.RecoveryCodes[0];
        var nieuw = _acc.RegenerateRecoveryCodes("sam", "een goed wachtwoord");
        Assert.NotNull(nieuw); Assert.Equal(8, _acc.RecoveryCodesLeft("sam"));
        Assert.Null(_acc.RecoverAccess("sam", oud, "weer een ander wachtwoord"));
        Assert.Null(_acc.RegenerateRecoveryCodes("sam", "fout wachtwoord!!"));
    }
}

public class ShareTests
{
    [Fact]
    public void DeelbestandRoundTripEnVerkeerdeCode()
    {
        var items = new[] { new StoplichtEntry(Guid.NewGuid(), DateTime.Now, "Rood", new[] { "Ik ben bang" }, new[] { "Ik wil nu hulp" }, "geheimetekst") };
        var code = ShareService.NewShareCode();
        var file = ShareService.Create("Sam", items, code);
        Assert.DoesNotContain("geheimetekst", Encoding.UTF8.GetString(file));
        var pkg = ShareService.Open(file, code.ToLowerInvariant());     // hoofdletters/streepjes maken niet uit
        Assert.Equal("geheimetekst", pkg!.Items[0].Text);
        Assert.Null(ShareService.Open(file, "AAAA-AAAA-AAAA"));
        file[^3] ^= 1;
        Assert.Null(ShareService.Open(file, code));                      // gemanipuleerd bestand
    }

    [Fact]
    public void HtmlDeelbestandRoundTripEnVerkeerdeCode()
    {
        var items = new[] { new StoplichtEntry(Guid.NewGuid(), DateTime.Now, "Oranje", new[] { "Ik ben moe" }, new[] { "Ik wil rust" }, "geheimetekst") };
        var code = ShareService.NewShareCode();
        var html = ShareService.CreateHtml("Zeer-Unieke-Naam", items, code);
        Assert.DoesNotContain("geheimetekst", html);
        Assert.DoesNotContain("Zeer-Unieke-Naam", html);       // ook de naam van de cliënt staat niet leesbaar in het bestand
        Assert.Equal("geheimetekst", ShareService.OpenHtml(html, code)!.Items[0].Text);
        Assert.Null(ShareService.OpenHtml(html, "AAAA-AAAA-AAAA"));
    }

    [Fact]
    public void OngeldigOfTeGrootDeelbestandWordtGeweigerd()
    {
        Assert.Null(ShareService.Open(Array.Empty<byte>(), "ABCDEFGH"));
        Assert.Null(ShareService.Open(new byte[10 * 1024 * 1024 + 1], "ABCDEFGH"));
        Assert.Null(ShareService.OpenHtml("<html><body>geen deelbestand</body></html>", "ABCDEFGH"));
        Assert.Null(ShareService.OpenHtml(ShareService.CreateHtml("Sam", Array.Empty<StoplichtEntry>(), ShareService.NewShareCode()), "TEKORT"));
    }

    [Fact]
    public void PlatteTekstBevatKleurEnReden()
    {
        var items = new[] { new StoplichtEntry(Guid.NewGuid(), DateTime.Now, "Rood", new[] { "Ik ben bang" }, new[] { "Ik wil nu hulp" }, "help") };
        var t = ShareService.PlainText("Sam", items);
        Assert.Contains("Rood", t); Assert.Contains("Ik ben bang", t);
    }
}

public class ExportTests : IDisposable
{
    readonly string _dir = Path.Combine(Path.GetTempPath(), "mg-export-" + Guid.NewGuid());
    public void Dispose() { try { Directory.Delete(_dir, true); } catch { } }

    [Fact]
    public void ExportBevatAllesEnNieuweSoortenGegevens()
    {
        using var store = new VaultStore(Crypto.Random(32), Path.Combine(_dir, "data"));
        var j = new JournalEntry(Guid.NewGuid(), DateTime.Now, 2, "dagboektekst");
        store.Save("diary", j.Id, j);
        var r = new Routine(Guid.NewGuid(), "Ochtend", "☀️", new[] { "Opstaan", "Tanden poetsen" });
        store.Save("routine", r.Id, r);
        var m = new ScaleEntry(Guid.NewGuid(), DateTime.Now, "Lichaam", 0, "Buik: spanning");
        store.Save("scale", m.Id, m);
        var c = new TalkCard(Guid.NewGuid(), "💬", "Ik wil praten");
        store.Save("card", c.Id, c);
        var reminder = new RoutineReminder(Guid.NewGuid(), "Medicatie innemen", "💊", "08:00", 127, true, Convert.ToBase64String(new byte[] { 1, 2, 3 }), true);
        store.Save("routinereminder", reminder.Id, reminder);
        var loadedReminder = store.Load<RoutineReminder>("routinereminder", reminder.Id);
        Assert.NotNull(loadedReminder);
        Assert.Equal("Medicatie innemen", loadedReminder!.Title);
        Assert.Equal("08:00", loadedReminder.Time);
        Assert.Equal(reminder.PictureBase64, loadedReminder.PictureBase64);

        var checkIn = new MoodCheckInEntry(Guid.NewGuid(), DateTime.Now, "Zenuwachtig", 8, "Werk", "Spannende afspraak");
        store.Save("moodcheckin", checkIn.Id, checkIn);
        store.Save("talk", Guid.Empty, new TalkPrep { Tell = "mijn verhaal" });

        var savedCheckIn = store.Load<MoodCheckInEntry>("moodcheckin", checkIn.Id);
        Assert.NotNull(savedCheckIn);
        Assert.Equal("Zenuwachtig", savedCheckIn!.Feeling);
        Assert.Equal(8, savedCheckIn.Intensity);

        var path = Path.Combine(_dir, "export.json");
        ExportService.ExportAll(store, "sam", path);
        var json = File.ReadAllText(path);
        foreach (var verwacht in new[] { "dagboektekst", "Tanden poetsen", "Buik: spanning", "Ik wil praten", "mijn verhaal", "Zenuwachtig", "Spannende afspraak", "Werk", "Medicatie innemen" })
            Assert.Contains(verwacht, json);
        Assert.Equal("Opstaan", store.Load<Routine>("routine", r.Id)!.Steps[0]);   // arrays blijven heel
    }
}

public class BackupRestoreTests : IDisposable
{
    readonly string _root = Path.Combine(Path.GetTempPath(), "mg-backup-test-" + Guid.NewGuid().ToString("N"));
    readonly AccountService _accounts;
    public BackupRestoreTests() => _accounts = new AccountService(Path.Combine(_root, "accounts"));
    public void Dispose() { try { Directory.Delete(_root, true); } catch { } }

    [Fact]
    public void RestoreSlaatZipSlipBestandenOver()
    {
        Directory.CreateDirectory(_root);
        var zipPath = Path.Combine(_root, "hostile.zip");
        var escapedName = "moodpress-zip-slip-" + Guid.NewGuid().ToString("N") + ".txt";
        var archivePath = "data/../../" + escapedName;
        var escapedPath = Path.GetFullPath(Path.Combine(_accounts.BaseFolder, archivePath));
        Assert.False(File.Exists(escapedPath));
        using (var zip = System.IO.Compression.ZipFile.Open(zipPath, System.IO.Compression.ZipArchiveMode.Create))
        {
            var entry = zip.CreateEntry(archivePath);
            using var writer = new StreamWriter(entry.Open());
            writer.Write("must-not-escape");
        }
        Assert.Throws<InvalidDataException>(() => BackupService.Restore(_accounts, zipPath));
        Assert.False(File.Exists(escapedPath));
    }

    [Fact]
    public void RestoreValidatesEverythingBeforeWritingAnyFile()
    {
        Directory.CreateDirectory(_root);
        var zipPath = Path.Combine(_root, "mixed-hostile.zip");
        var registered = _accounts.Register("restore-user", "correct horse battery");
        var accountName = Path.GetFileName(_accounts.AccountFilePath("restore-user"));
        using (var zip = System.IO.Compression.ZipFile.Open(zipPath, System.IO.Compression.ZipArchiveMode.Create))
        {
            using (var writer = new StreamWriter(zip.CreateEntry("accounts/" + accountName).Open())) writer.Write("not-extracted-before-validation");
            using (var writer = new StreamWriter(zip.CreateEntry("data/../../escape.txt").Open())) writer.Write("no");
        }
        var destinationAccounts = new AccountService(Path.Combine(_root, "empty-restore", "accounts"));
        var accountTarget = destinationAccounts.AccountFilePath("restore-user");
        Assert.False(File.Exists(accountTarget));
        Assert.Throws<InvalidDataException>(() => BackupService.Restore(destinationAccounts, zipPath));
        Assert.False(File.Exists(accountTarget)); // the valid first entry is not written before the whole archive passes validation.
    }

    [Fact]
    public void CreatedBackupRestoresAccountAndEncryptedVaultWithoutOverwriting()
    {
        _accounts.Register("backup-user", "correct horse battery");
        // Use an independent, test-only vault key: Registration intentionally never exposes the account's vault key.
        var testKey = Crypto.Random(32);
        try
        {
            using (var store = new VaultStore((byte[])testKey.Clone(), _accounts.DataFolder("backup-user")))
            {
                var item = new JournalEntry(Guid.NewGuid(), DateTime.Now, 3, "backup-test");
                store.Save("diary", item.Id, item);
            }
            var zipPath = Path.Combine(_root, "good-backup.zip");
            BackupService.Create(_accounts, "backup-user", zipPath);
            var destinationAccounts = new AccountService(Path.Combine(_root, "restored", "accounts"));
            var count = BackupService.Restore(destinationAccounts, zipPath);
            Assert.Equal(2, count);
            Assert.True(File.Exists(destinationAccounts.AccountFilePath("backup-user")));
            using (var restored = new VaultStore((byte[])testKey.Clone(), destinationAccounts.DataFolder("backup-user")))
                Assert.Equal("backup-test", Assert.Single(restored.All<JournalEntry>("diary")).Text);
            Assert.Equal(0, BackupService.Restore(destinationAccounts, zipPath)); // Existing files are not overwritten.
        }
        finally { CryptographicOperations.ZeroMemory(testKey); }
    }
}


public class SupportSharePackageTests
{
    [Fact]
    public void EncryptedPackageRoundTripIncludesOnlySelectedItems()
    {
        var plan = new SafetyPlan { PersonName = "Sam", Helps = "Rustige plek", Avoid = "Veel geluid", HelpOptions = new() { "calm" } };
        var routine = new RoutineSuggestion(Guid.NewGuid(), "Rustige ochtend", "☀️", new[] { "Opstaan", "Water drinken" }, DateTime.Now, "Begeleider");
        var light = new StoplichtEntry(Guid.NewGuid(), DateTime.Now, "Oranje", new[] { "Ik ben moe" }, new[] { "Ik wil rust" }, "persoonlijke notitie");
        var code = SupportShareService.NewShareCodeForUi();
        var bytes = SupportShareService.Create("Sam", plan, new[] { light }, new[] { routine }, code);
        Assert.DoesNotContain("persoonlijke notitie", Encoding.UTF8.GetString(bytes));
        var opened = SupportShareService.Open(bytes, code.ToLowerInvariant());
        Assert.NotNull(opened);
        Assert.Equal("Rustige plek", opened!.HelpPlan!.Helps);
        Assert.Equal("Rustige ochtend", opened.RoutineSuggestions.Single().Title);
        Assert.Equal("Oranje", opened.StoplightEntries.Single().Colour);
        Assert.Null(SupportShareService.Open(bytes, "FOUT-FOUT-FOUT"));
    }

    [Fact]
    public void EmptyOrManipulatedPackageIsRejected()
    {
        Assert.Throws<ArgumentException>(() => SupportShareService.Create("Sam", null, Array.Empty<StoplichtEntry>(), Array.Empty<RoutineSuggestion>(), "ABCDEFGH"));
        Assert.Null(SupportShareService.Open(Array.Empty<byte>(), "ABCDEFGH"));
        var bytes = SupportShareService.Create("Sam", new SafetyPlan { Helps = "rust" }, null, null, "ABCDEFGHJKLM");
        bytes[^1] ^= 0x01;
        Assert.Null(SupportShareService.Open(bytes, "ABCDEFGHJKLM"));
    }

    [Fact]
    public void RoutineProposalRequiresValidSteps()
    {
        Assert.Throws<ArgumentException>(() => SupportShareService.Create("Sam", null, null,
            new[] { new RoutineSuggestion(Guid.NewGuid(), "Leeg", "✅", Array.Empty<string>(), DateTime.Now, "Sam") }, "ABCDEFGHJKLM"));
    }
}


public class SupportShareV2Tests
{
    [Fact]
    public void V2PakketDeeltAlleenGeselecteerdeCheckIns()
    {
        var mood=new MoodCheckInEntry(Guid.NewGuid(),DateTime.Now,"Onrustig",7,"School","Ik wil rust");
        var youth=new YouthSupportEntry(Guid.NewGuid(),DateTime.Now,"Online / pesten",4,"Iemand die luistert","Notitie blijft privé tot selecteren");
        var code=SupportShareService.NewShareCodeForUi();
        var bytes=SupportShareService.Create("Sam",null,null,null,code,new[]{mood},new[]{youth});
        Assert.DoesNotContain("Notitie blijft privé",Encoding.UTF8.GetString(bytes));
        var opened=SupportShareService.Open(bytes,code);
        Assert.NotNull(opened);
        Assert.Single(opened!.MoodCheckIns); Assert.Single(opened.YouthCheckIns);
        Assert.Equal("Onrustig",opened.MoodCheckIns[0].Feeling);
        Assert.Equal(4,opened.YouthCheckIns[0].StressLevel);
    }

    [Fact]
    public void V2WeigertOngeldigeStressNiveaus()
    {
        Assert.Throws<ArgumentException>(() => SupportShareService.Create("Sam",null,null,null,"ABCDEFGHJKLM",null,new[]{new YouthSupportEntry(Guid.NewGuid(),DateTime.Now,"Online",9,"Rust","test")}));
    }

    [Fact]
    public void DeelcodeHeeftEenBovengrens()
    {
        Assert.Throws<ArgumentException>(() => SupportShareService.Create("Sam", new SafetyPlan { Helps = "rust" }, null, null, new string('A', 201)));
        Assert.Null(SupportShareService.Open(Array.Empty<byte>(), new string('A', 201)));
    }
}


public class MoodPressRoadmapModelTests
{
    [Fact]
    public void OlderAdultGoalJsonStillLoadsWhenReflectionAndStepsAreMissing()
    {
        var json = "{\"Id\":\"11111111-1111-1111-1111-111111111111\",\"Created\":\"2026-01-01T10:00:00\",\"Area\":\"Werk\",\"Title\":\"Kleine stap\",\"FirstStep\":\"Agenda openen\",\"TargetDate\":null,\"Done\":false}";
        var goal = JsonSerializer.Deserialize<AdultGoal>(json);
        Assert.NotNull(goal);
        Assert.Equal("Kleine stap", goal!.Title);
        Assert.Equal(string.Empty, goal.Reflection);
        Assert.Empty(goal.Steps);
    }

    [Fact]
    public void AdultGoalReflectionAndConsentLabelsRoundTrip()
    {
        var goal = new AdultGoal(Guid.NewGuid(), DateTime.Today, "Dagbesteding", "Pauze nemen", "Rustplek zoeken", null, true)
        { Reflection = "Een korte pauze hielp.", Steps = new[] { "Water pakken", "Rustige plek zoeken" } };
        var loadedGoal = JsonSerializer.Deserialize<AdultGoal>(JsonSerializer.Serialize(goal));
        Assert.Equal(goal.Reflection, loadedGoal!.Reflection);
        Assert.Equal(goal.Steps, loadedGoal.Steps);

        var consent = new ShareConsentRecord(Guid.NewGuid(), DateTime.Now, "Jobcoach", new[] { "stresscheck-ins" }, 0, 0)
        { YouthCheckInCount = 1, SelectedItemLabels = new[] { "Stress: school · 14-10-2026 08:00" } };
        var loadedConsent = JsonSerializer.Deserialize<ShareConsentRecord>(JsonSerializer.Serialize(consent));
        Assert.Equal(consent.SelectedItemLabels, loadedConsent!.SelectedItemLabels);
        Assert.Equal(1, loadedConsent.YouthCheckInCount);
    }

    [Fact]
    public void ChildRoutineProgressRemainsDaySpecific()
    {
        var id = Guid.NewGuid();
        var first = new RoutineProgress(Guid.NewGuid(), new DateTime(2026, 10, 14), id, new[] { 0, 2 });
        var second = new RoutineProgress(Guid.NewGuid(), new DateTime(2026, 10, 15), id, Array.Empty<int>());
        Assert.NotEqual(first.Day.Date, second.Day.Date);
        Assert.Equal(new[] { 0, 2 }, JsonSerializer.Deserialize<RoutineProgress>(JsonSerializer.Serialize(first))!.CompletedSteps);
    }
}


public class RoadmapExportTests
{
    [Fact]
    public void ExportBevatDeNieuweRoadmapGegevens()
    {
        var folder = Path.Combine(Path.GetTempPath(), "moodpress-export-test-" + Guid.NewGuid().ToString("N"));
        var output = Path.Combine(Path.GetTempPath(), "moodpress-export-" + Guid.NewGuid().ToString("N") + ".json");
        try
        {
            using var store = new VaultStore(Crypto.Random(32), folder);
            var goalId = Guid.NewGuid();
            store.Save("adultgoal", goalId, new AdultGoal(goalId, DateTime.Today, "Werk", "Pauze plannen", "Agenda openen", null, true) { Reflection = "Rust hielp", Steps = new[] { "Pauze in agenda zetten" } });
            var calmId = Guid.NewGuid();
            store.Save("calmoption", calmId, new CalmOptionEntry(calmId, "Rustige muziek", "Zet het volume zacht", DateTime.Now, DateTime.Now));
            var agendaId = Guid.NewGuid();
            store.Save("agenda", agendaId, new AgendaItem(agendaId, DateTime.Today, "14:30", "Afspraak", "⭐", false, "Gewijzigd")
            { Location = "Bibliotheek", Note = "Neem mijn boek mee", ChangeSummary = "Tijd: 14:00 → 14:30" });
            var youthId = Guid.NewGuid();
            store.Save("youthsupport", youthId, new YouthSupportEntry(youthId, DateTime.Now, "School", 3, "Luisteren", "Privé testnotitie"));
            var progressId = Guid.NewGuid();
            store.Save("routineprogress", progressId, new RoutineProgress(progressId, DateTime.Today, Guid.NewGuid(), new[] { 0 }));
            var consentId = Guid.NewGuid();
            store.Save("shareconsent", consentId, new ShareConsentRecord(consentId, DateTime.Now, "Begeleider", new[] { "stresscheck-ins" }, 0, 0) { SelectedItemLabels = new[] { "Stress: school" } });
            ExportService.ExportAll(store, "test", output);
            var json = File.ReadAllText(output);
            Assert.Contains("JongerenCheckins", json);
            Assert.Contains("PersoonlijkeDoelen", json);
            Assert.Contains("Reflection", json);
            Assert.Contains("Pauze in agenda zetten", json);
            Assert.Contains("PersoonlijkeRustlijst", json);
            Assert.Contains("Rustige muziek", json);
            Assert.Contains("Bibliotheek", json);
            Assert.Contains("Neem mijn boek mee", json);
            Assert.Contains("ChangeSummary", json);
            Assert.Contains("DagschemaVoortgang", json);
            Assert.Contains("GedeeldePakketToestemmingen", json);
            Assert.Contains("SelectedItemLabels", json);
        }
        finally
        {
            try { if (Directory.Exists(folder)) Directory.Delete(folder, true); } catch { }
            try { if (File.Exists(output)) File.Delete(output); } catch { }
        }
    }
}


public class MoodPressWholePlanModelTests
{
    [Fact]
    public void OlderAgendaJsonWithoutOptionalFieldsRemainsCompatible()
    {
        var json = "{\"Id\":\"11111111-1111-1111-1111-111111111111\",\"Date\":\"2026-10-14T00:00:00\",\"Time\":\"14:30\",\"Title\":\"Afspraak\",\"Icon\":\"⭐\",\"Done\":false}";
        var item = JsonSerializer.Deserialize<AgendaItem>(json);
        Assert.NotNull(item);
        Assert.Equal(string.Empty, item!.Location);
        Assert.Equal(string.Empty, item.Note);
        Assert.Equal(string.Empty, item.ChangeSummary);
    }

    [Fact]
    public void AgendaChangeDescriptionIdentifiesChangedFieldsWithoutCopyingPrivateNote()
    {
        var id = Guid.NewGuid();
        var previous = new AgendaItem(id, new DateTime(2026, 10, 14), "09:00", "Afspraak", "⭐", false, "Gepland")
        { Location = "Thuis", Note = "privé uitleg" };
        var current = previous with { Date = new DateTime(2026, 10, 15), Time = "10:00", Title = "Nieuwe afspraak", Location = "Werk", Note = "andere privé uitleg" };
        var changes = AgendaChangeService.DescribeChanges(previous, current);
        Assert.Contains(changes, x => x.StartsWith("Datum:"));
        Assert.Contains(changes, x => x.StartsWith("Tijd:"));
        Assert.Contains("Titel aangepast", changes);
        Assert.Contains("Locatie aangepast", changes);
        Assert.Contains("Notitie aangepast", changes);
        Assert.DoesNotContain(changes, x => x.Contains("privé uitleg", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public void AgendaChangeDescriptionIsEmptyWhenNothingChanged()
    {
        var item = new AgendaItem(Guid.NewGuid(), DateTime.Today, "09:00", "Afspraak", "⭐", false, "Gepland")
        { Location = "Thuis", Note = "Mijn notitie" };
        Assert.Empty(AgendaChangeService.DescribeChanges(item, item with { }));
        Assert.Empty(AgendaChangeService.DescribeChanges(null, item));
    }

    [Fact]
    public void GoalStepParserTrimsEmptyLinesAndLimitsNumberAndLength()
    {
        Assert.Equal(new[] { "Eerste", "Tweede" }, GoalStepService.Parse(" Eerste \r\n\r\n Tweede "));
        Assert.Throws<ArgumentException>(() => GoalStepService.Parse(string.Join("\n", Enumerable.Range(1, GoalStepService.MaximumSteps + 1).Select(i => "Stap " + i))));
        Assert.Throws<ArgumentException>(() => GoalStepService.Parse(new string('x', GoalStepService.MaximumStepLength + 1)));
    }

    [Fact]
    public void CalmOptionModelRoundTripsWithPrivateText()
    {
        var option = new CalmOptionEntry(Guid.NewGuid(), "Rustige muziek", "Volume zacht", DateTime.Now, DateTime.Now);
        var loaded = JsonSerializer.Deserialize<CalmOptionEntry>(JsonSerializer.Serialize(option));
        Assert.NotNull(loaded);
        Assert.Equal(option.Title, loaded!.Title);
        Assert.Equal(option.Note, loaded.Note);
    }
}
