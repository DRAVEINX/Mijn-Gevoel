using System.Security.Cryptography;
using System.Text;
using MijnGevoel.Core.Data;
using MijnGevoel.Core.Security;
using Xunit;

public sealed class VaultStoreTests : IDisposable
{
    private readonly string _directory = Path.Combine(Path.GetTempPath(), "moodpress-vault-test-" + Guid.NewGuid().ToString("N"));
    private readonly byte[] _key = Crypto.Random(Crypto.KeySize);
    private readonly VaultStore _store;

    public VaultStoreTests() => _store = new VaultStore((byte[])_key.Clone(), _directory);

    public void Dispose()
    {
        _store.Dispose();
        CryptographicOperations.ZeroMemory(_key);
        try { if (Directory.Exists(_directory)) Directory.Delete(_directory, recursive: true); } catch { }
    }

    [Fact]
    public void ConstructorRejectsInvalidKeyAndEmptyDirectory()
    {
        Assert.Throws<ArgumentException>(() => new VaultStore(new byte[8], _directory + "-bad-key"));
        Assert.Throws<ArgumentException>(() => new VaultStore(Crypto.Random(Crypto.KeySize), " "));
    }

    [Fact]
    public void RecordRoundTripsEncryptedAndLeavesNoTemporaryFiles()
    {
        var entry = new JournalEntry(Guid.NewGuid(), DateTime.UtcNow, 4, "privé notitie");
        _store.Save("diary", entry.Id, entry);
        var loaded = _store.Load<JournalEntry>("diary", entry.Id);
        Assert.Equal(entry, loaded);
        Assert.Single(Directory.GetFiles(_directory, "*.mg"));
        Assert.Empty(Directory.GetFiles(_directory, "*.tmp"));
        Assert.Empty(Directory.GetFiles(_directory, "*.json"));
    }

    [Fact]
    public void UnsafeKindIsRejectedBeforeAnyFileAccess()
    {
        Assert.Throws<ArgumentException>(() => _store.Save("../escape", Guid.NewGuid(), "secret"));
        Assert.Throws<ArgumentException>(() => _store.Load<string>("../escape", Guid.NewGuid()));
        Assert.Throws<ArgumentException>(() => _store.All<string>("../escape"));
        Assert.Throws<ArgumentException>(() => _store.Delete("../escape", Guid.NewGuid()));
        Assert.Empty(Directory.GetFiles(_directory));
    }

    [Fact]
    public void TamperedCiphertextReturnsNoRecordInsteadOfThrowing()
    {
        var id = Guid.NewGuid();
        _store.Save("diary", id, new JournalEntry(id, DateTime.UtcNow, 2, "privé"));
        var path = Path.Combine(_directory, $"diary-{id:N}.mg");
        var blob = File.ReadAllBytes(path);
        blob[^1] ^= 0x01;
        File.WriteAllBytes(path, blob);
        Assert.Null(_store.Load<JournalEntry>("diary", id));
        Assert.True(_store.ReadErrorCount > 0, "Een corrupt record moet een niet-gevoelige foutindicator opleveren.");
        Assert.Empty(_store.All<JournalEntry>("diary"));
    }

    [Fact]
    public void ValidEnvelopeWithInvalidJsonReturnsNoRecordInsteadOfThrowing()
    {
        var id = Guid.NewGuid();
        var invalidJson = Encoding.UTF8.GetBytes("{invalid json");
        var blob = Crypto.Seal(_key, invalidJson, $"diary:{id:N}");
        try { File.WriteAllBytes(Path.Combine(_directory, $"diary-{id:N}.mg"), blob); }
        finally
        {
            CryptographicOperations.ZeroMemory(invalidJson);
            CryptographicOperations.ZeroMemory(blob);
        }
        Assert.Null(_store.Load<JournalEntry>("diary", id));
        Assert.True(_store.ReadErrorCount > 0, "Ongeldige JSON moet zichtbaar worden als leesfout.");
    }

    [Fact]
    public void OversizedVaultFileIsIgnoredBeforeItsContentsAreRead()
    {
        var id = Guid.NewGuid();
        var path = Path.Combine(_directory, $"diary-{id:N}.mg");
        using (var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            stream.SetLength(VaultStore.MaxRecordBytes + 1);

        Assert.Null(_store.Load<JournalEntry>("diary", id));
        Assert.True(_store.ReadErrorCount > 0, "Een te groot bestand moet als niet-gevoelige leesfout worden gemeld.");
        Assert.Empty(_store.All<JournalEntry>("diary"));
        Assert.True(File.Exists(path)); // retain evidence for recovery; never silently delete user data.
    }

    [Fact]
    public void CiphertextCannotBeMovedBetweenRecordKinds()
    {
        var id = Guid.NewGuid();
        _store.Save("diary", id, new JournalEntry(id, DateTime.UtcNow, 4, "privé"));
        File.Copy(Path.Combine(_directory, $"diary-{id:N}.mg"), Path.Combine(_directory, $"note-{id:N}.mg"));
        Assert.Null(_store.Load<JournalEntry>("note", id));
    }
}
