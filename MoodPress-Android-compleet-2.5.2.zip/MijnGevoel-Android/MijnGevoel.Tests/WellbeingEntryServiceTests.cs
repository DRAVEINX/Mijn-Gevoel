using MijnGevoel.Core.Data;
using Xunit;

public sealed class WellbeingEntryServiceTests
{
    [Fact]
    public void OptionalValuesCanBeSkipped()
    {
        var entry = WellbeingEntryService.Create(Guid.NewGuid(), DateTime.Today, false, 3, false, 15, false, 4, " Even rusten ");
        Assert.Equal(0, entry.SleepQuality);
        Assert.Equal(-1, entry.MovementMinutes);
        Assert.Equal(0, entry.EnergyLevel);
        Assert.Equal("Even rusten", entry.Note);
    }

    [Fact]
    public void MovementCanBeRecordedAsZeroMinutes()
    {
        var entry = WellbeingEntryService.Create(Guid.NewGuid(), DateTime.Today, false, 3, true, 0, false, 4, "");
        Assert.Equal(0, entry.MovementMinutes);
    }

    [Theory]
    [InlineData(-1)]
    [InlineData(1441)]
    public void RejectsInvalidMovementMinutes(int minutes)
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => WellbeingEntryService.Create(Guid.NewGuid(), DateTime.Today, false, 3, true, minutes, false, 4, ""));
    }

    [Fact]
    public void RejectsCompletelyEmptyEntry()
    {
        Assert.Throws<ArgumentException>(() => WellbeingEntryService.Create(Guid.NewGuid(), DateTime.Today, false, 3, false, 0, false, 3, "  "));
    }

    [Fact]
    public void RejectsExcessivelyLongNote()
    {
        Assert.Throws<ArgumentException>(() => WellbeingEntryService.Create(Guid.NewGuid(), DateTime.Today, false, 3, false, 0, false, 3, new string('x', 1001)));
    }
}
