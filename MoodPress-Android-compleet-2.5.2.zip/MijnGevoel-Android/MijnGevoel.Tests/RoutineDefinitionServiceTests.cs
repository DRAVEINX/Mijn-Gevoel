using MijnGevoel.Core.Data;
using Xunit;

public sealed class RoutineDefinitionServiceTests
{
    [Fact]
    public void TrimsTitleAndStepsAndSuppliesDefaultIcon()
    {
        var routine = RoutineDefinitionService.Create(Guid.NewGuid(), "  Ochtend  ", " ", " Opstaan \r\n\r\n Tanden poetsen  \n");
        Assert.Equal("Ochtend", routine.Title);
        Assert.Equal("📝", routine.Icon);
        Assert.Equal(new[] { "Opstaan", "Tanden poetsen" }, routine.Steps);
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData(" ")]
    [InlineData("A")]
    public void RejectsMissingOrTooShortTitle(string? title) =>
        Assert.Throws<ArgumentException>(() => RoutineDefinitionService.Create(Guid.NewGuid(), title, "📝", "Stap één"));

    [Fact]
    public void RejectsEmptySteps()
    {
        Assert.Throws<ArgumentException>(() => RoutineDefinitionService.Create(Guid.NewGuid(), "Ochtend", "📝", " \n \r\n"));
    }

    [Fact]
    public void RejectsMoreThanFiftySteps()
    {
        var text = string.Join("\n", Enumerable.Range(1, 51).Select(i => $"Stap {i}"));
        Assert.Throws<ArgumentException>(() => RoutineDefinitionService.Create(Guid.NewGuid(), "Ochtend", "📝", text));
    }

    [Fact]
    public void RejectsAnOverlongStep()
    {
        Assert.Throws<ArgumentException>(() => RoutineDefinitionService.Create(Guid.NewGuid(), "Ochtend", "📝", new string('a', 501)));
    }

    [Fact]
    public void RejectsOverlongTitleAndIconAndEmptyId()
    {
        Assert.Throws<ArgumentException>(() => RoutineDefinitionService.Create(Guid.NewGuid(), new string('a', 121), "📝", "Stap"));
        Assert.Throws<ArgumentException>(() => RoutineDefinitionService.Create(Guid.NewGuid(), "Ochtend", new string('a', 17), "Stap"));
        Assert.Throws<ArgumentException>(() => RoutineDefinitionService.Create(Guid.Empty, "Ochtend", "📝", "Stap"));
    }
}
