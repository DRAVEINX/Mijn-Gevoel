using MijnGevoel.Core.Data;
using Xunit;

public sealed class AgendaStatusServiceTests
{
    [Fact]
    public void LegacyDoneItemRemainsCompleted()
    {
        var item = new AgendaItem(Guid.NewGuid(), DateTime.Today, "10:00", "Afspraak", "⭐", true);
        Assert.Equal("Afgerond", item.CurrentStatus);
        Assert.False(AgendaStatusService.IsActive(item));
    }

    [Theory]
    [InlineData("Gepland")]
    [InlineData("Bezig")]
    [InlineData("Uitgesteld")]
    [InlineData("Gewijzigd")]
    public void OpenStatusesRemainActive(string status)
    {
        var item = new AgendaItem(Guid.NewGuid(), DateTime.Today, "10:00", "Afspraak", "⭐", false, status);
        Assert.True(AgendaStatusService.IsActive(item));
    }

    [Fact]
    public void CancelledItemsAreNotConsideredNextActivities()
    {
        var cancelled = new AgendaItem(Guid.NewGuid(), DateTime.Today.AddDays(1), "08:00", "Geannuleerd", "⭐", false, "Geannuleerd");
        Assert.Null(AgendaSummaryService.FindNext(new[] { cancelled }, DateTime.Today));
    }

    [Fact]
    public void ChangingStatusSynchronizesLegacyDoneFlag()
    {
        var item = new AgendaItem(Guid.NewGuid(), DateTime.Today, "09:00", "Taak", "⭐", false);
        var done = AgendaStatusService.WithStatus(item, "Afgerond");
        Assert.True(done.Done);
        Assert.Equal("Afgerond", done.CurrentStatus);
        var deferred = AgendaStatusService.WithStatus(done, "Uitgesteld");
        Assert.False(deferred.Done);
        Assert.Equal("Uitgesteld", deferred.CurrentStatus);
    }

    [Fact]
    public void UnknownStatusFallsBackToSafeLegacyValue()
    {
        Assert.Equal("Gepland", AgendaStatusService.Normalize("onbekende-status", false));
    }
}
