using MijnGevoel.Core.Data;
using Xunit;

public sealed class TimerSessionServiceTests
{
    [Fact]
    public void ReconcileUsesEndTimeRatherThanScreenTickCount()
    {
        var start = new DateTime(2026, 10, 14, 10, 0, 0);
        var running = TimerSessionService.Start(TimerSessionService.CreateIdle(300), 300, start);

        var afterOneMinute = TimerSessionService.Reconcile(running, start.AddMinutes(1));

        Assert.True(afterOneMinute.State.IsRunning);
        Assert.Equal(240, afterOneMinute.State.RemainingSeconds);
        Assert.False(afterOneMinute.CompletedNow);
    }

    [Fact]
    public void ReconcileMarksTimerCompletedWhenEndTimePassed()
    {
        var start = new DateTime(2026, 10, 14, 10, 0, 0);
        var running = TimerSessionService.Start(TimerSessionService.CreateIdle(60), 60, start);

        var completed = TimerSessionService.Reconcile(running, start.AddSeconds(61));

        Assert.False(completed.State.IsRunning);
        Assert.Equal(0, completed.State.RemainingSeconds);
        Assert.NotNull(completed.State.CompletedAt);
        Assert.True(completed.CompletedNow);
        Assert.False(TimerSessionService.Reconcile(completed.State, start.AddSeconds(62)).CompletedNow);
    }

    [Fact]
    public void PausePreservesRemainingTimeAndStartResumesIt()
    {
        var start = new DateTime(2026, 10, 14, 10, 0, 0);
        var running = TimerSessionService.Start(TimerSessionService.CreateIdle(300), 300, start);
        var paused = TimerSessionService.Pause(running, start.AddSeconds(75));
        var resumed = TimerSessionService.Start(paused, 600, start.AddSeconds(100));

        Assert.False(paused.IsRunning);
        Assert.Equal(225, paused.RemainingSeconds);
        Assert.Equal(225, resumed.RemainingSeconds);
        Assert.Equal(300, resumed.TotalSeconds);
        Assert.Equal(start.AddSeconds(325), resumed.EndsAt);
    }

    [Fact]
    public void ResetUsesNewDurationAndClearsCompletion()
    {
        var reset = TimerSessionService.Reset(120);

        Assert.Equal(120, reset.TotalSeconds);
        Assert.Equal(120, reset.RemainingSeconds);
        Assert.False(reset.IsRunning);
        Assert.Null(reset.EndsAt);
        Assert.Null(reset.CompletedAt);
    }

    [Fact]
    public void CompletedTimerCanBeStartedAgainWithSelectedDuration()
    {
        var start = new DateTime(2026, 10, 14, 10, 0, 0);
        var completed = TimerSessionService.Reconcile(
            TimerSessionService.Start(TimerSessionService.CreateIdle(60), 60, start),
            start.AddMinutes(1)).State;

        var restarted = TimerSessionService.Start(completed, 600, start.AddMinutes(2));

        Assert.Equal(600, restarted.TotalSeconds);
        Assert.Equal(600, restarted.RemainingSeconds);
        Assert.True(restarted.IsRunning);
    }
}
