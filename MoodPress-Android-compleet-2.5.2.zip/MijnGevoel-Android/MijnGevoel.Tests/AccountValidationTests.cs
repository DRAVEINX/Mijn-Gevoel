using MijnGevoel.Core.Security;
using Xunit;

public sealed class AccountValidationTests
{
    [Theory]
    [InlineData("abc", "abc")]
    [InlineData("  Jordy  ", "Jordy")]
    public void ValidUsernamesAreTrimmed(string input, string expected) =>
        Assert.Equal(expected, AccountService.ValidateUsername(input));

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("ab")]
    [InlineData("no\nlines")]
    [InlineData("no\tcontrol")]
    public void InvalidUsernamesAreRejected(string? username) =>
        Assert.Throws<ArgumentException>(() => AccountService.ValidateUsername(username));

    [Fact]
    public void UsernamesLongerThan64CharactersAreRejected() =>
        Assert.Throws<ArgumentException>(() => AccountService.ValidateUsername(new string('a', 65)));
}
