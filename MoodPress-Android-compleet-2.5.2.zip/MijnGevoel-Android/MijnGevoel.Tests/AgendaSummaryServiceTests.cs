using MijnGevoel.Core.Data;
using Xunit;

public sealed class AgendaSummaryServiceTests
{
    static AgendaItem Activity(DateTime day, string time, string title, bool done = false) =>
        new(Guid.NewGuid(), day.Date, time, title, "📅", done);

    [Fact]
    public void FindsEarliestUnfinishedFutureActivityAndSkipsPastItems()
    {
        var now = new DateTime(2026, 10, 14, 10, 0, 0);
        var past = Activity(now, "09:30", "Al geweest");
        var next = Activity(now, "10:15", "Eerstvolgende");
        var later = Activity(now, "11:30", "Daarna");

        var result = AgendaSummaryService.FindNext(new[] { later, past, next }, now);

        Assert.Equal(next.Id, result?.Id);
    }

    [Fact]
    public void SkipsCompletedActivities()
    {
        var now = new DateTime(2026, 10, 14, 10, 0, 0);
        var completed = Activity(now, "10:30", "Klaar", done: true);
        var tomorrow = Activity(now.AddDays(1), "08:30", "Morgen");

        var result = AgendaSummaryService.FindNext(new[] { completed, tomorrow }, now);

        Assert.Equal(tomorrow.Id, result?.Id);
    }

    [Fact]
    public void ChoosesNextDayWhenNoActivityRemainsToday()
    {
        var now = new DateTime(2026, 10, 14, 18, 0, 0);
        var past = Activity(now, "09:00", "Ochtend");
        var tomorrow = Activity(now.AddDays(1), "08:00", "Morgen");

        var result = AgendaSummaryService.FindNext(new[] { past, tomorrow }, now);

        Assert.Equal(tomorrow.Id, result?.Id);
    }

    [Fact]
    public void KeepsUnscheduledActivityVisible()
    {
        var now = new DateTime(2026, 10, 14, 18, 0, 0);
        var unscheduled = Activity(now, "", "Tijd nog kiezen");
        var tomorrow = Activity(now.AddDays(1), "08:00", "Morgen");

        var result = AgendaSummaryService.FindNext(new[] { tomorrow, unscheduled }, now);

        Assert.Equal(unscheduled.Id, result?.Id);
    }

    [Fact]
    public void SupportsLegacyDotTimeSeparator()
    {
        var now = new DateTime(2026, 10, 14, 10, 0, 0);
        var next = Activity(now, "10.30", "Met oude tijdnotatie");

        var result = AgendaSummaryService.FindNext(new[] { next }, now);

        Assert.Equal(next.Id, result?.Id);
    }

    [Fact]
    public void ReturnsNullForEmptyOrMissingAgenda()
    {
        var now = new DateTime(2026, 10, 14, 10, 0, 0);

        Assert.Null(AgendaSummaryService.FindNext(Array.Empty<AgendaItem>(), now));
        Assert.Null(AgendaSummaryService.FindNext(null, now));
    }
}
