# Releasewijzigingen — MoodPress Android 2.3.1 (versionCode 28)

- Home toont de eerstvolgende niet-afgeronde agenda-activiteit, met dag en tijd.
- Afspraken waarvan de tijd vandaag al verstreken is, worden overgeslagen; afgeronde afspraken worden niet als volgende getoond.
- Activiteiten zonder tijd blijven zichtbaar met de aanduiding dat de tijd niet is ingesteld.
- Bij een lege agenda is er een duidelijke lege toestand met een directe route om een activiteit toe te voegen.
- Sorteerlogica ondergebracht in een Core-service met zes regressietests.
- Status: kandidaatbroncode; nog niet als gebouwd of op een echt Android-toestel getest totdat de GitHub Actions-workflows groen zijn en de acceptatietest is uitgevoerd.

---

## MoodPress 2.2.3 — icoon, tekstweergave en robuustheid
- Adaptive appicoon gecorrigeerd zodat de voorgrond niet onnodig wordt ingezoomd door een geknipte SVG-viewBox.
- Responsiever welkomstscherm, toegankelijkere labels en scrollbaar privacyscherm.
- Lange tekstvelden groeien met de ingevoerde inhoud mee.
- Extra invoergrenzen en validatie voor deelbestanden; tijdelijke sleutels/ontsleutelde buffers worden gewist.
- Robuustere padencontrole bij back-upherstel.
- Extra beveiligingsregressietests.
- Roadmap toegevoegd voor begeleider-/voogd-/ouderomgeving en functies per leeftijdsprofiel.

## MoodPress 2.2.2 — visuele afwerking

- Nieuw merkscherm met MoodPress-woordmerk en slogan.
- Consistent, glad vectorlogo voor splash, login, dashboard en launcher-icoon.
- Android-manifest gebruikt de daadwerkelijk gegenereerde MAUI appicon-resource.
- Knoppen en functietegels hebben woordafbreking en dynamische hoogtes om afgekapt tekst te voorkomen.

# Releasewijzigingen — MoodPress Android 2.0 (versionCode 20)

## Versie 2.0 — nieuwe gevoelsfuncties en release-inrichting

- Dagelijkse check-in met gekozen gevoel, intensiteit, aanleiding en optionele notitie.
- Gevoelskalender voor de laatste 30 dagen en dagdetails.
- Neutrale inzichten over 7 en 30 dagen, inclusief gemiddelde intensiteit en vaak gekozen gevoelens.
- Tekenen met kleuren en pendiktes, laatste lijn ongedaan maken en alles wissen.
- Check-ins opgenomen in het weekoverzicht, de privacytelling en leesbare JSON-export.
- De inzichtentelling sluit gegevens buiten de gekozen periode uit.
- Android-versie bijgewerkt naar `2.0` (version code `20`).
- Android-workflows en lokaal bouwscript bijgewerkt voor `.NET 10` / `net10.0-android`; tests en gedeelde core blijven op .NET 8.
- Een exporttest controleert nu ook dat check-ins blijven opgeslagen en in de export staan.

**Buildstatus:** alleen broncode is voorbereid en statisch gecontroleerd. Er is in deze werkomgeving geen .NET SDK beschikbaar; claim dus niet dat de release al compileert of op een toestel getest is. Voer de GitHub Release-workflow en daarna de acceptatietest uit.

---

# Releasewijzigingen — MoodPress 1.0.7 (versionCode 8)

## LVB-vriendelijke functies en beveiligde toegang

- **Vier duidelijke gevoelsknoppen:** blij, bedroefd, boos en bang zijn met grote knoppen en herkenbare emoji in te voeren. De keuze wordt privé en versleuteld opgeslagen. Bij een moeilijk gevoel verschijnen concrete helpopties uit de eigen helpkaart.
- **Persoonlijke helpkaart:** de cliënt kan vooraf kiezen welke hulpacties getoond worden. De seintje-knop opent een sms voor het vooraf ingestelde contact, maar verstuurt nooit automatisch.
- **Spraaknotities:** korte opnames van maximaal 60 seconden kunnen in het dagboek of bij het van-me-afschrijven worden opgenomen, afgespeeld en verwijderd. Bestanden worden als WAV opgenomen voor brede compatibiliteit en worden daarna in de versleutelde kluis opgeslagen. Opnames blijven op het toestel tenzij de gebruiker ze zelf exporteert of deelt.
- **Voorlezen:** uitleg bij functies heeft een voorleesknop; bestaande grote kaarten en invoerschermen behouden eenvoudige taal en visuele ondersteuning.
- **Eenvoudig weekoverzicht:** de laatste zeven dagen tonen per dag de laatst gekozen stemming met kleurblokken, plus een eenvoudig samenvattingsoverzicht.
- **Visuele ademhalingshulp en rustige meldingen:** een cirkel groeit en krimpt met het ademritme. De app toont geen onverwachte agenda-pop-ups; afspraken zijn nog steeds in de agenda zichtbaar.
- **Biometrisch terug ontgrendelen:** als de gebruiker bij aanmelden ‘Op dit toestel ingelogd blijven’ kiest, wordt de reeds geverifieerde kluissleutel versleuteld in Android SecureStorage bewaard. Na automatische vergrendeling vraagt de app om vingerafdruk/gezichtsherkenning waar het toestel dit ondersteunt. Bij annuleren of niet beschikbaar zijn blijft gewone login mogelijk. Wachtwoord en authenticatorcode worden niet bewaard. Uitloggen, wachtwoord wijzigen of account verwijderen wist de bewaarde sessie.
- **Google Play App Bundle:** de Release-workflow bouwt naast de ondertekende APK nu ook een ondertekende AAB voor een mogelijke interne test via Google Play Console. De AAB is niet rechtstreeks installeerbaar; deze is bedoeld om in Play Console te uploaden.
- **Privacy:** er wordt niets automatisch naar begeleiders of ouders verzonden. De app deelt geen stemming of spraaknotities zonder een expliciete actie van de gebruiker.
- Bestaande 17 unit-/security-tests blijven onderdeel van de CI-build.

Deze bronupdate moet nog door GitHub Actions worden gecompileerd en daarna op een Android-telefoon worden getest. De biometrische prompt is een extra toegangspoort; de opgeslagen kluissleutel is versleuteld via Android SecureStorage, maar in deze versie niet cryptografisch aan een biometriehardware-sleutel gekoppeld.


## Versie 1.0.8 (versionCode 9)

- **Copyrightvermelding toegevoegd:** `© 2026 Jordy Ham. Alle rechten voorbehouden.` is zichtbaar onderaan het aanmeldscherm en beginscherm en in Instellingen onder **Over MoodPress**.
- De Windows-instellingen tonen dezelfde copyrightvermelding onder **Over MoodPress**.
- Dit is een kleine onderhoudsupdate; de bestaande appfuncties en lokale gegevensstructuur zijn niet bewust gewijzigd.
- De Android-build moet nog via GitHub Actions worden uitgevoerd en op een toestel worden gecontroleerd.


## Versie 1.1.0 — geplande/broncode-update Android
- Dagelijkse check-in met gevoelsintensiteit, aanleiding en optionele notitie.
- Gevoelskalender voor de afgelopen 30 dagen.
- Inzichten over 7 en 30 dagen.
- Tekenen met kleur en pendikte, laatste lijn ongedaan maken en alles wissen.
- Check-ins opgenomen in gegevens-export en weekoverzicht.
- Status: broncode aangepast; build en fysieke toesteltests nog vereist.


## Versie 2.1 — Routines en meldingen
- Nieuwe module met eigen routineherinneringen, herhaling per weekdag, pictogrammen en eigen kleine afbeelding.
- Android-meldingen met geluid of stil, en herstel van geplande meldingen na reboot.
- Schema voor meldingen wordt encrypted opgeslagen via Android Keystore.


## MoodPress 2.2 — nieuwe visuele identiteit
- Appnaam, iconen, splashscreen en inlogscherm vernieuwd als MoodPress.
- Donkerblauwe interface met neonblauwe, cyan-, paarse en rozeaccenten.
- Compactere tegels op het startscherm met behoud van alle bestaande functies.
- Navigatiebalk onderaan met Home, Dag, Gevoel en Meer.
- Android package-id behouden om een update over de bestaande installatie mogelijk te houden.
