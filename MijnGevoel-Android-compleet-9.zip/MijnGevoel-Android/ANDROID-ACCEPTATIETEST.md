# Acceptatietest — Mijn Gevoel Android

Vink elke test pas af als die op een echte Android-telefoon en/of emulator is uitgevoerd. Broncode alleen is geen bewijs dat een test is geslaagd.

## Installatie en opstarten
- [ ] Debug-APK bouwt zonder fouten.
- [ ] APK kan worden geïnstalleerd en gestart op de ondersteunde Android-versie.
- [ ] App start opnieuw zonder vastlopen na sluiten en heropenen.
- [ ] Android-systeemterugknop navigeert logisch terug.

## Account en beveiliging
- [ ] Account aanmaken met een korte gebruikersnaam wordt geweigerd.
- [ ] Wachtwoord korter dan 10 tekens wordt geweigerd.
- [ ] QR-code werkt in een authenticator-app.
- [ ] Een foutieve registratiecode activeert het account niet.
- [ ] Een juiste code bevestigt registratie en maakt inloggen mogelijk.
- [ ] Een verkeerde wachtwoord/code-combinatie geeft geen toegang.
- [ ] Vijf foutieve aanmeldingen leiden tot tijdelijke vertraging.
- [ ] Een geldige herstelcode kan precies eenmaal worden gebruikt.
- [ ] Vernieuwde herstelcodes werken; de oude zijn niet meer geldig.
- [ ] Een gewijzigd wachtwoord werkt bij de volgende aanmelding.
- [ ] Automatisch vergrendelen gebeurt na de ingestelde inactiviteit.
- [ ] Naar de achtergrond gaan vergrendelt de actieve sessie.
- [ ] Schermafbeeldingen blokkeren aan/uit werkt via `FLAG_SECURE` op Android.

## Gegevens en functies
- [ ] Dagboek: opslaan, openen, wijzigen, nieuw en verwijderen.
- [ ] Van me afschrijven: opslaan, openen en verwijderen.
- [ ] Gezichtjes: juiste schaal 1–5 zichtbaar in week- en mood-overzicht.
- [ ] Stoplicht: groen/oranje/rood, redenen, behoeften en tekst blijven na opnieuw inloggen aanwezig.
- [ ] Stoplichtgeschiedenis: openen en verwijderen.
- [ ] Plan: contacten en wat helpt bewaren.
- [ ] Agenda: datum, tijd, pictogram, klaarzetten en verwijderen.
- [ ] Vandaag/morgen toont de juiste agenda-items.
- [ ] Timer start, pauzeert, hervat en eindigt.
- [ ] Ademhalingsscherm kan gestart en gestopt worden.
- [ ] Rusttips, prikkelmeter en lichaamsmeter bewaren data.
- [ ] Stappenplannen: standaardplannen, eigen plan, bewerken, uitvoeren en verwijderen.
- [ ] Gevoelswoorden worden getoond en voorlezen werkt op het apparaat.
- [ ] Basis- en eigen kaarten werken; eigen kaarten kunnen verwijderd worden.
- [ ] Gesprekskaart bewaren, tonen en delen werkt.
- [ ] Tekening kan met vinger worden gemaakt, bewaard, teruggezien en verwijderd.
- [ ] Delen met begeleider werkt met versleuteld `.mgdeel`, versleutelde HTML en expliciet bevestigde gewone tekst.
- [ ] Back-up wordt gedeeld/exporteert en bevat geen leesbare gegevensbestanden.
- [ ] Back-up terugzetten slaat bestaande bestanden over en accepteert geen paden buiten de backup-map.
- [ ] JSON-export heeft alle relevante onderdelen en wordt vooraf als leesbaar gewaarschuwd.
- [ ] Account verwijderen wist accountbestand en gegevensbestanden; daaropvolgend inloggen lukt niet.

## Privacy en stabiliteit
- [ ] Opslag staat binnen `FileSystem.AppDataDirectory`.
- [ ] Geen gevoelige data verschijnt in foutlogbestanden.
- [ ] Delen vraagt alleen om de data die de gebruiker aanvinkt.
- [ ] Test met vliegtuigstand: kernfuncties blijven offline werken, behalve authenticator-app buiten deze app.
- [ ] Test op kleine telefoon en groot lettertype: geen bedieningsknoppen zijn onbereikbaar.
- [ ] Test van schermrotatie, app naar achtergrond, inkomende oproep en hervatten.

**Releasecriteria:** alle relevante tests zijn uitgevoerd en geslaagd, kwetsbaarheden zijn beoordeeld, privacyverklaring/toestemming zijn gecontroleerd en de APK is met een eigen release-keystore ondertekend.
