using System.Security.Cryptography;
using System.Text.Json;
using MijnGevoel.Core.Security;

namespace MijnGevoel.Core.Data;

/// <summary>Elk item is een eigen AES-256-GCM-versleuteld bestand. Soort + id zijn aan de versleuteling gebonden:
/// bestanden kunnen dus niet stiekem worden verwisseld of aangepast zonder dat het opvalt.</summary>
public sealed class VaultStore : IDisposable
{
    readonly byte[] _key; readonly string _dir;
    public VaultStore(byte[] key, string dir) { _key = key; _dir = dir; Directory.CreateDirectory(dir); }

    string FileFor(string kind, Guid id) => Path.Combine(_dir, $"{kind}-{id:N}.mg");

    public void Save<T>(string kind, Guid id, T item)
    {
        var json = JsonSerializer.SerializeToUtf8Bytes(item);
        var blob = Crypto.Seal(_key, json, $"{kind}:{id:N}");
        CryptographicOperations.ZeroMemory(json);
        var p = FileFor(kind, id); var tmp = p + ".tmp";
        File.WriteAllBytes(tmp, blob);
        File.Move(tmp, p, true);
    }

    public T? Load<T>(string kind, Guid id)
    {
        var p = FileFor(kind, id);
        if (!File.Exists(p)) return default;
        try
        {
            var plain = Crypto.Open(_key, File.ReadAllBytes(p), $"{kind}:{id:N}");
            try { return JsonSerializer.Deserialize<T>(plain); }
            finally { CryptographicOperations.ZeroMemory(plain); }
        }
        catch (CryptographicException) { return default; }
    }

    public List<T> All<T>(string kind)
    {
        var list = new List<T>();
        foreach (var f in Directory.GetFiles(_dir, kind + "-*.mg"))
        {
            var name = Path.GetFileNameWithoutExtension(f);
            if (!Guid.TryParseExact(name[(kind.Length + 1)..], "N", out var id)) continue;
            var v = Load<T>(kind, id);
            if (v is not null) list.Add(v);
        }
        return list;
    }

    public void Delete(string kind, Guid id) => SecureDelete(FileFor(kind, id));

    /// <summary>Overschrijft het bestand met willekeurige data en verwijdert het (beperkt effect op SSD's, maar de inhoud is toch al versleuteld).</summary>
    public static void SecureDelete(string path)
    {
        try
        {
            if (!File.Exists(path)) return;
            long len = new FileInfo(path).Length;
            using (var fs = new FileStream(path, FileMode.Open, FileAccess.Write))
            {
                var buf = Crypto.Random((int)Math.Min(len, 1 << 20)); long w = 0;
                while (w < len) { int n = (int)Math.Min(buf.Length, len - w); fs.Write(buf, 0, n); w += n; }
                fs.Flush(true);
            }
        }
        catch (IOException) { }
        File.Delete(path);
    }

    public void Dispose() => CryptographicOperations.ZeroMemory(_key);
}
