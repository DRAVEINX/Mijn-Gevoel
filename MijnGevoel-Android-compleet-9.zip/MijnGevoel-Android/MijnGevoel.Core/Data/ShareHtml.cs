namespace MijnGevoel.Core.Data;

/// <summary>Zelfstandige, versleutelde HTML-pagina die elke begeleider in een browser kan openen (geen programma nodig).
/// De gegevens zijn AES-256-GCM-versleuteld; de sleutel komt uit PBKDF2-SHA256 (600.000 rondes) van de deelcode en wordt in de browser afgeleid.</summary>
internal static class ShareHtml
{
    public const string Template = """
<!DOCTYPE html>
<html lang="nl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light dark">
<meta name="robots" content="noindex">
<meta name="referrer" content="no-referrer">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src data:; base-uri 'none'; form-action 'none'">
<title>Mijn Gevoel - gedeeld bestand</title>
<style>
:root{--bg1:#e6f3f3;--bg2:#f3eefa;--card:rgba(255,255,255,.74);--line:rgba(30,60,70,.13);--text:#1f2a37;--muted:#58697a;--acc:#3c7a89;--acc2:#2f6b7a;--onacc:#fff;--inp:rgba(255,255,255,.8);--shadow:0 24px 60px rgba(20,50,60,.16)}
@media (prefers-color-scheme:dark){:root{--bg1:#10161c;--bg2:#1a1530;--card:rgba(38,48,58,.72);--line:rgba(255,255,255,.13);--text:#e8eef2;--muted:#9fb0bd;--acc:#6bb2c2;--acc2:#4e97a8;--onacc:#0f1519;--inp:rgba(15,21,25,.6);--shadow:0 24px 60px rgba(0,0,0,.45)}}
*{box-sizing:border-box}
html{background:var(--bg2)}
[hidden]{display:none!important}
body{margin:0;min-height:100vh;padding:28px 16px 48px;color:var(--text);font:17px/1.55 "Segoe UI Variable Text","Segoe UI",system-ui,-apple-system,Roboto,sans-serif;
background:radial-gradient(900px 500px at 8% -8%,rgba(60,170,190,.28),transparent 60%),radial-gradient(800px 520px at 100% 0%,rgba(150,120,240,.22),transparent 60%),linear-gradient(135deg,var(--bg1),var(--bg2));background-attachment:fixed}
.wrap{width:min(860px,100%);margin:0 auto}
.brand{display:flex;align-items:center;gap:16px;margin:6px 4px 22px}
.brand h1{margin:0;font-size:30px;letter-spacing:-.02em;line-height:1.1}
.brand p{margin:2px 0 0;color:var(--muted);font-size:15px}
.card{background:var(--card);-webkit-backdrop-filter:blur(20px) saturate(1.5);backdrop-filter:blur(20px) saturate(1.5);border:1px solid var(--line);border-radius:30px;padding:32px;box-shadow:var(--shadow)}
.center{text-align:center}
.lockicon{width:76px;height:76px;margin:0 auto 14px;display:grid;place-items:center;font-size:36px;border-radius:24px;background:linear-gradient(180deg,var(--acc),var(--acc2));box-shadow:0 10px 24px rgba(40,100,120,.35)}
h2{margin:6px 0 8px;font-size:24px;letter-spacing:-.01em}
.muted{color:var(--muted)}
.code{display:block;width:100%;max-width:420px;margin:20px auto 14px;padding:16px 18px;font:600 26px ui-monospace,"Cascadia Mono",Consolas,monospace;letter-spacing:.12em;text-align:center;text-transform:uppercase;color:var(--text);background:var(--inp);border:2px solid var(--line);border-radius:20px;outline:none;transition:border-color .2s,box-shadow .2s}
.code:focus{border-color:var(--acc);box-shadow:0 0 0 5px rgba(60,122,137,.22)}
button{font-weight:600;font-size:18px;font-family:inherit;cursor:pointer;border:0;border-radius:18px;padding:15px 28px;transition:transform .15s,box-shadow .15s,opacity .15s}
.primary{color:var(--onacc);background:linear-gradient(180deg,var(--acc),var(--acc2));box-shadow:0 10px 24px rgba(40,100,120,.35)}
.primary:hover{transform:translateY(-1px)}
.primary:active{transform:scale(.98)}
.primary:disabled{opacity:.6;cursor:wait}
.ghost{margin-top:22px;color:var(--text);background:transparent;border:2px solid var(--line)}
button:focus-visible{outline:3px solid #e0a100;outline-offset:3px}
.err{min-height:1.5em;margin:12px 0 0;color:#c0392b;font-weight:600}
@media (prefers-color-scheme:dark){.err{color:#ff8a80}}
.tiny{margin:18px 0 0;font-size:14px;color:var(--muted)}
.chips{display:flex;flex-wrap:wrap;gap:8px;margin:6px 0 4px}
.chip{display:inline-block;padding:7px 14px;border-radius:999px;font-size:15px;font-weight:600;border:1px solid var(--line);background:rgba(255,255,255,.35)}
.chip.Rood{background:rgba(239,83,80,.18)}.chip.Oranje{background:rgba(255,167,38,.2)}.chip.Groen{background:rgba(102,187,106,.2)}
.chip.soft{font-weight:500;background:rgba(127,127,127,.12)}
.note{margin:16px 2px 6px;color:var(--muted);font-size:15px}
.item{margin:16px 0;padding:20px 22px;border-radius:22px;border:1px solid var(--line);border-left:9px solid var(--b);background:var(--c);animation:rise .55s cubic-bezier(.2,.8,.2,1) both}
.Rood{--b:#ef5350;--c:rgba(239,83,80,.12)}.Oranje{--b:#ffa726;--c:rgba(255,167,38,.13)}.Groen{--b:#66bb6a;--c:rgba(102,187,106,.13)}
.ih{display:flex;align-items:center;gap:14px}
.big{font-size:34px;line-height:1}
.ih strong{font-size:20px}
.when{color:var(--muted);font-size:14px}
.lbl{margin:14px 0 2px;font-size:13px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}
blockquote{margin:14px 0 2px;padding:12px 16px;border-radius:14px;background:rgba(127,127,127,.12);white-space:pre-wrap}
@keyframes rise{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
@media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
@media (max-width:520px){.card{padding:22px;border-radius:24px}.code{font-size:21px}}
</style>
</head>
<body>
<div id="p" hidden data-s="{{SALT}}" data-n="{{NONCE}}" data-d="{{DATA}}" data-i="{{ITER}}"></div>
<main class="wrap">
  <header class="brand">
    <svg viewBox="0 0 64 64" width="58" height="58" aria-hidden="true"><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#56b0c0"/><stop offset="1" stop-color="#28687a"/></linearGradient></defs><rect x="2" y="2" width="60" height="60" rx="15" fill="url(#g)"/><path d="M32 50C14 37 12 22 23 18.5c4.5-1.5 8 1 9 4.5 1-3.500 4.500-6 9-4.500C52 22 50 37 32 50z" fill="#fff"/><circle cx="27" cy="31" r="1.9" fill="#28687a"/><circle cx="37" cy="31" r="1.9" fill="#28687a"/><path d="M26.500 36q5.500 4.500 11 0" stroke="#28687a" stroke-width="2.200" fill="none" stroke-linecap="round"/></svg>
    <div><h1>Mijn Gevoel</h1><p id="sub">Beveiligd bestand van een cli&euml;nt</p></div>
  </header>

  <section id="lock" class="card center">
    <div class="lockicon" aria-hidden="true">&#128274;</div>
    <h2>Dit bestand is beveiligd</h2>
    <p class="muted">De cli&euml;nt heeft dit zelf met je gedeeld. Typ de code die je van de cli&euml;nt hebt gekregen, bijvoorbeeld door te bellen of persoonlijk.</p>
    <input id="code" class="code" type="text" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="XXXX-XXXX-XXXX" aria-label="Code">
    <button id="go" class="primary" type="button">Openen</button>
    <p id="err" class="err" role="alert"></p>
    <p class="tiny">Alles wordt alleen in jouw browser ontcijferd. Er wordt niets verstuurd of opgeslagen.</p>
  </section>

  <section id="out" class="card" hidden></section>
</main>
<script>
(function(){
const P=document.getElementById('p').dataset;
const $=id=>document.getElementById(id);
const b64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
const enc=new TextEncoder(),dec=new TextDecoder();
const COL={Rood:['\uD83D\uDD34','Ik heb hulp nodig',0],Oranje:['\uD83D\uDFE0','Het gaat niet zo goed',1],Groen:['\uD83D\uDFE2','Het gaat goed',2]};
function el(tag,cls,text){const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined&&text!==null)e.textContent=text;return e;}
function fmt(s){try{return new Date(s).toLocaleString('nl-NL',{weekday:'long',day:'numeric',month:'long',hour:'2-digit',minute:'2-digit'});}catch(e){return s;}}
if(!(window.crypto&&window.crypto.subtle)){$('err').textContent='Open dit bestand in Edge, Chrome of Safari (niet in een voorbeeldvenster van een app) om het te kunnen lezen.';}
async function open(){
  $('err').textContent='';$('go').disabled=true;$('go').textContent='Even wachten\u2026';
  try{
    const code=$('code').value.replace(/[^A-Za-z0-9]/g,'').toUpperCase();
    const km=await crypto.subtle.importKey('raw',enc.encode(code),'PBKDF2',false,['deriveKey']);
    const key=await crypto.subtle.deriveKey({name:'PBKDF2',salt:b64(P.s),iterations:parseInt(P.i,10),hash:'SHA-256'},km,{name:'AES-GCM',length:256},false,['decrypt']);
    const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:b64(P.n),additionalData:enc.encode('MGDEEL-HTML1')},key,b64(P.d));
    render(JSON.parse(dec.decode(plain)));
  }catch(e){
    $('err').textContent='Openen lukt niet. Controleer de code en probeer het nog een keer.';
    $('go').disabled=false;$('go').textContent='Openen';
  }
}
function chips(parent,label,list){
  if(!list||!list.length)return;
  parent.appendChild(el('div','lbl',label));
  const r=el('div','chips');list.forEach(x=>r.appendChild(el('span','chip soft',x)));parent.appendChild(r);
}
function render(pkg){
  $('sub').textContent='Gedeeld door '+pkg.From+' \u2022 '+fmt(pkg.Created);
  const items=(pkg.Items||[]).slice().sort((a,b)=>((COL[a.Colour]||[0,0,3])[2]-(COL[b.Colour]||[0,0,3])[2])||(new Date(b.Created)-new Date(a.Created)));
  const out=$('out');out.textContent='';
  const sum=el('div','chips');
  ['Rood','Oranje','Groen'].forEach(k=>{const n=items.filter(i=>i.Colour===k).length;if(n)sum.appendChild(el('span','chip '+k,COL[k][0]+' '+n+'\u00D7 '+k.toLowerCase()));});
  out.appendChild(sum);
  out.appendChild(el('p','note','De cli\u00EBnt heeft zelf gekozen om dit te delen. Neem contact op volgens het afgesproken protocol van jullie organisatie. Mijn Gevoel waarschuwt niemand automatisch.'));
  items.forEach((i,idx)=>{
    const c=COL[i.Colour]||['\u26AA','',3];
    const card=el('article','item '+i.Colour);card.style.animationDelay=(idx*70)+'ms';
    const h=el('div','ih');h.appendChild(el('span','big',c[0]));
    const t=el('div');t.appendChild(el('strong',null,i.Colour+' \u2013 '+c[1]));t.appendChild(el('div','when',fmt(i.Created)));
    h.appendChild(t);card.appendChild(h);
    chips(card,'Waarom',i.Reasons);chips(card,'Wat is nodig',i.Needs);
    if(i.Text&&i.Text.trim())card.appendChild(el('blockquote',null,i.Text));
    out.appendChild(card);
  });
  const close=el('button','ghost','Sluiten');close.type='button';close.onclick=()=>location.reload();out.appendChild(close);
  $('lock').hidden=true;out.hidden=false;window.scrollTo(0,0);
}
$('go').addEventListener('click',open);
$('code').addEventListener('keydown',e=>{if(e.key==='Enter')open();});
})();
</script>
</body>
</html>
""";
}
