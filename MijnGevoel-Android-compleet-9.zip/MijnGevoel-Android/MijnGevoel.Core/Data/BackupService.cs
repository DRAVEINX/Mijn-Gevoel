using System.IO.Compression;
using MijnGevoel.Core.Security;

namespace MijnGevoel.Core.Data;

/// <summary>Back-up = zip met het (al versleutelde) accountbestand en alle (al versleutelde) gegevens. Zonder wachtwoord + authenticator/herstelcode onleesbaar.</summary>
public static class BackupService
{
    public static void Create(AccountService acc, string username, string zipPath)
    {
        if (File.Exists(zipPath)) File.Delete(zipPath);
        using var zip = ZipFile.Open(zipPath, ZipArchiveMode.Create);
        var af = acc.AccountFilePath(username);
        zip.CreateEntryFromFile(af, "accounts/" + Path.GetFileName(af));
        var dir = acc.DataFolder(username);
        if (Directory.Exists(dir))
            foreach (var f in Directory.GetFiles(dir, "*.mg"))
                zip.CreateEntryFromFile(f, "data/" + Path.GetFileName(dir) + "/" + Path.GetFileName(f));
    }

    /// <summary>Zet terug zonder iets te overschrijven. Geeft het aantal teruggezette bestanden.</summary>
    public static int Restore(AccountService acc, string zipPath)
    {
        var baseDir = Path.GetFullPath(acc.BaseFolder); int n = 0;
        using var zip = ZipFile.OpenRead(zipPath);
        foreach (var e in zip.Entries)
        {
            if (e.FullName.EndsWith('/')) continue;
            if (!(e.FullName.StartsWith("accounts/") || e.FullName.StartsWith("data/"))) continue;
            var target = Path.GetFullPath(Path.Combine(baseDir, e.FullName));
            if (!target.StartsWith(baseDir + Path.DirectorySeparatorChar)) continue;   // zip-slip beveiliging
            if (File.Exists(target)) continue;
            Directory.CreateDirectory(Path.GetDirectoryName(target)!);
            e.ExtractToFile(target); n++;
        }
        return n;
    }
}
