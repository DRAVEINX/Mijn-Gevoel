using System.Security.Cryptography;
using System.Text;

namespace MijnGevoel.Core.Security;

/// <summary>TOTP volgens RFC 6238 (6 cijfers, 30 sec, SHA-1) - werkt met Google/Microsoft Authenticator e.d.</summary>
public static class Totp
{
    const string Alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

    public static byte[] NewSecret() => Crypto.Random(20);

    public static string ToBase32(byte[] data)
    {
        var sb = new StringBuilder();
        int buffer = 0, bits = 0;
        foreach (var b in data)
        {
            buffer = (buffer << 8) | b; bits += 8;
            while (bits >= 5) { sb.Append(Alphabet[(buffer >> (bits - 5)) & 31]); bits -= 5; }
        }
        if (bits > 0) sb.Append(Alphabet[(buffer << (5 - bits)) & 31]);
        return sb.ToString();
    }

    public static string OtpAuthUri(string username, byte[] secret, string issuer = "Mijn Gevoel") =>
        $"otpauth://totp/{Uri.EscapeDataString(issuer)}:{Uri.EscapeDataString(username)}" +
        $"?secret={ToBase32(secret)}&issuer={Uri.EscapeDataString(issuer)}&algorithm=SHA1&digits=6&period=30";

    public static string Code(byte[] secret, long step)
    {
        var counter = BitConverter.GetBytes(step);
        if (BitConverter.IsLittleEndian) Array.Reverse(counter);
        using var h = new HMACSHA1(secret);
        var hash = h.ComputeHash(counter);
        int o = hash[^1] & 0x0F;
        int bin = ((hash[o] & 0x7F) << 24) | (hash[o + 1] << 16) | (hash[o + 2] << 8) | hash[o + 3];
        return (bin % 1_000_000).ToString("D6");
    }

    public static long CurrentStep(DateTimeOffset? now = null) =>
        (now ?? DateTimeOffset.UtcNow).ToUnixTimeSeconds() / 30;

    /// <summary>Geeft de gematchte stap terug of null. Venster +/-1 stap (30 sec klokverschil).
    /// De aanroeper moet stappen &lt;= laatst gebruikte stap weigeren (geen hergebruik van een code).</summary>
    public static long? Verify(byte[] secret, string input, DateTimeOffset? now = null)
    {
        input = new string(input.Where(char.IsDigit).ToArray());
        if (input.Length != 6) return null;
        long cur = CurrentStep(now);
        long? hit = null;
        for (long s = cur - 1; s <= cur + 1; s++)   // altijd alle 3 doorlopen: constante tijd
            if (CryptographicOperations.FixedTimeEquals(Encoding.ASCII.GetBytes(Code(secret, s)), Encoding.ASCII.GetBytes(input)))
                hit = s;
        return hit;
    }
}
