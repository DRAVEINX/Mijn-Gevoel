using System.Security.Cryptography;
using Konscious.Security.Cryptography;

namespace MijnGevoel.Core.Security;

/// <summary>Basisbouwstenen: Argon2id (sleutel uit wachtwoord) en AES-256-GCM (versleutelen + integriteit).</summary>
public static class Crypto
{
    public const int KeySize = 32, NonceSize = 12, TagSize = 16, SaltSize = 16;

    public static byte[] Random(int n) => RandomNumberGenerator.GetBytes(n);

    // Argon2id: 64 MB geheugen, 3 rondes, 4 threads (OWASP-conform). Maakt gokken extreem traag.
    public static byte[] DeriveKey(string secret, byte[] salt)
    {
        var bytes = System.Text.Encoding.UTF8.GetBytes(secret.Normalize(System.Text.NormalizationForm.FormKC));
        try
        {
            using var a = new Argon2id(bytes)
            { Salt = salt, DegreeOfParallelism = 4, Iterations = 3, MemorySize = 65536 };
            return a.GetBytes(KeySize);
        }
        finally { CryptographicOperations.ZeroMemory(bytes); }
    }

    /// <summary>Uitvoer: nonce | ciphertext | tag. 'context' wordt meegeauthenticeerd (voorkomt verwisselen van blobs).</summary>
    public static byte[] Seal(byte[] key, byte[] plain, string context)
    {
        var nonce = Random(NonceSize);
        var ct = new byte[plain.Length];
        var tag = new byte[TagSize];
        using var g = new AesGcm(key, TagSize);
        g.Encrypt(nonce, plain, ct, tag, System.Text.Encoding.UTF8.GetBytes(context));
        return [.. nonce, .. ct, .. tag];
    }

    /// <summary>Gooit CryptographicException bij verkeerde sleutel of gemanipuleerde data.</summary>
    public static byte[] Open(byte[] key, byte[] blob, string context)
    {
        if (blob.Length < NonceSize + TagSize) throw new CryptographicException("Ongeldige data.");
        var nonce = blob[..NonceSize];
        var tag = blob[^TagSize..];
        var ct = blob[NonceSize..^TagSize];
        var plain = new byte[ct.Length];
        using var g = new AesGcm(key, TagSize);
        g.Decrypt(nonce, ct, tag, plain, System.Text.Encoding.UTF8.GetBytes(context));
        return plain;
    }
}
