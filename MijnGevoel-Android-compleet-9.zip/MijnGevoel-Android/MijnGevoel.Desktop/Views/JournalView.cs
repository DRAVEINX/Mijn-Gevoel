using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using MijnGevoel.Core.Data;

namespace MijnGevoel.Desktop;

/// <summary>Gedeeld scherm voor het dagboek (met gezichtjes) en "van me afschrijven" (zonder).</summary>
sealed class JournalView : ViewBase
{
    readonly string _kind;
    readonly TextBox _text = new() { AcceptsReturn = true, TextWrapping = TextWrapping.Wrap, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, MinHeight = 240, VerticalContentAlignment = VerticalAlignment.Top };
    readonly ListBox _list = new() { MinHeight = 320, Margin = new Thickness(5) };
    readonly TextBlock _status = Ui.Label("");
    readonly List<Button> _moodButtons = new();
    List<JournalEntry> _items = new();
    Guid? _current; int _moodVal; bool _loading;

    public JournalView(string kind, bool withMood, string title, string intro)
    {
        _kind = kind;
        var left = new StackPanel { Margin = new Thickness(14) };
        left.Children.Add(Ui.Label(intro));
        left.Children.Add(Ui.Label("Tip: druk op de Windows-toets + H om te praten in plaats van te typen.", muted: true));
        if (withMood)
        {
            var row = new UniformGrid { Columns = 5 };
            for (int i = 0; i < 5; i++) { int v = i + 1; var b = Ui.MoodButton(Moods.All[i], () => SetMood(v)); _moodButtons.Add(b); row.Children.Add(b); }
            left.Children.Add(row);
        }
        left.Children.Add(_text);
        var btns = new WrapPanel();
        btns.Children.Add(Ui.Btn("💾 Bewaren", Save));
        btns.Children.Add(Ui.Btn("✨ Nieuw", New, soft: true));
        if (Session.Settings.ReadAloud) btns.Children.Add(Ui.Btn("🔊 Voorlezen", () => Speaker.Toggle(_text.Text), soft: true));
        btns.Children.Add(Ui.Btn("🗑 Weggooien", Discard, danger: true));
        left.Children.Add(btns); left.Children.Add(_status);

        var right = new DockPanel { Margin = new Thickness(14) };
        var hdr = Ui.Label("Eerder opgeschreven", muted: true);
        DockPanel.SetDock(hdr, Dock.Top);
        right.Children.Add(hdr); right.Children.Add(_list);
        _list.SelectionChanged += (_, _) => OnSelect();

        var grid = new Grid();
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(3, GridUnitType.Star) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(2, GridUnitType.Star) });
        var leftCard = Ui.Card(new ScrollViewer { Content = left, VerticalScrollBarVisibility = ScrollBarVisibility.Auto }, 6);
        var rightCard = Ui.Card(right, 6);
        Grid.SetColumn(rightCard, 1);
        grid.Children.Add(leftCard);
        grid.Children.Add(rightCard);
        Shell(title, grid, () => { Speaker.Stop(); GoHome(); });
        Reload();
    }

    void SetMood(int v)
    {
        _moodVal = v;
        for (int i = 0; i < _moodButtons.Count; i++) _moodButtons[i].BorderBrush = (i + 1 == v) ? Brushes.Black : Brushes.Transparent;
    }

    void Reload()
    {
        _items = Session.Store!.All<JournalEntry>(_kind).OrderByDescending(e => e.Created).ToList();
        _loading = true; _list.Items.Clear();
        foreach (var e in _items)
        {
            var emoji = e.Mood > 0 ? Moods.All[e.Mood - 1].Emoji + " " : "";
            var snip = e.Text.Replace('\n', ' ').Replace('\r', ' ');
            if (snip.Length > 40) snip = snip[..40] + "…";
            _list.Items.Add($"{e.Created:dd-MM-yyyy HH:mm}  {emoji}{snip}");
        }
        _loading = false;
    }

    void OnSelect()
    {
        if (_loading || _list.SelectedIndex < 0) return;
        var e = _items[_list.SelectedIndex];
        _current = e.Id; _text.Text = e.Text; SetMood(e.Mood); _status.Text = "";
    }

    void New() { _current = null; _text.Clear(); SetMood(0); _list.SelectedIndex = -1; _status.Text = ""; }

    void Save()
    {
        if (string.IsNullOrWhiteSpace(_text.Text) && _moodVal == 0) { _status.Text = "Schrijf eerst iets op."; return; }
        var old = _items.FirstOrDefault(i => i.Id == _current);
        var e = old is null
            ? new JournalEntry(Guid.NewGuid(), DateTime.Now, _moodVal, _text.Text)
            : old with { Mood = _moodVal, Text = _text.Text };
        Session.Store!.Save(_kind, e.Id, e);
        _current = e.Id; Reload(); _status.Text = "Opgeslagen ✔";
    }

    void Discard()
    {
        if (_current is Guid id)
        {
            if (!Ui.Confirm("Wil je dit echt weggooien? Het is dan weg.")) return;
            Session.Store!.Delete(_kind, id); New(); Reload();
        }
        else if (_text.Text.Length > 0 && Ui.Confirm("Wil je wat je geschreven hebt weggooien?")) New();
    }
}

sealed class MoodView : ViewBase
{
    public MoodView()
    {
        var entries = Session.Store!.All<JournalEntry>("diary").Where(e => e.Mood > 0).ToList();
        var rows = new StackPanel { Margin = new Thickness(0, 8, 0, 8) };
        for (int d = 13; d >= 0; d--)
        {
            var day = DateTime.Today.AddDays(-d);
            var es = entries.Where(e => e.Created.Date == day).ToList();
            var line = new DockPanel { Margin = new Thickness(0, 3, 0, 3) };
            var lbl = Ui.Label(day.ToString("ddd d MMM", Ui.Nl)); lbl.Width = 190;
            DockPanel.SetDock(lbl, Dock.Left); line.Children.Add(lbl);
            if (es.Count == 0) line.Children.Add(Ui.Label("–", muted: true));
            else
            {
                double avg = es.Average(e => e.Mood); int r = (int)Math.Round(avg);
                var bar = new Border { Height = 32, Width = (6 - avg) / 5.0 * 380, CornerRadius = new CornerRadius(8), Background = Moods.BrushFor(r), HorizontalAlignment = HorizontalAlignment.Left };
                var sp = new StackPanel { Orientation = Orientation.Horizontal };
                sp.Children.Add(bar); sp.Children.Add(Ui.Label($"{Moods.All[r - 1].Emoji} {Moods.All[r - 1].Name}"));
                line.Children.Add(sp);
            }
            rows.Children.Add(line);
        }
        string summary = entries.Count == 0
            ? "Je hebt nog geen gezichtjes gekozen. Kies er een op het beginscherm of in je dagboek."
            : "Een lange balk betekent: je voelde je fijn. Een korte balk betekent: je voelde je minder fijn. Dit is alleen voor jezelf, tenzij je het aan iemand wilt laten zien.";
        Shell("Hoe voel ik me?", Ui.Page(Ui.Label("De laatste 14 dagen", title: true), Ui.Label(summary), rows));
    }
}
