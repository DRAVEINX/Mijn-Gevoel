using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Ink;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using MijnGevoel.Core.Data;

namespace MijnGevoel.Desktop;

sealed class DrawView : ViewBase
{
    readonly InkCanvas _ink = new() { Background = Brushes.White, MinHeight = 400, Margin = new Thickness(8) };
    readonly List<byte[]> _hist = new();
    readonly TextBlock _status = Ui.Label("");
    int _pos, _savedPos;
    Guid? _id; DateTime _created = DateTime.Now; string? _title;
    Color _color = Colors.Black; double _size = 5; bool _marker;

    static readonly (string Name, string Hex)[] Colours =
    {
        ("Zwart", "#000000"), ("Grijs", "#808080"), ("Rood", "#E53935"), ("Oranje", "#FB8C00"), ("Geel", "#FDD835"),
        ("Groen", "#43A047"), ("Blauw", "#1E88E5"), ("Paars", "#8E24AA"), ("Roze", "#EC407A"), ("Bruin", "#6D4C41"),
    };

    public DrawView(DrawingEntry? open = null)
    {
        if (open is not null)
        {
            _id = open.Id; _created = open.Created; _title = open.Title;
            _ink.Strokes = new StrokeCollection(new MemoryStream(open.Isf));
        }
        ApplyPen(); Snapshot(); _savedPos = _pos;
        _ink.StrokeCollected += (_, _) => Snapshot();
        _ink.StrokeErased += (_, _) => Snapshot();

        var tools = new StackPanel { Margin = new Thickness(8), Width = 270 };
        tools.Children.Add(Ui.Label("Kleur"));
        var cols = new WrapPanel();
        foreach (var c in Colours)
        {
            var col = (Color)ColorConverter.ConvertFromString(c.Hex);
            var b = new Button { Background = new SolidColorBrush(col), Width = 48, Height = 48, MinHeight = 48, Padding = new Thickness(0), Margin = new Thickness(4) };
            System.Windows.Automation.AutomationProperties.SetName(b, c.Name);
            b.Click += (_, _) => { _color = col; ApplyPen(); };
            cols.Children.Add(b);
        }
        tools.Children.Add(cols);
        tools.Children.Add(Ui.Label("Gereedschap"));
        var wp = new WrapPanel();
        wp.Children.Add(Ui.Btn("✏️ Pen", () => { _marker = false; ApplyPen(); }));
        wp.Children.Add(Ui.Btn("🖍 Markeer", () => { _marker = true; ApplyPen(); }));
        wp.Children.Add(Ui.Btn("🧽 Gum", () => _ink.EditingMode = InkCanvasEditingMode.EraseByStroke, soft: true));
        tools.Children.Add(wp);
        tools.Children.Add(Ui.Label("Dikte"));
        var sz = new WrapPanel();
        sz.Children.Add(Ui.Btn("Dun", () => { _size = 2; ApplyPen(); }, soft: true));
        sz.Children.Add(Ui.Btn("Middel", () => { _size = 5; ApplyPen(); }, soft: true));
        sz.Children.Add(Ui.Btn("Dik", () => { _size = 12; ApplyPen(); }, soft: true));
        tools.Children.Add(sz);
        var act = new WrapPanel();
        act.Children.Add(Ui.Btn("↶ Ongedaan", Undo, soft: true));
        act.Children.Add(Ui.Btn("↷ Opnieuw", Redo, soft: true));
        act.Children.Add(Ui.Btn("🗑 Alles wissen", () => { if (Ui.Confirm("Alles wissen?")) { _ink.Strokes.Clear(); Snapshot(); } }, danger: true));
        tools.Children.Add(act);
        tools.Children.Add(Ui.Btn("💾 Bewaren", () => Save()));
        tools.Children.Add(Ui.Btn("🖼️ Mijn tekeningen", () => Leave(() => MainWindow.Current.Navigate(new GalleryView())), soft: true));
        tools.Children.Add(Ui.Btn("📤 Opslaan als plaatje", Export, soft: true));
        tools.Children.Add(_status);

        var frame = new Border { Child = _ink, BorderThickness = new Thickness(3), Margin = new Thickness(8) };
        frame.SetResourceReference(Border.BorderBrushProperty, "Accent");
        var root = new DockPanel();
        DockPanel.SetDock(tools, Dock.Left);
        root.Children.Add(Ui.Card(new ScrollViewer { Content = tools, VerticalScrollBarVisibility = ScrollBarVisibility.Auto }, 6));
        DockPanel.SetDock(root.Children[0], Dock.Left);
        root.Children.Add(frame);
        Shell("Tekenen", root, () => Leave(GoHome));
    }

    bool Dirty => _pos != _savedPos;

    void ApplyPen()
    {
        _ink.EditingMode = InkCanvasEditingMode.Ink;
        double s = _marker ? _size * 3 : _size;
        _ink.DefaultDrawingAttributes = new DrawingAttributes { Color = _color, Width = s, Height = s, FitToCurve = true, IsHighlighter = _marker };
    }

    void Snapshot()
    {
        while (_hist.Count > _pos + 1) _hist.RemoveAt(_hist.Count - 1);
        using var ms = new MemoryStream(); _ink.Strokes.Save(ms);
        _hist.Add(ms.ToArray());
        if (_hist.Count > 60) { _hist.RemoveAt(0); _savedPos--; }
        _pos = _hist.Count - 1;
    }
    void Undo() { if (_pos > 0) { _pos--; _ink.Strokes = new StrokeCollection(new MemoryStream(_hist[_pos])); } }
    void Redo() { if (_pos < _hist.Count - 1) { _pos++; _ink.Strokes = new StrokeCollection(new MemoryStream(_hist[_pos])); } }

    byte[] Thumb()
    {
        int w = (int)_ink.ActualWidth, h = (int)_ink.ActualHeight;
        if (w < 1 || h < 1) return Array.Empty<byte>();
        var rtb = new RenderTargetBitmap(w, h, 96, 96, PixelFormats.Pbgra32);
        rtb.Render(_ink);
        var enc = new PngBitmapEncoder(); enc.Frames.Add(BitmapFrame.Create(rtb));
        using var ms = new MemoryStream(); enc.Save(ms); return ms.ToArray();
    }

    void Save()
    {
        using var ms = new MemoryStream(); _ink.Strokes.Save(ms);
        var e = new DrawingEntry(_id ?? Guid.NewGuid(), _created, _title ?? $"Tekening {DateTime.Now:dd-MM-yyyy HH:mm}", ms.ToArray(), Thumb());
        _id = e.Id; _title = e.Title;
        Session.Store!.Save("drawing", e.Id, e);
        _savedPos = _pos; _status.Text = "Opgeslagen ✔";
    }

    void Leave(Action next)
    {
        if (Dirty)
        {
            var r = MessageBox.Show("Wil je je tekening bewaren?", "Mijn Gevoel", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
            if (r == MessageBoxResult.Cancel) return;
            if (r == MessageBoxResult.Yes) Save();
        }
        next();
    }

    void Export()
    {
        var dlg = new SaveFileDialog { Filter = "Plaatje (*.png)|*.png", FileName = $"Tekening {DateTime.Now:yyyy-MM-dd HH.mm}.png" };
        if (dlg.ShowDialog() == true) { File.WriteAllBytes(dlg.FileName, Thumb()); _status.Text = "Plaatje opgeslagen ✔"; }
    }
}

sealed class GalleryView : ViewBase
{
    public GalleryView()
    {
        var wrap = new WrapPanel();
        var items = Session.Store!.All<DrawingEntry>("drawing").OrderByDescending(d => d.Created).ToList();
        if (items.Count == 0) wrap.Children.Add(Ui.Label("Je hebt nog geen tekeningen. Maak je eerste tekening!"));
        foreach (var d in items)
        {
            var img = new Image { Width = 220, Height = 150, Stretch = Stretch.Uniform, Source = Decode(d.Png) };
            var cap = new TextBlock { Text = d.Created.ToString("dd-MM-yyyy HH:mm"), HorizontalAlignment = HorizontalAlignment.Center };
            var sp = new StackPanel(); sp.Children.Add(img); sp.Children.Add(cap);
            var open = new Button { Content = sp, Padding = new Thickness(8) };
            System.Windows.Automation.AutomationProperties.SetName(open, "Tekening van " + cap.Text);
            open.Click += (_, _) => MainWindow.Current.Navigate(new DrawView(d));
            var del = Ui.Btn("🗑 Weggooien", () =>
            {
                if (!Ui.Confirm("Deze tekening weggooien?")) return;
                Session.Store!.Delete("drawing", d.Id);
                MainWindow.Current.Navigate(new GalleryView());
            }, danger: true);
            var card = new StackPanel { Margin = new Thickness(8) };
            card.Children.Add(open); card.Children.Add(del);
            wrap.Children.Add(card);
        }
        Shell("Mijn tekeningen", Ui.Page(Ui.Btn("🎨 Nieuwe tekening", () => MainWindow.Current.Navigate(new DrawView())), wrap));
    }

    static BitmapImage? Decode(byte[] png)
    {
        if (png.Length == 0) return null;
        var b = new BitmapImage();
        b.BeginInit(); b.CacheOption = BitmapCacheOption.OnLoad; b.DecodePixelWidth = 440; b.StreamSource = new MemoryStream(png); b.EndInit(); b.Freeze();
        return b;
    }
}
