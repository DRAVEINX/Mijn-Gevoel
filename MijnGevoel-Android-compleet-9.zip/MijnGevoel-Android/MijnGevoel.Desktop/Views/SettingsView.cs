using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using MijnGevoel.Core.Data;

namespace MijnGevoel.Desktop;

sealed class SettingsView : ViewBase
{
    public SettingsView()
    {
        var s = Session.Settings;
        void Apply() { Session.SaveSettings(); Theme.Apply(s); MainWindow.Current.Navigate(new SettingsView()); }
        Action Set(Action a) => () => { a(); Apply(); };

        UIElement Choices(string title, (string Label, bool On, Action Do)[] opts)
        {
            var wp = new WrapPanel();
            foreach (var o in opts) wp.Children.Add(Ui.Btn((o.On ? "✔ " : "") + o.Label, o.Do, soft: !o.On));
            var sp = new StackPanel();
            sp.Children.Add(Ui.Label(title)); sp.Children.Add(wp);
            return sp;
        }

        var readAloud = new CheckBox { Content = "Laat de knop 'Voorlezen' zien", IsChecked = s.ReadAloud };
        readAloud.Click += (_, _) => { s.ReadAloud = readAloud.IsChecked == true; Session.SaveSettings(); };
        var motion = new CheckBox { Content = "Zachte bewegingen (knoppen en schermen bewegen een klein beetje)", IsChecked = s.Animations };
        motion.Click += (_, _) => { s.Animations = motion.IsChecked == true; Session.SaveSettings(); };

        var wide = new CheckBox { Content = "Ruime regelafstand", IsChecked = s.WideLines };
        wide.Click += (_, _) => { s.WideLines = wide.IsChecked == true; Apply(); };
        var capture = new CheckBox { Content = "Schermafbeeldingen en schermopname van dit venster blokkeren (bij beeldbellen en schermdelen zie je dan zwart)", IsChecked = s.BlockCapture };
        capture.Click += (_, _) => { s.BlockCapture = capture.IsChecked == true; Apply(); };

        // Wachtwoord veranderen
        var old = new PasswordField("Je oude wachtwoord");
        var n1 = new PasswordField("Nieuw wachtwoord (minstens 10 tekens)");
        var n2 = new PasswordField("Nieuw wachtwoord nog een keer");
        var pwStatus = Ui.Label("");
        var change = Ui.Btn("Wachtwoord veranderen");
        change.Click += async (_, _) =>
        {
            if (n1.Value != n2.Value) { pwStatus.Text = "De twee nieuwe wachtwoorden zijn niet hetzelfde."; return; }
            change.IsEnabled = false;
            string u = Session.Username, o = old.Value, n = n1.Value;
            var ok = await Task.Run(() => Session.Accounts.ChangePassword(u, o, n));
            change.IsEnabled = true;
            pwStatus.Text = ok ? "Je wachtwoord is veranderd ✔" : "Dat is niet gelukt. Is je oude wachtwoord goed? Het nieuwe moet minstens 10 tekens zijn.";
            if (ok) { old.Clear(); n1.Clear(); n2.Clear(); }
        };

        // Herstelcodes
        var recLabel = Ui.Label($"Je hebt nog {Session.Accounts.RecoveryCodesLeft(Session.Username)} herstelcode(s). Maak nieuwe codes als je er bijna geen meer hebt. De oude codes werken dan niet meer.");
        var recPw = new PasswordField("Typ je wachtwoord om nieuwe codes te maken");
        var recStatus = Ui.Label("");
        var recBtn = Ui.Btn("🔑 Nieuwe herstelcodes maken");
        recBtn.Click += async (_, _) =>
        {
            recBtn.IsEnabled = false; string u = Session.Username, p = recPw.Value;
            var codes = await Task.Run(() => Session.Accounts.RegenerateRecoveryCodes(u, p));
            recBtn.IsEnabled = true;
            if (codes is null) { recStatus.Text = "Dat is niet gelukt. Controleer je wachtwoord."; return; }
            recPw.Clear(); MainWindow.Current.Navigate(new RecoveryCodesView(codes));
        };

        // Back-up
        var backup = Ui.Btn("💾 Back-up maken", () =>
        {
            var dlg = new SaveFileDialog { Filter = "Back-up (*.zip)|*.zip", FileName = $"MijnGevoel-backup-{DateTime.Now:yyyy-MM-dd}.zip" };
            if (dlg.ShowDialog() != true) return;
            BackupService.Create(Session.Accounts, Session.Username, dlg.FileName);
            Ui.Info("Je back-up is gemaakt. Alles is versleuteld, maar bewaar het bestand toch op een veilige plek.");
        }, soft: true);

        // Account verwijderen
        var delPw = new PasswordField("Typ je wachtwoord om te bevestigen");
        var delStatus = Ui.Label("");
        var delete = Ui.Btn("🗑 Mijn account en alles wat erin staat verwijderen", null, danger: true);
        delete.Click += async (_, _) =>
        {
            if (!Ui.Confirm("Weet je het zeker? Al je tekeningen, je dagboek en je agenda worden voorgoed verwijderd.")) return;
            if (!Ui.Confirm("Echt zeker? Dit kan niet meer ongedaan worden gemaakt.")) return;
            string u = Session.Username, p = delPw.Value;
            var ok = await Task.Run(() => Session.Accounts.DeleteAccount(u, p));
            if (ok) MainWindow.Current.Lock("Je account is verwijderd.");
            else delStatus.Text = "Dat is niet gelukt. Controleer je wachtwoord.";
        };

        Shell("Instellingen", Ui.Page(
            Choices("Grootte van de letters", new[] {
                ("Normaal", s.TextSize == 0, Set(() => s.TextSize = 0)),
                ("Groot", s.TextSize == 1, Set(() => s.TextSize = 1)),
                ("Extra groot", s.TextSize == 2, Set(() => s.TextSize = 2)) }),
            Choices("Kleuren", new[] {
                ("Rustig", s.Theme == "Rustig", Set(() => s.Theme = "Rustig")),
                ("Donker", s.Theme == "Donker", Set(() => s.Theme = "Donker")),
                ("Hoog contrast", s.Theme == "Hoog contrast", Set(() => s.Theme = "Hoog contrast")) }),
            Choices("Vergrendel automatisch na", new[] {
                ("1 minuut", s.AutoLockMinutes == 1, Set(() => s.AutoLockMinutes = 1)),
                ("5 minuten", s.AutoLockMinutes == 5, Set(() => s.AutoLockMinutes = 5)),
                ("10 minuten", s.AutoLockMinutes == 10, Set(() => s.AutoLockMinutes = 10)),
                ("30 minuten", s.AutoLockMinutes == 30, Set(() => s.AutoLockMinutes = 30)) }),
            Choices("Lettertype", new[] {
                ("Standaard", s.FontName == "Standaard", Set(() => s.FontName = "Standaard")),
                ("Verdana", s.FontName == "Verdana", Set(() => s.FontName = "Verdana")),
                ("Arial", s.FontName == "Arial", Set(() => s.FontName = "Arial")),
                ("Georgia", s.FontName == "Georgia", Set(() => s.FontName = "Georgia")) }),
            wide, readAloud, motion, capture,
            Ui.Label("Herstelcodes", title: true), recLabel, recPw, recStatus, recBtn,
            Ui.Label("Wachtwoord", title: true), old, n1, n2, pwStatus, change,
            Ui.Label("Back-up", title: true), backup,
            Ui.Label("Account verwijderen", title: true), delPw, delStatus, delete));
    }
}
