using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using MijnGevoel.Core.Data;

namespace MijnGevoel.Desktop;

sealed class AgendaView : ViewBase
{
    DateTime _day = DateTime.Today;
    readonly TextBlock _dayLabel = Ui.Label("", title: true);
    readonly StackPanel _list = new();
    readonly TextBox _title = new(), _time = new();
    readonly TextBlock _status = Ui.Label("");
    readonly List<Button> _iconBtns = new();
    string _icon = "⭐";

    static readonly (string Icon, string Name)[] Icons =
    {
        ("🏥", "Dokter"), ("👥", "Afspraak"), ("💊", "Medicijnen"), ("🍽️", "Eten"), ("🚌", "Reizen"),
        ("🏃", "Sporten"), ("📞", "Bellen"), ("🎉", "Feest"), ("⭐", "Anders"),
    };

    public AgendaView()
    {
        var nav = new WrapPanel { HorizontalAlignment = HorizontalAlignment.Center };
        nav.Children.Add(Ui.Btn("◀ Vorige dag", () => Move(-1), soft: true));
        nav.Children.Add(Ui.Btn("Vandaag", () => { _day = DateTime.Today; Reload(); }));
        nav.Children.Add(Ui.Btn("Volgende dag ▶", () => Move(1), soft: true));

        var iconRow = new WrapPanel();
        foreach (var ic in Icons)
        {
            var b = Ui.Btn(ic.Icon, null, soft: true);
            b.MinWidth = 60;
            System.Windows.Automation.AutomationProperties.SetName(b, ic.Name);
            b.ToolTip = ic.Name;
            var icon = ic.Icon;
            b.Click += (_, _) => { _icon = icon; MarkIcon(); };
            _iconBtns.Add(b); iconRow.Children.Add(b);
        }

        var form = new StackPanel { Margin = new Thickness(0, 16, 0, 0) };
        form.Children.Add(Ui.Label("Iets toevoegen aan deze dag", title: true));
        form.Children.Add(Ui.Label("Kies een plaatje"));
        form.Children.Add(iconRow);
        form.Children.Add(Ui.Field("Wat ga je doen?", _title));
        form.Children.Add(Ui.Field("Hoe laat? (bijvoorbeeld 14:30, mag leeg blijven)", _time));
        form.Children.Add(Ui.Btn("➕ Toevoegen", Add));
        form.Children.Add(_status);

        Shell("Agenda", Ui.Page(nav, _dayLabel, _list, form));
        MarkIcon(); Reload();
    }

    void MarkIcon()
    {
        for (int i = 0; i < Icons.Length; i++)
            _iconBtns[i].BorderBrush = Icons[i].Icon == _icon ? Brushes.Black : (Brush)FindBrush("Accent");
    }
    static Brush FindBrush(string key) => (Brush)Application.Current.Resources[key];

    void Move(int d) { _day = _day.AddDays(d); Reload(); }

    void Add()
    {
        var t = _title.Text.Trim();
        if (t.Length == 0) { _status.Text = "Schrijf eerst op wat je gaat doen."; return; }
        string time = "";
        var raw = _time.Text.Trim().Replace('.', ':');
        if (raw.Length > 0)
        {
            if (!TimeOnly.TryParse(raw, CultureInfo.InvariantCulture, DateTimeStyles.None, out var to))
            { _status.Text = "Die tijd begrijp ik niet. Typ bijvoorbeeld 14:30."; return; }
            time = to.ToString("HH:mm");
        }
        var item = new AgendaItem(Guid.NewGuid(), _day.Date, time, t, _icon, false);
        Session.Store!.Save("agenda", item.Id, item);
        _title.Clear(); _time.Clear(); _status.Text = "Toegevoegd ✔";
        Reload();
    }

    void Reload()
    {
        _dayLabel.Text = _day.ToString("dddd d MMMM yyyy", Ui.Nl) + (_day.Date == DateTime.Today ? "  (vandaag)" : "");
        _list.Children.Clear();
        var items = Session.Store!.All<AgendaItem>("agenda").Where(a => a.Date.Date == _day.Date).OrderBy(a => a.Time).ToList();
        if (items.Count == 0) _list.Children.Add(Ui.Label("Niets gepland voor deze dag.", muted: true));
        foreach (var a in items)
        {
            var item = a;
            var del = Ui.Btn("🗑", () =>
            {
                if (!Ui.Confirm("Weghalen uit je agenda?")) return;
                Session.Store!.Delete("agenda", item.Id); Reload();
            }, danger: true);
            DockPanel.SetDock(del, Dock.Right);
            var text = new TextBlock
            {
                Text = $"{item.Icon}  {(item.Time.Length > 0 ? item.Time + "  " : "")}{item.Title}",
                TextWrapping = TextWrapping.Wrap,
                TextDecorations = item.Done ? TextDecorations.Strikethrough : null,
            };
            var cb = new CheckBox { IsChecked = item.Done, Content = text };
            System.Windows.Automation.AutomationProperties.SetName(cb, item.Title + (item.Done ? ", klaar" : ", nog niet klaar"));
            cb.Checked += (_, _) => Toggle(item, true);
            cb.Unchecked += (_, _) => Toggle(item, false);
            var row = new DockPanel(); row.Children.Add(del); row.Children.Add(cb);
            var card = new Border { Child = row, CornerRadius = new CornerRadius(12), Padding = new Thickness(10, 4, 4, 4), Margin = new Thickness(0, 4, 0, 4) };
            card.SetResourceReference(Border.BackgroundProperty, "Surface");
            _list.Children.Add(card);
        }
    }

    void Toggle(AgendaItem a, bool done) { Session.Store!.Save("agenda", a.Id, a with { Done = done }); Reload(); }
}
