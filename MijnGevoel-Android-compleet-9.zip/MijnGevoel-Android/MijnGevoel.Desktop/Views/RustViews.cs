using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using MijnGevoel.Core.Data;
using Shapes = System.Windows.Shapes;

namespace MijnGevoel.Desktop;

static class Pick
{
    /// <summary>Knoppen waarvan je er meer dan één kunt kiezen (✔ + dikke rand, dus niet alleen kleur).</summary>
    public static WrapPanel Toggles(IEnumerable<string> items, HashSet<string> set)
    {
        var wp = new WrapPanel();
        foreach (var it in items)
        {
            var text = it;
            var b = Ui.Btn(text, null, soft: true);
            var tb = (TextBlock)b.Content;
            b.Click += (_, _) =>
            {
                if (!set.Remove(text)) set.Add(text);
                bool on = set.Contains(text);
                tb.Text = (on ? "✔ " : "") + text;
                b.BorderBrush = on ? Brushes.Black : (Brush)Application.Current.Resources["Accent"];
            };
            wp.Children.Add(b);
        }
        return wp;
    }
}

/// <summary>Ademhaling: een cirkel die groter en kleiner wordt (4 tellen in, 6 tellen uit, 6 keer). Zonder bewegingen: alleen tekst en tellen.</summary>
sealed class BreathView : ViewBase
{
    const int Rounds = 6;
    readonly DispatcherTimer _t = new() { Interval = TimeSpan.FromSeconds(1) };
    readonly ScaleTransform _sc = new(0.5, 0.5);
    readonly TextBlock _msg = Ui.Label("Druk op Start", title: true);
    readonly TextBlock _count = Ui.Label("");
    readonly Button _start = Ui.Btn("▶ Start");
    int _left, _round; bool _in, _running;

    public BreathView()
    {
        var dot = new Shapes.Ellipse { Width = 260, Height = 260, Opacity = 0.85, RenderTransformOrigin = new Point(0.5, 0.5), RenderTransform = _sc, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        dot.SetResourceReference(Shapes.Shape.FillProperty, "Accent");
        var host = new Grid { Height = 290 }; host.Children.Add(dot);
        _msg.HorizontalAlignment = HorizontalAlignment.Center; _count.HorizontalAlignment = HorizontalAlignment.Center;
        _start.Click += (_, _) => Toggle();
        _t.Tick += (_, _) => Tick();
        Unloaded += (_, _) => _t.Stop();
        Shell("Ademhaling", Ui.Page(
            Ui.Label("Ademhalen", title: true),
            Ui.Label("Adem in door je neus (4 tellen) en rustig uit (6 tellen). Je doet dit 6 keer. Je mag altijd stoppen."),
            host, _msg, _count, _start));
    }

    void SetStart(string t) => ((TextBlock)_start.Content).Text = t;
    void SetScale(double v) { _sc.BeginAnimation(ScaleTransform.ScaleXProperty, null); _sc.BeginAnimation(ScaleTransform.ScaleYProperty, null); _sc.ScaleX = v; _sc.ScaleY = v; }

    void Toggle()
    {
        if (_running) { _t.Stop(); _running = false; SetStart("▶ Start"); _msg.Text = "Gestopt. Goed bezig!"; _count.Text = ""; SetScale(0.5); }
        else { _running = true; _round = 0; SetStart("⏹ Stop"); Phase(true); _t.Start(); }
    }

    void Phase(bool inhale)
    {
        _in = inhale; _left = inhale ? 4 : 6;
        _msg.Text = inhale ? "Adem in…" : "Adem uit…"; _count.Text = _left.ToString();
        double to = inhale ? 1.0 : 0.5;
        if (Motion.Enabled)
        {
            var a = new DoubleAnimation(to, TimeSpan.FromSeconds(_left)) { EasingFunction = new SineEase { EasingMode = EasingMode.EaseInOut } };
            _sc.BeginAnimation(ScaleTransform.ScaleXProperty, a); _sc.BeginAnimation(ScaleTransform.ScaleYProperty, a);
        }
        else SetScale(to);
    }

    void Tick()
    {
        _left--;
        if (_left > 0) { _count.Text = _left.ToString(); return; }
        if (_in) { Phase(false); return; }
        _round++;
        if (_round >= Rounds) { _t.Stop(); _running = false; SetStart("▶ Nog een keer"); _msg.Text = "Goed gedaan 🌿"; _count.Text = ""; }
        else Phase(true);
    }
}

/// <summary>Rustplek: weinig prikkels, rustige kleuren, een paar tips en je eigen plan.</summary>
sealed class CalmView : ViewBase
{
    static readonly string[] Tips =
    {
        "Je bent veilig. Je hoeft nu niets.", "Kijk om je heen. Noem 3 dingen die je ziet.", "Voel je voeten op de grond.",
        "Adem rustig in en uit.", "Drink een slokje water.", "Dit gevoel gaat voorbij. Het blijft niet zo.",
    };
    int _tip;

    public CalmView()
    {
        var tip = new TextBlock { Text = Tips[0], TextWrapping = TextWrapping.Wrap, TextAlignment = TextAlignment.Center, Foreground = Brushes.Black, Margin = new Thickness(24, 40, 24, 40), FontSize = (double)Application.Current.Resources["TitleFont"] };
        var bg = new SolidColorBrush(Color.FromRgb(0xCF, 0xE8, 0xE4));
        if (Motion.Enabled)
            bg.BeginAnimation(SolidColorBrush.ColorProperty, new ColorAnimation(Color.FromRgb(0xE3, 0xD9, 0xF2), TimeSpan.FromSeconds(9)) { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever });
        var panel = new Border { Child = tip, Background = bg, CornerRadius = new CornerRadius(28), MinHeight = 220, Margin = new Thickness(0, 8, 0, 8) };
        var kids = new List<UIElement>
        {
            Ui.Label("Rustplek", title: true), panel,
            Ui.Btn("Volgende tip", () => { _tip = (_tip + 1) % Tips.Length; tip.Text = Tips[_tip]; }, soft: true),
            Ui.Btn("🫁 Samen ademhalen", () => MainWindow.Current.Navigate(new BreathView())),
            Ui.Btn("🚦 Ik heb hulp nodig", () => MainWindow.Current.Navigate(new StoplichtView()), soft: true),
        };
        kids.AddRange(PlanView.Summary());
        Shell("Rustplek", Ui.Page(kids.ToArray()));
    }
}

/// <summary>Prikkelmeter: hoe druk is het in mijn hoofd en om me heen?</summary>
sealed class PrikkelView : ViewBase
{
    static readonly (string Name, string Hex)[] Levels =
    {
        ("Heel rustig", "#8FD694"), ("Rustig", "#C5E384"), ("Gaat wel", "#F4E285"), ("Druk", "#F5B971"), ("Veel te druk", "#E88B8B"),
    };
    static readonly string[] Kinds = { "Hoofd", "Omgeving" };
    readonly int[] _val = new int[2];
    readonly TextBlock _status = Ui.Label("");

    public PrikkelView()
    {
        var kids = new List<UIElement> { Ui.Label("Prikkelmeter", title: true), Ui.Label("Hoe druk is het? Kies voor allebei een kleur.") };
        string[] titles = { "In mijn hoofd", "Om me heen (geluid, licht, mensen)" };
        for (int k = 0; k < 2; k++)
        {
            int kind = k;
            var row = new UniformGrid { Columns = 5 };
            var btns = new List<Button>();
            for (int l = 0; l < 5; l++)
            {
                int level = l + 1;
                var b = new Button
                {
                    Content = new TextBlock { Text = $"{level}\n{Levels[l].Name}", TextAlignment = TextAlignment.Center, TextWrapping = TextWrapping.Wrap },
                    Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString(Levels[l].Hex)),
                    Foreground = Brushes.Black, Padding = new Thickness(4, 10, 4, 10),
                };
                b.Click += (_, _) =>
                {
                    _val[kind] = level;
                    for (int i = 0; i < btns.Count; i++) btns[i].BorderBrush = (i + 1 == level) ? Brushes.Black : Brushes.Transparent;
                };
                btns.Add(b); row.Children.Add(b);
            }
            kids.Add(Ui.Label(titles[k])); kids.Add(row);
        }
        kids.Add(Ui.Btn("💾 Opslaan", Save)); kids.Add(_status);
        Shell("Prikkelmeter", Ui.Page(kids.ToArray()));
    }

    void Save()
    {
        if (_val[0] == 0 && _val[1] == 0) { _status.Text = "Kies eerst een kleur."; return; }
        for (int k = 0; k < 2; k++)
            if (_val[k] > 0) { var e = new ScaleEntry(Guid.NewGuid(), DateTime.Now, Kinds[k], _val[k], ""); Session.Store!.Save("scale", e.Id, e); }
        _status.Text = "Opgeslagen ✔";
        if (_val.Any(v => v >= 4) && Ui.Confirm("Het is druk. Wil je even naar de Rustplek?")) MainWindow.Current.Navigate(new CalmView());
    }
}

/// <summary>Mijn lichaam: waar voel ik iets en wat voel ik?</summary>
sealed class LichaamView : ViewBase
{
    readonly HashSet<string> _where = new(), _what = new();
    readonly TextBlock _status = Ui.Label("");

    public LichaamView()
    {
        Shell("Mijn lichaam", Ui.Page(
            Ui.Label("Mijn lichaam", title: true),
            Ui.Label("Waar voel je iets? En wat voel je? Je mag meer dan één ding kiezen."),
            Ui.Label("Waar?"),
            Pick.Toggles(new[] { "Hoofd", "Keel", "Borst", "Buik", "Rug", "Armen", "Handen", "Benen", "Voeten", "Overal" }, _where),
            Ui.Label("Wat voel je?"),
            Pick.Toggles(new[] { "Spanning", "Pijn", "Kriebel", "Warm", "Koud", "Zwaar", "Misselijk", "Trillerig" }, _what),
            Ui.Btn("💾 Opslaan", Save), _status));
    }

    void Save()
    {
        if (_where.Count == 0 || _what.Count == 0) { _status.Text = "Kies waar je het voelt en wat je voelt."; return; }
        var e = new ScaleEntry(Guid.NewGuid(), DateTime.Now, "Lichaam", 0, $"{string.Join(", ", _where)}: {string.Join(", ", _what)}");
        Session.Store!.Save("scale", e.Id, e);
        _status.Text = "Opgeslagen ✔ Dit kun je aan je begeleider laten zien als je dat wilt.";
    }
}

/// <summary>Gevoelswoorden: wat betekent het en wanneer voel je het?</summary>
sealed class WordsView : ViewBase
{
    static readonly (string E, string W, string T)[] Words =
    {
        ("😄", "Blij", "Je voelt je licht en vrolijk. Iets is leuk of gaat goed."),
        ("😌", "Rustig", "Je lijf en je hoofd zijn kalm. Je hoeft niets."),
        ("🥳", "Trots", "Je hebt iets gedaan wat je moeilijk vond, en het is gelukt."),
        ("😢", "Verdrietig", "Je voelt je zwaar of leeg. Soms moet je huilen."),
        ("😠", "Boos", "Je voelt je warm en gespannen. Je vindt iets niet eerlijk of het mocht niet van jou."),
        ("😨", "Bang", "Je denkt dat er iets ergs gebeurt. Je hart gaat snel."),
        ("😬", "Zenuwachtig", "Je buik kriebelt. Er komt iets spannends aan."),
        ("🥺", "Eenzaam", "Je wilt graag bij iemand zijn, maar je voelt je alleen."),
        ("😴", "Moe", "Je hebt weinig energie. Je wilt rusten."),
        ("🤯", "Overprikkeld", "Er komt te veel tegelijk binnen: geluid, licht, mensen. Je hoofd zit vol."),
        ("😞", "Teleurgesteld", "Je had iets anders verwacht en het ging anders."),
        ("😳", "Beschaamd", "Je wilt dat niemand je ziet, omdat je denkt dat je iets stoms deed."),
        ("😕", "Verward", "Je snapt het even niet. Je weet niet wat je moet doen."),
        ("😮‍💨", "Opgelucht", "Iets spannends is voorbij. Je mag ontspannen."),
        ("🙏", "Dankbaar", "Je vindt het fijn dat iemand iets goeds voor je deed."),
        ("😒", "Jaloers", "Een ander heeft iets wat jij ook graag zou willen."),
    };

    public WordsView()
    {
        var kids = new List<UIElement> { Ui.Label("Gevoelswoorden", title: true), Ui.Label("Hier lees je wat gevoelens betekenen. Dat helpt als je het moeilijk vindt om te zeggen hoe je je voelt.") };
        foreach (var w in Words)
        {
            var word = w;
            var sp = new StackPanel();
            sp.Children.Add(Ui.Label($"{word.E}  {word.W}", title: false));
            sp.Children.Add(Ui.Label(word.T, muted: true));
            if (Session.Settings.ReadAloud) sp.Children.Add(Ui.Btn("🔊 Voorlezen", () => Speaker.Toggle($"{word.W}. {word.T}"), soft: true));
            kids.Add(Ui.Card(sp, 10));
        }
        Shell("Gevoelswoorden", Ui.Page(kids.ToArray()), () => { Speaker.Stop(); GoHome(); });
    }
}

/// <summary>Kaarten om te laten zien (communicatie). Eigen kaarten zijn mogelijk.</summary>
sealed class CardsView : ViewBase
{
    static readonly (string E, string T)[] Basis =
    {
        ("🤫", "Ik wil even rust"), ("🙋", "Ik heb hulp nodig"), ("❓", "Ik snap het niet"), ("🔁", "Kun je het nog een keer zeggen?"),
        ("🐢", "Kun je langzamer praten?"), ("🚻", "Ik moet naar de wc"), ("🥤", "Ik heb dorst"), ("🍽️", "Ik heb honger"),
        ("🔇", "Het is te druk of te hard"), ("✋", "Ik wil niet aangeraakt worden"), ("💬", "Ik wil praten"), ("🏠", "Ik wil naar huis"),
    };

    public CardsView()
    {
        var wrap = new WrapPanel();
        foreach (var c in Basis) wrap.Children.Add(CardButton(c.E, c.T, null));
        foreach (var c in Session.Store!.All<TalkCard>("card").OrderBy(x => x.Text))
        {
            var card = c;
            wrap.Children.Add(CardButton(card.Emoji, card.Text, () =>
            {
                if (!Ui.Confirm("Deze kaart weggooien?")) return;
                Session.Store!.Delete("card", card.Id); MainWindow.Current.Navigate(new CardsView());
            }));
        }
        var emoji = new TextBox { Text = "💬", MaxLength = 4 };
        var text = new TextBox();
        var add = Ui.Btn("➕ Kaart toevoegen", () =>
        {
            var t = text.Text.Trim(); if (t.Length == 0) return;
            var e = emoji.Text.Trim().Length == 0 ? "💬" : emoji.Text.Trim();
            var c = new TalkCard(Guid.NewGuid(), e, t);
            Session.Store!.Save("card", c.Id, c); MainWindow.Current.Navigate(new CardsView());
        }, soft: true);
        Shell("Kaarten", Ui.Page(
            Ui.Label("Kaarten om te laten zien", title: true),
            Ui.Label("Tik op een kaart. Dan wordt hij groot, zodat je hem aan iemand kunt laten zien."),
            wrap,
            Ui.Label("Eigen kaart maken", title: true),
            Ui.Field("Plaatje (een emoji)", emoji), Ui.Field("Wat staat er op de kaart?", text), add));
    }

    static UIElement CardButton(string e, string t, Action? delete)
    {
        var sp = new StackPanel { Width = 190, Margin = new Thickness(4, 6, 4, 6) };
        var content = new StackPanel();
        var emoji = new TextBlock { Text = e, HorizontalAlignment = HorizontalAlignment.Center };
        emoji.SetResourceReference(TextBlock.FontSizeProperty, "TitleFont");
        content.Children.Add(emoji);
        content.Children.Add(new TextBlock { Text = t, TextWrapping = TextWrapping.Wrap, TextAlignment = TextAlignment.Center });
        var b = new Button { Content = content, Padding = new Thickness(10) };
        b.SetResourceReference(FrameworkElement.StyleProperty, "TileButton");
        System.Windows.Automation.AutomationProperties.SetName(b, t);
        b.Click += (_, _) => MainWindow.Current.Navigate(new CardShowView(e, t, true, () => MainWindow.Current.Navigate(new CardsView())));
        sp.Children.Add(b);
        if (delete is not null) sp.Children.Add(Ui.Btn("🗑", delete, soft: true));
        return sp;
    }
}

/// <summary>Een kaart of tekst groot op het scherm, om te laten zien aan iemand anders.</summary>
sealed class CardShowView : ViewBase
{
    public CardShowView(string emoji, string text, bool big, Action back)
    {
        double title = (double)Application.Current.Resources["TitleFont"];
        var e = new TextBlock { Text = emoji, FontSize = title * 3, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 10, 0, 10) };
        var t = new TextBlock { Text = text, FontSize = title * (big ? 1.5 : 1.0), TextWrapping = TextWrapping.Wrap, TextAlignment = TextAlignment.Center, Margin = new Thickness(10, 10, 10, 20) };
        var kids = new List<UIElement> { e, t };
        if (Session.Settings.ReadAloud) kids.Add(Ui.Btn("🔊 Voorlezen", () => Speaker.Toggle(text), soft: true));
        Shell("Kaart", Ui.Page(kids.ToArray()), () => { Speaker.Stop(); back(); });
    }
}

/// <summary>Gesprekskaart: bedenk van tevoren wat je wilt zeggen, vragen en wat er moet gebeuren.</summary>
sealed class TalkPrepView : ViewBase
{
    public TalkPrepView()
    {
        var p = Session.Store!.Load<TalkPrep>("talk", Guid.Empty) ?? new TalkPrep();
        TextBox Box(string v) => new TextBox { Text = v, AcceptsReturn = true, TextWrapping = TextWrapping.Wrap, MinHeight = 90, VerticalContentAlignment = VerticalAlignment.Top };
        var tell = Box(p.Tell); var ask = Box(p.Ask); var want = Box(p.Want);
        var status = Ui.Label("");
        string Combined() =>
            $"Ik wil vertellen:\n{tell.Text.Trim()}\n\nIk wil vragen:\n{ask.Text.Trim()}\n\nIk wil dat:\n{want.Text.Trim()}";
        var save = Ui.Btn("💾 Bewaren", () =>
        {
            Session.Store!.Save("talk", Guid.Empty, new TalkPrep { Tell = tell.Text, Ask = ask.Text, Want = want.Text });
            status.Text = "Opgeslagen ✔";
        });
        var wp = new WrapPanel();
        wp.Children.Add(save);
        wp.Children.Add(Ui.Btn("👀 Laat dit zien", () => MainWindow.Current.Navigate(new CardShowView("🗣️", Combined(), false, () => MainWindow.Current.Navigate(new TalkPrepView()))), soft: true));
        if (Session.Settings.ReadAloud) wp.Children.Add(Ui.Btn("🔊 Voorlezen", () => Speaker.Toggle(Combined()), soft: true));
        wp.Children.Add(Ui.Btn("🧹 Leegmaken", () => { tell.Clear(); ask.Clear(); want.Clear(); }, soft: true));
        Shell("Gesprekskaart", Ui.Page(
            Ui.Label("Gesprekskaart", title: true),
            Ui.Label("Een gesprek met je begeleider of dokter? Schrijf van tevoren op wat je wilt zeggen. Tip: druk op de Windows-toets + H om te praten in plaats van te typen.", muted: false),
            Ui.Field("Wat wil ik vertellen?", tell), Ui.Field("Wat wil ik vragen?", ask), Ui.Field("Wat wil ik dat er gebeurt?", want),
            wp, status), () => { Speaker.Stop(); GoHome(); });
    }
}

/// <summary>Weekoverzicht: alleen tellen wat er is gedaan. Geen oordeel. Alleen voor jezelf, tenzij je het deelt.</summary>
sealed class WeekView : ViewBase
{
    public WeekView()
    {
        var st = Session.Store!;
        var since = DateTime.Today.AddDays(-6);
        var lights = st.All<StoplichtEntry>("light").Where(e => e.Created.Date >= since).ToList();
        var moods = st.All<JournalEntry>("diary").Where(e => e.Created.Date >= since && e.Mood > 0).ToList();
        var agenda = st.All<AgendaItem>("agenda").Where(a => a.Date.Date >= since && a.Date.Date <= DateTime.Today).ToList();
        int Count(string c) => lights.Count(l => l.Colour == c);
        string most = moods.Count == 0 ? "nog niets gekozen"
            : Moods.All[moods.GroupBy(m => m.Mood).OrderByDescending(g => g.Count()).First().Key - 1].Name;
        var lines = new[]
        {
            $"🟢 Groen: {Count("Groen")}     🟠 Oranje: {Count("Oranje")}     🔴 Rood: {Count("Rood")}",
            $"Gezichtjes gekozen: {moods.Count}. Het meest gekozen: {most}.",
            $"Agenda: {agenda.Count(a => a.Done)} van {agenda.Count} afgevinkt.",
            $"Dagboek: {st.All<JournalEntry>("diary").Count(e => e.Created.Date >= since && e.Text.Length > 0)} keer geschreven.",
            $"Van me afschrijven: {st.All<JournalEntry>("note").Count(e => e.Created.Date >= since)} briefjes.",
            $"Tekeningen gemaakt: {st.All<DrawingEntry>("drawing").Count(e => e.Created.Date >= since)}.",
            $"Prikkelmeter en lichaam: {st.All<ScaleEntry>("scale").Count(e => e.Created.Date >= since)} keer ingevuld.",
        };
        Shell("Weekoverzicht", Ui.Page(
            Ui.Label("Mijn week", title: true),
            Ui.Label($"{since:d MMMM} t/m {DateTime.Today:d MMMM}", muted: true),
            Ui.Label(string.Join("\n\n", lines)),
            Ui.Label("Dit zie alleen jij, tenzij je het deelt.", muted: true),
            Ui.Btn("📤 Delen met mijn begeleider", () => MainWindow.Current.Navigate(new ShareView(null)), soft: true)));
    }
}
