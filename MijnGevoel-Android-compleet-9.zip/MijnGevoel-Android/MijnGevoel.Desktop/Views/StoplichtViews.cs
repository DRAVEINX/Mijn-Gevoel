using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using Microsoft.Win32;
using MijnGevoel.Core.Data;

namespace MijnGevoel.Desktop;

/// <summary>Stoplicht-check-in: één vraag per scherm (kleur, waarom, wat nodig, eventueel tekst).</summary>
sealed class StoplichtView : ViewBase
{
    string _colour = "";
    readonly HashSet<string> _reasons = new(), _needs = new();
    string _text = "";

    public StoplichtView(string? colour = null)
    {
        if (colour is null) StepColour(); else Picked(colour);
    }

    void StepColour() => Shell("Mijn stoplicht", Ui.Page(
        Ui.Label("Hoe is het nu?", title: true),
        Ui.Label("Kies de kleur die bij jou past. Je kunt het later altijd weer veranderen."),
        Light.Big("Groen", () => Picked("Groen")), Light.Big("Oranje", () => Picked("Oranje")), Light.Big("Rood", () => Picked("Rood"))));

    void Picked(string c) { _colour = c; if (c == "Groen") StepText(); else StepChoices(true); }

    void StepChoices(bool reasons)
    {
        var l = Light.Of(_colour);
        var set = reasons ? _reasons : _needs;
        var items = reasons ? Light.Reasons : Light.Needs;
        var wp = new WrapPanel();
        foreach (var it in items)
        {
            var b = Ui.Btn(it.Emoji + "  " + it.Text, null, soft: true);
            var tb = (TextBlock)b.Content; var text = it.Text; var full = it.Emoji + "  " + it.Text;
            b.Click += (_, _) =>
            {
                if (!set.Remove(text)) set.Add(text);
                bool on = set.Contains(text);
                tb.Text = (on ? "✔ " : "") + full;
                b.BorderBrush = on ? Brushes.Black : (Brush)Application.Current.Resources["Accent"];
            };
            wp.Children.Add(b);
        }
        var next = Ui.Btn("Verder →", () => { if (reasons) StepChoices(false); else StepText(); });
        Shell("Mijn stoplicht", Ui.Page(
            Ui.Label($"{l.Emoji} {l.Title}", title: true),
            Ui.Label(reasons ? "Waarom is het niet groen? Je mag meer dan één ding kiezen." : "Wat heb je nodig? Je mag meer dan één ding kiezen."),
            wp, next),
            () => { if (reasons) StepColour(); else StepChoices(true); });
    }

    void StepText()
    {
        var box = new TextBox { AcceptsReturn = true, TextWrapping = TextWrapping.Wrap, MinHeight = 160, VerticalContentAlignment = VerticalAlignment.Top };
        var save = Ui.Btn("💾 Opslaan", () => { _text = box.Text; Save(); });
        Shell("Mijn stoplicht", Ui.Page(
            Ui.Label("Wil je er iets bij schrijven?", title: true),
            Ui.Label("Dit hoeft niet. Je mag het ook leeg laten."),
            box, save),
            () => { if (_colour == "Groen") StepColour(); else StepChoices(false); });
    }

    void Save()
    {
        var e = new StoplichtEntry(Guid.NewGuid(), DateTime.Now, _colour, _reasons.ToArray(), _needs.ToArray(), _text);
        Session.Store!.Save("light", e.Id, e);
        Done(e);
    }

    void Done(StoplichtEntry e)
    {
        var l = Light.Of(e.Colour);
        var kids = new List<UIElement> { Ui.Label($"{l.Emoji} Opgeslagen ✔", title: true) };
        if (e.Colour == "Groen")
            kids.Add(Ui.Label("Fijn dat het goed gaat!"));
        else
        {
            kids.Add(Ui.Label(e.Colour == "Rood"
                ? "Goed dat je dit aangeeft. Je hoeft dit niet alleen te doen."
                : "Goed dat je dit aangeeft."));
            kids.Add(Ui.Label("Let op: Mijn Gevoel kan zelf niemand waarschuwen of bellen. Vertel het aan iemand die je vertrouwt, of deel het met je begeleider met de knop hieronder.", muted: false));
            kids.AddRange(PlanView.Summary());
            if (e.Colour == "Rood")
                kids.Add(Ui.Label("Is het gevaarlijk, of denk je erover om jezelf iets aan te doen? Bel dan nu 112, of 113 Zelfmoordpreventie: 0800-0113 (gratis, dag en nacht)."));
            kids.Add(Ui.Btn("📤 Deel dit met mijn begeleider", () => MainWindow.Current.Navigate(new ShareView(e.Id)), danger: e.Colour == "Rood"));
        }
        kids.Add(Ui.Btn("🏠 Naar het beginscherm", GoHome, soft: true));
        Shell("Mijn stoplicht", Ui.Page(kids.ToArray()));
    }
}

sealed class StoplichtHistoryView : ViewBase
{
    public StoplichtHistoryView()
    {
        var items = Session.Store!.All<StoplichtEntry>("light").OrderByDescending(e => e.Created).ToList();
        var log = Session.Store.All<ShareLogEntry>("sharelog").OrderByDescending(e => e.Created).ToList();
        var list = new StackPanel();
        if (items.Count == 0) list.Children.Add(Ui.Label("Je hebt nog niets ingevuld.", muted: true));
        foreach (var e in items)
        {
            var entry = e; var l = Light.Of(e.Colour);
            var sp = new StackPanel();
            sp.Children.Add(Row($"{l.Emoji} {l.Title} - {l.Sub}", e.Created.ToString("dddd d MMMM yyyy HH:mm", Ui.Nl), bold: true));
            if (e.Reasons.Length > 0) sp.Children.Add(Row("Waarom: " + string.Join(", ", e.Reasons)));
            if (e.Needs.Length > 0) sp.Children.Add(Row("Nodig: " + string.Join(", ", e.Needs)));
            if (e.Text.Length > 0) sp.Children.Add(Row(e.Text));
            var del = Ui.Btn("🗑 Weggooien", () =>
            {
                if (!Ui.Confirm("Dit weggooien?")) return;
                Session.Store!.Delete("light", entry.Id); MainWindow.Current.Navigate(new StoplichtHistoryView());
            }, soft: true);
            sp.Children.Add(del);
            list.Children.Add(new Border { Child = sp, Background = Light.BrushFor(e.Colour), CornerRadius = new CornerRadius(12), Padding = new Thickness(10), Margin = new Thickness(0, 6, 0, 6) });
        }
        string shared = log.Count == 0 ? "Je hebt nog niets gedeeld met een begeleider."
            : $"Je hebt {log.Count} keer iets gedeeld met een begeleider. Het laatst op {log[0].Created:dd-MM-yyyy HH:mm}.";
        Shell("Mijn stoplicht-overzicht", Ui.Page(
            Ui.Btn("🚦 Nieuwe stoplicht-melding", () => MainWindow.Current.Navigate(new StoplichtView())),
            Ui.Btn("📤 Delen met mijn begeleider", () => MainWindow.Current.Navigate(new ShareView(null)), soft: true),
            Ui.Label(shared, muted: true), list));
    }

    static UIElement Row(string text, string? right = null, bool bold = false)
    {
        var t = new TextBlock { Text = right is null ? text : text + "\n" + right, TextWrapping = TextWrapping.Wrap, Foreground = Brushes.Black, Margin = new Thickness(2, 2, 2, 2) };
        if (bold) t.FontWeight = FontWeights.SemiBold;
        return t;
    }
}

/// <summary>Mijn plan: wie kan ik bellen en wat helpt mij. Wordt getoond bij oranje en rood.</summary>
sealed class PlanView : ViewBase
{
    public static SafetyPlan Load() => Session.Store!.Load<SafetyPlan>("plan", Guid.Empty) ?? new SafetyPlan();

    public static IEnumerable<UIElement> Summary()
    {
        var p = Load();
        if (p.Contacts.Count(c => c.Name.Length > 0) > 0)
        {
            yield return Ui.Label("Met wie kan ik praten?", title: false);
            foreach (var c in p.Contacts.Where(c => c.Name.Length > 0))
                yield return Ui.Label($"📞 {c.Name}   {c.Phone}");
        }
        if (p.Helps.Trim().Length > 0) { yield return Ui.Label("Dit helpt mij:"); yield return Ui.Label(p.Helps); }
        if (p.Contacts.Count == 0 && p.Helps.Trim().Length == 0)
            yield return Ui.Label("Tip: vul bij 'Mijn plan' in met wie je kunt praten en wat jou helpt.", muted: true);
    }

    public PlanView()
    {
        var plan = Load();
        while (plan.Contacts.Count < 3) plan.Contacts.Add(new ContactPerson("", ""));
        var names = new List<TextBox>(); var phones = new List<TextBox>();
        var kids = new List<UIElement>
        {
            Ui.Label("Mijn plan", title: true),
            Ui.Label("Vul in met wie je kunt praten als het even niet goed gaat, en wat jou helpt. Dit staat alleen bij jou."),
        };
        for (int i = 0; i < 3; i++)
        {
            var n = new TextBox { Text = plan.Contacts[i].Name }; var p = new TextBox { Text = plan.Contacts[i].Phone };
            names.Add(n); phones.Add(p);
            kids.Add(Ui.Field($"Persoon {i + 1}: naam", n)); kids.Add(Ui.Field("Telefoonnummer", p));
        }
        var helps = new TextBox { Text = plan.Helps, AcceptsReturn = true, TextWrapping = TextWrapping.Wrap, MinHeight = 140, VerticalContentAlignment = VerticalAlignment.Top };
        kids.Add(Ui.Field("Wat helpt mij? (bijvoorbeeld: muziek luisteren, tekenen, een rondje lopen)", helps));
        var status = Ui.Label("");
        kids.Add(Ui.Btn("💾 Bewaren", () =>
        {
            var p = new SafetyPlan { Helps = helps.Text };
            for (int i = 0; i < 3; i++) p.Contacts.Add(new ContactPerson(names[i].Text.Trim(), phones[i].Text.Trim()));
            Session.Store!.Save("plan", Guid.Empty, p); status.Text = "Opgeslagen ✔";
        }));
        kids.Add(status);
        Shell("Mijn plan", Ui.Page(kids.ToArray()));
    }
}

/// <summary>De cliënt kiest zelf wat wordt gedeeld. Standaard: een versleuteld, leesbaar bestand (.html) dat elke begeleider in een browser kan openen, zonder programma.</summary>
sealed class ShareView : ViewBase
{
    public ShareView(Guid? preselect)
    {
        var entries = Session.Store!.All<StoplichtEntry>("light").OrderByDescending(e => e.Created).Take(40).ToList();
        var boxes = new List<(CheckBox Box, StoplichtEntry E)>();
        var kids = new List<UIElement>
        {
            Ui.Label("Delen met mijn begeleider", title: true),
            Ui.Label("Jij bepaalt wat je deelt. Vink hieronder aan wat je wilt laten zien. Er wordt niets gedeeld wat je niet aanvinkt."),
            Ui.Label("Je begeleider hoeft Mijn Gevoel niet te hebben. Het bestand opent in elke browser (Edge, Chrome, Safari), ook op een telefoon. Je kunt het bijvoorbeeld via WhatsApp of e-mail sturen. Je begeleider typt een code om het te lezen.", muted: true),
        };
        if (entries.Count == 0) kids.Add(Ui.Label("Je hebt nog geen stoplicht-meldingen.", muted: true));
        foreach (var e in entries)
        {
            var l = Light.Of(e.Colour);
            var why = e.Reasons.Length > 0 ? " - " + string.Join(", ", e.Reasons) : "";
            var cb = new CheckBox { IsChecked = e.Id == preselect, Content = new TextBlock { Text = $"{e.Created:dd-MM HH:mm}  {l.Emoji} {l.Title}{why}", TextWrapping = TextWrapping.Wrap } };
            boxes.Add((cb, e)); kids.Add(cb);
        }
        var name = new TextBox { Text = Session.Username };
        kids.Add(Ui.Field("Jouw naam voor je begeleider", name));
        var status = Ui.Label("");
        var go = Ui.Btn("📤 Maak het bestand");
        go.Click += async (_, _) =>
        {
            var chosen = boxes.Where(b => b.Box.IsChecked == true).Select(b => b.E).ToList();
            if (chosen.Count == 0) { status.Text = "Vink eerst aan wat je wilt delen."; return; }
            var dlg = new SaveFileDialog
            {
                Filter = "Leesbaar bestand voor begeleiders (*.html)|*.html|Alleen voor het programma Mijn Gevoel (*.mgdeel)|*.mgdeel",
                FileName = $"Mijn-Gevoel-delen-{DateTime.Now:yyyy-MM-dd}",
            };
            if (dlg.ShowDialog() != true) return;
            go.IsEnabled = false; status.Text = "Even wachten…";
            var code = ShareService.NewShareCode(); string who = name.Text.Trim(); string path = dlg.FileName;
            bool mg = path.EndsWith(".mgdeel", StringComparison.OrdinalIgnoreCase);
            await Task.Run(() =>
            {
                if (mg) File.WriteAllBytes(path, ShareService.Create(who, chosen, code));
                else File.WriteAllText(path, ShareService.CreateHtml(who, chosen, code), new UTF8Encoding(false));
            });
            var log = new ShareLogEntry(Guid.NewGuid(), DateTime.Now, chosen.Count);
            Session.Store!.Save("sharelog", log.Id, log);
            Result(code, path, who, chosen, mg);
        };
        kids.Add(status); kids.Add(go);
        Shell("Delen", Ui.Page(kids.ToArray()));
    }

    void Result(string code, string path, string who, List<StoplichtEntry> chosen, bool mg)
    {
        var codeBox = new TextBox { Text = code, IsReadOnly = true, FontFamily = new FontFamily("Consolas"), HorizontalAlignment = HorizontalAlignment.Left, MinWidth = 380 };
        codeBox.SetResourceReference(TextBox.FontSizeProperty, "TitleFont");
        var kids = new List<UIElement>
        {
            Ui.Label("Het bestand is klaar ✔", title: true),
            Ui.Label("Je begeleider heeft deze code nodig om het te openen:"),
            codeBox,
            Ui.Label("Schrijf de code nu op, want je ziet hem hierna niet meer. Geef de code op een andere manier door dan het bestand, bijvoorbeeld door te bellen of het persoonlijk te zeggen. Zet de code dus niet in hetzelfde WhatsApp-gesprek als het bestand."),
            Ui.Label(mg
                ? "Je begeleider opent dit bestand in Mijn Gevoel via 'Ik ben begeleider: deelbestand openen'."
                : "Zo stuur je het via WhatsApp: open het gesprek, tik op de paperclip, kies Document en kies dit bestand. Je begeleider opent het bestand in een browser en typt de code. Dat kan ook op een computer."),
            Ui.Btn("📂 Laat het bestand zien in de map", () => Process.Start("explorer.exe", $"/select,\"{path}\""), soft: true),
        };
        if (!mg) kids.Add(Ui.Btn("📋 Kopieer als tekst voor WhatsApp (niet versleuteld)", () => CopyText(who, chosen), soft: true));
        kids.Add(Ui.Btn("🏠 Naar het beginscherm", GoHome, soft: true));
        Shell("Delen", Ui.Page(kids.ToArray()));
    }

    static void CopyText(string who, List<StoplichtEntry> chosen)
    {
        if (!Ui.Confirm("Dit kopieert je meldingen als gewone tekst. Die tekst is niet versleuteld door Mijn Gevoel. Als je het in WhatsApp plakt, blijft het in dat gesprek staan, ook op de telefoon van je begeleider. Een versleuteld bestand is veiliger. Wil je het toch kopiëren?")) return;
        try
        {
            var text = ShareService.PlainText(who, chosen);
            Clipboard.SetText(text);
            var t = new DispatcherTimer { Interval = TimeSpan.FromSeconds(60) };
            t.Tick += (_, _) => { t.Stop(); try { if (Clipboard.ContainsText() && Clipboard.GetText() == text) Clipboard.Clear(); } catch { } };
            t.Start();
            Ui.Info("Gekopieerd. Plak het nu in WhatsApp. Na een minuut wordt het klembord weer leeggemaakt.");
        }
        catch (Exception) { Ui.Info("Kopiëren lukt niet. Probeer het nog een keer."); }
    }
}

/// <summary>Voor begeleiders: een deelbestand openen met de code. Er is geen account nodig; er wordt niets opgeslagen.</summary>
sealed class ShareOpenView : UserControl
{
    readonly Action _back;
    public ShareOpenView(Action back) { _back = back; ShowOpen(); }

    void ShowOpen()
    {
        string? file = null;
        var fileLabel = Ui.Label("Nog geen bestand gekozen.", muted: true);
        var code = new TextBox();
        var status = Ui.Label("");
        var pick = Ui.Btn("📂 Kies het deelbestand", () =>
        {
            var dlg = new OpenFileDialog { Filter = "Deelbestand (*.mgdeel)|*.mgdeel" };
            if (dlg.ShowDialog() == true) { file = dlg.FileName; fileLabel.Text = Path.GetFileName(file); }
        }, soft: true);
        var open = Ui.Btn("Openen"); open.IsDefault = true;
        open.Click += async (_, _) =>
        {
            if (file is null) { status.Text = "Kies eerst een bestand."; return; }
            open.IsEnabled = false; status.Text = "Even wachten…";
            string f = file, c = code.Text;
            var pkg = await Task.Run(() => MijnGevoel.Core.Data.ShareService.Open(File.ReadAllBytes(f), c));
            open.IsEnabled = true;
            if (pkg is null) status.Text = "Openen lukt niet. Controleer de code en het bestand.";
            else ShowContent(pkg);
        };
        Content = Ui.Page(
            Ui.Label("Voor begeleiders", title: true),
            Ui.Label("Open hier een deelbestand van een cliënt. Hiervoor is geen account nodig. Er wordt niets op deze computer bewaard."),
            pick, fileLabel, Ui.Field("Code (die de cliënt je heeft gegeven)", code), status, open,
            Ui.Btn("← Terug", _back, soft: true));
    }

    void ShowContent(SharePackage pkg)
    {
        string order(string c) => c == "Rood" ? "0" : c == "Oranje" ? "1" : "2";
        var list = new StackPanel();
        foreach (var e in pkg.Items.OrderBy(i => order(i.Colour)).ThenByDescending(i => i.Created))
        {
            var l = Light.Of(e.Colour);
            var sp = new StackPanel();
            void Line(string t, bool bold = false) => sp.Children.Add(new TextBlock { Text = t, TextWrapping = TextWrapping.Wrap, Foreground = Brushes.Black, FontWeight = bold ? FontWeights.SemiBold : FontWeights.Normal, Margin = new Thickness(2) });
            Line($"{l.Emoji} {l.Title} - {l.Sub}   ({e.Created:dd-MM-yyyy HH:mm})", true);
            if (e.Reasons.Length > 0) Line("Waarom: " + string.Join(", ", e.Reasons));
            if (e.Needs.Length > 0) Line("Nodig: " + string.Join(", ", e.Needs));
            if (e.Text.Length > 0) Line(e.Text);
            list.Children.Add(new Border { Child = sp, Background = Light.BrushFor(e.Colour), CornerRadius = new CornerRadius(12), Padding = new Thickness(10), Margin = new Thickness(0, 6, 0, 6) });
        }
        Content = Ui.Page(
            Ui.Label($"Gedeeld door {pkg.From}", title: true),
            Ui.Label($"Gemaakt op {pkg.Created:dd-MM-yyyy HH:mm}. De cliënt heeft zelf gekozen om dit te delen. Rood staat bovenaan. Neem contact op met de cliënt volgens het afgesproken protocol van jullie organisatie."),
            list, Ui.Btn("Sluiten", _back, soft: true));
    }
}

sealed class RecoveryCodesView : ViewBase
{
    public RecoveryCodesView(IReadOnlyList<string> codes)
    {
        var box = new TextBox { Text = string.Join("\n", codes), IsReadOnly = true, AcceptsReturn = true, Height = 220 };
        Shell("Nieuwe herstelcodes", Ui.Page(
            Ui.Label("Je nieuwe herstelcodes", title: true),
            Ui.Label("Je oude codes werken niet meer. Schrijf deze codes op of print ze, en bewaar ze op een veilige plek, niet bij je telefoon. Elke code werkt één keer."),
            box,
            Ui.Btn("🖨 Printen", () => RecoverySheet.Print(Session.Username, codes), soft: true),
            Ui.Btn("Klaar, ik heb ze bewaard", () => MainWindow.Current.Navigate(new SettingsView()))));
    }
}
