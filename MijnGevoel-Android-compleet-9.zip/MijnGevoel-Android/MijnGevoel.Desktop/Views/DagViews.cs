using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Threading;
using MijnGevoel.Core.Data;
using Shapes = System.Windows.Shapes;

namespace MijnGevoel.Desktop;

sealed record NavItem(string Icon, string Text, Func<UserControl> Make);

/// <summary>Een groep tegels (houdt het beginscherm rustig: eerst kiezen waar je heen wilt).</summary>
sealed class CategoryView : ViewBase
{
    public CategoryView(string icon, string title, params NavItem[] items)
    {
        var grid = new UniformGrid { Columns = 2 };
        foreach (var it in items) grid.Children.Add(HomeView.Tile(it.Icon, it.Text, it.Make));
        Shell($"{icon} {title}", Ui.Page(grid));
    }
}

/// <summary>Mijn dag: eerst-dan, daarna de hele dag met pictogrammen. Met "Volgende dag" kijk je alvast naar morgen (geen verrassingen).</summary>
sealed class DayView : ViewBase
{
    DateTime _day;
    public DayView(DateTime day) { _day = day.Date; Build(); }

    static string Key(AgendaItem a) => a.Time.Length == 0 ? "99:99" : a.Time;
    void Move(int d) { _day = _day.AddDays(d); Build(); }
    void Toggle(AgendaItem a) { Session.Store!.Save("agenda", a.Id, a with { Done = !a.Done }); Build(); }

    void Build()
    {
        var all = Session.Store!.All<AgendaItem>("agenda").Where(a => a.Date.Date == _day).OrderBy(a => Key(a)).ToList();
        bool today = _day == DateTime.Today;
        string nowT = DateTime.Now.ToString("HH:mm");
        var next = all.FirstOrDefault(i => !i.Done && (!today || i.Time.Length == 0 || string.CompareOrdinal(i.Time, nowT) >= 0))
                   ?? all.FirstOrDefault(i => !i.Done);
        var then = next is null ? null : all.Where(i => !i.Done && i.Id != next.Id).FirstOrDefault(i => string.CompareOrdinal(Key(i), Key(next)) >= 0);

        string name = today ? "Vandaag" : _day == DateTime.Today.AddDays(1) ? "Morgen" : _day == DateTime.Today.AddDays(-1) ? "Gisteren" : _day.ToString("dddd", Ui.Nl);
        var nav = new WrapPanel { HorizontalAlignment = HorizontalAlignment.Center };
        nav.Children.Add(Ui.Btn("◀ Vorige dag", () => Move(-1), soft: true));
        nav.Children.Add(Ui.Btn("Vandaag", () => { _day = DateTime.Today; Build(); }));
        nav.Children.Add(Ui.Btn("Volgende dag ▶", () => Move(1), soft: true));

        var kids = new List<UIElement> { Ui.Label($"{name}", title: true), Ui.Label(_day.ToString("dddd d MMMM yyyy", Ui.Nl), muted: true), nav };
        if (all.Count == 0)
        {
            kids.Add(Ui.Label("Er staat niets gepland voor deze dag."));
            kids.Add(Ui.Btn("📅 Iets toevoegen in de agenda", () => MainWindow.Current.Navigate(new AgendaView())));
        }
        else
        {
            if (next is not null)
            {
                kids.Add(Ui.Label("Eerst", title: false)); kids.Add(Card(next, strong: true));
                if (then is not null) { kids.Add(Ui.Label("Dan")); kids.Add(Card(then, strong: false)); }
            }
            else kids.Add(Ui.Label("Alles is klaar 🎉"));
            kids.Add(Ui.Label("De hele dag", title: true));
            foreach (var a in all) kids.Add(Card(a, strong: false));
        }
        Shell("Mijn dag", Ui.Page(kids.ToArray()));
    }

    UIElement Card(AgendaItem a, bool strong)
    {
        double big = (double)Application.Current.Resources["TitleFont"];
        var icon = new TextBlock { Text = a.Icon, FontSize = big * (strong ? 1.8 : 1.2), VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(6, 0, 16, 0) };
        var txt = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
        txt.Children.Add(new TextBlock { Text = a.Time.Length > 0 ? a.Time : "Geen tijd", Opacity = 0.75 });
        var title = new TextBlock { Text = a.Title, TextWrapping = TextWrapping.Wrap, FontWeight = FontWeights.SemiBold, TextDecorations = a.Done ? TextDecorations.Strikethrough : null };
        if (strong) title.FontSize = big;
        txt.Children.Add(title);
        var done = Ui.Btn(a.Done ? "↩ Terugzetten" : "✅ Klaar", () => Toggle(a), soft: a.Done);
        DockPanel.SetDock(done, Dock.Right); DockPanel.SetDock(icon, Dock.Left);
        var dock = new DockPanel();
        dock.Children.Add(done); dock.Children.Add(icon); dock.Children.Add(txt);
        var b = new Border { Child = dock, CornerRadius = new CornerRadius(20), Padding = new Thickness(16), Margin = new Thickness(0, 6, 0, 6), BorderThickness = new Thickness(strong ? 3 : 1), Opacity = a.Done ? 0.6 : 1 };
        b.SetResourceReference(Border.BackgroundProperty, "Surface");
        b.SetResourceReference(Border.BorderBrushProperty, "Accent");
        return b;
    }
}

/// <summary>Visuele timer: een gekleurde taartpunt die langzaam kleiner wordt. Geen geluid, geen schrik.</summary>
sealed class TimerView : ViewBase
{
    readonly DispatcherTimer _t = new() { Interval = TimeSpan.FromMilliseconds(250) };
    readonly Shapes.Path _wedge = new();
    readonly TextBlock _time = Ui.Label("", title: true);
    readonly TextBlock _msg = Ui.Label("");
    readonly Button _start = Ui.Btn("▶ Start");
    TimeSpan _total = TimeSpan.FromMinutes(10), _left = TimeSpan.FromMinutes(10);
    DateTime _end; bool _running;

    public TimerView()
    {
        _wedge.SetResourceReference(Shapes.Shape.FillProperty, "Accent");
        var back = new Shapes.Ellipse { Width = 300, Height = 300, StrokeThickness = 4 };
        back.SetResourceReference(Shapes.Shape.FillProperty, "Surface");
        back.SetResourceReference(Shapes.Shape.StrokeProperty, "Accent");
        var canvas = new Canvas { Width = 300, Height = 300, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 10, 0, 10) };
        canvas.Children.Add(back); canvas.Children.Add(_wedge);
        _time.HorizontalAlignment = HorizontalAlignment.Center;
        _msg.HorizontalAlignment = HorizontalAlignment.Center;

        var mins = new WrapPanel { HorizontalAlignment = HorizontalAlignment.Center };
        foreach (var m in new[] { 5, 10, 15, 20, 30, 45, 60 }) { int mm = m; mins.Children.Add(Ui.Btn($"{mm} min", () => SetTotal(mm), soft: true)); }
        _start.Click += (_, _) => Toggle();
        var controls = new WrapPanel { HorizontalAlignment = HorizontalAlignment.Center };
        controls.Children.Add(_start);
        controls.Children.Add(Ui.Btn("↺ Opnieuw", () => SetTotal((int)_total.TotalMinutes), soft: true));

        _t.Tick += (_, _) => Tick();
        Unloaded += (_, _) => _t.Stop();
        Render();
        Shell("Timer", Ui.Page(Ui.Label("Timer", title: true), Ui.Label("Kies hoe lang. Je ziet de tijd kleiner worden."), mins, canvas, _time, _msg, controls));
    }

    void SetStart(string text) => ((TextBlock)_start.Content).Text = text;

    void SetTotal(int minutes)
    {
        _total = TimeSpan.FromMinutes(Math.Max(1, minutes)); _left = _total; _running = false; _t.Stop();
        SetStart("▶ Start"); _msg.Text = ""; Render();
    }

    void Toggle()
    {
        if (_running)
        {
            _running = false; _t.Stop(); _left = _end - DateTime.Now; if (_left < TimeSpan.Zero) _left = TimeSpan.Zero;
            SetStart("▶ Verder");
        }
        else
        {
            if (_left <= TimeSpan.Zero) _left = _total;
            _end = DateTime.Now + _left; _running = true; _t.Start(); SetStart("⏸ Pauze"); _msg.Text = "";
        }
    }

    void Tick()
    {
        _left = _end - DateTime.Now;
        if (_left <= TimeSpan.Zero) { _left = TimeSpan.Zero; _running = false; _t.Stop(); SetStart("▶ Start"); _msg.Text = "⏰ De tijd is om!"; }
        Render();
    }

    void Render()
    {
        int s = (int)Math.Ceiling(_left.TotalSeconds);
        _time.Text = $"{s / 60:00}:{s % 60:00}";
        _wedge.Data = Wedge(_total.TotalSeconds <= 0 ? 0 : _left.TotalSeconds / _total.TotalSeconds);
    }

    static Geometry Wedge(double frac)
    {
        const double c = 150, r = 135;
        if (frac >= 0.999) return new EllipseGeometry(new Point(c, c), r, r);
        if (frac <= 0.001) return Geometry.Empty;
        double ang = 2 * Math.PI * frac;
        var fig = new PathFigure { StartPoint = new Point(c, c), IsClosed = true };
        fig.Segments.Add(new LineSegment(new Point(c, c - r), true));
        fig.Segments.Add(new ArcSegment(new Point(c + r * Math.Sin(ang), c - r * Math.Cos(ang)), new Size(r, r), 0, ang > Math.PI, SweepDirection.Clockwise, true));
        return new PathGeometry(new[] { fig });
    }
}

/// <summary>Stappenplannen: lijst, aanpassen en uitvoeren (één stap per scherm).</summary>
sealed class RoutinesView : ViewBase
{
    public RoutinesView()
    {
        var st = Session.Store!;
        if (!Session.Settings.RoutinesSeeded)
        {
            foreach (var d in Defaults()) st.Save("routine", d.Id, d);
            Session.Settings.RoutinesSeeded = true; Session.SaveSettings();
        }
        var list = new StackPanel();
        foreach (var rt in st.All<Routine>("routine").OrderBy(x => x.Title))
        {
            var routine = rt;
            var row = new WrapPanel();
            row.Children.Add(Ui.Btn($"{routine.Icon} {routine.Title}", () => MainWindow.Current.Navigate(new RoutineRunView(routine))));
            row.Children.Add(Ui.Btn("✏️ Aanpassen", () => MainWindow.Current.Navigate(new RoutineEditView(routine)), soft: true));
            row.Children.Add(Ui.Btn("🗑", () =>
            {
                if (!Ui.Confirm("Dit stappenplan weggooien?")) return;
                st.Delete("routine", routine.Id); MainWindow.Current.Navigate(new RoutinesView());
            }, soft: true));
            list.Children.Add(row);
        }
        Shell("Stappenplannen", Ui.Page(
            Ui.Label("Stappenplannen", title: true),
            Ui.Label("Een stappenplan helpt je om iets te doen, stap voor stap. Je kunt ze zelf aanpassen."),
            list,
            Ui.Btn("➕ Nieuw stappenplan", () => MainWindow.Current.Navigate(new RoutineEditView(null)), soft: true)));
    }

    static IEnumerable<Routine> Defaults()
    {
        yield return new Routine(Guid.NewGuid(), "Ochtend", "☀️", new[] { "Opstaan", "Naar de wc", "Gezicht wassen", "Tanden poetsen", "Aankleden", "Ontbijten" });
        yield return new Routine(Guid.NewGuid(), "Tanden poetsen", "🦷", new[] { "Tandpasta op de tandenborstel", "Boven poetsen", "Onder poetsen", "Tong poetsen", "Mond spoelen" });
        yield return new Routine(Guid.NewGuid(), "Avond", "🌙", new[] { "Tas voor morgen klaarzetten", "Tanden poetsen", "Pyjama aan", "Licht uit" });
    }
}

sealed class RoutineEditView : ViewBase
{
    public RoutineEditView(Routine? existing)
    {
        var title = new TextBox { Text = existing?.Title ?? "" };
        var icon = new TextBox { Text = existing?.Icon ?? "📝", MaxLength = 4 };
        var steps = new TextBox { Text = existing is null ? "" : string.Join("\n", existing.Steps), AcceptsReturn = true, TextWrapping = TextWrapping.Wrap, MinHeight = 220, VerticalContentAlignment = VerticalAlignment.Top };
        var status = Ui.Label("");
        var save = Ui.Btn("💾 Bewaren", () =>
        {
            var lines = steps.Text.Split('\n').Select(l => l.Trim()).Where(l => l.Length > 0).ToArray();
            if (title.Text.Trim().Length == 0 || lines.Length == 0) { status.Text = "Vul een naam in en minstens één stap."; return; }
            var r = new Routine(existing?.Id ?? Guid.NewGuid(), title.Text.Trim(), icon.Text.Trim().Length == 0 ? "📝" : icon.Text.Trim(), lines);
            Session.Store!.Save("routine", r.Id, r);
            MainWindow.Current.Navigate(new RoutinesView());
        });
        Shell("Stappenplan maken", Ui.Page(
            Ui.Label(existing is null ? "Nieuw stappenplan" : "Stappenplan aanpassen", title: true),
            Ui.Field("Naam", title), Ui.Field("Plaatje (een emoji)", icon),
            Ui.Field("Stappen (elke stap op een nieuwe regel)", steps), status, save),
            () => MainWindow.Current.Navigate(new RoutinesView()));
    }
}

sealed class RoutineRunView : ViewBase
{
    readonly Routine _r; int _i;
    public RoutineRunView(Routine r) { _r = r; Build(); }

    void Build()
    {
        int n = _r.Steps.Length;
        var kids = new List<UIElement> { Ui.Label($"{_r.Icon} {_r.Title}", title: true) };
        var bar = new Grid { Height = 16, Margin = new Thickness(6, 8, 6, 14) };
        bar.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(_i, GridUnitType.Star) });
        bar.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(Math.Max(0, n - _i), GridUnitType.Star) });
        var filled = new Border { CornerRadius = new CornerRadius(8) }; filled.SetResourceReference(Border.BackgroundProperty, "Accent");
        var rest = new Border { CornerRadius = new CornerRadius(8), Opacity = 0.35 }; rest.SetResourceReference(Border.BackgroundProperty, "Accent");
        Grid.SetColumn(rest, 1); bar.Children.Add(filled); bar.Children.Add(rest);
        kids.Add(bar);
        if (_i >= n)
        {
            kids.Add(Ui.Label("🎉 Klaar! Goed gedaan.", title: true));
            kids.Add(Ui.Btn("↺ Nog een keer", () => { _i = 0; Build(); }, soft: true));
            kids.Add(Ui.Btn("Terug naar de stappenplannen", () => MainWindow.Current.Navigate(new RoutinesView())));
        }
        else
        {
            kids.Add(Ui.Label($"Stap {_i + 1} van {n}", muted: true));
            var step = Ui.Label(_r.Steps[_i], title: true); step.Margin = new Thickness(6, 20, 6, 20);
            kids.Add(step);
            kids.Add(Ui.Btn("✅ Klaar, volgende", () => { _i++; Build(); }));
            var row = new WrapPanel();
            if (_i > 0) row.Children.Add(Ui.Btn("← Vorige", () => { _i--; Build(); }, soft: true));
            if (Session.Settings.ReadAloud) row.Children.Add(Ui.Btn("🔊 Voorlezen", () => Speaker.Toggle(_r.Steps[_i]), soft: true));
            kids.Add(row);
        }
        Shell("Stappenplan", Ui.Page(kids.ToArray()), () => { Speaker.Stop(); MainWindow.Current.Navigate(new RoutinesView()); });
    }
}
