using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using MijnGevoel.Core.Data;

namespace MijnGevoel.Desktop;

/// <summary>Toestemming in eenvoudige taal, bij het eerste gebruik (en opnieuw als de tekst verandert).</summary>
sealed class ConsentView : UserControl
{
    public static bool Needed() => !Session.Store!.All<ConsentRecord>("consent").Any(c => c.Version >= ConsentInfo.CurrentVersion);

    const string Text =
        "Mijn Gevoel is voor jou. Wat je hier maakt, staat alleen op deze computer. Het is versleuteld.\n\n" +
        "Wat bewaren we? Je tekeningen, je dagboek, je briefjes, je agenda, je stoplicht en je plan.\n\n" +
        "Wie kan het zien? Alleen jij. Je begeleider ziet alleen wat jij zelf deelt.\n\n" +
        "Mijn Gevoel waarschuwt niemand. Heb je hulp nodig? Vertel het dan zelf aan iemand, of deel het met je begeleider.\n\n" +
        "Je mag alles altijd weghalen of meenemen. Je mag altijd stoppen. Dat staat bij 'Mijn privacy'.\n\n" +
        "De organisatie die Mijn Gevoel aan jou geeft, is verantwoordelijk voor je gegevens. Vraag je begeleider wie dat is en waar je de privacyverklaring vindt.";

    public ConsentView()
    {
        var agree = new CheckBox { Content = "Ik heb dit gelezen of laten voorlezen." };
        var self = Ui.Btn("✅ Ik ga akkoord"); var together = Ui.Btn("👥 Ik ga akkoord, samen met mijn vertegenwoordiger of begeleider", null, soft: true);
        self.IsEnabled = together.IsEnabled = false;
        agree.Checked += (_, _) => self.IsEnabled = together.IsEnabled = true;
        agree.Unchecked += (_, _) => self.IsEnabled = together.IsEnabled = false;
        void Save(string mode)
        {
            var c = new ConsentRecord(Guid.NewGuid(), DateTime.Now, ConsentInfo.CurrentVersion, mode);
            Session.Store!.Save("consent", c.Id, c);
            Speaker.Stop();
            MainWindow.Current.Navigate(new HomeView());
        }
        self.Click += (_, _) => Save("zelf");
        together.Click += (_, _) => Save("samen");
        Content = Ui.Page(
            Ui.Label("Voordat je begint", title: true),
            Ui.Label(Text),
            Ui.Btn("🔊 Lees voor", () => Speaker.Toggle(Text), soft: true),
            agree, self, together,
            Ui.Btn("Nee, nu niet", () => MainWindow.Current.Lock(), soft: true));
    }
}

/// <summary>Mijn privacy: wat is er bewaard, en de rechten van de cliënt (inzage, meenemen, wissen, klacht).</summary>
sealed class PrivacyView : ViewBase
{
    public PrivacyView()
    {
        var st = Session.Store!;
        var consent = st.All<ConsentRecord>("consent").OrderByDescending(c => c.Created).FirstOrDefault();
        var count = new[]
        {
            $"Dagboek: {st.All<JournalEntry>("diary").Count} stukjes",
            $"Van me afschrijven: {st.All<JournalEntry>("note").Count} briefjes",
            $"Stoplicht: {st.All<StoplichtEntry>("light").Count} meldingen",
            $"Tekeningen: {st.All<DrawingEntry>("drawing").Count}",
            $"Agenda: {st.All<AgendaItem>("agenda").Count} afspraken",
            $"Gedeeld met een begeleider: {st.All<ShareLogEntry>("sharelog").Count} keer",
        };
        var consentText = consent is null ? "Er is nog geen toestemming vastgelegd."
            : $"Je hebt toestemming gegeven op {consent.Created:dd-MM-yyyy} ({(consent.Mode == "samen" ? "samen met een vertegenwoordiger of begeleider" : "zelf")}).";

        var export = Ui.Btn("📥 Mijn gegevens downloaden (leesbaar bestand)", () =>
        {
            if (!Ui.Confirm("Dit bestand is leesbaar voor iedereen die het opent. Het is niet versleuteld. Bewaar het veilig en haal het weg als je het niet meer nodig hebt. Wil je doorgaan?")) return;
            var dlg = new SaveFileDialog { Filter = "Gegevens (*.json)|*.json", FileName = $"Mijn-gegevens-{DateTime.Now:yyyy-MM-dd}.json" };
            if (dlg.ShowDialog() != true) return;
            ExportService.ExportAll(st, Session.Username, dlg.FileName);
            Ui.Info("Je gegevens zijn opgeslagen.");
        }, soft: true);
        var backup = Ui.Btn("💾 Versleutelde back-up maken", () =>
        {
            var dlg = new SaveFileDialog { Filter = "Back-up (*.zip)|*.zip", FileName = $"MijnGevoel-backup-{DateTime.Now:yyyy-MM-dd}.zip" };
            if (dlg.ShowDialog() != true) return;
            BackupService.Create(Session.Accounts, Session.Username, dlg.FileName);
            Ui.Info("Je back-up is gemaakt.");
        }, soft: true);

        Shell("Mijn privacy", Ui.Page(
            Ui.Label("Wat bewaart Mijn Gevoel van jou?", title: true),
            Ui.Label(string.Join("\n", count)),
            Ui.Label($"Alles staat versleuteld in deze map: {DataLocation.CurrentBase}. Niemand anders kan het lezen, tenzij jij het deelt."),
            Ui.Label(consentText, muted: true),
            Ui.Label("Dit mag je doen", title: true),
            Ui.Label("Je mag zien wat er van je bewaard is, het meenemen, het aanpassen of het weghalen. Je mag ook stoppen. Dat kost niets."),
            export, backup,
            Ui.Btn("🗑 Alles weghalen en stoppen (bij Instellingen)", () => MainWindow.Current.Navigate(new SettingsView()), danger: true),
            Ui.Label("Vragen of klachten", title: true),
            Ui.Label("Vraag je begeleider wie verantwoordelijk is voor je gegevens en wie de functionaris gegevensbescherming (FG) is. Ben je niet tevreden? Je mag ook een klacht indienen bij de Autoriteit Persoonsgegevens (autoriteitpersoonsgegevens.nl)."),
            Ui.Btn("📜 Toestemming opnieuw lezen", () => MainWindow.Current.Navigate(new ConsentView()), soft: true)));
    }
}
