using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using MijnGevoel.Core.Data;
using MijnGevoel.Core.Security;

namespace MijnGevoel.Desktop;

sealed class LoginView : UserControl
{
    public LoginView(string? message = null) => ShowLogin(message);

    void ShowLogin(string? msg = null)
    {
        var user = new TextBox();
        var pw = new PasswordField("Wachtwoord");
        var code = new TextBox { MaxLength = 8 };
        var status = Ui.Label(msg ?? (DataLocation.Missing ? "De map met je gegevens is niet beschikbaar. Is je USB-stick of OneDrive verbonden? Kies anders onderaan een andere map." : ""));
        var go = Ui.Btn("Inloggen"); go.IsDefault = true;
        go.Click += async (_, _) =>
        {
            go.IsEnabled = false; status.Text = "Even wachten…";
            string u = user.Text, p = pw.Value, c = code.Text;
            var res = await Task.Run(() => Session.Accounts.Login(u, p, c));
            go.IsEnabled = true;
            if (res.Success)
            {
                Session.Start(u.Trim(), res.VaultKey!);
                if (ConsentView.Needed()) MainWindow.Current.Navigate(new ConsentView()); else MainWindow.Current.Navigate(new HomeView());
            }
            else status.Text = res.Message;
        };
        Content = Ui.Page(
            Ui.Label("Welkom bij Mijn Gevoel", title: true),
            Ui.Label("Log in met je gebruikersnaam, je wachtwoord en de 6 cijfers uit je authenticator-app."),
            Ui.Field("Gebruikersnaam", user), pw, Ui.Field("Code uit je app (6 cijfers)", code),
            status, go,
            Ui.Label("Staat je code er al even? Wacht dan tot er een nieuwe code in je app staat.", muted: true),
            Ui.Btn("Ik heb nog geen account", ShowRegister, soft: true),
            Ui.Btn("Ik kom er niet meer in", ShowRecover, soft: true),
            Ui.Btn("Back-up terugzetten", Restore, soft: true),
            Ui.Btn("Ik ben begeleider: deelbestand openen", ShowShare, soft: true),
            Ui.Btn("📁 Waar staan mijn gegevens?", ShowLocation, soft: true));
    }

    void ShowRegister()
    {
        var user = new TextBox();
        var p1 = new PasswordField("Kies een wachtwoord (minstens 10 tekens)");
        var p2 = new PasswordField("Typ je wachtwoord nog een keer");
        var status = Ui.Label("");
        var go = Ui.Btn("Account maken");
        go.Click += async (_, _) =>
        {
            if (p1.Value != p2.Value) { status.Text = "De twee wachtwoorden zijn niet hetzelfde."; return; }
            go.IsEnabled = false; status.Text = "Even wachten…";
            string u = user.Text.Trim(), p = p1.Value;
            try { var reg = await Task.Run(() => Session.Accounts.Register(u, p)); ShowQrStep(u, p, reg); }
            catch (Exception ex) when (ex is ArgumentException || ex is InvalidOperationException)
            { status.Text = ex.Message; go.IsEnabled = true; }
        };
        Content = Ui.Page(
            Ui.Label("Account maken", title: true),
            Ui.Label("Tip: kies een zin van een paar woorden, bijvoorbeeld: ik fiets graag door het bos. Dat is veilig en makkelijk te onthouden."),
            Ui.Field("Kies een gebruikersnaam", user), p1, p2, status, go,
            Ui.Btn("← Terug naar inloggen", () => ShowLogin(), soft: true));
    }

    void ShowQrStep(string u, string p, Registration reg)
    {
        var bmp = new BitmapImage();
        bmp.BeginInit(); bmp.CacheOption = BitmapCacheOption.OnLoad; bmp.StreamSource = new MemoryStream(reg.QrPng); bmp.EndInit(); bmp.Freeze();
        var img = new Image { Source = bmp, Width = 260, Height = 260, HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(6) };
        RenderOptions.SetBitmapScalingMode(img, BitmapScalingMode.NearestNeighbor);

        var codes = new TextBox { Text = string.Join("\n", reg.RecoveryCodes), IsReadOnly = true, AcceptsReturn = true, Height = 220 };
        var saved = new CheckBox { Content = "Ik heb de herstelcodes opgeschreven en bewaard." };
        var code = new TextBox { MaxLength = 8 };
        var status = Ui.Label("");
        var done = Ui.Btn("Klaar"); done.IsEnabled = false;
        saved.Checked += (_, _) => done.IsEnabled = true;
        saved.Unchecked += (_, _) => done.IsEnabled = false;
        done.Click += async (_, _) =>
        {
            done.IsEnabled = false; var c = code.Text;
            var ok = await Task.Run(() => Session.Accounts.ConfirmRegistration(u, p, c));
            if (ok) ShowLogin("Je account is klaar. Je kunt nu inloggen.");
            else { status.Text = "Die code klopt niet. Kijk in je app en probeer het nog een keer."; done.IsEnabled = true; }
        };
        Content = Ui.Page(
            Ui.Label("Stap 1: koppel je authenticator-app", title: true),
            Ui.Label("Open een authenticator-app op je telefoon (bijvoorbeeld Microsoft Authenticator of Google Authenticator) en scan deze QR-code."),
            img,
            Ui.Label($"Lukt scannen niet? Typ dan deze sleutel over in je app: {reg.SecretForManualEntry}", muted: true),
            Ui.Label("Stap 2: bewaar je herstelcodes", title: true),
            Ui.Label("Schrijf deze codes op papier en bewaar ze op een veilige plek. Heb je je telefoon of wachtwoord kwijt? Dan kom je met deze codes weer binnen. Elke code werkt één keer."),
            codes, Ui.Btn("🖨 Herstelcodes printen", () => RecoverySheet.Print(u, reg.RecoveryCodes), soft: true), saved,
            Ui.Label("Stap 3: typ de code uit je app", title: true),
            Ui.Field("De 6 cijfers die nu in je app staan", code), status, done);
    }

    void ShowRecover()
    {
        var user = new TextBox(); var rc = new TextBox(); var np = new PasswordField("Nieuw wachtwoord (minstens 10 tekens)");
        var status = Ui.Label("");
        var go = Ui.Btn("Opnieuw instellen");
        go.Click += async (_, _) =>
        {
            go.IsEnabled = false; status.Text = "Even wachten…";
            string u = user.Text.Trim(), c = rc.Text, p = np.Value;
            var reg = await Task.Run(() => Session.Accounts.RecoverAccess(u, c, p));
            if (reg is null) { status.Text = "Dat is niet gelukt. Controleer je gebruikersnaam en herstelcode. Het nieuwe wachtwoord moet minstens 10 tekens zijn."; go.IsEnabled = true; }
            else ShowQrStep(u, p, reg);
        };
        Content = Ui.Page(
            Ui.Label("Ik kom er niet meer in", title: true),
            Ui.Label("Typ je gebruikersnaam en één van je herstelcodes. Daarna kies je een nieuw wachtwoord en koppel je je authenticator-app opnieuw."),
            Ui.Field("Gebruikersnaam", user), Ui.Field("Herstelcode (bijvoorbeeld ABCD-EFGH-JKMN)", rc), np, status, go,
            Ui.Btn("← Terug naar inloggen", () => ShowLogin(), soft: true));
    }

    void ShowLocation()
    {
        var info = Ui.Label($"Nu: {DataLocation.CurrentBase}" + (DataLocation.Missing ? "\nLet op: deze map is nu niet beschikbaar (USB-stick of OneDrive niet verbonden?)." : ""));
        var status = Ui.Label("");
        var choose = Ui.Btn("📂 Kies een andere map…", () =>
        {
            var dlg = new OpenFolderDialog { Title = "Kies de map waar Mijn Gevoel je gegevens bewaart" };
            if (dlg.ShowDialog() != true) return;
            var target = dlg.FolderName; var oldBase = DataLocation.CurrentBase;
            if (string.Equals(Path.GetFullPath(target).TrimEnd('\\'), Path.GetFullPath(oldBase).TrimEnd('\\'), StringComparison.OrdinalIgnoreCase)) return;
            bool copy = Directory.Exists(Path.Combine(oldBase, "accounts")) &&
                        Ui.Confirm("Wil je je bestaande accounts en gegevens meenemen naar de nieuwe map? Ze worden gekopieerd. De oude bestanden blijven staan tot jij ze zelf verwijdert.");
            try
            {
                if (copy) DataLocation.CopyAll(oldBase, target);
                DataLocation.Set(target);
                Session.Accounts = DataLocation.CreateAccounts();
                ShowLocation();
            }
            catch (Exception) { status.Text = "Dat is niet gelukt. Kies een map waar je in mag schrijven."; }
        });
        var reset = Ui.Btn("↩ Terug naar de standaardmap", () =>
        {
            DataLocation.Reset(); Session.Accounts = DataLocation.CreateAccounts(); ShowLocation();
        }, soft: true);
        var open = Ui.Btn("🗂 Open de map", () => { try { Directory.CreateDirectory(DataLocation.CurrentBase); System.Diagnostics.Process.Start("explorer.exe", "\"" + DataLocation.CurrentBase + "\""); } catch (Exception) { } }, soft: true);
        Content = Ui.Page(
            Ui.Label("Waar staan mijn gegevens?", title: true), info,
            Ui.Label("Je kunt een andere map kiezen, bijvoorbeeld in OneDrive of op een USB-stick. Dan heb je je gegevens ook op een andere computer. Alles in die map is versleuteld, ook in de cloud."),
            Ui.Label("Let op: gebruik hetzelfde account maar op één computer tegelijk, en zorg dat de map klaar is voor je inlogt.", muted: true),
            choose, reset, open, status,
            Ui.Btn("← Terug naar inloggen", () => ShowLogin(), soft: true));
    }

    void ShowShare() => Content = new ShareOpenView(() => ShowLogin());

    void Restore()
    {
        var dlg = new OpenFileDialog { Filter = "Back-up (*.zip)|*.zip", Title = "Kies je back-up" };
        if (dlg.ShowDialog() != true) return;
        try
        {
            int n = BackupService.Restore(Session.Accounts, dlg.FileName);
            Ui.Info(n > 0 ? "Je back-up is teruggezet. Je kunt nu inloggen." : "Er is niets teruggezet. Misschien bestaat dit account al op deze computer.");
        }
        catch (Exception) { Ui.Info("Dit bestand is geen geldige back-up."); }
    }
}
