using System.Globalization;
using System.Speech.Synthesis;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Effects;
using MijnGevoel.Core.Data;
using MijnGevoel.Core.Security;

namespace MijnGevoel.Desktop;

static class Session
{
    public static AccountService Accounts = DataLocation.CreateAccounts();
    public static VaultStore? Store;
    public static string Username = "";
    public static UserSettings Settings = new();

    public static void Start(string user, byte[] key)
    {
        End();
        Username = user;
        Store = new VaultStore(key, Accounts.DataFolder(user));
        Settings = Store.Load<UserSettings>("settings", Guid.Empty) ?? new UserSettings();
        Theme.Apply(Settings);
    }
    public static void SaveSettings() => Store?.Save("settings", Guid.Empty, Settings);
    public static void End()
    {
        Speaker.Stop();
        Store?.Dispose(); Store = null;
        Username = ""; Settings = new UserSettings();
        Theme.Apply(Settings);
    }
}

static class Theme
{
    sealed record Pal(string Bg1, string Bg2, string Surface, string Card, string CardBorder, string Text, string Acc1, string Acc2, string OnAccent, string Danger, string Focus);

    public static void Apply(UserSettings s)
    {
        var app = Application.Current; if (app is null) return;
        var r = app.Resources;
        var p = s.Theme switch
        {
            "Donker" => new Pal("#10161C", "#1A1530", "#26303A", "#D9222B36", "#3A4756", "#E8EEF2", "#6BB2C2", "#4E97A8", "#0F1519", "#E27D8E", "#FFD166"),
            "Hoog contrast" => new Pal("#000000", "#000000", "#000000", "#FF000000", "#FFFFFF", "#FFFFFF", "#FFFF00", "#FFFF00", "#000000", "#FF6B6B", "#00FFFF"),
            _ => new Pal("#E6F3F3", "#F3EEFA", "#FFFFFF", "#F5FFFFFF", "#D5E3E6", "#1F2A37", "#3C7A89", "#2F6B7A", "#FFFFFF", "#B3475B", "#E0A100"),
        };
        Color C(string h) => (Color)ColorConverter.ConvertFromString(h);
        SolidColorBrush B(string h) => new SolidColorBrush(C(h));
        r["Bg"] = B(p.Bg1); r["Surface"] = B(p.Surface); r["Card"] = B(p.Card); r["CardBorder"] = B(p.CardBorder);
        r["Text"] = B(p.Text); r["Accent"] = B(p.Acc1); r["OnAccent"] = B(p.OnAccent); r["Danger"] = B(p.Danger); r["Focus"] = B(p.Focus);
        r["BgGradient"] = new LinearGradientBrush(C(p.Bg1), C(p.Bg2), 45);
        r["AccentGradient"] = new LinearGradientBrush(C(p.Acc1), C(p.Acc2), 90);
        double b = s.TextSize switch { 0 => 18, 2 => 28, _ => 22 };
        string fam = s.FontName switch { "Verdana" => "Verdana", "Arial" => "Arial", "Georgia" => "Georgia", _ => "Segoe UI Variable Text, Segoe UI" };
        r["UiFont"] = new FontFamily(fam);
        r["BaseFont"] = b; r["TitleFont"] = b * 1.5;
    }
}

static class Speaker
{
    static SpeechSynthesizer? _s;
    public static void Toggle(string text)
    {
        _s ??= Create();
        if (_s.State == SynthesizerState.Speaking) { _s.SpeakAsyncCancelAll(); return; }
        if (!string.IsNullOrWhiteSpace(text)) _s.SpeakAsync(text);
    }
    public static void Stop() => _s?.SpeakAsyncCancelAll();
    static SpeechSynthesizer Create()
    {
        var s = new SpeechSynthesizer();
        try { s.SelectVoiceByHints(VoiceGender.NotSet, VoiceAge.NotSet, 0, new CultureInfo("nl-NL")); } catch { }
        return s;
    }
}

static class Moods
{
    public static readonly (string Emoji, string Name, string Hex)[] All =
    {
        ("😄", "Blij", "#8FD694"), ("🙂", "Goed", "#C5E384"), ("😐", "Gaat wel", "#F4E285"),
        ("😟", "Niet fijn", "#F5B971"), ("😢", "Verdrietig", "#E88B8B"),
    };
    public static Brush BrushFor(int mood) => new SolidColorBrush((Color)ColorConverter.ConvertFromString(All[mood - 1].Hex));
}

static class Ui
{
    public static readonly CultureInfo Nl = CultureInfo.GetCultureInfo("nl-NL");

    public static TextBlock Label(string text, bool title = false, bool muted = false)
    {
        var t = new TextBlock { Text = text, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(6) };
        t.SetResourceReference(TextBlock.FontSizeProperty, title ? "TitleFont" : "BaseFont");
        if (title) t.FontWeight = FontWeights.SemiBold;
        if (muted) t.Opacity = 0.75;
        if (Session.Settings.WideLines)
        {
            t.LineStackingStrategy = LineStackingStrategy.BlockLineHeight;
            t.LineHeight = (double)Application.Current.Resources[title ? "TitleFont" : "BaseFont"] * 1.6;
        }
        return t;
    }

    public static Button Btn(string text, Action? click = null, bool soft = false, bool danger = false)
    {
        var b = new Button { Content = new TextBlock { Text = text, TextWrapping = TextWrapping.Wrap, TextAlignment = TextAlignment.Center } };
        if (soft) b.SetResourceReference(FrameworkElement.StyleProperty, "Soft");
        if (danger) b.SetResourceReference(Control.BackgroundProperty, "Danger");
        AutomationProperties.SetName(b, text);
        if (click is not null) b.Click += (_, _) => click();
        return b;
    }

    public static Button MoodButton((string Emoji, string Name, string Hex) m, Action click)
    {
        var sp = new StackPanel();
        var e = new TextBlock { Text = m.Emoji, HorizontalAlignment = HorizontalAlignment.Center };
        e.SetResourceReference(TextBlock.FontSizeProperty, "TitleFont");
        sp.Children.Add(e);
        sp.Children.Add(new TextBlock { Text = m.Name, HorizontalAlignment = HorizontalAlignment.Center, TextAlignment = TextAlignment.Center, TextWrapping = TextWrapping.Wrap });
        var b = new Button { Content = sp, Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString(m.Hex)), Foreground = Brushes.Black, Padding = new Thickness(4, 8, 4, 8) };
        AutomationProperties.SetName(b, m.Name);
        b.Click += (_, _) => click();
        return b;
    }

    public static StackPanel Field(string label, UIElement input)
    {
        AutomationProperties.SetName(input, label);
        var p = new StackPanel { Margin = new Thickness(0, 6, 0, 6) };
        p.Children.Add(Label(label)); p.Children.Add(input);
        return p;
    }

    public static Border Card(UIElement child, double pad = 16)
    {
        var b = new Border
        {
            Child = child, Padding = new Thickness(pad), Margin = new Thickness(10), CornerRadius = new CornerRadius(24), BorderThickness = new Thickness(1),
            Effect = new DropShadowEffect { BlurRadius = 24, ShadowDepth = 4, Direction = 270, Opacity = 0.15 },
        };
        b.SetResourceReference(Border.BackgroundProperty, "Card");
        b.SetResourceReference(Border.BorderBrushProperty, "CardBorder");
        return b;
    }

    public static ScrollViewer Page(params UIElement[] kids)
    {
        var sp = new StackPanel();
        foreach (var k in kids) sp.Children.Add(k);
        var card = Card(sp, 28);
        card.MaxWidth = 940; card.Margin = new Thickness(24); card.HorizontalAlignment = HorizontalAlignment.Center; card.CornerRadius = new CornerRadius(28);
        return new ScrollViewer { Content = card, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
    }

    public static bool Confirm(string msg) =>
        MessageBox.Show(msg, "Mijn Gevoel", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes;
    public static void Info(string msg) =>
        MessageBox.Show(msg, "Mijn Gevoel", MessageBoxButton.OK, MessageBoxImage.Information);
}

/// <summary>Wachtwoordveld met "Laat zien"-optie (handig als typen lastig is).</summary>
sealed class PasswordField : StackPanel
{
    readonly PasswordBox _pw = new();
    readonly TextBox _txt = new() { Visibility = Visibility.Collapsed };
    readonly CheckBox _show = new() { Content = "Laat zien" };

    public PasswordField(string label)
    {
        Margin = new Thickness(0, 6, 0, 6);
        AutomationProperties.SetName(_pw, label); AutomationProperties.SetName(_txt, label);
        Children.Add(Ui.Label(label)); Children.Add(_pw); Children.Add(_txt); Children.Add(_show);
        _show.Checked += (_, _) => { _txt.Text = _pw.Password; _pw.Visibility = Visibility.Collapsed; _txt.Visibility = Visibility.Visible; };
        _show.Unchecked += (_, _) => { _pw.Password = _txt.Text; _txt.Visibility = Visibility.Collapsed; _pw.Visibility = Visibility.Visible; };
    }
    public string Value => _show.IsChecked == true ? _txt.Text : _pw.Password;
    public void Clear() { _pw.Clear(); _txt.Clear(); _show.IsChecked = false; }
}

abstract class ViewBase : UserControl
{
    protected void Shell(string title, UIElement body, Action? onBack = null)
    {
        var back = Ui.Btn("← Terug", () => { if (onBack is not null) onBack(); else GoHome(); }, soft: true);
        var bar = new DockPanel { Margin = new Thickness(14, 10, 14, 4) };
        DockPanel.SetDock(back, Dock.Left);
        bar.Children.Add(back);
        bar.Children.Add(Ui.Label(title, title: true));
        var root = new DockPanel();
        DockPanel.SetDock(bar, Dock.Top);
        root.Children.Add(bar); root.Children.Add(body);
        Content = root;
    }
    protected static void GoHome() => MainWindow.Current.Navigate(new HomeView());
}
