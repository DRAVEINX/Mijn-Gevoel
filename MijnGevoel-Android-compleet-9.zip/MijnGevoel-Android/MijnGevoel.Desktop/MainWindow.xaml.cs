using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using MijnGevoel.Core.Data;

namespace MijnGevoel.Desktop;

public partial class MainWindow : Window
{
    public static MainWindow Current { get; private set; } = null!;
    DateTime _last = DateTime.UtcNow;
    readonly HashSet<Guid> _announced = new();
    readonly DispatcherTimer _tick = new() { Interval = TimeSpan.FromSeconds(15) };

    public MainWindow()
    {
        InitializeComponent();
        Current = this;
        SourceInitialized += (_, _) => Capture.Apply(this, Session.Settings.BlockCapture);
        Theme.Apply(new UserSettings());
        PreviewMouseMove += (_, _) => Activity();
        PreviewMouseDown += (_, _) => Activity();
        PreviewKeyDown += OnKey;
        PreviewStylusMove += (_, _) => Activity();
        PreviewTouchMove += (_, _) => Activity();
        _tick.Tick += (_, _) => OnTick();
        _tick.Start();
        Closed += (_, _) => Session.End();   // sleutel uit het geheugen wissen
        Navigate(new LoginView());
    }

    void Activity() => _last = DateTime.UtcNow;

    public void Navigate(UserControl view)
    {
        Host.Content = view;
        Motion.FadeIn(view);
        bool inn = Session.Store is not null;
        LockBtn.Visibility = inn ? Visibility.Visible : Visibility.Collapsed;
        HideBtn.Visibility = LockBtn.Visibility;
        Capture.Apply(this, Session.Settings.BlockCapture);
        WhoText.Text = inn ? $"Ingelogd als {Session.Username}" : "";
        Activity();
    }

    void Lock_Click(object sender, RoutedEventArgs e) => Lock();
    void Hide_Click(object sender, RoutedEventArgs e) => ShowCover();

    void ShowCover()
    {
        if (Session.Store is null) return;
        Speaker.Stop();
        Cover.Visibility = Visibility.Visible;
        Cover.Focus(); Keyboard.Focus(Cover);          // toetsen gaan niet meer naar het scherm eronder
    }
    void HideCover() { Cover.Visibility = Visibility.Collapsed; }
    void Cover_Down(object sender, MouseButtonEventArgs e) => HideCover();

    void OnKey(object sender, KeyEventArgs e)
    {
        Activity();
        if (Cover.Visibility == Visibility.Visible) { HideCover(); e.Handled = true; return; }
        if (e.Key == Key.H && Keyboard.Modifiers == ModifierKeys.Control) { ShowCover(); e.Handled = true; }
    }

    public void Lock(string? message = null)
    {
        Session.End();
        Banner.Visibility = Visibility.Collapsed;
        Cover.Visibility = Visibility.Collapsed;
        _announced.Clear();
        Navigate(new LoginView(message));
    }

    void Banner_Click(object sender, RoutedEventArgs e) => Banner.Visibility = Visibility.Collapsed;

    void OnTick()
    {
        if (Session.Store is null) return;
        var s = Session.Settings;
        if (s.AutoLockMinutes > 0 && (DateTime.UtcNow - _last).TotalMinutes >= s.AutoLockMinutes)
        { Lock("Je bent een tijdje weg geweest. Daarom is Mijn Gevoel vergrendeld om je gegevens te beschermen."); return; }

        // Zachte herinnering (geen pop-up): een balk bovenaan, 10 minuten voor een afspraak.
        var now = DateTime.Now;
        foreach (var a in Session.Store.All<AgendaItem>("agenda"))
        {
            if (a.Done || a.Date.Date != now.Date || a.Time.Length == 0) continue;
            if (!TimeOnly.TryParse(a.Time, out var t)) continue;
            var diff = (t.ToTimeSpan() - now.TimeOfDay).TotalMinutes;
            if (diff <= 10 && diff >= -1 && _announced.Add(a.Id))
            {
                BannerText.Text = $"⏰ {a.Icon} {a.Title} - om {a.Time}";
                Banner.Visibility = Visibility.Visible;
            }
        }
    }
}
