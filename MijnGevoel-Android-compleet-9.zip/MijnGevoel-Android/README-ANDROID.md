# Mijn Gevoel — Android

Zie [ANDROID-START-HIER.md](ANDROID-START-HIER.md) voor installatie/bouwen en [ANDROID-ACCEPTATIETEST.md](ANDROID-ACCEPTATIETEST.md) voor de volledige testchecklist.

Android-project: `MijnGevoel.Android/MijnGevoel.Android.csproj`  
Gedeelde beveiligings- en datalaag: `MijnGevoel.Core/MijnGevoel.Core.csproj`  
Oorspronkelijke Windows-app: `MijnGevoel.Desktop/MijnGevoel.Desktop.csproj`
