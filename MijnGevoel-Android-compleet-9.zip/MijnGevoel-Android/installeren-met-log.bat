@echo off
rem Installeert de .msi en schrijft precies op wat er gebeurt in installlog.txt. Stuur installlog.txt naar mij als het niet lukt.
cd /d "%~dp0"
if not exist "MijnGevoel-installatie.msi" (
  echo MijnGevoel-installatie.msi staat niet in deze map. Draai eerst bouwen.bat.
  pause
  exit /b 1
)
echo Installeren... (er komt een vraag om beheerder-rechten, kies Ja)
msiexec /i "%~dp0MijnGevoel-installatie.msi" /l*v "%~dp0installlog.txt"
echo.
echo Afgesloten met code %errorlevel%. 0 = gelukt. Stuur anders het bestand installlog.txt naar mij.
explorer /select,"%~dp0installlog.txt"
pause
