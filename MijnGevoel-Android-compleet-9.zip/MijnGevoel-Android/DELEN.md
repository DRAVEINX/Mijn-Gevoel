# Mijn Gevoel delen met mensen om je heen

Er zijn twee verpakkingen:
- **`MijnGevoel-draagbaar.zip`** (aanrader om te delen): uitpakken, `Installeren.bat` dubbelklikken. Geen beheerder nodig, geen .msi. Verwijderen met `Verwijderen.bat`.
- **`MijnGevoel-installatie.msi`**: gewone Windows-installatie voor beheerders (stille installatie: `msiexec /i MijnGevoel-installatie.msi /qn`).

## Optie A: laten bouwen in de cloud (je hoeft zelf niet meer te bouwen)
Hiermee bouwt GitHub het pakket voor je en krijg je een downloadlink om te delen.
1. Maak een gratis account op https://github.com en kies **New repository**. Naam bijvoorbeeld `mijn-gevoel`. Kies **Private** (alleen jij en mensen die je uitnodigt) of **Public** (iedereen met de link kan downloaden; de broncode is dan ook openbaar).
2. Pak `MijnGevoel.zip` uit. Open in de nieuwe repository **Add file > Upload files** en sleep **alle bestanden en mappen uit de uitgepakte map `MijnGevoel`** erin (ook de map `.github`). Klik **Commit changes**.
3. Open het tabblad **Actions**. Het bouwen start vanzelf (ongeveer 5-10 minuten). Bij een groen vinkje kun je onder de run bij **Artifacts** het pakket downloaden.
4. **Link om te delen:** ga naar **Releases > Create a new release**, vul bij tag `v1.0.8` in, klik **Publish release**. Na een paar minuten staan `MijnGevoel-draagbaar.zip` en `.msi` onder die release. Bij een Public repository kan iedereen die link openen; bij Private alleen mensen die je als collaborator uitnodigt (Settings > Collaborators).
5. Gaat het bouwen fout? Klik op de rode run, kopieer de foutregels (of een schermafbeelding) en stuur ze naar mij.
Zet **nooit echte persoonsgegevens** in de repository. Het pakket bevat alleen programmacode.

## Optie B: zelf het zip-bestand doorgeven
Stuur `MijnGevoel-draagbaar.zip` via een gedeelde map (OneDrive, Google Drive), WeTransfer of een USB-stick. Geef het alleen door aan mensen die je kent.

## Wat je ontvangers moet vertellen
- Alleen Windows 11. Pak het zip uit en dubbelklik op `Installeren.bat`.
- Windows waarschuwt voor een onbekende uitgever omdat het programma niet is ondertekend: **Meer informatie > Toch uitvoeren**. Als Windows 11 "Slimme app-beheer" (Smart App Control) aan heeft, kan het programma geblokkeerd worden. Zet die beveiliging dan **niet** uit; wacht liever op een ondertekende versie.
- Het is een testversie: alleen verzonnen gegevens. Schrijf de herstelcodes op papier.
- Alles blijft op hun eigen computer. Jij kunt hun gegevens niet zien en zij de jouwe niet.

## Ondertekenen (voor echt gebruik)
Zonder digitale handtekening blijft Windows waarschuwen. Voor uitdelen aan veel mensen of aan cliënten heb je een code-signing-certificaat nodig (of een ondertekeningsdienst). Pas daarna verdwijnen de meeste waarschuwingen.

## Cliënten en professioneel gebruik
Delen met vrienden en familie om te testen kan met bovenstaande. Voor cliënten van een organisatie gelden de stappen in `OPLEVERING.md` (beveiligingstoets, privacybeoordeling, test met cliënten, ondertekenen).

## Werkt de .msi niet?
Dubbelklik `installeren-met-log.bat`. Het maakt `installlog.txt` met de exacte reden. Stuur dat bestand naar mij. Intussen werkt de draagbare installatie zonder .msi.

## Nieuw in 1.0.8
- **De .msi is nu een gewone zichtbare installatie:** welkom, gebruiksinformatie, map kiezen, voortgang en "Klaar" met de optie om Mijn Gevoel meteen te starten. Stil installeren kan nog met `/qn`.
- **Gegevens niet meer vast op een pc:** op het inlogscherm staat "Waar staan mijn gegevens?". Kies daar een andere map, bijvoorbeeld in OneDrive of op een USB-stick. Alles daarin is versleuteld. Gebruik een account op één computer tegelijk.
- **Winrar/zip:** `MijnGevoel-draagbaar.zip` kun je ook als .rar inpakken en doorgeven.
