namespace MijnGevoel.AndroidApp;

/// <summary>Toont een neutraal scherm zolang de gebruiker even privacy nodig heeft.</summary>
public sealed class PrivacyCoverPage : ContentPage
{
    protected override void OnAppearing()
    {
        base.OnAppearing();
        AppSession.Touch();
    }

    public PrivacyCoverPage()
    {
        Title = "Privacyscherm";
        BackgroundColor = Color.FromArgb("#E6F3F3");
        var restore = new Button
        {
            Text = "Tik hier om terug te gaan",
            FontSize = 22,
            TextColor = Color.FromArgb("#1F2A37"),
            BackgroundColor = Colors.White,
            CornerRadius = 18,
            Padding = new Thickness(22, 18),
            HorizontalOptions = LayoutOptions.Center,
            VerticalOptions = LayoutOptions.Center
        };
        restore.Clicked += async (_, _) =>
        {
            if (Navigation.NavigationStack.Count > 1) await Navigation.PopAsync();
        };
        Content = new Grid
        {
            Padding = 24,
            Children =
            {
                new VerticalStackLayout
                {
                    Spacing = 18,
                    VerticalOptions = LayoutOptions.Center,
                    Children =
                    {
                        new Label { Text = "Mijn Gevoel", FontSize = 32, FontAttributes = FontAttributes.Bold, TextColor = Color.FromArgb("#3C7A89"), HorizontalTextAlignment = TextAlignment.Center },
                        new Label { Text = "Je scherm is even verborgen.", FontSize = 20, TextColor = Color.FromArgb("#1F2A37"), HorizontalTextAlignment = TextAlignment.Center },
                        restore
                    }
                }
            }
        };
    }
}
