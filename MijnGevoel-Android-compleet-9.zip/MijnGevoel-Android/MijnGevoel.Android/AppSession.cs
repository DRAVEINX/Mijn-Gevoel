using Microsoft.Maui.Storage;
using System.Security.Cryptography;
using MijnGevoel.Core.Data;
using MijnGevoel.Core.Security;

namespace MijnGevoel.AndroidApp;

/// <summary>Beheert alleen de huidige, ontgrendelde sessie. De gegevens zelf worden door VaultStore per bestand versleuteld.</summary>
public static class AppSession
{
    static AccountService? _accounts;
    public static AccountService Accounts => _accounts ??= new AccountService(Path.Combine(FileSystem.AppDataDirectory, "accounts"));
    public static VaultStore? Store { get; private set; }
    public static string Username { get; private set; } = "";
    public static UserSettings Settings { get; private set; } = new();
    public static DateTime LastActivityUtc { get; private set; } = DateTime.UtcNow;
    public static bool IsUnlocked => Store is not null;

    public static void Start(string username, byte[] vaultKey)
    {
        End();
        Username = username;
        // VaultStore owns its key array and wipes it when the session ends.
        Store = new VaultStore((byte[])vaultKey.Clone(), Accounts.DataFolder(username));
        CryptographicOperations.ZeroMemory(vaultKey);
        Settings = Store.Load<UserSettings>("settings", Guid.Empty) ?? new UserSettings();
        LastActivityUtc = DateTime.UtcNow;
        AndroidScreenPrivacy.Apply(Settings.BlockCapture);
    }

    public static void SaveSettings() => Store?.Save("settings", Guid.Empty, Settings);
    public static void Touch() => LastActivityUtc = DateTime.UtcNow;

    public static void End()
    {
        Store?.Dispose();
        Store = null;
        Username = "";
        Settings = new UserSettings();
        LastActivityUtc = DateTime.UtcNow;
    }
}

public static class AndroidScreenPrivacy
{
    public static void Apply(bool enabled)
    {
#if ANDROID
        try
        {
            var activity = Microsoft.Maui.ApplicationModel.Platform.CurrentActivity;
            var window = activity?.Window;
            if (window is null) return;
            if (enabled) window.AddFlags(Android.Views.WindowManagerFlags.Secure);
            else window.ClearFlags(Android.Views.WindowManagerFlags.Secure);
        }
        catch { /* platform privacy setting must not crash the app */ }
#endif
    }
}
