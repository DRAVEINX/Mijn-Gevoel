using Microsoft.Maui.Storage;
using MijnGevoel.Core.Data;

namespace MijnGevoel.AndroidApp;

/// <summary>Begeleiderweergave: opent alleen het bewust gedeelde bestand in het geheugen; het slaat niets op in het account.</summary>
public sealed class ShareOpenPage : ContentPage
{
    byte[]? _fileBytes;
    readonly Entry _code;
    readonly Label _status;
    readonly Label _fileName;

    public ShareOpenPage()
    {
        Title = "Gedeeld bestand openen";
        BackgroundColor = AppUi.Background;
        _code = AppUi.Entry("Deelcode van de cliënt");
        _status = AppUi.Label("Kies het .mgdeel-bestand en voer daarna de code in.");
        _fileName = AppUi.Label("Nog geen bestand gekozen.", muted: true);
        Content = new ScrollView
        {
            Content = AppUi.Stack(
                AppUi.Title("Voor begeleiders"),
                AppUi.Label("Hiervoor is geen account nodig. Het bestand en de deelcode moeten apart van elkaar zijn ontvangen. Het geopende bestand wordt niet in Mijn Gevoel opgeslagen."),
                AppUi.AsyncButton("📂 Kies een deelbestand", PickAsync),
                _fileName,
                _code,
                AppUi.AsyncButton("🔓 Open versleuteld bestand", OpenAsync),
                _status,
                AppUi.Button("← Terug", async () => await Navigation.PopAsync(), quiet: true))
        };
    }

    async Task PickAsync()
    {
        var picked = await FilePicker.Default.PickAsync(new PickOptions { PickerTitle = "Kies het gedeelde .mgdeel-bestand" });
        if (picked is null) return;
        await using var stream = await picked.OpenReadAsync();
        using var memory = new MemoryStream();
        await stream.CopyToAsync(memory);
        _fileBytes = memory.ToArray();
        _fileName.Text = picked.FileName;
        _status.Text = "Bestand klaar. Vul de deelcode in die je apart hebt ontvangen.";
    }

    async Task OpenAsync()
    {
        if (_fileBytes is null) { _status.Text = "Kies eerst het deelbestand."; return; }
        if (string.IsNullOrWhiteSpace(_code.Text)) { _status.Text = "Vul de deelcode in."; return; }
        var package = await Task.Run(() => ShareService.Open(_fileBytes, _code.Text));
        if (package is null) { _status.Text = "Openen lukte niet. Controleer het bestand en de deelcode."; return; }

        Title = "Gedeelde meldingen";
        var root = new VerticalStackLayout { Padding = 16, Spacing = 10, BackgroundColor = AppUi.Background };
        root.Children.Add(AppUi.Title("Gedeeld door " + package.From));
        root.Children.Add(AppUi.Label($"Ontvangen deelbestand · gemaakt op {package.Created:dd-MM-yyyy HH:mm}. De cliënt heeft zelf geselecteerd wat gedeeld werd. Dit scherm bewaart de inhoud niet."));
        foreach (var entry in package.Items.OrderBy(x => x.Colour == "Rood" ? 0 : x.Colour == "Oranje" ? 1 : 2).ThenByDescending(x => x.Created))
        {
            var emoji = entry.Colour == "Rood" ? "🔴" : entry.Colour == "Oranje" ? "🟠" : "🟢";
            var lines = new VerticalStackLayout { Spacing = 4 };
            lines.Children.Add(AppUi.Label($"{emoji} {entry.Colour} — {entry.Created:dd-MM-yyyy HH:mm}", title: true));
            if (entry.Reasons.Length > 0) lines.Children.Add(AppUi.Label("Waarom: " + string.Join(", ", entry.Reasons)));
            if (entry.Needs.Length > 0) lines.Children.Add(AppUi.Label("Nodig: " + string.Join(", ", entry.Needs)));
            if (!string.IsNullOrWhiteSpace(entry.Text)) lines.Children.Add(AppUi.Label(entry.Text));
            root.Children.Add(AppUi.Card(lines));
        }
        root.Children.Add(AppUi.Button("Sluiten", async () => await Navigation.PopAsync()));
        Content = new ScrollView { Content = root };
        _fileBytes = null;
        _code.Text = "";
    }
}
