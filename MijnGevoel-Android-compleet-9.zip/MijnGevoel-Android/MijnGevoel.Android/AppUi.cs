using Microsoft.Maui.ApplicationModel;
using Microsoft.Maui.Controls.Shapes;
using Microsoft.Maui.Media;
namespace MijnGevoel.AndroidApp;

internal static class AppUi
{
    static Page? ActivePage
    {
        get
        {
            var root = Application.Current?.Windows.FirstOrDefault()?.Page;
            return root is NavigationPage navigation
                ? navigation.Navigation.NavigationStack.LastOrDefault() ?? navigation
                : root;
        }
    }
    public static Color Background => AppSession.Settings.Theme switch
    {
        "Donker" => Color.FromArgb("#10161C"),
        "Hoog contrast" => Colors.Black,
        _ => Color.FromArgb("#E6F3F3")
    };
    public static Color Surface => AppSession.Settings.Theme switch
    {
        "Donker" => Color.FromArgb("#26303A"),
        "Hoog contrast" => Colors.Black,
        _ => Colors.White
    };
    public static Color Foreground => AppSession.Settings.Theme switch
    {
        "Donker" => Color.FromArgb("#E8EEF2"),
        "Hoog contrast" => Colors.White,
        _ => Color.FromArgb("#1F2A37")
    };
    public static Color Accent => AppSession.Settings.Theme == "Hoog contrast" ? Colors.Yellow : Color.FromArgb("#3C7A89");
    public static Color Border => AppSession.Settings.Theme == "Hoog contrast" ? Colors.White : Color.FromArgb("#D5E3E6");
    public static double BaseFont => AppSession.Settings.TextSize switch { 0 => 16, 2 => 25, _ => 20 };
    public static double TitleFont => BaseFont * 1.35;
    public static string FontFamily => AppSession.Settings.FontName switch { "Georgia" => "serif", "Standaard" => "sans-serif", _ => "sans-serif" };

    public static void Speak(string text)
    {
        if (AppSession.Settings.ReadAloud && !string.IsNullOrWhiteSpace(text)) TextToSpeech.Default.SpeakAsync(text);
    }

    public static Label Label(string text, bool title = false, bool muted = false)
    {
        var l = new Label
        {
            Text = text,
            FontSize = title ? TitleFont : BaseFont,
            FontFamily = FontFamily,
            FontAttributes = title ? FontAttributes.Bold : FontAttributes.None,
            TextColor = muted ? Foreground.WithAlpha(0.75f) : Foreground,
            LineBreakMode = LineBreakMode.WordWrap,
            Margin = new Thickness(0, 2, 0, 2),
            LineHeight = AppSession.Settings.WideLines ? 1.5 : 1.1
        };
        return l;
    }

    public static Entry Entry(string placeholder, string? value = null, Keyboard? keyboard = null, bool password = false)
    {
        var e = new Entry
        {
            Placeholder = placeholder,
            Text = value ?? "",
            FontSize = BaseFont,
            FontFamily = FontFamily,
            TextColor = Foreground,
            PlaceholderColor = Foreground.WithAlpha(0.55f),
            BackgroundColor = Surface,
            ClearButtonVisibility = ClearButtonVisibility.WhileEditing,
            IsPassword = password,
            Keyboard = keyboard ?? Keyboard.Default,
            Margin = new Thickness(0, 2, 0, 6)
        };
        e.TextChanged += (_, _) => AppSession.Touch();
        return e;
    }

    public static Editor Editor(string placeholder, string? value = null, int height = 150)
    {
        var e = new Editor
        {
            Placeholder = placeholder,
            Text = value ?? "",
            FontSize = BaseFont,
            FontFamily = FontFamily,
            TextColor = Foreground,
            PlaceholderColor = Foreground.WithAlpha(0.55f),
            BackgroundColor = Surface,
            AutoSize = EditorAutoSizeOption.Disabled,
            HeightRequest = height,
            Margin = new Thickness(0, 2, 0, 6)
        };
        e.TextChanged += (_, _) => AppSession.Touch();
        return e;
    }

    public static Button Button(string text, Action action, bool quiet = false, bool danger = false)
    {
        var b = new Button
        {
            Text = text,
            FontSize = BaseFont,
            FontFamily = FontFamily,
            TextColor = danger ? Colors.White : quiet ? Foreground : (AppSession.Settings.Theme == "Hoog contrast" ? Colors.Black : Colors.White),
            BackgroundColor = danger ? Color.FromArgb("#B3475B") : quiet ? Surface : Accent,
            BorderColor = quiet ? Border : Accent,
            BorderWidth = 1,
            CornerRadius = 14,
            Padding = new Thickness(14, 12),
            HorizontalOptions = LayoutOptions.Fill,
            Margin = new Thickness(0, 2, 0, 4)
        };
        b.Clicked += (_, _) =>
        {
            AppSession.Touch();
            try { action(); }
            catch (Exception ex)
            {
                AppLog.Write(ex);
                MainThread.BeginInvokeOnMainThread(async () =>
                {
                    var page = ActivePage;
                    if (page is not null)
                        await page.DisplayAlertAsync("Er ging iets mis", "Deze actie is niet gelukt. Je gegevens zijn niet bewust gedeeld; probeer het opnieuw.", "OK");
                });
            }
        };
        return b;
    }

    public static Button AsyncButton(string text, Func<Task> action, bool quiet = false, bool danger = false)
    {
        var b = new Button
        {
            Text = text,
            FontSize = BaseFont,
            FontFamily = FontFamily,
            TextColor = danger ? Colors.White : quiet ? Foreground : (AppSession.Settings.Theme == "Hoog contrast" ? Colors.Black : Colors.White),
            BackgroundColor = danger ? Color.FromArgb("#B3475B") : quiet ? Surface : Accent,
            BorderColor = quiet ? Border : Accent,
            BorderWidth = 1,
            CornerRadius = 14,
            Padding = new Thickness(14, 12),
            HorizontalOptions = LayoutOptions.Fill,
            Margin = new Thickness(0, 2, 0, 4)
        };
        b.Clicked += async (_, _) =>
        {
            AppSession.Touch(); b.IsEnabled = false;
            try { await action(); }
            catch (Exception ex)
            {
                AppLog.Write(ex);
                var page = ActivePage;
                if (page is not null)
                    await page.DisplayAlertAsync("Er ging iets mis", "De actie is niet gelukt. Controleer je invoer en probeer het opnieuw.", "OK");
            }
            finally { b.IsEnabled = true; }
        };
        return b;
    }

    public static Picker Picker(string title, IEnumerable<string> options, string? selected = null)
    {
        var p = new Picker { Title = title, FontSize = BaseFont, FontFamily = FontFamily, TextColor = Foreground, BackgroundColor = Surface, Margin = new Thickness(0, 2, 0, 6) };
        foreach (var option in options) p.Items.Add(option);
        if (selected is not null)
        {
            int ix = p.Items.IndexOf(selected);
            if (ix >= 0) p.SelectedIndex = ix;
        }
        p.SelectedIndexChanged += (_, _) => AppSession.Touch();
        return p;
    }

    public static VerticalStackLayout Stack(params View[] views)
    {
        var s = new VerticalStackLayout { Spacing = 10, Padding = new Thickness(16), BackgroundColor = Background };
        foreach (var v in views) s.Children.Add(v);
        return s;
    }

    public static Border Card(View child)
    {
        return new Border
        {
            Content = child,
            Stroke = new SolidColorBrush(Border),
            StrokeThickness = 1,
            BackgroundColor = Surface,
            Padding = 12,
            Margin = new Thickness(0, 4),
            StrokeShape = new RoundRectangle { CornerRadius = 16 }
        };
    }

    public static Label Title(string title) => Label(title, title: true);
}
