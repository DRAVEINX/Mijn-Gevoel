# Handleiding Mijn Gevoel

## Voor de cliënt
**Eerste keer**
1. Klik op "Ik heb nog geen account".
2. Kies een gebruikersnaam en een wachtwoord. Tip: een zin, bijvoorbeeld "ik fiets graag door het bos".
3. Scan de QR-code met een authenticator-app op je telefoon (Microsoft Authenticator of Google Authenticator).
4. Schrijf de herstelcodes op papier. Bewaar ze veilig.
5. Typ de 6 cijfers uit je app. Klaar!

**Elke keer**: typ je gebruikersnaam, je wachtwoord en de 6 cijfers uit je app.

**Wat kan ik doen?**
- Tekenen: kies kleur en dikte. "Ongedaan" maakt het laatste weer weg.
- Van me afschrijven: schrijf op wat je dwarszit. Bewaar het of gooi het weg.
- Dagboek: kies een gezichtje en schrijf erbij wat je wilt.
- Agenda: zet afspraken met een plaatje en een tijd. Je krijgt een balk bovenaan 10 minuten ervoor.
- Hoe voel ik me?: zie hoe je je de laatste 14 dagen voelde.
- Instellingen: grotere letters, andere kleuren, voorlezen.

**Ik kom er niet meer in?** Klik op "Ik kom er niet meer in" en gebruik een herstelcode.
**Weggaan?** Klik op "Vergrendel". Na een tijdje zonder iets doen vergrendelt het programma vanzelf.

## Voor begeleiders
- Alles blijft op de computer van de cliënt, versleuteld. Begeleiders kunnen niet meekijken, tenzij de cliënt het zelf laat zien.
- Help de cliënt bij het instellen en let erop dat de herstelcodes veilig worden bewaard (bijvoorbeeld in een afgesloten kast).
- Maak samen af en toe een back-up (Instellingen > Back-up maken).
- Bij zorgen over de veiligheid van de cliënt: het programma wijst naar 113 Zelfmoordpreventie (0800-0113) en 112. Het programma stelt zelf geen diagnose.

## Nieuw: stoplicht, mijn plan en delen
**Stoplicht** (op het beginscherm): kies een kleur.
- 🟢 Groen: het gaat goed.
- 🟠 Oranje: het gaat niet zo goed. Je kiest waarom (bijvoorbeeld moe, bang, iets met andere mensen) en wat je nodig hebt (bijvoorbeeld praten, rust).
- 🔴 Rood: ik heb hulp nodig. Je kiest waarom en wat je nodig hebt en je ziet direct je plan en de nummers 112 en 113 (0800-0113).
**Belangrijk:** Mijn Gevoel waarschuwt zelf niemand. Vertel het aan iemand of gebruik "Deel dit met mijn begeleider".

**Mijn plan:** vul in met wie je kunt praten (naam en telefoonnummer) en wat jou helpt. Dit zie je bij oranje en rood.

**Delen met je begeleider:** jij kiest welke meldingen je deelt. Je krijgt een versleuteld bestand en een code. Geef bestand en code op twee verschillende manieren door. Je begeleider kiest "Ik ben begeleider: deelbestand openen".

**Herstelcodes:** print ze of schrijf ze op. Bij Instellingen kun je nieuwe maken. Op het beginscherm zie je een waarschuwing als er bijna geen meer zijn.

## Nieuw: leesbaar delen, toestemming en privacy
- **Delen:** je maakt een bestand (.html). Je begeleider opent het in een browser en typt de code. Dat kan ook op een telefoon. Je begeleider hoeft Mijn Gevoel niet te hebben.
- **Via WhatsApp:** open het gesprek, tik op de paperclip, kies Document en kies het bestand. Stuur de code op een andere manier door, bijvoorbeeld door te bellen.
- **Tekst kopiëren:** kan, maar die tekst is niet versleuteld. Kies dit alleen als het echt moet.
- **Toestemming:** de eerste keer lees je kort wat Mijn Gevoel doet en geef je toestemming, alleen of samen met iemand.
- **Mijn privacy:** je ziet wat er bewaard is, kunt je gegevens downloaden, een back-up maken of alles weghalen.
- **Zachte bewegingen** kun je uitzetten bij Instellingen.

## Nieuw in versie 1.0.4
**Beginscherm in groepen:** stoplicht en gezichtjes staan bovenaan. Daaronder kies je een groep: Mijn dag, Rust en gevoel, Praten en delen, Maken en schrijven, Mijn gegevens.
- **Mijn dag:** Vandaag laat zien wat je *eerst* en *dan* doet. Met "Volgende dag" kijk je alvast naar morgen. Verder: agenda, timer en stappenplannen.
- **Timer:** kies hoeveel minuten. Je ziet een kleurvlak kleiner worden. Er is geen geluid.
- **Stappenplannen:** één stap per scherm, met voorbeelden die je kunt aanpassen of zelf maken.
- **Ademhalen:** een cirkel die groter en kleiner wordt. Zonder bewegingen krijg je alleen tekst en tellen.
- **Rustplek:** rustige kleuren, een paar tips en je eigen plan.
- **Prikkelmeter en Mijn lichaam:** laat zien hoe druk het is en waar je iets voelt.
- **Gevoelswoorden:** lees wat gevoelens betekenen.
- **Kaarten om te laten zien:** tik op een kaart ("Ik wil even rust") en laat hem groot zien. Je kunt eigen kaarten maken.
- **Gesprekskaart:** schrijf van tevoren op wat je wilt zeggen en vragen.
- **Weekoverzicht:** een telling van je week, zonder oordeel.
- **Snel verbergen:** druk op Ctrl + H of op "Verberg". Er komt een leeg scherm voor je gegevens.
- **Instellingen:** lettertype, ruime regelafstand en schermopname blokkeren.
- **Praten in plaats van typen:** druk op de Windows-toets + H.
