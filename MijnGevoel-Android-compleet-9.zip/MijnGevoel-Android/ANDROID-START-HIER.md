# Mijn Gevoel voor Android — start hier

Dit pakket bevat de bestaande Windows-broncode én een aparte Android-app. De Android-app gebruikt `MijnGevoel.Core` voor accountbeheer, Argon2id-afleiding, AES-256-GCM-versleuteling, TOTP-authenticatie, herstelcodes, export, back-ups en delen.

## Status

De Android-broncode en de CI-bouwworkflow zijn voorbereid, maar in de huidige werkomgeving kon ik **geen APK compileren of uitvoeren**: de .NET SDK/Android workload ontbreekt en netwerktoegang om die te installeren is niet beschikbaar. Behandel dit daarom als een Android-project in testfase, niet als een reeds gevalideerde productie-app.

## Benodigdheden

- .NET 8 SDK
- MAUI Android-workload (`dotnet workload install maui-android`)
- Java JDK en Android SDK/platform tools (Visual Studio Installer kan die op Windows installeren; op Linux moeten Java en de Android SDK ook aanwezig zijn)
- Een Android-telefoon of emulator voor de tests

## Bouwen

Open een terminal in de projectmap waar dit bestand staat en voer uit:

```bash
./scripts/build-android.sh
```

Of voer handmatig uit:

```bash
dotnet workload install maui-android
dotnet restore MijnGevoel.Android/MijnGevoel.Android.csproj
dotnet publish MijnGevoel.Android/MijnGevoel.Android.csproj -c Debug -f net8.0-android -p:AndroidPackageFormat=apk
```

Het script voert eerst de beveiligingstests uit en kopieert daarna de gebouwde APK naar `artifacts/MijnGevoel-Android-debug.apk`, met een SHA-256-checksum in `artifacts/SHA256SUMS.txt`. Als de build slaagt, installeer die debug-APK alleen op een testtelefoon. Een release voor distributie vereist een eigen release-keystore en test op echte apparaten.

## APK ophalen via GitHub

De workflow `.github/workflows/android-build.yml` voert eerst `MijnGevoel.Tests` uit en bouwt daarna bij wijzigingen of handmatig starten een debug-APK. Als een test of de build faalt, wordt de APK niet als geslaagd artifact gepubliceerd. In GitHub ga je naar **Actions → Build Mijn Gevoel for Android → laatste run → Artifacts → MijnGevoel-Android-debug-apk**. De workflow is opgenomen in de broncode, maar is nog niet uitgevoerd vanuit deze omgeving.

## Beveiliging en Android-opslag

- Accounts en gegevens blijven in de privé-appmap van Android; andere gewone apps kunnen die map niet direct lezen.
- De gegevensbestanden blijven per item AES-GCM-versleuteld. De vaultsleutel is alleen tijdens een ontgrendelde sessie in het geheugen.
- Er is TOTP-inloggen met herstelcodes en mislukte-aanmeldingsvertraging.
- Het scherm wordt automatisch vergrendeld na de ingestelde inactiviteit en ook als de app naar de achtergrond gaat.
- De optie **Schermafbeeldingen blokkeren** gebruikt Android `FLAG_SECURE`. Dat voorkomt normale screenshots/schermopnames in de beveiligde activiteit, maar geen foto van buitenaf of opname op een aangepast/rooted toestel.
- De Android-versie kiest bewust geen vrije opslagmap buiten de privé-appmap. Gebruik **Versleutelde back-up maken** en de Android-deelfunctie om een back-up veilig te bewaren. Android scoped storage werkt anders dan de zelfgekozen mappen op Windows.
- Een JSON-export is leesbaar en niet versleuteld; deel die alleen bewust.

## Functionaliteit

De mobiele interface bevat: stoplicht en overzicht, dagboek en briefjes, agenda en herinnering terwijl de app open is, vandaag/morgen, timer, stappenplannen, ademhalen, rustplek, prikkelmeter, lichaamsmeter, gevoelswoorden, mood-overzicht, communicatiekaarten, gesprekskaart, veiligheidsplan, tekeningen en galerij, delen met begeleider, weekoverzicht, privacybedekking, instellingen, herstelcodes, wachtwoord wijzigen, gegevensexport, back-up terugzetten vanaf het inlogscherm/verwijderen van account, gedeeld .mgdeel-bestand openen voor begeleiders en hulp.

## Eerst testen

Volg `ANDROID-ACCEPTATIETEST.md`. Voer de account- en hersteltests alleen uit met testgegevens. Zet nog geen echte gevoelige gegevens in de app voordat de Android-build succesvol is en de beveiligings- en hersteltests zijn geslaagd.
