# Overzicht van functies (versie 1.0.4)

## Gebouwd (alles lokaal en versleuteld, geen server)
Inloggen met wachtwoord + authenticator, herstelcodes (printen/vernieuwen), toestemming, Mijn privacy (inzage, export, back-up, wissen) | Stoplicht (groen/oranje/rood met reden en behoefte), Mijn plan | Delen als versleuteld leesbaar bestand (.html) of programma-bestand, optionele tekst-kopie | Mijn dag (eerst-dan, morgen bekijken), agenda met herinneringsbalk, visuele timer, stappenplannen | Ademhalen, Rustplek, Prikkelmeter, Mijn lichaam, Gevoelswoorden, Hoe voel ik me?, Weekoverzicht | Kaarten om te laten zien, Gesprekskaart | Tekenen (pen, markeerstift, gum, ongedaan, galerij), Van me afschrijven, Dagboek | Snel verbergen (Ctrl+H), schermopname blokkeren (optioneel), lettertype, ruime regelafstand, 3 thema's, zachte bewegingen aan/uit | Back-up en terugzetten, modern uiterlijk.

## Bewust nog niet gebouwd (en waarom)
| Idee | Reden |
|---|---|
| Spraakmemo's (geluid opnemen) | Vraagt een audiobibliotheek en testen met microfoons; geluidsopnames zijn gevoelige gegevens. Tip: Windows-dicteren (Windows-toets + H) werkt al in alle tekstvelden |
| Spraak naar tekst in de app zelf | Windows heeft dit al ingebouwd (Windows-toets + H); eigen herkenning is minder betrouwbaar |
| Windows Hello (vingerafdruk/gezicht) | Vraagt extra Windows-onderdelen en veel testen op echte apparaten; het huidige wachtwoord + authenticator is al sterk |
| Online dashboard voor begeleiders, berichten, gezamenlijke doelen, synchronisatie, mobiele app | Vraagt een server, toestemming, een nieuwe DPIA en een besluit van de organisatie (zie docs/5) |
| Tekenlagen, stempels, kleurplaten, fotodagboek | Eerst testen of cliënten dit willen; foto's zijn extra gevoelige gegevens |
| Pictogramsets (Sclera/Beta) | Licentie moet eerst worden geregeld; nu zijn het emoji |
| AI-functies (analyse van dagboek, emotieherkenning) | Kan onder de AI-verordening vallen en past niet bij de huidige DPIA |
| Automatische updates | Komt met de MSI-versies; een updatemechanisme is nodig voor de Cyber Resilience Act (zie docs/6) |
