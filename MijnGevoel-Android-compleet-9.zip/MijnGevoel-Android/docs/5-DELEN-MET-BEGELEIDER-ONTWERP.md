# Delen met een begeleider - wat er nu is en wat later kan

## Nu ingebouwd (zonder server)
1. Cliënt kiest welke stoplicht-meldingen worden gedeeld ("Delen met mijn begeleider").
2. De app maakt een **versleuteld deelbestand** (.mgdeel) en toont een **deelcode** (12 tekens).
3. Het bestand en de code gaan via **verschillende kanalen** naar de begeleider (bijv. USB/e-mail + mondeling).
4. De begeleider kiest op het inlogscherm "Ik ben begeleider", opent bestand + code en ziet rood bovenaan. Er wordt niets opgeslagen en er is geen account nodig.
5. De cliënt ziet in het overzicht hoe vaak er is gedeeld.

**Eigenschappen:** de cliënt beslist per melding; geen live inzage; geen automatische waarschuwing; geen server om te beveiligen of aan te vragen. **Beperking:** het werkt niet vanzelf; er moet iemand het bestand doorsturen.

## Later: online delen/live meekijken (aparte fase, alleen met organisatiebesluit)
**Vereisten vooraf:** DPIA aangevuld, verwerkersovereenkomst, hosting in de EU, beheer- en incidentproces, bereikbaarheid van begeleiders (een rode melding die niemand leest is gevaarlijk).

**Voorgesteld ontwerp**
- **Koppeling:** cliënt en begeleider koppelen eenmalig met een koppelcode (persoonlijk uitgewisseld). Cliënt kan de koppeling altijd intrekken.
- **End-to-end versleuteld:** de server bewaart alleen versleutelde meldingen en weet niet wat erin staat. Sleutels per koppeling; de begeleider heeft een eigen account met tweede factor.
- **Instelbaar per cliënt:** niets automatisch / alleen oranje en rood / alleen rood. Gekozen door de cliënt (of met wettelijk vertegenwoordiger).
- **Rode melding:** push/e-mail/sms naar een afgesproken groep begeleiders, met bevestiging van ontvangst ("gelezen") en escalatie als niemand reageert. De app blijft duidelijk zeggen wat wél en niet automatisch gebeurt.
- **Transparantie:** cliënt ziet wie wat wanneer heeft gezien (inzagelog).
- **Minimale data:** geen dagboek of tekeningen, tenzij de cliënt dat per item deelt.
- **Beheer:** toegangsbeheer op rol, audit-log, automatische verwijdering na afgesproken termijn, penetratietest van server en app, back-up en herstelplan.

**Niet doen:** gegevens onversleuteld op de server, één gezamenlijke begeleider-login, meekijken zonder dat de cliënt het weet, en rode meldingen alleen via de app laten lopen als alarmsysteem.

## Update: leesbaar zonder programma, WhatsApp en andere Windows-programma's
- **Standaardformaat is nu een versleuteld HTML-bestand (.html).** Elke begeleider opent het in een browser (Edge, Chrome, Safari; op computer en telefoon) en typt de code. Er is geen Mijn Gevoel nodig.
- **Beveiliging van het bestand:** AES-256-GCM, sleutel uit PBKDF2-SHA256 (600.000 rondes) van de code; ontcijferen gebeurt alleen in de browser; de pagina blokkeert netwerkverkeer; geen cookies of externe bronnen. Getest in een echte browser (Chromium).
- **Via WhatsApp:** het bestand kan als document worden verstuurd. Houd rekening met: (1) de code nooit in hetzelfde gesprek, (2) WhatsApp bewaart het bestand op telefoons en in eventuele back-ups, (3) bestanden openen in een voorbeeldvenster van een app werkt soms niet; dan in de browser openen.
- **Tekst kopiëren** ("voor WhatsApp") is er alleen na een duidelijke waarschuwing en is **niet versleuteld**. De organisatie kan besluiten dit af te raden of te verbieden.
- **Organisatiebesluit nodig:** mogen cliëntgegevens via WhatsApp (diensten van een derde partij, doorgifte buiten de EU mogelijk) of via e-mail? Veel zorgorganisaties staan dit niet toe. Leg het besluit vast in de DPIA en in het register (docs/6 en docs/7).
- **Programma-formaat (.mgdeel)** blijft beschikbaar voor wie dat liever heeft.
