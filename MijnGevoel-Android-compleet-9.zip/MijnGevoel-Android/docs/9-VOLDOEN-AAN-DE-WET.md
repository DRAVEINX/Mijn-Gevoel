# Voldoet Mijn Gevoel aan de wet? Eerlijk antwoord

Niemand kan van software zeggen dat ze "aan alle wetten voldoet". Dat oordeel is voor een jurist of de toezichthouder, voor een concrete situatie. Wat wel kan: de techniek zo bouwen dat naleven mogelijk is, en vastleggen wat de gebruiker nog moet regelen.

## Wat de software technisch regelt
Versleuteling, tweede factor, inzage en export, wissen, toestemming vastleggen, geen telemetrie, geen AI, delen alleen op keuze van de cliënt, gegevens in een zelf gekozen map (zie docs/6).

## Per soort gebruiker
- **Familie en vrienden (privé):** de AVG is dan grotendeels niet van toepassing (huishoudelijke uitzondering). Het is een testversie, gebruik op eigen risico.
- **Organisaties (zorg, onderwijs, bedrijf):** zij zijn verwerkingsverantwoordelijke en regelen DPIA, register, grondslag, FG-advies, datalekprocedure en beveiligingstoets (docs/2, 6, 7 en OPLEVERING.md).
- **Gegevens in OneDrive of een andere cloud:** de organisatie moet beoordelen of dat mag (verwerker, locatie, afspraken). De bestanden zijn versleuteld, maar de cloud-aanbieder blijft betrokken.
- **Verspreiding aan het publiek:** kan onder de Cyber Resilience Act vallen (volledig vanaf 11 december 2027) en vraagt een ondertekende uitgave en een updatebeleid.

## Waarom het nog niet "volmaakt voor iedereen" is
Het programma is niet extern getest, niet getest met cliënten, niet ondertekend en niet juridisch beoordeeld. Dat los je niet op met meer code, maar met de stappen in `OPLEVERING.md`.
