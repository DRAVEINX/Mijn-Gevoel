# DPIA-concept - Mijn Gevoel

> **Dit is een voorbereid concept, geen afgeronde DPIA.** Een DPIA hoort door de verwerkingsverantwoordelijke (de organisatie die het programma inzet) te worden vastgesteld, met advies van de Functionaris Gegevensbescherming (FG) en juridische controle. Waarschijnlijk is een DPIA verplicht: het gaat om bijzondere persoonsgegevens (gezondheid/welzijn) van kwetsbare personen.

## 1. Beschrijving van de verwerking
- **Wat:** lokale app voor tekenen, schrijven, dagboek, agenda, gevoelsgezichtjes en stoplicht (groen/oranje/rood, met reden en behoefte), plus een noodplan met contactpersonen.
- **Waar staan gegevens:** uitsluitend versleuteld op de computer van de cliënt. Geen server, geen analyse, geen advertenties.
- **Delen:** alleen op initiatief van de cliënt, via een versleuteld deelbestand met een aparte code. De app waarschuwt niemand automatisch.
- **Wie is verantwoordelijk:** *(in te vullen: organisatie)*. Maker van de software: *(in te vullen)*.

## 2. Doelen en grondslag (door organisatie in te vullen)
- Doel: cliënt ondersteunen bij het uiten en bijhouden van gevoelens en afspraken; eerder hulp kunnen vragen.
- Grondslag (art. 6) en uitzondering bijzondere gegevens (art. 9): *(bijv. uitdrukkelijke toestemming of zorgverlening; laten beoordelen door FG/jurist)*.
- Toestemming: begrijpelijke uitleg (eenvoudige taal/beeld), wilsbekwaamheid beoordelen, indien nodig wettelijk vertegenwoordiger betrekken, intrekken moet altijd kunnen (verwijderfunctie bestaat).

## 3. Noodzaak en proportionaliteit
- Dataminimalisatie: geen telemetrie, geen cloud, geen contactlijst-import, alleen wat cliënt zelf invult.
- Bewaartermijn: bepaalt de cliënt; verwijderen kan per item of het hele account.
- Delen: per melding gekozen, zichtbaar in "wat heb ik gedeeld".

## 4. Risico's en maatregelen
| Risico | Kans/Impact (in te schatten) | Maatregel in de app | Restrisico/actie organisatie |
|---|---|---|---|
| Onbevoegde toegang door huisgenoot | Midden/hoog | Wachtwoord + TOTP, auto-lock, versleuteling | Cliënt voorlichten; geen gedeeld Windows-account |
| Diefstal/verlies van computer | Midden/hoog | AES-256-GCM, Argon2id | Schijfversleuteling (BitLocker) verplicht stellen |
| Verlies van toegang (telefoon + herstelcodes kwijt) | Midden/midden | Herstelcodes, printen, nieuwe codes maken, waarschuwing bij weinig codes | Herstelbeleid (zie document 4) |
| Verkeerd delen / deelbestand onderschept | Laag-midden/hoog | Versleuteld, aparte code, cliënt kiest items | Afspraken over kanaal en wie mag openen |
| Rode melding wordt niet opgemerkt (**veiligheidsrisico**) | Midden/hoog | App zegt expliciet dat zij niemand waarschuwt; toont noodplan, 112 en 113 | Organisatie moet protocol en bereikbaarheid regelen; app niet als alarmsysteem presenteren |
| Misbruik door begeleider (te veel meekijken) | Laag/hoog | Alleen delen op initiatief cliënt; geen live inzage | Gedragscode begeleiders |
| Beveiligingslek in software | Laag-midden/hoog | Tests; externe toets (document 1) | Hertest, updatebeleid |
| Cliënt begrijpt niet wat er gebeurt | Midden/midden | Eenvoudige taal, pictogrammen, handleiding | Testen met cliënten (document 3) |

## 5. Rechten van betrokkenen
Inzage en export: back-up (versleuteld) en eigen inzage in de app. Verwijderen: "Account verwijderen". Rectificatie: items bewerken/verwijderen. Bezwaar/intrekken: verwijderen en stoppen met gebruik.

## 6. Openstaande punten voor de organisatie
1. Rol bepalen (verwerkingsverantwoordelijke/verwerker) en afspraken vastleggen.
2. Grondslag en toestemmingsprocedure vaststellen met FG/jurist.
3. Beoordelen of de software door het beoogde gebruik onder medische-hulpmiddelenregelgeving kan vallen.
4. Alarmprotocol voor rode meldingen (wie, wanneer, hoe snel).
5. Resultaat beveiligingstoets verwerken en DPIA actualiseren.
6. Vaststellen of voorafgaande raadpleging van de toezichthouder nodig is (als restrisico hoog blijft).
7. Evaluatiemoment plannen (bijv. jaarlijks).

## Aanvulling: wetgeving en nieuwe functies
- Wettelijk kader en status per 5 oktober 2026: zie `docs/6-WETGEVING-AVG-EN-2027.md`. Modellen (register, toestemming, datalek, verzoeken): `docs/7-MODELLEN-AVG.md`.
- Nieuw: toestemmingsscherm, "Mijn privacy" (inzage/export/wissen), leesbaar deelbestand (.html) en optionele tekst-kopie voor chat. Risico's: verzending via WhatsApp/e-mail (derde partij, bewaring op telefoons), kopiëren van tekst naar klembord (niet versleuteld), export als leesbaar bestand. Maatregelen: waarschuwingen, versleuteld formaat als standaard, klembord wordt na 60 seconden leeggemaakt, organisatiebeleid voor kanalen.
- Open punten: grondslag en uitzonderingsgrond bijzondere gegevens, FG-advies, CRA-classificatie, status Data Omnibus.

## Aanvulling versie 1.0.4
Nieuwe functies zijn volledig lokaal: dagplanning, timer, stappenplannen, ademhaling, rustplek, prikkelmeter, lichaam, gevoelswoorden, kaarten, gesprekskaart, weekoverzicht, snel verbergen, schermopname blokkeren. Er is geen nieuwe verzending of server. Nieuwe gegevenssoorten (prikkelmeter, lichaam) zijn welzijnsgegevens en vallen onder dezelfde maatregelen. De app geeft geen adviezen of diagnoses; tips in de Rustplek zijn algemeen. Laat een behandelaar de inhoud van tips en gevoelswoorden nalezen.
