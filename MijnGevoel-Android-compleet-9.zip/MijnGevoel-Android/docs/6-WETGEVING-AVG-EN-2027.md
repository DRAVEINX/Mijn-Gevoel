# Wetgeving: AVG en andere regels, nu (5 oktober 2026) en in 2027

> **Let op:** dit is een praktisch overzicht om mee te werken, **geen juridisch advies** en geen volledige wettekst. De volledige AVG (Verordening (EU) 2016/679) staat op eur-lex.europa.eu; de Uitvoeringswet AVG (UAVG) op wetten.overheid.nl. Wetgeving verandert: laat de functionaris gegevensbescherming (FG) of een jurist dit nalopen vóór gebruik met cliënten en controleer de status opnieuw vóór elke uitrol.
> De statusinformatie hieronder is verzameld op 5 oktober 2026 uit openbare bronnen (zie onderaan).

## 1. Is er een aparte "privacywet van 2027"?
Niet gevonden. Er is **geen nieuwe, aparte privacywet** met ingang van 2027 aangetroffen. De AVG blijft gelden en is **niet gewijzigd**. Wel zijn er andere regels die in 2026-2027 belangrijk zijn voor deze app (hoofdstuk 3). Zie je ergens een andere wet genoemd, laat die dan door de FG controleren.

## 2. De AVG toegepast op Mijn Gevoel (artikel voor artikel)
**Rollen:** de organisatie die Mijn Gevoel aan cliënten geeft is meestal *verwerkingsverantwoordelijke* (art. 4, 24). De maker van de software is geen verwerker zolang hij geen toegang heeft tot de gegevens (de app werkt lokaal, zonder server). Leg die conclusie vast; ze verandert zodra er een server of ondersteuning met toegang tot gegevens komt (dan: art. 28-verwerkersovereenkomst).

| Art. | Wat de AVG vraagt | In de app | Door de organisatie te regelen |
|---|---|---|---|
| 5(1)a | Rechtmatig, behoorlijk, transparant | Toestemmingsscherm in eenvoudige taal; "Mijn privacy" | Privacyverklaring in begrijpelijke taal (en beeld/voorlezen) |
| 5(1)b | Doelbinding | Gegevens alleen voor eigen gebruik en delen op initiatief cliënt | Doel vastleggen; geen hergebruik voor andere doelen |
| 5(1)c | Minimale gegevensverwerking | Geen telemetrie, geen cloud, geen contacten-import, geen analytics | Niets extra's laten invullen |
| 5(1)d | Juistheid | Cliënt kan alles aanpassen/weggooien | n.v.t. |
| 5(1)e | Opslagbeperking | Cliënt kan per item en alles verwijderen (veilig wissen) | Bewaartermijn en afspraken bij einde zorg/gebruik |
| 5(1)f, 32 | Integriteit, vertrouwelijkheid, passende beveiliging | AES-256-GCM, Argon2id, TOTP, herstelcodes, auto-lock, versleutelde delen/back-ups | BitLocker, beveiligingstoets (docs/1), updatebeleid |
| 5(2), 24 | Verantwoordingsplicht | Toestemming met datum en wijze vastgelegd; deel-log | Register, DPIA, beleid aantoonbaar vastleggen (docs/7) |
| 6 | Grondslag | - | Grondslag kiezen en vastleggen (toestemming en/of zorgverlening/gerechtvaardigd belang) |
| 7 | Voorwaarden toestemming (aantoonbaar, vrij, begrijpelijk, intrekbaar) | Toestemmingsscherm, voorlezen, vastlegging, intrekken via "Alles weghalen" | Toestemming mag niet de voorwaarde zijn voor zorg; wilsbekwaamheid beoordelen |
| 8 | Kinderen (NL: onder 16 jaar bij diensten van de informatiemaatschappij) | Keuze "samen met vertegenwoordiger/begeleider" | Voor minderjarigen en wilsonbekwamen: toestemming vertegenwoordiger; beoordeel of art. 8 van toepassing is |
| 9, UAVG 30 | Bijzondere persoonsgegevens (gezondheid/welzijn) | Extra bescherming; uitdrukkelijke toestemming | Uitzonderingsgrond kiezen (bv. 9(2)a toestemming of 9(2)h zorg onder beroepsgeheim) en vastleggen |
| 12-14 | Transparante, begrijpelijke informatie | Eenvoudige taal; "Mijn privacy" | Privacyverklaring (docs: PRIVACY-CONCEPT), aanpasbaar per doelgroep |
| 15 | Inzage | Overzicht met aantallen + export als leesbaar JSON | Verzoekprocedure (docs/7) |
| 16 | Rectificatie | Items bewerken | - |
| 17 | Wissen | Item of account verwijderen (overschrijven + wissen) | Back-ups/exports die cliënt zelf maakte: uitleggen |
| 18, 21 | Beperking, bezwaar | Stoppen en weghalen | Procedure |
| 19 | Mededeling aan ontvangers | Deel-log toont wat gedeeld is | Ontvangers (begeleiders) informeren bij wissen als dat redelijk kan |
| 20 | Overdraagbaarheid | JSON-export + versleutelde back-up | - |
| 22 | Geautomatiseerde besluiten | Geen: de app neemt geen besluiten en doet geen profilering | Houd het zo (zie AI hieronder) |
| 25 | Privacy by design en default | Lokaal, versleuteld, delen is uit tot cliënt kiest, notificaties alleen lokaal | Instellingen niet standaard verruimen |
| 26-28 | Gezamenlijk/verwerker | Geen verwerker nodig bij lokale werking | Verwerkersovereenkomst als er ooit een server, hosting of support met toegang komt |
| 30 | Register van verwerkingsactiviteiten | - | Register invullen (model in docs/7) |
| 31 | Medewerking toezichthouder | - | Contactpersoon aanwijzen |
| 33-34 | Datalek: melden aan AP binnen 72 uur, en aan betrokkenen bij hoog risico | Geen centrale logging; lokaal systeem | Procedure (docs/7) |
| 35-36 | DPIA, voorafgaande raadpleging | DPIA-concept (docs/2) | DPIA vaststellen; AP raadplegen bij hoog restrisico |
| 37-39 | Functionaris gegevensbescherming | - | FG waarschijnlijk verplicht bij grootschalige verwerking van bijzondere gegevens; laten vaststellen |
| 44-49 | Doorgifte buiten de EU | Geen doorgifte door de app | **WhatsApp/e-mail** zijn diensten van derden: de organisatie beslist of die gebruikt mogen worden (zie docs/5) |
| 77, 82, 83 | Klachtrecht bij AP, schadevergoeding, boetes (tot 20 miljoen euro of 4% omzet) | Vermelding klachtrecht in "Mijn privacy" | Aansprakelijkheid en verzekering nakijken |

**Cookies/ePrivacy:** de app en de deelbestanden gebruiken geen cookies, trackers of externe verbindingen (het deelbestand blokkeert netwerkverkeer met een Content-Security-Policy). Artikel 5(3) ePrivacy is daarom niet aan de orde.

## 3. Andere wetten en regels die nu of in 2027 belangrijk zijn
| Regel | Status (5 okt 2026) | Betekenis voor Mijn Gevoel |
|---|---|---|
| **AVG** | Geldt volledig en ongewijzigd | Zie hoofdstuk 2 |
| **UAVG** + "Verzamelwet gegevensbescherming" (Kamerstuk 36 264) | Wetsvoorstel tot wijziging van de UAVG lag in 2026 bij de Eerste Kamer; of het is aangenomen/in werking is: nog controleren | Mogelijk kleine wijzigingen in grondslagen; FG laten controleren |
| **Digital Omnibus - AI** (wijziging AI-verordening) | Aangenomen; gepubliceerd in het Publicatieblad op 24 juli 2026. Nieuwe data: hoog-risicosystemen (bijlage III) **2 december 2027**, ingebedde systemen (bijlage I) 2 augustus 2028, markering van AI-inhoud 2 december 2026 | Mijn Gevoel gebruikt **geen AI**. Voeg geen AI (bijv. emotieherkenning of analyse van het dagboek) toe zonder nieuwe toetsing: dat kan verboden of hoog-risico zijn |
| **Digital Omnibus - data** (voorstel tot wijziging AVG, ePrivacy, NIS2-meldingen, Data Act) | **Niet aangenomen**; Raad en Parlement onderhandelen nog (september 2026: Raadstekst en ongeveer 1.800 amendementen in het Parlement). Besluit niet vóór eind 2026, waarschijnlijk 2027 of later. Het Raadscompromis liet o.a. de definitie van persoonsgegevens ongewijzigd | Tot dan geldt de AVG zoals nu. **Volg dit dossier** en actualiseer de DPIA zodra er een definitieve tekst is |
| **Cyber Resilience Act (CRA)**, Verordening (EU) 2024/2847 | Meldplicht voor actief misbruikte kwetsbaarheden en ernstige incidenten geldt **sinds 11 september 2026**; volledige verplichtingen (o.a. CE-markering, beveiligingseisen, SBOM, updates) **vanaf 11 december 2027** | Geldt voor "producten met digitale elementen" die in de EU op de markt worden gebracht, ook software. Gratis open source buiten commerciële activiteit valt erbuiten. Laat vaststellen of jullie verspreiding eronder valt; zo ja: meld- en kwetsbaarhedenbeleid, SBOM, updatemechanisme, ondersteuningsperiode, conformiteitsbeoordeling |
| **Cyberbeveiligingswet** (NIS2) | **In werking sinds 15 augustus 2026** | Geldt voor organisaties (bijv. zorg) die als essentieel/belangrijk gelden; zij moeten ook de beveiliging van hun leveranciers/software meenemen. Verwacht vragen van afnemers over jullie beveiliging |
| **Europese toegankelijkheidsrichtlijn (EAA)** | Van toepassing sinds 28 juni 2025 voor bepaalde producten/diensten | Mogelijk niet direct van toepassing op deze app; WCAG 2.2 / EN 301 549 aanhouden is verstandig voor deze doelgroep |
| **Medische hulpmiddelen (MDR)** | Geldt | Mijn Gevoel doet geen diagnose of behandeling en wordt zo niet aangeprezen. Maak geen medische claims, anders kan het een medisch hulpmiddel zijn |
| **Zorgwetten** (o.a. WGBO, Wabvpz, NEN 7510/7512/7513) | Gelden voor zorgaanbieders | Alleen relevant als de app deel wordt van het zorgproces/dossier; FG laten beoordelen |

## 4. Wat is in dit pakket al verwerkt
- Toestemmingsscherm in eenvoudige taal met vastlegging van datum/versie/wijze (art. 7).
- "Mijn privacy": inzage, export, back-up, wissen, klachtrecht (art. 12-20, 77).
- Bijzondere bescherming en veilig wissen (art. 5, 9, 17, 32).
- Delen alleen op keuze van de cliënt; versleuteld bestand leesbaar zonder programma; deel-log (art. 5, 25).
- Geen AI, geen telemetrie, geen externe verbindingen (art. 5, 22, 25; AI-verordening).
- Modellen voor register, toestemming, datalek, verzoeken en bewaartermijnen (docs/7).
- Beveiligingstoets-opdracht, DPIA-concept, testplan en herstelbeleid (docs/1-5).

## 5. Te doen vóór gebruik (checklist)
1. FG/jurist laat dit document en docs/2 beoordelen en stelt rollen, grondslag en uitzonderingsgrond vast.
2. DPIA vaststellen; AP raadplegen bij hoog restrisico (art. 36).
3. Register (art. 30), datalekprocedure en verzoekprocedure inrichten (docs/7).
4. Beleid voor WhatsApp/e-mail vaststellen (toegestaan of niet; zie docs/5).
5. CRA-status en classificatie laten vaststellen; meld- en updateproces inrichten.
6. Beveiligingstoets en toegankelijkheidstoets uitvoeren; daarna test met cliënten (docs/1, docs/3).
7. Opnieuw controleren: Data Omnibus (AVG-wijzigingen), Verzamelwet gegevensbescherming, CRA-richtsnoeren.

## Bronnen (geraadpleegd op 5 oktober 2026)
- Digital Omnibus-tijdlijn en AI-omnibus: medialaws.eu legislative tracker; iubenda (16 juni 2026); usercentrics knowledge hub; GDPR Local (21 september 2026) over de Raadstekst.
- Cyber Resilience Act: Goodwin (september 2026), Agence Scroll, McCann FitzGerald, Presencis timeline.
- Cyberbeveiligingswet: Nederlands Juristenblad / Staatsblad 2026, 187 en 189; Forvis Mazars; RSM.
- Verzamelwet gegevensbescherming: Eerste Kamer, Kamerstuk 36 264 (nota naar aanleiding van het tweede verslag, 18 mei 2026).
- AVG-tekst: eur-lex.europa.eu (Verordening 2016/679); UAVG: wetten.overheid.nl.
