# Testplan met cliënten en begeleiders

> Doel: ontdekken of Mijn Gevoel begrijpelijk, rustig en veilig voelt, **vóórdat** het breed wordt gebruikt.

## 1. Opzet
- 5-8 cliënten (verschillende profielen: licht verstandelijke beperking, autisme, ADD/ADHD) en 3-5 begeleiders.
- Sessies van maximaal 30-40 minuten, met pauze. Een vertrouwd persoon mag erbij zijn.
- Locatie: rustige, bekende ruimte. Laat cliënten kiezen: pen/touch/muis, lettergrootte, thema.

## 2. Ethiek en veiligheid (eerst regelen)
- Toestemming in eenvoudige taal (ook beeld/voorlezen); wilsbekwaamheid en eventueel wettelijk vertegenwoordiger.
- Cliënt mag altijd stoppen zonder uitleg. Laat dit duidelijk zeggen.
- **Gebruik testgegevens, geen echte dagboeken.** Vraag niemand echte problemen in te vullen; gebruik verzonnen voorbeelden of een fictief personage.
- Stoplicht "rood" testen met een verzonnen situatie; een begeleider is aanwezig. Spreek af wat gebeurt als iemand tijdens de test écht van streek raakt (rust, praten, protocol).
- Geen opnames zonder uitdrukkelijke toestemming; noteer liever observaties.

## 3. Taken (laat cliënt hardop denken, begeleid niet te snel)
1. Account maken met authenticator-app en herstelcodes opschrijven.
2. Inloggen.
3. Een tekening maken en bewaren.
4. Iets "van me afschrijven" en weggooien.
5. Een dagboekregel met gezichtje opslaan.
6. Een afspraak met tijd in de agenda zetten.
7. Het stoplicht invullen (oranje, met reden en behoefte).
8. "Mijn plan" invullen.
9. Een deelbestand maken (verzonnen melding) en laten openen door begeleider.
10. Vergrendelen en opnieuw inloggen; herstelcodes gebruiken (oefenaccount).

## 4. Wat observeren
- Waar hapert iemand, vraagt om hulp, of raakt overprikkeld (geluid, kleur, veel keuzes)?
- Begrijpt iemand woorden als "vergrendel", "herstelcode", "delen"?
- Zijn pictogrammen en kleuren duidelijk (ook bij kleurenblindheid)? Werkt voorlezen?
- Voelt het veilig? Begrijpt de cliënt dat de app **niemand automatisch waarschuwt**?
- Authenticator-stap: welke stap lukt niet zonder hulp? (Verwacht: dit is het lastigste onderdeel.)

## 5. Vragen aan de cliënt (eenvoudig)
"Wat vond je makkelijk?" "Wat vond je moeilijk?" "Wat snap je niet?" "Zou je dit gebruiken?" "Voelde iets raar of eng?" Gebruik gezichtjes (blij/neutraal/verdrietig) als antwoord.

## 6. Vragen aan begeleiders
Past het in de werkwijze? Is het delen duidelijk? Welk protocol hoort bij oranje/rood? Hoe vaak kijken jullie? Wat ontbreekt?

## 7. Succescriteria (voorbeeld, vooraf vaststellen)
- 80% maakt zonder hulp een tekening en dagboekregel.
- Minstens 70% rondt registratie af met maximaal één hulpvraag; zo niet: begeleide registratie als standaard inrichten.
- Niemand raakt overprikkeld door standaardinstellingen.
- Iedereen kan uitleggen dat de app zelf niemand waarschuwt.

## 8. Na afloop
Bevindingen samenvatten, prioriteren (veiligheid > begrijpelijkheid > gemak), aanpassen, **herhalen** met een nieuwe kleine groep. Leg ook vast welke taalniveau-controle is gedaan (bijv. B1 of lager) en wie de teksten heeft nagekeken.
