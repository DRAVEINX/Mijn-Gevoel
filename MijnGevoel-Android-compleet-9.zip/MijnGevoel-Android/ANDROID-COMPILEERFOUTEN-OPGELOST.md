# Android-compileerfouten: gerichte fixes

Deze broncode-update herstelt compileerfouten uit de tweede GitHub Actions-run:

- Verwijderd: optionele `builder.Logging.AddDebug()`-aanroep zonder de bijbehorende package reference.
- Vervangen: `FadeTo(...)` door de .NET MAUI 10-methode `FadeToAsync(...)`.
- Agenda: `DatePicker.Date` krijgt een veilige fallback als de waarde null is.
- Bestandspaden in `FeaturePage`: expliciet `System.IO.Path.Combine` om verwarring met `Microsoft.Maui.Controls.Shapes.Path` te voorkomen.
- Tekeninteractie: aanrakingen worden eerst naar een array omgezet, zodat er geen `Count`-methode als getal wordt gebruikt.
- Android-app target bijgewerkt naar `net10.0-android`; gedeelde Core- en testprojecten blijven op .NET 8.

De code moet opnieuw via GitHub Actions worden gebouwd. Deze fixes zijn gebaseerd op de compilerregels in de mislukte build; ze bewijzen op zichzelf nog niet dat er geen andere compileer- of runtimeproblemen bestaan.
