@echo off
setlocal
cd /d "%~dp0"
set "LOG=%~dp0bouwlog.txt"
rem Maakt MijnGevoel-installatie.msi en schrijft alles op in bouwlog.txt (stuur dat bestand op als er iets misgaat).
powershell -NoProfile -Command "'Mijn Gevoel bouwen - ' + (Get-Date) | Out-File -Encoding utf8 -FilePath '%LOG%'"
echo.

echo [0/5] Controle van .NET 8 SDK...
powershell -NoProfile -Command "dotnet --info 2>&1 | ForEach-Object { $s=$_.ToString(); Write-Host $s; $s } | Out-File -Append -Encoding utf8 -FilePath '%LOG%'; exit $LASTEXITCODE" || goto :geendotnet

echo [1/5] Tests draaien...
powershell -NoProfile -Command "dotnet test MijnGevoel.Tests 2>&1 | ForEach-Object { $s=$_.ToString(); Write-Host $s; $s } | Out-File -Append -Encoding utf8 -FilePath '%LOG%'; exit $LASTEXITCODE" || goto :fout

echo [2/5] Programma bouwen (zelfstandige MijnGevoel.exe)...
powershell -NoProfile -Command "dotnet publish MijnGevoel.Desktop -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o publish 2>&1 | ForEach-Object { $s=$_.ToString(); Write-Host $s; $s } | Out-File -Append -Encoding utf8 -FilePath '%LOG%'; exit $LASTEXITCODE" || goto :fout

echo [3/5] WiX installeren (eenmalig)...
powershell -NoProfile -Command "dotnet tool update --global wix --version 5.0.2; wix extension add -g WixToolset.UI.wixext/5.0.2 2>&1 | ForEach-Object { $s=$_.ToString(); Write-Host $s; $s } | Out-File -Append -Encoding utf8 -FilePath '%LOG%'; exit 0" || goto :fout

echo [4/5] MSI maken...
powershell -NoProfile -Command "wix build installer\Package.wxs -ext WixToolset.UI.wixext -culture nl-NL -arch x64 -d PublishDir=publish -o MijnGevoel-installatie.msi 2>&1 | ForEach-Object { $s=$_.ToString(); Write-Host $s; $s } | Out-File -Append -Encoding utf8 -FilePath '%LOG%'; exit $LASTEXITCODE" || goto :fout

echo [5/5] Draagbaar pakket maken (zonder msi te installeren)...
powershell -NoProfile -Command "New-Item -ItemType Directory -Force -Path 'uitrol\MijnGevoel-draagbaar' | Out-Null; Copy-Item 'publish\MijnGevoel.exe' 'uitrol\MijnGevoel-draagbaar\' -Force; Copy-Item 'uitrol-sjabloon\*' 'uitrol\MijnGevoel-draagbaar\' -Force; Compress-Archive -Path 'uitrol\MijnGevoel-draagbaar\*' -DestinationPath 'MijnGevoel-draagbaar.zip' -Force 2>&1 | ForEach-Object { $s=$_.ToString(); Write-Host $s; $s } | Out-File -Append -Encoding utf8 -FilePath '%LOG%'; exit $LASTEXITCODE" || goto :fout

echo.
echo KLAAR! Twee bestanden om te installeren of te delen:
echo   1. %~dp0MijnGevoel-installatie.msi
echo   2. %~dp0MijnGevoel-draagbaar.zip  (uitpakken en Installeren.bat dubbelklikken; geen beheerder nodig)
echo MSI lukt niet? Dubbelklik installeren-met-log.bat en stuur installlog.txt naar mij.
echo Stille installatie (voor beheerders): msiexec /i MijnGevoel-installatie.msi /qn
echo Teken de .exe en de .msi met een code-signing-certificaat voordat je ze uitdeelt.
pause
goto :eof

:geendotnet
echo.
echo De .NET 8 SDK is niet gevonden. Installeer die eerst: https://dotnet.microsoft.com/download
echo Draai daarna dit bestand opnieuw.
pause
exit /b 1

:fout
echo.
echo ER GING IETS MIS bij het bouwen.
echo Stuur het bestand bouwlog.txt (staat in dezelfde map als dit bestand) naar mij, dan los ik het op.
explorer /select,"%LOG%"
pause
exit /b 1
