# Privacyverklaring Mijn Gevoel (CONCEPT - laat dit juridisch controleren voor gebruik)

**Wat wordt opgeslagen?** Gebruikersnaam, versleutelde sleutels, en wat de cliënt zelf invult: dagboek, briefjes, tekeningen, agenda, gevoelsgezichtjes en instellingen.
**Waar?** Alleen op de computer van de cliënt, in `%LocalAppData%\MijnGevoel`. Er wordt niets via internet verstuurd en er zijn geen analyse- of advertentietools.
**Hoe beschermd?** Versleuteld met AES-256-GCM. De sleutel is alleen te openen met wachtwoord én code uit de authenticator-app (of een herstelcode).
**Wie kan het lezen?** Alleen de cliënt. De maker van het programma heeft geen toegang.
**Verwijderen:** Instellingen > "Mijn account ... verwijderen" wist alle gegevens definitief.
**Meenemen/overzetten:** Instellingen > "Back-up maken".
**Let op (voor de organisatie):** dit zijn gegevens over gezondheid en welzijn (bijzondere persoonsgegevens onder de AVG). Doe vooraf een DPIA, leg de verwerkingsgrondslag en toestemming (ook via wettelijk vertegenwoordiger indien nodig) vast, en laat de beveiliging extern toetsen.

**Stoplicht en delen:** de stoplicht-meldingen (kleur, reden, wat nodig, eigen tekst) en het noodplan (contactpersonen) staan alleen versleuteld op de computer. Ze worden alleen gedeeld als de cliënt dat zelf kiest, via een versleuteld deelbestand met een aparte code. Mijn Gevoel waarschuwt zelf niemand en is geen alarmsysteem.
**Verdere documenten:** zie de map `docs` (beveiligingstoets, DPIA-concept, testplan, herstelbeleid, ontwerp delen).

**Toestemming en rechten:** bij het eerste gebruik vraagt de app toestemming in eenvoudige taal en legt datum en wijze vast. Onder "Mijn privacy" kan de cliënt zien wat er bewaard is, het meenemen (leesbaar bestand of versleutelde back-up), aanpassen, wissen en stoppen. Klachten kunnen worden gericht aan de verantwoordelijke organisatie of aan de Autoriteit Persoonsgegevens.
**Delen:** standaard als versleuteld bestand (.html) dat in elke browser te lezen is met een code. Wie het bestand of de gewone tekst via een chatprogramma verstuurt, maakt gebruik van de dienst van die aanbieder; kies dit bewust.
**Wetgeving en modellen:** zie `docs/6` en `docs/7`.
