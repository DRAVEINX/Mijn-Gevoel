# Release-kandidaat 1.0.1 (build 2)

- SkiaSharp en SkiaSharp.NativeAssets.Android bijgewerkt naar 3.119.4 om de oude native-librarywaarschuwing voor 16 KB-pagina's te verhelpen; zie de SkiaSharp NuGet-pakketten en Android 16 KB-documentatie.
- Expliciete verwijzing naar Microsoft.Maui.Controls 10.0.110 toegevoegd volgens de MAUI-buildwaarschuwing.
- Android-weergaveversie ingesteld op 1.0.1 en interne versiecode op 2.
- Dit is een release-kandidaat; bouw en test hem opnieuw voordat hij dagelijks wordt gebruikt.
