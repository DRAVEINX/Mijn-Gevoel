# Mijn Gevoel — Android 2.0

Android-broncode, nieuwe gevoelsfuncties en bijgewerkte releaseworkflows.

- **Android-project:** `MijnGevoel.Android/MijnGevoel.Android.csproj` (`net10.0-android`)
- **Gedeelde beveiligings- en datalaag:** `MijnGevoel.Core/MijnGevoel.Core.csproj`
- **Tests:** `MijnGevoel.Tests/MijnGevoel.Tests.csproj`
- **Windows-app:** `MijnGevoel.Desktop/MijnGevoel.Desktop.csproj`

Begin bij [ANDROID-START-HIER.md](ANDROID-START-HIER.md), voer daarna de controles uit in [ANDROID-ACCEPTATIETEST.md](ANDROID-ACCEPTATIETEST.md).

**Let op:** de broncode is nog geen geteste APK. De .NET 10/MAUI-build en de toesteltests moeten na upload via GitHub Actions/lokaal worden uitgevoerd.
