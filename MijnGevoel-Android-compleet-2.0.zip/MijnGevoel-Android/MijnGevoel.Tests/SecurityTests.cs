using System.Security.Cryptography;
using System.Text;
using MijnGevoel.Core.Data;
using MijnGevoel.Core.Security;
using Xunit;

public class TotpTests
{
    static readonly byte[] Rfc = Encoding.ASCII.GetBytes("12345678901234567890");   // testgeheim uit RFC 6238

    [Theory]
    [InlineData(59L, "287082")]
    [InlineData(1111111109L, "081804")]
    [InlineData(1234567890L, "005924")]
    public void KlopptMetRfc6238(long unix, string expected) => Assert.Equal(expected, Totp.Code(Rfc, unix / 30));

    [Fact]
    public void VerwerptVerkeerdeCode() => Assert.Null(Totp.Verify(Rfc, "000000", DateTimeOffset.FromUnixTimeSeconds(59)));
}

public class CryptoTests
{
    [Fact]
    public void RoundTrip()
    {
        var key = Crypto.Random(32);
        Assert.Equal("hoi"u8.ToArray(), Crypto.Open(key, Crypto.Seal(key, "hoi"u8.ToArray(), "x"), "x"));
    }

    [Fact]
    public void ManipulatieEnVerkeerdeContextWordenGeweigerd()
    {
        var key = Crypto.Random(32);
        var blob = Crypto.Seal(key, "geheim"u8.ToArray(), "a");
        Assert.ThrowsAny<CryptographicException>(() => Crypto.Open(key, blob, "b"));
        blob[15] ^= 1;
        Assert.ThrowsAny<CryptographicException>(() => Crypto.Open(key, blob, "a"));
    }
}

public class AccountTests : IDisposable
{
    readonly string _base = Path.Combine(Path.GetTempPath(), "mg-test-" + Guid.NewGuid());
    readonly AccountService _acc;
    public AccountTests() => _acc = new AccountService(Path.Combine(_base, "accounts"));
    public void Dispose() { try { Directory.Delete(_base, true); } catch { } }

    static byte[] FromBase32(string s)
    {
        const string a = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
        var o = new List<byte>(); int buf = 0, bits = 0;
        foreach (var ch in s) { buf = (buf << 5) | a.IndexOf(ch); bits += 5; if (bits >= 8) { o.Add((byte)(buf >> (bits - 8))); bits -= 8; } }
        return o.ToArray();
    }
    static string NowCode(Registration r) => Totp.Code(FromBase32(r.SecretForManualEntry), Totp.CurrentStep());

    Registration Setup(string user = "sam", string pw = "een goed wachtwoord")
    {
        var r = _acc.Register(user, pw);
        Assert.True(_acc.ConfirmRegistration(user, pw, NowCode(r)));
        return r;
    }

    [Fact] public void RegistrerenEnInloggen()
    {
        var r = Setup();
        var res = _acc.Login("SAM", "een goed wachtwoord", NowCode(r));   // hoofdletters maken niet uit
        Assert.True(res.Success); Assert.Equal(32, res.VaultKey!.Length);
    }

    [Fact] public void VerkeerdWachtwoordWordtGeweigerd()
    {
        var r = Setup(); Assert.False(_acc.Login("sam", "fout wachtwoord!!", NowCode(r)).Success);
    }

    [Fact] public void CodeKanNietTweeKeerGebruiktWorden()
    {
        var r = Setup(); var code = NowCode(r);
        Assert.True(_acc.Login("sam", "een goed wachtwoord", code).Success);
        Assert.False(_acc.Login("sam", "een goed wachtwoord", code).Success);
    }

    [Fact] public void BlokkadeNaVijfFouten()
    {
        var r = Setup();
        for (int i = 0; i < 5; i++) _acc.Login("sam", "fout wachtwoord!!", "000000");
        var res = _acc.Login("sam", "een goed wachtwoord", NowCode(r));
        Assert.False(res.Success); Assert.Contains("Wacht", res.Message);
    }

    [Fact] public void HerstelcodeWerktEenKeer()
    {
        var r = Setup(); var code = r.RecoveryCodes[0];
        var nieuw = _acc.RecoverAccess("sam", code, "nieuw wachtwoord 123");
        Assert.NotNull(nieuw);
        Assert.True(_acc.ConfirmRegistration("sam", "nieuw wachtwoord 123", NowCode(nieuw!)));
        Assert.True(_acc.Login("sam", "nieuw wachtwoord 123", NowCode(nieuw!)).Success);
        Assert.Null(_acc.RecoverAccess("sam", code, "weer een ander wachtwoord"));   // oude code is vervallen
    }

    [Fact] public void GegevensZijnVersleuteldEnTerugTeLezen()
    {
        var r = Setup(); var res = _acc.Login("sam", "een goed wachtwoord", NowCode(r));
        using var store = new VaultStore(res.VaultKey!, _acc.DataFolder("sam"));
        var e = new JournalEntry(Guid.NewGuid(), DateTime.Now, 2, "supergeheim dagboek");
        store.Save("diary", e.Id, e);
        Assert.Equal("supergeheim dagboek", store.Load<JournalEntry>("diary", e.Id)!.Text);
        var raw = File.ReadAllBytes(Directory.GetFiles(_acc.DataFolder("sam"), "diary-*.mg")[0]);
        Assert.DoesNotContain("supergeheim", Encoding.UTF8.GetString(raw));
    }

    [Fact] public void NieuweHerstelcodesVervangenDeOude()
    {
        var r = Setup(); var oud = r.RecoveryCodes[0];
        var nieuw = _acc.RegenerateRecoveryCodes("sam", "een goed wachtwoord");
        Assert.NotNull(nieuw); Assert.Equal(8, _acc.RecoveryCodesLeft("sam"));
        Assert.Null(_acc.RecoverAccess("sam", oud, "weer een ander wachtwoord"));
        Assert.Null(_acc.RegenerateRecoveryCodes("sam", "fout wachtwoord!!"));
    }
}

public class ShareTests
{
    [Fact]
    public void DeelbestandRoundTripEnVerkeerdeCode()
    {
        var items = new[] { new StoplichtEntry(Guid.NewGuid(), DateTime.Now, "Rood", new[] { "Ik ben bang" }, new[] { "Ik wil nu hulp" }, "geheimetekst") };
        var code = ShareService.NewShareCode();
        var file = ShareService.Create("Sam", items, code);
        Assert.DoesNotContain("geheimetekst", Encoding.UTF8.GetString(file));
        var pkg = ShareService.Open(file, code.ToLowerInvariant());     // hoofdletters/streepjes maken niet uit
        Assert.Equal("geheimetekst", pkg!.Items[0].Text);
        Assert.Null(ShareService.Open(file, "AAAA-AAAA-AAAA"));
        file[^3] ^= 1;
        Assert.Null(ShareService.Open(file, code));                      // gemanipuleerd bestand
    }

    [Fact]
    public void HtmlDeelbestandRoundTripEnVerkeerdeCode()
    {
        var items = new[] { new StoplichtEntry(Guid.NewGuid(), DateTime.Now, "Oranje", new[] { "Ik ben moe" }, new[] { "Ik wil rust" }, "geheimetekst") };
        var code = ShareService.NewShareCode();
        var html = ShareService.CreateHtml("Zeer-Unieke-Naam", items, code);
        Assert.DoesNotContain("geheimetekst", html);
        Assert.DoesNotContain("Zeer-Unieke-Naam", html);       // ook de naam van de cliënt staat niet leesbaar in het bestand
        Assert.Equal("geheimetekst", ShareService.OpenHtml(html, code)!.Items[0].Text);
        Assert.Null(ShareService.OpenHtml(html, "AAAA-AAAA-AAAA"));
    }

    [Fact]
    public void PlatteTekstBevatKleurEnReden()
    {
        var items = new[] { new StoplichtEntry(Guid.NewGuid(), DateTime.Now, "Rood", new[] { "Ik ben bang" }, new[] { "Ik wil nu hulp" }, "help") };
        var t = ShareService.PlainText("Sam", items);
        Assert.Contains("Rood", t); Assert.Contains("Ik ben bang", t);
    }
}

public class ExportTests : IDisposable
{
    readonly string _dir = Path.Combine(Path.GetTempPath(), "mg-export-" + Guid.NewGuid());
    public void Dispose() { try { Directory.Delete(_dir, true); } catch { } }

    [Fact]
    public void ExportBevatAllesEnNieuweSoortenGegevens()
    {
        using var store = new VaultStore(Crypto.Random(32), Path.Combine(_dir, "data"));
        var j = new JournalEntry(Guid.NewGuid(), DateTime.Now, 2, "dagboektekst");
        store.Save("diary", j.Id, j);
        var r = new Routine(Guid.NewGuid(), "Ochtend", "☀️", new[] { "Opstaan", "Tanden poetsen" });
        store.Save("routine", r.Id, r);
        var m = new ScaleEntry(Guid.NewGuid(), DateTime.Now, "Lichaam", 0, "Buik: spanning");
        store.Save("scale", m.Id, m);
        var c = new TalkCard(Guid.NewGuid(), "💬", "Ik wil praten");
        store.Save("card", c.Id, c);
        var checkIn = new MoodCheckInEntry(Guid.NewGuid(), DateTime.Now, "Zenuwachtig", 8, "Werk", "Spannende afspraak");
        store.Save("moodcheckin", checkIn.Id, checkIn);
        store.Save("talk", Guid.Empty, new TalkPrep { Tell = "mijn verhaal" });

        var savedCheckIn = store.Load<MoodCheckInEntry>("moodcheckin", checkIn.Id);
        Assert.NotNull(savedCheckIn);
        Assert.Equal("Zenuwachtig", savedCheckIn!.Feeling);
        Assert.Equal(8, savedCheckIn.Intensity);

        var path = Path.Combine(_dir, "export.json");
        ExportService.ExportAll(store, "sam", path);
        var json = File.ReadAllText(path);
        foreach (var verwacht in new[] { "dagboektekst", "Tanden poetsen", "Buik: spanning", "Ik wil praten", "mijn verhaal", "Zenuwachtig", "Spannende afspraak", "Werk" })
            Assert.Contains(verwacht, json);
        Assert.Equal("Opstaan", store.Load<Routine>("routine", r.Id)!.Steps[0]);   // arrays blijven heel
    }
}
