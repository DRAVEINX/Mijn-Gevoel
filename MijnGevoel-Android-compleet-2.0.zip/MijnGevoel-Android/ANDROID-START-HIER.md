# Mijn Gevoel Android 2.0 — start hier

Dit project bevat de Android-app van Mijn Gevoel, de gedeelde beveiligings-/datalaag en de bestaande Windows-broncode. De Android-app target **.NET 10 MAUI** (`net10.0-android`). De tests en gedeelde core gebruiken nog `net8.0`.

## Wat nieuw is in Android 2.0

- Dagelijkse gevoelscheck-in met intensiteit (1–10), aanleiding en optionele notitie.
- Gevoelskalender met opgeslagen check-ins van de laatste 30 dagen; tik op een dag om de details te bekijken.
- Neutrale inzichten over 7 en 30 dagen: aantallen, gemiddelde intensiteit en vaak gekozen gevoelens. Dit is geen diagnose.
- Tekenen met zes kleuren en drie pendiktes, de laatste lijn ongedaan maken en het canvas wissen.
- Check-ins zitten in het weekoverzicht, de privacytelling en de leesbare gegevens-export.
- Android-versie 2.0 met version code 20.

## Belangrijke status

Dit pakket is **broncode**, geen kant-en-klare APK. In deze werkomgeving is geen .NET SDK of MAUI Android-workload beschikbaar, dus ik kan geen echte C#-build uitvoeren en geen app op een telefoon testen. De releaseworkflow is bijgewerkt, maar moet na het uploaden naar GitHub worden uitgevoerd. Een groene build is nog geen vervanging voor een toesteltest.

## Benodigdheden

- .NET 10 SDK voor de Android-app.
- .NET 8 targeting/runtime-ondersteuning voor de tests en gedeelde core (bij SDK-setup kunnen beide SDK's worden geïnstalleerd).
- MAUI Android-workload: `dotnet workload install maui-android`.
- Java 17 en Android SDK/platform-tools.
- Een Android-telefoon of emulator voor acceptatietests.

## Lokaal bouwen

Open een terminal in de map `MijnGevoel-Android` en voer uit:

```bash
dotnet workload restore MijnGevoel.Android/MijnGevoel.Android.csproj
dotnet restore MijnGevoel.Tests/MijnGevoel.Tests.csproj
dotnet test MijnGevoel.Tests/MijnGevoel.Tests.csproj --configuration Release
dotnet restore MijnGevoel.Android/MijnGevoel.Android.csproj
dotnet publish MijnGevoel.Android/MijnGevoel.Android.csproj --configuration Debug --framework net10.0-android -p:AndroidPackageFormat=apk
```

Of gebruik `scripts/build-android.sh`. Het script zet de debug-APK en de SHA-256-checksum in `artifacts/`.

## Release bouwen via GitHub

1. Upload de inhoud van deze projectmap naar de hoofdmap van je GitHub-repository.
2. Upload ook `MijnGevoel-Android-compleet-2.0.zip` naar de hoofdmap.
3. Plaats het meegeleverde `android-release.yml` in `.github/workflows/android-release.yml` en commit de wijzigingen.
4. Controleer dat de bestaande GitHub Secrets voor de eigen ondertekeningssleutel aanwezig zijn; zet geen sleutel of wachtwoord in de broncode.
5. Open **Actions → Mijn Gevoel 2.0 - Android Release → Run workflow**.
6. Download alleen bij een geslaagde run het artifact met de release-APK, AAB en checksums.

De AAB is bedoeld voor upload naar Google Play Console en is niet rechtstreeks te installeren. De APK is bedoeld voor Android-installatie. Behoud de oude versie als terugvaloptie en maak vóór installatie een versleutelde back-up.

## Acceptatietest

Doorloop `ANDROID-ACCEPTATIETEST.md` eerst met een testaccount en zonder echte gevoelige gegevens. Test in ieder geval inloggen, authenticator/herstelcodes, automatisch vergrendelen, biometrie indien ingesteld, export/back-up/herstel, accountverwijdering, check-ins en tekeningen. Zet geen echte cliëntgegevens in de app voordat build én toesteltests geslaagd zijn.
