using AndroidX.Biometric;
using AndroidX.Core.Content;
using AndroidX.Fragment.App;
using Microsoft.Maui.ApplicationModel;

namespace MijnGevoel.AndroidApp;

/// <summary>Toont de systeemprompt voor biometrisch ontgrendelen. Annuleren laat de gewone login beschikbaar.</summary>
internal static class BiometricUnlock
{
    static BiometricPrompt? _activePrompt;
    static Callback? _activeCallback;

    public static async Task<bool> AuthenticateAsync(string title = "Ontgrendel Mijn Gevoel")
    {
        var activity = Platform.CurrentActivity as FragmentActivity;
        if (activity is null) return false;

        var result = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        try
        {
            var executor = ContextCompat.GetMainExecutor(activity);
            if (executor is null) return false;
            _activeCallback = new Callback(result);
            _activePrompt = new BiometricPrompt(activity, executor, _activeCallback);
            var promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .SetTitle(title)
                .SetSubtitle("Gebruik de vingerafdruk of gezichtsherkenning van je telefoon")
                .SetNegativeButtonText("Gebruik wachtwoord")
                .SetAllowedAuthenticators(0x00FF) // BIOMETRIC_WEAK: ook apparaatondersteunde gezichtsherkenning toestaan.
                .Build();
            _activePrompt.Authenticate(promptInfo);
            return await result.Task;
        }
        catch (Exception ex)
        {
            AppLog.Write(ex);
            return false;
        }
        finally
        {
            _activePrompt = null;
            _activeCallback = null;
        }
    }

    sealed class Callback(TaskCompletionSource<bool> result) : BiometricPrompt.AuthenticationCallback
    {
        public override void OnAuthenticationSucceeded(BiometricPrompt.AuthenticationResult authenticationResult)
            => result.TrySetResult(true);

        public override void OnAuthenticationError(int errorCode, Java.Lang.ICharSequence errString)
            => result.TrySetResult(false);

        // Bij een niet-herkende scan blijft de systeemprompt open zodat de gebruiker opnieuw kan proberen.
        public override void OnAuthenticationFailed() { }
    }
}
