using MijnGevoel.Core.Data;
using Microsoft.Maui.ApplicationModel.Communication;

namespace MijnGevoel.AndroidApp;

public enum FeatureKind
{
    Stoplicht, DayToday, DayTomorrow, Agenda, Timer, Routines,
    Breath, Calm, Sensory, Body, MoodHistory, FeelingWords,
    Cards, TalkPrep, StoplichtHistory, Share, SafetyPlan,
    Draw, Gallery, Notes, Journal, Privacy, Week, Settings, Help, WhoWorks, DailyCheckIn, MoodCalendar, MoodInsights
}

public sealed class DashboardPage : ContentPage
{
    bool _consentPrompted;
    static readonly (string Name, string Icon, FeatureKind Kind)[][] Groups =
    {
        new[] { ("Vandaag", "🗓️", FeatureKind.DayToday), ("Wie werkt er?", "👥", FeatureKind.WhoWorks), ("Morgen bekijken", "🌙", FeatureKind.DayTomorrow), ("Agenda", "📅", FeatureKind.Agenda), ("Timer", "⏳", FeatureKind.Timer), ("Stappenplannen", "✅", FeatureKind.Routines) },
        new[] { ("Ademhalen", "🫁", FeatureKind.Breath), ("Rustplek", "🛋️", FeatureKind.Calm), ("Prikkelmeter", "🎚️", FeatureKind.Sensory), ("Mijn lichaam", "🧍", FeatureKind.Body), ("Hoe voel ik me?", "📊", FeatureKind.MoodHistory), ("Gevoelswoorden", "📖", FeatureKind.FeelingWords), ("Dagelijkse check-in", "💚", FeatureKind.DailyCheckIn), ("Gevoelskalender", "🗓️", FeatureKind.MoodCalendar), ("Mijn inzichten", "📈", FeatureKind.MoodInsights) },
        new[] { ("Kaarten om te laten zien", "🗂️", FeatureKind.Cards), ("Gesprekskaart", "🗣️", FeatureKind.TalkPrep), ("Stoplicht-overzicht", "🚦", FeatureKind.StoplichtHistory), ("Delen met mijn begeleider", "📤", FeatureKind.Share), ("Mijn helpkaart / plan", "🆘", FeatureKind.SafetyPlan) },
        new[] { ("Tekenen", "✏️", FeatureKind.Draw), ("Mijn tekeningen", "🖼️", FeatureKind.Gallery), ("Van me afschrijven", "📝", FeatureKind.Notes), ("Dagboek", "📖", FeatureKind.Journal) },
        new[] { ("Mijn privacy", "🔐", FeatureKind.Privacy), ("Weekoverzicht", "🗒️", FeatureKind.Week), ("Instellingen", "⚙️", FeatureKind.Settings), ("Hulp", "❓", FeatureKind.Help) }
    };
    static readonly string[] GroupNames = { "Mijn dag", "Rust en gevoel", "Praten en delen", "Maken en schrijven", "Mijn gegevens" };

    public DashboardPage()
    {
        Title = "Mijn Gevoel";
        BackgroundColor = AppUi.Background;
        ToolbarItems.Add(new ToolbarItem("🔒 Vergrendel", null, async () => await ((App)Application.Current!).LockToLoginAsync("Je sessie is vergrendeld.")));
        ToolbarItems.Add(new ToolbarItem("🙈 Scherm verbergen", null, async () => await Navigation.PushAsync(new PrivacyCoverPage())));
        Build();
    }

    void Build()
    {
        var root = new VerticalStackLayout { Padding = new Thickness(16), Spacing = 12, BackgroundColor = AppUi.Background };
        root.Children.Add(AppUi.Title($"Hoi {AppSession.Username}!"));
        root.Children.Add(AppUi.Label("Hoe is het nu? Je kunt iets kiezen, opschrijven of even tot rust komen."));
        int left = AppSession.Accounts.RecoveryCodesLeft(AppSession.Username);
        if (left <= 2)
            root.Children.Add(AppUi.Card(new VerticalStackLayout { Children = { AppUi.Label($"⚠️ Je hebt nog {left} herstelcode(s). Maak nieuwe codes bij Instellingen.") } }));

        root.Children.Add(AppUi.Title("Hoe voel ik me?"));
        root.Children.Add(AppUi.Label("Kies het gevoel dat nu het beste past. Er is geen goed of fout.", muted: true));
        var feelings = new[]
        {
            (Key: "Blij", Label: "😄\nBLIJ", Color: "#D8F0DC"),
            (Key: "Bedroefd", Label: "😢\nBEDROEFD", Color: "#DDEBFA"),
            (Key: "Boos", Label: "😠\nBOOS", Color: "#F9D9D8"),
            (Key: "Bang", Label: "😨\nBANG", Color: "#E8DFF8")
        };
        var feelingsGrid = new Grid
        {
            ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) },
            RowDefinitions = { new RowDefinition(GridLength.Auto), new RowDefinition(GridLength.Auto) },
            ColumnSpacing = 8, RowSpacing = 8
        };
        var feelingStatus = AppUi.Label("");
        var helpPanel = new VerticalStackLayout
        {
            IsVisible = false, Spacing = 8, Padding = 12,
            BackgroundColor = AppUi.Surface
        };
        foreach (var feeling in feelings.Select((item, index) => (item, index)))
        {
            var item = feeling.item;
            var index = feeling.index;
            var button = AppUi.AsyncButton(item.Label, async () => await SaveFourGFeelingAsync(item.Key, feelingStatus, helpPanel), quiet: true);
            button.FontSize = 22;
            button.FontAttributes = FontAttributes.Bold;
            button.HeightRequest = 94;
            button.BackgroundColor = Color.FromArgb(item.Color);
            button.BorderColor = Color.FromArgb(item.Color);
            button.TextColor = Color.FromArgb("#1F2A37");
            button.CornerRadius = 16;
            Grid.SetColumn(button, index % 2);
            Grid.SetRow(button, index / 2);
            feelingsGrid.Children.Add(button);
        }
        root.Children.Add(feelingsGrid);
        root.Children.Add(feelingStatus);
        root.Children.Add(helpPanel);
        root.Children.Add(AppUi.Button("🆘 Mijn helpkaart instellen", () => Navigate(FeatureKind.SafetyPlan), quiet: true));
        root.Children.Add(AppUi.Button("🚦 Stoplicht invullen", () => Navigate(FeatureKind.Stoplicht), quiet: true));

        for (int groupIndex = 0; groupIndex < Groups.Length; groupIndex++)
        {
            root.Children.Add(AppUi.Title(GroupNames[groupIndex]));
            foreach (var item in Groups[groupIndex])
            {
                var button = AppUi.Button($"{item.Icon}  {item.Name}  →", () => Navigate(item.Kind), quiet: true);
                root.Children.Add(button);
            }
        }
        root.Children.Add(AppUi.Button("🔒 Sessie vergrendelen", async () => await ((App)Application.Current!).LockToLoginAsync(), danger: true));
        root.Children.Add(AppUi.AsyncButton("🚪 Uitloggen en sessie vergeten", async () =>
        {
            if (await DisplayAlertAsync("Uitloggen?", "Je opgeslagen sessie wordt verwijderd. Je moet daarna opnieuw inloggen met je gegevens.", "Uitloggen", "Annuleren"))
                await ((App)Application.Current!).LockToLoginAsync("Je bent uitgelogd. Log opnieuw in met je gegevens.", forgetRemembered: true);
        }, quiet: true));
        root.Children.Add(AppUi.Label("Alles staat in je privé-appopslag en wordt versleuteld. Mijn Gevoel waarschuwt niemand automatisch.", muted: true));
        root.Children.Add(AppUi.Copyright());
        Content = new ScrollView { Content = root };
    }

    void Navigate(FeatureKind kind) => Navigation.PushAsync(kind == FeatureKind.WhoWorks ? new WieWerktErPage() : new FeaturePage(kind));

    async Task SaveFourGFeelingAsync(string feeling, Label status, VerticalStackLayout helpPanel)
    {
        var record = new FourGFeelingEntry(Guid.NewGuid(), DateTime.Now, feeling);
        AppSession.Store!.Save("feeling4g", record.Id, record);
        status.Text = $"Opgeslagen: {FeelingEmoji(feeling)} {feeling}.";
        AppUi.Speak($"Je hebt {feeling} gekozen. Dit is opgeslagen. Er wordt niets automatisch gedeeld.");
        helpPanel.Children.Clear();
        helpPanel.Children.Add(AppUi.Title(feeling == "Blij" ? "Fijn dat je dit deelt" : "Wat kan nu helpen?"));
        if (feeling == "Blij")
        {
            helpPanel.Children.Add(AppUi.Label("Je gevoel is bewaard. Je hoeft verder niets te doen."));
            helpPanel.IsVisible = true;
            return;
        }

        var plan = AppSession.Store.Load<SafetyPlan>("plan", Guid.Empty) ?? new SafetyPlan();
        var options = plan.HelpOptions?.Where(x => !string.IsNullOrWhiteSpace(x)).Distinct().ToList() ?? new List<string>();
        if (options.Count == 0)
            options = new List<string> { "breath", "calm", "stressball", "walk" };

        foreach (var option in options)
        {
            helpPanel.Children.Add(AppUi.AsyncButton(HelpOptionLabel(option), async () => await RunHelpOptionAsync(option), quiet: true));
        }
        helpPanel.Children.Add(AppUi.Button("👥 Wie werkt er vandaag?", () => Navigation.PushAsync(new WieWerktErPage()), quiet: true));
        helpPanel.Children.Add(AppUi.Button("🆘 Mijn helpkaart bekijken", () => Navigate(FeatureKind.SafetyPlan), quiet: true));
        helpPanel.Children.Add(AppUi.AsyncButton("📱 Een seintje aan mijn contact voorbereiden", SendSignalAsync, quiet: true));
        helpPanel.Children.Add(AppUi.Label("Er wordt niets automatisch verzonden. Jij kiest zelf of je een bericht opent en verstuurt.", muted: true));
        helpPanel.IsVisible = true;
    }

    static string FeelingEmoji(string feeling) => feeling switch { "Blij" => "😄", "Bedroefd" => "😢", "Boos" => "😠", "Bang" => "😨", _ => "🙂" };

    static string HelpOptionLabel(string key) => key switch
    {
        "breath" => "🫁 Samen rustig ademhalen",
        "calm" => "🛋️ Naar mijn rustplek",
        "music" => "🎧 Rustige muziek luisteren",
        "stressball" => "🧸 Pak mijn stressbal",
        "walk" => "🚶 Even rustig wandelen",
        "talk" => "💬 Met iemand praten",
        _ => "🆘 Mijn helpkaart openen"
    };

    async Task RunHelpOptionAsync(string key)
    {
        switch (key)
        {
            case "breath": await Navigation.PushAsync(new FeaturePage(FeatureKind.Breath)); break;
            case "calm": await Navigation.PushAsync(new FeaturePage(FeatureKind.Calm)); break;
            case "music": await Navigation.PushAsync(new FeaturePage(FeatureKind.Breath)); break;
            case "walk":
                AppUi.Speak("Als het veilig kan, loop rustig een klein rondje. Vraag hulp als je niet alleen naar buiten kunt.");
                await DisplayAlertAsync("Een kleine stap", "Als het veilig kan, loop rustig een klein rondje. Vraag hulp als je niet alleen naar buiten kunt.", "OK");
                break;
            case "stressball":
                AppUi.Speak("Pak je stressbal. Knijp rustig een paar keer en voel je voeten op de grond.");
                await DisplayAlertAsync("Een kleine stap", "Pak je stressbal. Knijp rustig een paar keer en voel je voeten op de grond.", "OK");
                break;
            case "talk": await Navigation.PushAsync(new WieWerktErPage()); break;
            default: await Navigation.PushAsync(new FeaturePage(FeatureKind.SafetyPlan)); break;
        }
    }

    async Task SendSignalAsync()
    {
        var plan = AppSession.Store?.Load<SafetyPlan>("plan", Guid.Empty) ?? new SafetyPlan();
        var contact = plan.Contacts.FirstOrDefault(c => !string.IsNullOrWhiteSpace(c.Phone));
        if (contact is null)
        {
            await DisplayAlertAsync("Eerst een contact toevoegen", "Vul bij 'Mijn helpkaart / plan' de naam en het telefoonnummer in van iemand die je vertrouwt.", "Mijn helpkaart openen");
            await Navigation.PushAsync(new FeaturePage(FeatureKind.SafetyPlan));
            return;
        }

        const string body = "Hoi, ik heb het nu moeilijk. Kun je contact met mij opnemen?";
        bool proceed = await DisplayAlertAsync("Een seintje voorbereiden", $"Er wordt een sms klaargezet voor {contact.Name}. De app verstuurt niets vanzelf. Je kunt in de Berichten-app zelf nog kiezen om te versturen.", "Sms openen", "Annuleren");
        if (!proceed) return;
        try
        {
            await Sms.Default.ComposeAsync(new SmsMessage(body, new[] { contact.Phone }));
        }
        catch (Exception ex)
        {
            AppLog.Write(ex);
            await DisplayAlertAsync("Sms niet geopend", "Je kunt je contact ook zelf bellen of een bericht sturen.", "OK");
        }
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        // Herbouw het dashboard na terugkeer uit Instellingen, zodat thema en tekstgrootte meteen gelden.
        if (AppSession.Store is not null) Build();
        AppSession.Touch();
        if (AppSession.Settings.Animations) { Opacity = 0; _ = this.FadeToAsync(1, 180, Easing.CubicOut); }
        if (_consentPrompted || AppSession.Store is null) return;
        if (AppSession.Store.All<ConsentRecord>("consent").Any(c => c.Version >= ConsentInfo.CurrentVersion)) { _consentPrompted = true; return; }
        _consentPrompted = true;
        const string text = "Mijn Gevoel is voor jou. Je dagboek, tekeningen, agenda en andere gegevens worden versleuteld op deze telefoon bewaard. Je begeleider ziet alleen wat jij zelf deelt. De app waarschuwt niemand en belt niemand. Je mag je gegevens meenemen of verwijderen. Vraag je begeleider wie verantwoordelijk is voor je gegevens en waar de privacyverklaring staat.";
        await DisplayAlertAsync("Voordat je begint", text, "Ik heb dit gelezen");
        var choice = await DisplayActionSheetAsync("Met wie gebruik je Mijn Gevoel?", "Nu niet", null, "Zelf", "Samen met mijn vertegenwoordiger of begeleider");
        if (choice == "Zelf" || choice == "Samen met mijn vertegenwoordiger of begeleider")
        {
            var consent = new ConsentRecord(Guid.NewGuid(), DateTime.Now, ConsentInfo.CurrentVersion, choice == "Zelf" ? "zelf" : "samen");
            AppSession.Store.Save("consent", consent.Id, consent);
        }
        else
        {
            await ((App)Application.Current!).LockToLoginAsync("Je kunt later toestemming geven door opnieuw in te loggen.");
        }
    }
}
