# Releasewijzigingen — Mijn Gevoel Android 2.0 (versionCode 20)

## Versie 2.0 — nieuwe gevoelsfuncties en release-inrichting

- Dagelijkse check-in met gekozen gevoel, intensiteit, aanleiding en optionele notitie.
- Gevoelskalender voor de laatste 30 dagen en dagdetails.
- Neutrale inzichten over 7 en 30 dagen, inclusief gemiddelde intensiteit en vaak gekozen gevoelens.
- Tekenen met kleuren en pendiktes, laatste lijn ongedaan maken en alles wissen.
- Check-ins opgenomen in het weekoverzicht, de privacytelling en leesbare JSON-export.
- De inzichtentelling sluit gegevens buiten de gekozen periode uit.
- Android-versie bijgewerkt naar `2.0` (version code `20`).
- Android-workflows en lokaal bouwscript bijgewerkt voor `.NET 10` / `net10.0-android`; tests en gedeelde core blijven op .NET 8.
- Een exporttest controleert nu ook dat check-ins blijven opgeslagen en in de export staan.

**Buildstatus:** alleen broncode is voorbereid en statisch gecontroleerd. Er is in deze werkomgeving geen .NET SDK beschikbaar; claim dus niet dat de release al compileert of op een toestel getest is. Voer de GitHub Release-workflow en daarna de acceptatietest uit.

---

# Releasewijzigingen — Mijn Gevoel 1.0.7 (versionCode 8)

## LVB-vriendelijke functies en beveiligde toegang

- **Vier duidelijke gevoelsknoppen:** blij, bedroefd, boos en bang zijn met grote knoppen en herkenbare emoji in te voeren. De keuze wordt privé en versleuteld opgeslagen. Bij een moeilijk gevoel verschijnen concrete helpopties uit de eigen helpkaart.
- **Persoonlijke helpkaart:** de cliënt kan vooraf kiezen welke hulpacties getoond worden. De seintje-knop opent een sms voor het vooraf ingestelde contact, maar verstuurt nooit automatisch.
- **Spraaknotities:** korte opnames van maximaal 60 seconden kunnen in het dagboek of bij het van-me-afschrijven worden opgenomen, afgespeeld en verwijderd. Bestanden worden als WAV opgenomen voor brede compatibiliteit en worden daarna in de versleutelde kluis opgeslagen. Opnames blijven op het toestel tenzij de gebruiker ze zelf exporteert of deelt.
- **Voorlezen:** uitleg bij functies heeft een voorleesknop; bestaande grote kaarten en invoerschermen behouden eenvoudige taal en visuele ondersteuning.
- **Eenvoudig weekoverzicht:** de laatste zeven dagen tonen per dag de laatst gekozen stemming met kleurblokken, plus een eenvoudig samenvattingsoverzicht.
- **Visuele ademhalingshulp en rustige meldingen:** een cirkel groeit en krimpt met het ademritme. De app toont geen onverwachte agenda-pop-ups; afspraken zijn nog steeds in de agenda zichtbaar.
- **Biometrisch terug ontgrendelen:** als de gebruiker bij aanmelden ‘Op dit toestel ingelogd blijven’ kiest, wordt de reeds geverifieerde kluissleutel versleuteld in Android SecureStorage bewaard. Na automatische vergrendeling vraagt de app om vingerafdruk/gezichtsherkenning waar het toestel dit ondersteunt. Bij annuleren of niet beschikbaar zijn blijft gewone login mogelijk. Wachtwoord en authenticatorcode worden niet bewaard. Uitloggen, wachtwoord wijzigen of account verwijderen wist de bewaarde sessie.
- **Google Play App Bundle:** de Release-workflow bouwt naast de ondertekende APK nu ook een ondertekende AAB voor een mogelijke interne test via Google Play Console. De AAB is niet rechtstreeks installeerbaar; deze is bedoeld om in Play Console te uploaden.
- **Privacy:** er wordt niets automatisch naar begeleiders of ouders verzonden. De app deelt geen stemming of spraaknotities zonder een expliciete actie van de gebruiker.
- Bestaande 17 unit-/security-tests blijven onderdeel van de CI-build.

Deze bronupdate moet nog door GitHub Actions worden gecompileerd en daarna op een Android-telefoon worden getest. De biometrische prompt is een extra toegangspoort; de opgeslagen kluissleutel is versleuteld via Android SecureStorage, maar in deze versie niet cryptografisch aan een biometriehardware-sleutel gekoppeld.


## Versie 1.0.8 (versionCode 9)

- **Copyrightvermelding toegevoegd:** `© 2026 Jordy Ham. Alle rechten voorbehouden.` is zichtbaar onderaan het aanmeldscherm en beginscherm en in Instellingen onder **Over Mijn Gevoel**.
- De Windows-instellingen tonen dezelfde copyrightvermelding onder **Over Mijn Gevoel**.
- Dit is een kleine onderhoudsupdate; de bestaande appfuncties en lokale gegevensstructuur zijn niet bewust gewijzigd.
- De Android-build moet nog via GitHub Actions worden uitgevoerd en op een toestel worden gecontroleerd.


## Versie 1.1.0 — geplande/broncode-update Android
- Dagelijkse check-in met gevoelsintensiteit, aanleiding en optionele notitie.
- Gevoelskalender voor de afgelopen 30 dagen.
- Inzichten over 7 en 30 dagen.
- Tekenen met kleur en pendikte, laatste lijn ongedaan maken en alles wissen.
- Check-ins opgenomen in gegevens-export en weekoverzicht.
- Status: broncode aangepast; build en fysieke toesteltests nog vereist.
