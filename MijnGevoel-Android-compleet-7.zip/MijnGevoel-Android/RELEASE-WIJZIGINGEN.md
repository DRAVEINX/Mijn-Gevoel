# Release-kandidaat 1.0.2 (build 3)

- Tekenscherm aangepast: de GraphicsView staat niet langer in de pagina-ScrollView; Android kan daardoor vingerbewegingen doorgeven zonder dat de scrollcontainer de tekenbeweging overneemt.
- Tekenen wordt afgebroken als de aanraking door Android wordt geannuleerd.
- Verouderde .NET MAUI-aanroepen `DisplayAlert` en `DisplayActionSheet` vervangen door de asynchrone API's.
- De verouderde `Application.MainPage`-instelling vervangen door `Application.CreateWindow`.
- GitHub Actions-workflows bijgewerkt naar versies met Node.js 24-runtime.
- Android-weergaveversie verhoogd naar 1.0.2 en interne versiecode naar 3, zodat dit als update boven versie 1.0.1 kan worden geïnstalleerd met dezelfde releasesleutel.

De code is statisch gecontroleerd, maar moet nog in GitHub Actions worden gecompileerd en op een Android-telefoon worden getest.

## Herstel na buildcontrole
- De tekenpagina gebruikt nu het tekenvlak zelf als flexibele Grid-rij in plaats van een vaste rij-index.
- GraphicsView heeft `EnableTouchEvents` expliciet ingeschakeld, zodat vingerbewegingen worden verwerkt.
- De Grid-indeling is aangepast om te bouwen met de MAUI 10 `IView`-API.


## Versie 1.0.3 (Android)
- De ademhalingsoefening speelt standaard een zachte, originele instrumentale achtergrondmuziek af.
- Muziek kan aan of uit worden gezet tijdens de oefening.
- De muziek stopt wanneer de oefening stopt of wanneer de gebruiker het scherm verlaat.
- De muziek is ingebouwd in de app en werkt zonder internetverbinding.
