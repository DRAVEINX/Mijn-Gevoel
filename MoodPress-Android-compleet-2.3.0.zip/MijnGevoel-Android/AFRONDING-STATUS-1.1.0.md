# MoodPress Android 1.1.0 — afrondingsstatus

## Wat in deze broncode is opgenomen
- Dagelijkse gevoelscheck-in met gevoel, intensiteit, aanleiding en optionele notitie.
- Gevoelskalender met de laatste 30 dagen en opgeslagen check-ins.
- Inzichten over 7 en 30 dagen, gebaseerd op eigen check-ins.
- Check-ins opgenomen in de gegevens-export en het weekoverzicht.
- Tekenen: kleuren, pendiktes, laatste lijn ongedaan maken en alles wissen.
- Correctie: eerder getekende lijnen behouden hun eigen kleur en pendikte wanneer een nieuwe kleur of pendikte wordt gekozen.
- Android-versienummer verhoogd naar 1.1.0 (version code 11).

## Controles uitgevoerd in deze werkomgeving
- ZIP-structuur gelezen en bronbestanden aangepast.
- Alle `.csproj`-bestanden konden als XML worden geparseerd.
- Nieuwe functiepagina's zijn aan het dashboard en de feature-router gekoppeld.
- Verwijzingen naar de check-in zijn toegevoegd aan export en weekoverzicht.
- De tekenlogica gebruikt parallelle lijsten voor punten, kleur en pendikte; verwijderen/alles wissen/opslaan maakt deze lijsten samen leeg of korter.

## Wat NIET als geslaagd kan worden gemeld
De .NET SDK (`dotnet`) is niet geïnstalleerd in deze werkomgeving. Daarom is hier geen echte C#-compilatie uitgevoerd en is er geen nieuwe APK gebouwd. Ook kan deze omgeving geen test op een fysieke Android-telefoon uitvoeren. Dit bestand claimt dus niet dat de APK al compileert of dat runtime-tests geslaagd zijn.

## Volgende stappen op een Windows-pc met .NET MAUI
1. Pak dit ZIP-bestand uit in een nieuwe map; overschrijf de vorige werkende broncode niet.
2. Open PowerShell in de map `MijnGevoel-Android`.
3. Controleer installatie:
   ```powershell
   dotnet --info
   dotnet workload list
   ```
4. Herstel workloads indien nodig:
   ```powershell
   dotnet workload restore .\MijnGevoel.Android\MijnGevoel.Android.csproj
   ```
5. Bouw eerst de Android-debugversie:
   ```powershell
   dotnet build .\MijnGevoel.Android\MijnGevoel.Android.csproj -f net10.0-android -c Debug
   ```
   Als het projectbestand een andere Android target framework-versie vermeldt, gebruik dan die versie.
6. Als de build faalt, bewaar de volledige uitvoer en los de eerste compileerfout op voordat je verdergaat.
7. Installeer de debug-APK op een testtoestel en doorloop de acceptatietests in `ANDROID-ACCEPTATIETEST.md`.
8. Bouw pas na geslaagde tests de release:
   ```powershell
   dotnet publish .\MijnGevoel.Android\MijnGevoel.Android.csproj -f net10.0-android -c Release
   ```
9. Controleer de ondertekening en installeer de release-APK. Houd de bestaande APK als terugvaloptie.

## Verplichte acceptatietests voor deze upgrade
- Check-in opslaan met en zonder notitie.
- Check-in blijft aanwezig na app afsluiten en opnieuw openen.
- Kalender toont opgeslagen gegevens op de juiste dag en een leeg resultaat op dagen zonder gegevens.
- Inzichten tellen alleen check-ins binnen de gekozen periode.
- Export bevat de check-ins en blijft leesbaar.
- Tekenen met twee verschillende kleuren en pendiktes; controleren dat eerdere lijnen hun eigen stijl behouden.
- Laatste lijn ongedaan maken; alle lijnen wissen; lege tekening niet opslaan.
- Na opslaan verschijnt de tekening in de galerij met alle kleuren.
- Privacyvergrendeling, accountverwijdering, back-up/herstel en bestaande schermen opnieuw testen.
