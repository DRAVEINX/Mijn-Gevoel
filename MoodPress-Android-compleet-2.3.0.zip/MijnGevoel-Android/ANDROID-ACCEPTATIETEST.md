## Extra visuele acceptatietest — MoodPress 2.2.2

- [ ] Installeer de nieuwe APK als update met dezelfde ondertekeningssleutel.
- [ ] Controleer op het startscherm van Android of het hart/vinger-logo wordt getoond; herstart zo nodig de launcher als het oude icoon in cache blijft.
- [ ] Bij het openen toont het merkscherm het logo, “MoodPress”, “Druk op je gevoel” en de cursieve slogan in drie regels.
- [ ] Open Home en controleer de vier kleurtegels, hun teksten en de navigatie onderaan.
- [ ] Stel in MoodPress de grootste tekstgrootte in; controleer dat knopteksten kunnen afbreken en geen acties buiten het scherm drukken.
- [ ] Open Routines en herinneringen; controleer dat Wijzigen, Aan/Uit en Weggooien op drie volledige knoppen passen.
- [ ] Open Tekenen en controleer het tekenvak, kleuren en pendiktes.
- [ ] Doorloop login, biometrie, vergrendeling en het privacy-scherm.

---

# Acceptatietest — MoodPress Android

Vink elke test pas af als die op een echte Android-telefoon en/of emulator is uitgevoerd. Broncode alleen is geen bewijs dat een test is geslaagd.

## Installatie en opstarten
- [ ] Debug-APK bouwt zonder fouten.
- [ ] APK kan worden geïnstalleerd en gestart op de ondersteunde Android-versie.
- [ ] App start opnieuw zonder vastlopen na sluiten en heropenen.
- [ ] Android-systeemterugknop navigeert logisch terug.

## Account en beveiliging
- [ ] Account aanmaken met een korte gebruikersnaam wordt geweigerd.
- [ ] Wachtwoord korter dan 10 tekens wordt geweigerd.
- [ ] QR-code werkt in een authenticator-app.
- [ ] Een foutieve registratiecode activeert het account niet.
- [ ] Een juiste code bevestigt registratie en maakt inloggen mogelijk.
- [ ] Een verkeerde wachtwoord/code-combinatie geeft geen toegang.
- [ ] Vijf foutieve aanmeldingen leiden tot tijdelijke vertraging.
- [ ] Een geldige herstelcode kan precies eenmaal worden gebruikt.
- [ ] Vernieuwde herstelcodes werken; de oude zijn niet meer geldig.
- [ ] Een gewijzigd wachtwoord werkt bij de volgende aanmelding.
- [ ] Automatisch vergrendelen gebeurt na de ingestelde inactiviteit.
- [ ] Naar de achtergrond gaan vergrendelt de actieve sessie.
- [ ] Schermafbeeldingen blokkeren aan/uit werkt via `FLAG_SECURE` op Android.

## Gegevens en functies
- [ ] Dagboek: opslaan, openen, wijzigen, nieuw en verwijderen.
- [ ] Van me afschrijven: opslaan, openen en verwijderen.
- [ ] Gezichtjes: juiste schaal 1–5 zichtbaar in week- en mood-overzicht.
- [ ] Stoplicht: groen/oranje/rood, redenen, behoeften en tekst blijven na opnieuw inloggen aanwezig.
- [ ] Stoplichtgeschiedenis: openen en verwijderen.
- [ ] Plan: contacten en wat helpt bewaren.
- [ ] Agenda: datum, tijd, pictogram, klaarzetten en verwijderen.
- [ ] Vandaag/morgen toont de juiste agenda-items.
- [ ] Timer start, pauzeert, hervat en eindigt.
- [ ] Ademhalingsscherm kan gestart en gestopt worden.
- [ ] Rusttips, prikkelmeter en lichaamsmeter bewaren data.
- [ ] Stappenplannen: standaardplannen, eigen plan, bewerken, uitvoeren en verwijderen.
- [ ] Gevoelswoorden worden getoond en voorlezen werkt op het apparaat.
- [ ] Basis- en eigen kaarten werken; eigen kaarten kunnen verwijderd worden.
- [ ] Gesprekskaart bewaren, tonen en delen werkt.
- [ ] Tekening kan met vinger worden gemaakt, bewaard, teruggezien en verwijderd.
- [ ] Delen met begeleider werkt met versleuteld `.mgdeel`, versleutelde HTML en expliciet bevestigde gewone tekst.
- [ ] Back-up wordt gedeeld/exporteert en bevat geen leesbare gegevensbestanden.
- [ ] Back-up terugzetten slaat bestaande bestanden over en accepteert geen paden buiten de backup-map.
- [ ] JSON-export heeft alle relevante onderdelen en wordt vooraf als leesbaar gewaarschuwd.
- [ ] Account verwijderen wist accountbestand en gegevensbestanden; daaropvolgend inloggen lukt niet.

## Privacy en stabiliteit
- [ ] Opslag staat binnen `FileSystem.AppDataDirectory`.
- [ ] Geen gevoelige data verschijnt in foutlogbestanden.
- [ ] Delen vraagt alleen om de data die de gebruiker aanvinkt.
- [ ] Test met vliegtuigstand: kernfuncties blijven offline werken, behalve authenticator-app buiten deze app.
- [ ] Test op kleine telefoon en groot lettertype: geen bedieningsknoppen zijn onbereikbaar.
- [ ] Test van schermrotatie, app naar achtergrond, inkomende oproep en hervatten.

**Releasecriteria:** alle relevante tests zijn uitgevoerd en geslaagd, kwetsbaarheden zijn beoordeeld, privacyverklaring/toestemming zijn gecontroleerd en de APK is met een eigen release-keystore ondertekend.


## Aanvulling voor Android 1.0.7 — LVB, spraak en biometrie

Voer deze tests uit met een testaccount en zonder gevoelige echte cliëntgegevens totdat alles is goedgekeurd.

- [ ] Dashboard: alle vier grote gevoelens (blij, bedroefd, boos, bang) zijn leesbaar en kunnen worden opgeslagen. Een moeilijk gevoel toont de helpopties uit Mijn plan.
- [ ] Helpkaart: stel twee hulpopties en één contact in. De SMS-knop vraagt eerst toestemming en opent alleen de sms-app; er wordt niets automatisch verstuurd.
- [ ] Voorlezen: de knop leest de uitleg voor wanneer Voorlezen in Instellingen aan staat. Na uitzetten verdwijnt de knop.
- [ ] Spraaknotitie: geef microfoontoestemming, neem een korte WAV-notitie op, speel deze af en verwijder hem. Herstart de app en controleer dat bewaarde audio nog kan worden afgespeeld.
- [ ] Privacy: maak een versleutelde back-up en controleer dat de app de leesbare export als niet-versleuteld waarschuwt. Deel een export niet zonder toestemming.
- [ ] Ademhalen: de cirkel wordt groter bij inademen en kleiner bij uitademen. Controleer muziek met de 5-seconden test, zet de muziek uit, start/stop de oefening en controleer dat muziek bij verlaten van het scherm stopt.
- [ ] Geen onverwachte pop-ups: laat de agenda-tijd verstrijken terwijl de app open is; er mag geen onverwacht agenda-venster verschijnen. De automatische vergrendeling blijft wel werken.
- [ ] Ingelogd blijven: vink dit aan bij login op een eigen testtelefoon met ingestelde vingerafdruk/gezichtsherkenning. Laat de app automatisch vergrendelen; biometrie moet de sessie heropenen. Annuleer de prompt en controleer dat de gewone login beschikbaar blijft.
- [ ] Uitloggen: kies “Uitloggen en sessie vergeten” en controleer dat biometrie niet terug kan inloggen zonder de gewone login.
- [ ] Google Play: als het AAB wordt gebruikt, upload het alleen naar een testtrack in Play Console. Het AAB-bestand is niet de APK voor handmatige installatie.


## Android 2.0 — check-ins, kalender, inzichten en tekenen
- [ ] Dagelijkse check-in slaat gevoel, intensiteit, aanleiding en notitie op.
- [ ] Check-ins blijven na afsluiten en opnieuw inloggen beschikbaar.
- [ ] Gevoelskalender toont de juiste dagen en toont details van de gekozen dag.
- [ ] Inzichten tellen alleen de laatste 7 en 30 dagen en geven geen diagnose.
- [ ] Leesbare export bevat de nieuwe check-ins en toont vooraf een waarschuwing.
- [ ] Tekenkleur en pendikte werken zichtbaar op het canvas.
- [ ] Laatste lijn ongedaan maken verwijdert alleen de meest recente lijn.
- [ ] Alles wissen maakt het canvas leeg; daarna kan een nieuwe tekening worden gemaakt.
- [ ] Opgeslagen PNG toont de gekozen kleur en pendikte.
- [ ] Bestaande tekeningen en andere bestaande gegevens blijven leesbaar.


## Extra controle voor MoodPress 2.0.1 — tekenen
- Open **Tekenen**.
- Kies een kleur en pendikte.
- Tik op **Begin met tekenen** en controleer dat het witte tekenvak direct zichtbaar is.
- Teken met je vinger minstens twee lijnen.
- Controleer **Ongedaan maken**, **Alles wissen**, teruggaan naar kleur/pendikte en **Tekening bewaren**.
- Open **Mijn tekeningen** en controleer of de opgeslagen tekening zichtbaar is.
