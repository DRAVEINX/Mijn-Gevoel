# MoodPress 2.3.0 — roadmap upgrade

## In deze update

- Android app version `2.3.0`, versionCode `27`; previous 2.2.2 files are not overwritten by the package.
- More robust icon foreground framing and text wrapping/auto-sizing from 2.2.3 are retained.
- Child profile: visual daily schedule, per-day routine checklist, optional text-to-speech, trusted-contact help card, clear-this-day confirmation, routine proposal approval.
- Teen profile: private stress check-ins, boundary phrases, online-safety plan, 30-day self-reflection (not a diagnosis), delete individual check-ins.
- Adult profile: optional target dates, small goals and steps, optional positive reflection, 7/30-day energy averages, delete individual entries, explicitly confirmed sharing.
- Offline supporter section: separate local PIN, local encrypted help plan, encrypted snapshot import/export, explicit item selection and share-consent log, local supporter audit, conversation guide, color/stress explainer.
- Privacy data export contains teen check-ins, teen safety plan, adult goals and reflections, energy records, routine progress and share consent history.
- Support packages validate bounds and selected content; raw share-code length is limited before key derivation.
- Regression tests added for v2 encrypted-package round trips, invalid stress values, legacy AdultGoal JSON compatibility, consent labels and day-specific child routine progress.

## Important boundaries

This version implements the offline/local roadmap and manual encrypted snapshot exchange. It does **not** implement live linked accounts, cloud synchronization, a server-issued one-time pairing code, remotely enforced revocation or a remote cross-device access log. These require a real backend, authentication, data-protection rules and security review. The local log only records events on the device where they occur. A snapshot that has already been sent cannot be recalled by the app.

The app must not be presented as an alarm service. It does not automatically alert parents or supporters when a user picks red or records high stress.

## Validation status

Static source checks and archive validation are run before delivery. This environment has no .NET SDK, so the C# unit tests, Android compile, signed APK and AAB are **not** claimed as passed until the 2.3.0 GitHub Actions workflows finish green. Then perform on-device smoke tests on the icon, large text, child schedule, sharing, restore and existing drawing function.
