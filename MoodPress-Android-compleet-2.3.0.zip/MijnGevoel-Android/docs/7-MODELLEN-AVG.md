# Modellen voor de organisatie (AVG) - invullen en laten controleren door de FG

## A. Register van verwerkingsactiviteiten (art. 30)
| Onderdeel | Invullen |
|---|---|
| Verwerkingsverantwoordelijke (naam, adres, contact) | *(organisatie)* |
| Functionaris gegevensbescherming (contact) | *(naam/e-mail)* |
| Naam verwerking | MoodPress (cliëntapp voor tekenen, dagboek, agenda, stoplicht) |
| Doel | Cliënt ondersteunen bij uiten en bijhouden van gevoelens en afspraken; hulp kunnen vragen |
| Categorieën betrokkenen | Cliënten (kwetsbare personen) |
| Categorieën gegevens | Gebruikersnaam; dagboek, briefjes, tekeningen, agenda, stoplichtmeldingen (welzijn/gezondheid), noodplan met contactpersonen, toestemming, instellingen |
| Bijzondere categorieën | Ja (gezondheid/welzijn) |
| Grondslag (art. 6) en uitzondering (art. 9) | *(vast te stellen)* |
| Ontvangers | Geen standaard. Alleen begeleiders aan wie de cliënt zelf een deelbestand geeft |
| Doorgifte buiten EU | Geen door de app. Let op gekozen kanalen (WhatsApp, e-mail) |
| Bewaartermijn | Bepaalt cliënt; bij einde gebruik verwijderen *(termijn vastleggen)* |
| Beveiligingsmaatregelen | AES-256-GCM, Argon2id, TOTP, herstelcodes, auto-lock, BitLocker op computers, toegangsbeleid, toetsing (docs/1) |

## B. Toestemmingsverklaring (eenvoudige taal; aan te passen)
**Voor wie:** cliënt, eventueel samen met vertegenwoordiger/begeleider.
- Ik snap dat MoodPress mijn tekeningen, dagboek, agenda en stoplicht bewaart op mijn computer.
- Ik snap dat alleen ik het kan lezen. Mijn begeleider ziet alleen wat ik zelf deel.
- Ik snap dat MoodPress niemand waarschuwt. Als ik hulp nodig heb, vertel ik het zelf aan iemand of deel ik het.
- Ik mag alles bekijken, meenemen, aanpassen of weghalen. Ik mag altijd stoppen. Dat is goed voor mij en mijn zorg.
- Ik geef toestemming. ☐ Zelf ☐ Samen met: ______________ (naam vertegenwoordiger/begeleider)
Datum: ________ Handtekening of kruisje: ________
*Toestemming in de app wordt automatisch vastgelegd met datum en wijze. Op papier is dit formulier een aanvulling voor wie dat wil. Beoordeel wilsbekwaamheid en betrek zo nodig de wettelijk vertegenwoordiger.*

## C. Datalekprocedure (art. 33-34)
1. **Melden:** iedereen meldt een (vermoed) lek direct bij *(contactpersoon/FG)*, bijvoorbeeld: verloren computer, deelbestand naar verkeerde persoon, geraden of gedeelde code, gestolen herstelcodes.
2. **Beoordelen** (binnen 24 uur): welke gegevens, hoeveel cliënten, was het versleuteld (AES-256: een gestolen computer zonder wachtwoord + tweede factor is meestal laag risico), kans op schade.
3. **Melden aan de Autoriteit Persoonsgegevens:** binnen **72 uur** na ontdekking, tenzij het lek waarschijnlijk geen risico oplevert. Leg altijd het besluit vast.
4. **Melden aan betrokkenen** (in begrijpelijke taal) bij waarschijnlijk **hoog risico**.
5. **Maatregelen:** deelcode/herstelcodes vernieuwen (Instellingen), wachtwoord wijzigen, bestanden wissen, nieuwe deelbestanden maken.
6. **Registreren** in het datalekregister, evalueren en verbeteren.
*Als de organisatie onder de Cyberbeveiligingswet valt, gelden daarnaast eigen meldplichten voor significante incidenten. De softwaremaker kan onder de CRA meldplichten hebben voor actief misbruikte kwetsbaarheden.*

## D. Procedure rechten van betrokkenen (art. 12-22)
- Verzoek kan mondeling of schriftelijk, ook via begeleider. Controleer de identiteit zonder extra gegevens te vragen.
- **Antwoord binnen 1 maand** (verlengbaar met 2 maanden bij complexe verzoeken, met uitleg).
- Antwoord in eenvoudige taal, kosteloos.
- Inzage/overdracht: cliënt gebruikt "Mijn privacy" (export, back-up). Wil de cliënt hulp, dan helpt een begeleider zonder zelf mee te lezen.
- Wissen: cliënt gebruikt "Alles weghalen en stoppen". Leg uit dat eerder gemaakte exports/back-ups/deelbestanden en verstuurde chatberichten apart verwijderd moeten worden.
- Registreer verzoeken en afhandeling. Wijs op het klachtrecht bij de Autoriteit Persoonsgegevens.

## E. Checklist verwerkersovereenkomst (art. 28) - alleen nodig bij server/hosting/support met toegang
Onderwerp en duur; aard en doel; soort gegevens; instructies alleen van verantwoordelijke; geheimhouding; beveiliging (art. 32); sub-verwerkers met toestemming; bijstand bij rechten, datalekken en DPIA; teruggave/verwijdering; audits; geen doorgifte buiten de EU zonder grondslag.

## F. Bewaartermijnen (voorstel, door organisatie vast te stellen)
| Gegevens | Voorstel |
|---|---|
| Gegevens in de app | Zolang cliënt de app gebruikt; cliënt kan altijd wissen |
| Deelbestanden bij begeleiders | Verwijderen na gebruik; niet bewaren in dossier zonder aparte grondslag |
| Back-ups en exports | Cliënt beheert; adviseer verwijderen als niet meer nodig |
| Datalek-/verzoekregister | *(bijv. 5 jaar; laten bepalen)* |

## G. Aanvulling register (versie 1.0.4)
Extra gegevens die de cliënt zelf invult en alleen lokaal en versleuteld worden bewaard: stappenplannen, prikkelmeter en lichaamsmeldingen (welzijn/gezondheid), eigen kaarten, gesprekskaart, instellingen voor lettertype en toegankelijkheid. Grondslag, doel en bewaartermijn gelden zoals in onderdeel A. De weekoverzicht-pagina rekent alleen lokaal en deelt niets.
