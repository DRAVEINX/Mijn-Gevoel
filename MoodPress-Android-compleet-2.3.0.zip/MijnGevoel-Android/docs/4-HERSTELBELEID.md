# Herstelbeleid: telefoon en herstelcodes kwijt

**Probleem:** MoodPress is zo gemaakt dat niemand (ook niet de maker of organisatie) de gegevens kan openen zonder wachtwoord + authenticator of herstelcode. Dat is veilig, maar kwijtraken van alles betekent dat gegevens verloren zijn.

## Wat de app nu doet
- Bij registreren: 8 eenmalige herstelcodes, met **printen** en een verplicht vinkje "ik heb ze opgeschreven".
- Herstellen: met één code kiest de cliënt een nieuw wachtwoord en koppelt de authenticator opnieuw.
- Instellingen > **Nieuwe herstelcodes maken** (wachtwoord nodig); de oude werken dan niet meer.
- Op het beginscherm een waarschuwing als er nog 2 of minder codes zijn.
- **Back-up** (versleuteld) maken en terugzetten; de back-up helpt niet zonder toegangsgegevens.

## Keuzes voor de organisatie (kies bewust, leg vast)
| Optie | Voordeel | Nadeel |
|---|---|---|
| A. Alleen de cliënt bewaart de codes (standaard) | Maximale privacy | Verlies = gegevens kwijt |
| B. Cliënt bewaart codes zelf én geeft een tweede set aan een vertrouwde persoon (verzegelde envelop) | Minder kans op verlies | Die persoon kan in principe toegang krijgen; alleen met uitdrukkelijke keuze en toestemming van de cliënt |
| C. Begeleiders helpen bij opbergen (bijv. afgesloten kast per cliënt) | Praktisch voor wie moeite heeft met bewaren | Zelfde afweging als B; toegang tot de kast moet streng geregeld |

**Aanbeveling:** A als standaard, B alleen als de cliënt dat zelf wil en begrijpt. Registreer dat besluit en hoe vaak een envelop is geopend. Maak nooit een "achterdeur" in de software; dat ondermijnt de veiligheid voor iedereen.

## Praktische afspraken
- Codes op papier, niet op dezelfde computer of in de cloud; niet fotograferen.
- Bij registratie begeleid: begeleider helpt bij opschrijven, kijkt niet mee naar wachtwoord.
- Jaarlijks controleren of de codes nog bestaan en nog twee of meer codes over zijn.
- Verloren codes én telefoon: nieuw account maken; oude gegevens zijn onleesbaar. Leg dit bij de start uit (in eenvoudige taal).
