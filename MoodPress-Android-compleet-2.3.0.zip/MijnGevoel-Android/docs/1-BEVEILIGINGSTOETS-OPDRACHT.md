# Opdracht externe beveiligingstoets - MoodPress

> Dit document is een startpunt om een externe partij (pentest-/securitybureau) opdracht te geven. De toets zelf moet door een onafhankelijke, ervaren partij worden uitgevoerd. Deze documenten vervangen die toets niet.

## 1. Wat wordt getest
Windows-programma "MoodPress" (WPF/.NET 8, zelfstandige .exe) met lokale, versleutelde opslag. Broncode wordt beschikbaar gesteld (whitebox/greybox aanbevolen).

## 2. Waarom is dit gevoelig
Dagboek, tekeningen, agenda en stoplichtmeldingen (hoe het met iemand gaat en waarom) van kwetsbare cliënten. Dit zijn bijzondere persoonsgegevens (gezondheid/welzijn).

## 3. Dreigingsmodel (wat willen we tegenhouden)
| Aanvaller | Voorbeeld | Beoogde bescherming |
|---|---|---|
| Huisgenoot/medebewoner/familie met toegang tot de computer | Zit achter een ontgrendelde of verloren computer | Automatisch vergrendelen; gegevens versleuteld; sleutel uit geheugen gewist bij vergrendelen |
| Dief met de schijf (offline) | Kopieert `%LocalAppData%\MijnGevoel` | AES-256-GCM; sleutel alleen via Argon2id-wachtwoord of herstelcode |
| Aanvaller die wachtwoord kent/raadt | Phishing, gokken | Tweede factor (TOTP), blokkade, geen hergebruik van codes |
| Kwaadaardig bestand | Gemanipuleerd back-up- of deelbestand | Zip-slip bescherming; AES-GCM-authenticatie; wrong-code => geen informatie |
| Malware op dezelfde computer onder dezelfde gebruiker | Keylogger, geheugen uitlezen | **Buiten scope van bescherming** (alleen mitigaties); expliciet beoordelen |

## 4. Te testen onderdelen (minimaal)
1. Inloggen: omzeilen van wachtwoord/TOTP, lockout-omzeiling, replay van TOTP-code, timing/gebruikersopsomming, herstelcode-flow, `ConfirmRegistration`-misbruik.
2. Cryptografie: correct gebruik van Argon2id-parameters, AES-GCM (nonce-uniekheid, AAD-binding), sleutelhiërarchie (kluissleutel, herstelslots), nulstellen van sleutels in geheugen.
3. Opslag: bestandsrechten onder `%LocalAppData%`, atomisch schrijven, verwijderen (`SecureDelete`), terugdraaien/verwisselen van bestanden.
4. Back-up en terugzetten: zip-slip, overschrijven van bestaande accounts, kwaadaardige archieven.
5. Deelbestanden (.mgdeel): sterkte van de deelcode (12 tekens, ~59 bit + Argon2id), manipulatie, JSON-deserialisatie, informatielekkage in bestandsstructuur.
6. UI/Windows: schermopname/klembord/afdrukken van herstelcodes, crash-meldingen zonder gevoelige info, auto-lock bij pen-/touch-invoer, taakbalk/voorbeeldvensters.
7. Supply chain: gebruikte pakketten (Konscious.Security.Cryptography.Argon2, QRCoder, System.Speech), reproduceerbare build, code signing, updatemechanisme (ontbreekt nog).

## 5. Bekende beperkingen (eerlijk vooraf delen met de tester)
- De lockout-teller staat in het accountbestand: een aanvaller met schrijfrechten kan die resetten. Bescherming offline rust op Argon2id en de sterkte van het wachtwoord.
- Wachtwoorden en sleutels bestaan tijdelijk als .NET-strings/arrays in het geheugen (`PasswordBox`-waarde, `string`); geheugenforensiek is niet uitgesloten.
- Geen hardware-gebonden sleutel (TPM/Windows Hello) en geen Windows-gebruikersprofiel-koppeling (DPAPI) in deze versie.
- TOTP gebruikt SHA-1 (standaard voor authenticator-apps).
- Geen auto-update; geen geverifieerde code-signing tot de organisatie een certificaat heeft.

## 6. Oplevering van de tester
Management-samenvatting in gewone taal, bevindingen met ernst (bv. CVSS), reproduceerbare stappen, advies per bevinding, **hertest** na herstel, en een verklaring van wat wel/niet is getest.

## 7. Praktisch
- Kies een partij met ervaring in zorg/privacy en vraag om referenties; laat de organisatie (FG/CISO) de opdracht aanvaarden.
- Laat ook de toegankelijkheid toetsen (WCAG 2.2 / EN 301 549) en, als het in de zorg wordt gebruikt, de relevante NEN 7510-eisen.
- Lever aan: broncode, bouwinstructies (`bouwen.bat`), testaccounts en dit document.
