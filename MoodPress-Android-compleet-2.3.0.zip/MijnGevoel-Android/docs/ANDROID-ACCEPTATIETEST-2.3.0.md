# MoodPress Android 2.3.0 — acceptatietest op echt toestel

Voer deze lijst uit nadat beide GitHub Actions-workflows groen zijn. Doe de tests eerst op een toestel met een back-up; gebruik geen echte bijzonder gevoelige informatie in een test-share.

## Installatie en pictogram
- [ ] Installeer de ondertekende APK over 2.2.2 met dezelfde sleutel; controleer dat de Android package-id gelijk blijft.
- [ ] Controleer het pictogram op startscherm, app-lade en recente apps: geen afgesneden hart/vinger, logo netjes gecentreerd in ronde én vierkante maskers.
- [ ] Open de app, vergrendel en ontgrendel, sluit af en start opnieuw.

## Tekst en toegankelijkheid
- [ ] Zet Android-tekstgrootte op normaal, groot en extra groot; controleer startscherm, kaarten, instellingen, deelpakket, ouder/begeleiderscherm en foutmeldingen.
- [ ] Controleer lange woorden, URL's, namen, lange notities en Nederlands met accenten; geen tekst mag onbereikbaar buiten het scherm vallen.
- [ ] Test voorlezen op dagschema en stoplichtuitleg; zet voorlezen uit in instellingen en controleer dat er niet ongevraagd wordt voorgelezen.
- [ ] Test hoog contrast/donker thema, brede regels en grotere tekst als deze instellingen beschikbaar zijn.

## Tekenen, dagboek en routines — regressie
- [ ] Maak een tekening met meerdere kleuren en diktes, wis/annuleer waar beschikbaar, bewaar en open opnieuw.
- [ ] Schrijf en open een dagboekstuk, spraaknotitie en gewone notitie.
- [ ] Maak/ wijzig/verwijder een routine en controleer een herinnering met eigen dagen/tijd. Verifieer de Android-meldingsmachtiging.
- [ ] Maak een back-up en herstel hem naar een aparte testaccount of na bevestigde back-up; controleer dat bestaand bestand niet stil wordt overschreven.

## Kindprofiel
- [ ] Kies Profiel > Kind en controleer de snelkoppelingen.
- [ ] Voeg twee activiteiten toe, vink er één af en controleer dat de status wordt bewaard.
- [ ] Vink routinestappen af; controleer dat voortgang per datum gescheiden blijft.
- [ ] Reset voortgang voor één dag; controleer dat andere dagen intact blijven.
- [ ] Test dagschema voorlezen en helpcontacten uit de eigen helpkaart.

## Jongerenprofiel
- [ ] Maak stresscheck-in; sluit en open opnieuw om te controleren dat deze privé bewaard is.
- [ ] Toon een grens-zin, sla een online-veiligheidsplan op en wijzig dit.
- [ ] Controleer 30-dagen samenvatting, verwijder één check-in en kijk of de aantallen aanpassen.

## Volwassenenprofiel
- [ ] Maak een doel zonder streefdatum én één met streefdatum.
- [ ] Rond een doel af met terugblik; open het doel opnieuw en verwijder een testdoel.
- [ ] Sla energiemetingen op, controleer 7-/30-dagen gemiddelden en verwijder één meting.

## Ouders / voogden / begeleiders en delen
- [ ] Maak de lokale ondersteuner-toegangscode; sluit en open de ondersteunersomgeving opnieuw.
- [ ] Vul ondersteuningsplan en contactpersoon in; bewaar, sluit en controleer de opgeslagen waarden.
- [ ] Maak een routinevoorstel, deel bestand en code via aparte kanalen. Op de cliënttelefoon moet de cliënt de routine eerst expliciet goedkeuren voordat die wordt opgeslagen.
- [ ] Maak een ondersteuningspakket met één geselecteerd item; controleer dat niet-geselecteerde items ontbreken.
- [ ] Open met goede code en met verkeerde code; verkeerde code mag niets tonen of opslaan.
- [ ] Weiger een routine-/planvoorstel; controleer dat er niets verandert.
- [ ] Controleer de deelgeschiedenis met gekozen onderdelen en het lokale logboek. Verifieer dat beide duidelijk aangeven dat ze geen online cross-device log zijn.
- [ ] Controleer dat stoplicht rood of stressniveau geen automatische waarschuwing aan anderen verstuurt.

## Privacy en gegevens
- [ ] Controleer export: jongerencheck-ins, veiligheidsplan, doelen/reflecties, energiemetingen, routinevoortgang en deelgeschiedenis aanwezig.
- [ ] Bekijk privacy-aantallen en deelgeschiedenis, maak versleutelde back-up en bevestig accountverwijderen/herstelprocedure.
- [ ] Verwijder alleen testrecords en controleer dat andere records blijven bestaan.

Noteer elk probleem met: model telefoon, Android-versie, tekstgrootte, schermnaam, exacte stappen, verwacht resultaat en werkelijk resultaat. Plaats geen persoonlijke dagboekteksten of deelcodes in openbare bugrapporten.
