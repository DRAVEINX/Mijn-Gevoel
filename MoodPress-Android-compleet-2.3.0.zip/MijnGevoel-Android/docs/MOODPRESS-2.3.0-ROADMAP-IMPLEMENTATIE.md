# MoodPress 2.3.0 — implementatie van de offline roadmap

## Werkelijk ingebouwd in de broncode

| Onderdeel | Implementatie in 2.3.0 | Privacygrens |
|---|---|---|
| Start en leeftijdsprofiel | Profielen Kind, Jongere, Volwassene en Algemeen; startscherm toont relevante snelkoppelingen | Profiel kiest alleen de interface, niet een medische beoordeling |
| Kindvriendelijk dagschema | Datumselectie, agenda-items afvinken, routines per dag afvinken, voortgang alleen voor die dag wissen, voorlezen via apparaat-spraak, eigen helpkaart en contactpersonen | Voortgang wordt niet automatisch gedeeld |
| Jongeren | Privé-stresscheck-ins, eigen behoefte/notitie, grens-zinnen, online-veiligheidsplan, 30-dagen samenvatting, individuele check-ins verwijderen | Geen diagnose, geen automatische alert en niets delen zonder selectie |
| Volwassenen | Kleine doelen, eerste stap, optionele streefdatum, vrijwillige reflectie na afronding, energiemetingen, 7/30-dagen gemiddelden, individuele metingen verwijderen en expliciet delen | Geen score/ranglijst/diagnose; delen vraagt bevestiging |
| Ondersteuner-ingang | Apart lokaal PIN, eigen lokale ondersteuningsplan, gespreksgids, kleur/stress-uitleg, voorstellen voor routines, lokaal gebeurtenissenlog | PIN is lokaal; geen cliënt-account of live synchronisatie |
| Delen en ontvangen | Cliënt selecteert afzonderlijke stoplichtitems, routines, gevoelscheck-ins, stresscheck-ins en/of helpplan; versleuteld bestand met aparte code; ontvanger kan eerst lezen en daarna expliciet goedkeuren of routine toevoegen | Snapshot; bestand kan na versturen niet op afstand worden ingetrokken |
| Deelgeschiedenis | Lokale toestemming/registratie met geselecteerde labels en categorie-aantallen; gebruiker kan lokale registratie wissen | Dit is geen server-side toegangslog of bewijs dat de ontvanger het verwijderde |
| Privacy/export | JSON-export bevat jonger_check-ins/veiligheidsplan, doelen en reflecties, energie, routinevoortgang en toestemmingsregistraties | JSON-export is leesbaar/niet versleuteld; app waarschuwt de gebruiker |
| Veiligheidsmaatregelen | Lengte-/itemlimieten in ondersteuningspakket, AES-GCM-versleuteling met code, inputcontrole, back-up ZIP-padbeveiliging en regressietests | Externe security-review blijft nodig |

## Niet verantwoord als “werkend” te claimen zonder extra infrastructuur

De roadmap bevat ook online cliëntaccounts voor ondersteuners, live synchronisatie, een server-uitgegeven eenmalige koppelcode, online ingetrokken toegang en een toegangslog dat over twee apparaten synchroniseert. Dit is **niet** ingebouwd in deze offline release. Daarvoor is een server/cloudomgeving nodig met echte authenticatie, database, beheer van rollen, transport- en opslagversleuteling, toestemming per gebruiker, bewaartermijnen en een security-/privacy-review. De bestaande repository- en GitHub-omgeving is geen veilig backend voor persoonlijke gevoel- of ondersteuningsgegevens. Daarom bootst 2.3.0 geen nep-liveverbinding na.

Ook is MoodPress geen alarmcentrale: het stuurt geen waarschuwing automatisch naar ouders of begeleiders als iemand rood kiest of stress registreert.

## Validatie

- Statische C# delimiter-scan: gecontroleerd.
- Projectversie, workflowpaden en pakketinhoud: worden vóór oplevering gecontroleerd.
- Een lokale C#-compile en `dotnet test` zijn in de beschikbare omgeving niet uitvoerbaar omdat de .NET SDK ontbreekt.
- Laat beide GitHub Actions-workflows volledig groen lopen. Test daarna op het echte Android-apparaat: installeren als update, pictogram, lang/groot tekst, lezen voor, tekenen, delen/ontvangen, routine goedkeuren, export/back-up terugzetten, automatische vergrendeling en verwijderen/herstel.

Deze notitie beschrijft functies in de broncode; alleen een succesvolle Android-build plus on-device controle bevestigt de volledige werking.
