# Voorstel: MoodPress voor kind, jongere, volwassene én ondersteuner

## Richting
Maak niet één app waarin een ouder alles kan bekijken, maar één persoonlijke MoodPress met een **vrijwillig gekoppelde ondersteunersomgeving**. De cliënt houdt eigen regie. De ouder, voogd of begeleider ziet uitsluitend informatie waarvoor toegang is verleend. De app is geen alarmcentrale en mag niet beloven dat iemand een rode melding direct ziet.

## Wat bestaat nu al
- De gebruiker kiest zelf welke stoplichtmeldingen gedeeld worden.
- MoodPress maakt een versleuteld deelbestand en deelcode.
- De ontvanger opent het bestand met de code; de inhoud wordt niet als begeleidersaccount opgeslagen.

Dit is een bruikbare veilige basis voor de eerste versie van een aparte ondersteuneromgeving.

## Fase 1 — Ondersteuner-dashboard zonder live meekijken
**Doel:** direct bruikbaar, zonder server of automatische toegang tot het dagboek.
- Op het inlogscherm twee duidelijke ingangen: **Mijn MoodPress** en **Ouder / voogd / begeleider**.
- De ondersteuneringang opent een eigen startpagina met: gedeeld bestand openen, uitleg over kleuren/sterkte, gespreksvragen en een lokaal print-/bewaarbaar ondersteuningsplan.
- Een gedeeld item toont datum, wat de persoon zelf gedeeld heeft, en een korte ondersteuningssuggestie: “Vraag wat nu helpt; ga niet uit van een diagnose.”
- Geen dagboek, tekeningen, spraaknotities of volledige historie standaard zichtbaar.
- Een zichtbare uitleg dat rood niet automatisch door een mens wordt gelezen; voor direct gevaar moet men rechtstreeks passende hulp inschakelen.

## Fase 2 — Koppeling met expliciete toestemming
- Een cliënt maakt een eenmalige koppelcode en ziet exact welke gegevens de ondersteuner kan bekijken.
- De cliënt kiest per categorie (bijvoorbeeld alleen stoplicht, alleen routines, of ook gedeelde check-ins) en kan de koppeling altijd intrekken.
- Een log laat zien wie wat wanneer heeft geopend.
- Ouders/voogden/begeleiders krijgen eigen accounts en rollen; er is geen gedeeld wachtwoord voor een hele organisatie.
- De cliënt ziet een begrijpelijke melding wanneer een koppeling actief is en wanneer gegevens zijn gedeeld.

## Fase 3 — Herinneringen en samen plannen
- Samen een dagindeling bouwen: school, werk, dagbesteding, rust, eten, afspraken en overgangsmomenten.
- De gebruiker keurt een routine of wijziging goed voordat die op zijn/haar eigen apparaat verschijnt.
- Een gedeelde strategiekaart: “Wat helpt als ik overprikkeld ben”, “Wat niet helpt”, “Hoe vraag je mij iets als praten moeilijk is”.
- Afspraakdoelen en positieve terugblik, zonder ranglijst of strafpunten.
- Optionele weekbespreking: de gebruiker selecteert zelf wat hij/zij wil bespreken.

## Leeftijds- en gebruiksprofielen

### Kinderen
- Grote pictogrammen, duidelijke knoppen, audio-uitleg en maximaal één keuze per scherm.
- Visueel dagschema, gevoelens kiezen, prikkelmeter, adem-/rustspel, “help me”-kaart en voorspelbare overgangsmeldingen.
- Een vertrouwde volwassene toevoegen op een eenvoudige, uitlegbare manier; geen verborgen meekijkfunctie.

### Jongeren
- Meer eigen regie en privacy, snelle check-ins, school/sociale stress, grenzen aangeven, pesten melden via een zelfgekozen contactplan, en voorbereiding op lastige gesprekken.
- Optionele reflectie en patronen (“op welke momenten had ik rust nodig?”), nooit als medische diagnose.
- Delen per item en zichtbare toegangsgeschiedenis; een ouder ziet niet automatisch het privé-dagboek.

### Volwassenen
- Werk en dagbesteding, afspraken, energie- en prikkelbudget, routines en persoonlijke doelen.
- Zelfgekozen ondersteuningskaarten voor collega, jobcoach, begeleider of partner.
- Week-/maandoverzicht met trends die de gebruiker kan verbergen of wissen.

### Ouders / voogden / begeleiders
- Alleen gedeelde gegevens, een rustig leesbaar dashboard, uitleg hoe je het gesprek voert, ondersteuningsplan en rolgebonden toegang.
- Aanpasbare tekstgrootte, hoog contrast, voorlezen en duidelijke foutmeldingen.
- Geen stiekeme locatie, microfoon, screenshot of continue monitoring.

## Privacy en veiligheid vóór een online versie
Gevoelens, dagboeknotities en ondersteuningsinformatie zijn zeer persoonlijk. Voordat gegevens tussen apparaten of accounts synchroniseren, zijn minimaal nodig: expliciete toestemming per categorie, intrekken van toegang, versleuteling tijdens overdracht en opslag, beveiligingsreview, logboek, bewaartermijn/verwijderen, herstelplan en een duidelijke privacyverklaring. Voor kinderen moet de doelgroepgerichte uitleg eenvoudig zijn en moeten toestemming en wettelijke vertegenwoordiging zorgvuldig worden beoordeeld. De juiste juridische afspraken hangen af van de leeftijd, het gebruik en de organisatie; laat die vóór online lancering beoordelen.

## Mijn aanbevolen volgorde
1. Eerst de pictogram- en tekstproblemen oplossen en de 2.2.3 APK testen.
2. Daarna fase 1 bouwen: de ondersteuneringang, uitleg, deelbestand openen en gespreks-/ondersteuningsplan — geen live server.
3. Met enkele gebruikers uit elk leeftijdsprofiel testen wat begrijpelijk en prettig voelt.
4. Alleen daarna beslissen of online koppeling nodig is en de extra privacy- en beveiligingsfase starten.
