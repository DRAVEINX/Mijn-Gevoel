# Acceptatietest na het bouwen (handmatig, ongeveer 90 minuten)

> MoodPress is geschreven zonder het hier te kunnen draaien. Loop deze lijst één keer volledig door op een schone Windows 11-computer vóór je het aan cliënten geeft. Vink af wat klopt. Wat niet klopt, stuur je op (zie onderaan). Gebruik **verzonnen gegevens**.

## A. Installeren
- [ ] `bouwen.bat` eindigt met "Klaar!" en er staat een `.msi` in de map. *Verwacht:* geen fouten, tests slagen.
- [ ] .msi installeren (UAC-vraag is normaal). *Verwacht:* programma in `C:\Program Files\MoodPress`, snelkoppeling in startmenu en op bureaublad, met het hart-pictogram.
- [ ] Programma start. *Verwacht:* inlogscherm met logo; geen foutmelding. Op Windows 10 verschijnt de melding dat Windows 11 nodig is.
- [ ] Nieuwere .msi (hoger versienummer) installeren over de oude. *Verwacht:* oude versie wordt vervangen; gegevens blijven.
- [ ] Verwijderen via Instellingen > Apps. *Verwacht:* programma weg; map `%LocalAppData%\MijnGevoel` blijft.

## B. Account en inloggen
- [ ] "Ik heb nog geen account": gebruikersnaam, wachtwoord korter dan 10 tekens. *Verwacht:* duidelijke melding.
- [ ] Wachtwoord van 10+ tekens, twee keer. *Verwacht:* QR-code, sleutel om over te typen, 8 herstelcodes, knop "Printen" opent printvenster.
- [ ] QR scannen met Microsoft/Google Authenticator; knop "Klaar" blijft grijs tot het vinkje bij de herstelcodes.
- [ ] Verkeerde code invullen. *Verwacht:* "klopt niet". Goede code. *Verwacht:* "Je account is klaar".
- [ ] Inloggen met goede gegevens. *Verwacht:* toestemmingsscherm (eerste keer), daarna beginscherm.
- [ ] Zelfde 6 cijfers direct nog eens gebruiken (uitloggen/inloggen). *Verwacht:* geweigerd; na de volgende code lukt het.
- [ ] 5 keer foutief inloggen. *Verwacht:* blokkade met wachttijd, ook met goede gegevens.
- [ ] Vergrendel-knop en wachten op automatisch vergrendelen (zet op 1 minuut). *Verwacht:* terug naar inloggen met uitleg.
- [ ] Start programma opnieuw en log in. *Verwacht:* alle gegevens er nog.

## C. Herstel
- [ ] "Ik kom er niet meer in": gebruikersnaam, één herstelcode, nieuw wachtwoord. *Verwacht:* nieuwe QR en nieuwe codes; daarna inloggen met nieuw wachtwoord.
- [ ] Dezelfde herstelcode nog eens. *Verwacht:* werkt niet.
- [ ] Instellingen > Nieuwe herstelcodes maken (met wachtwoord). *Verwacht:* 8 nieuwe codes; oude werken niet.
- [ ] Gebruik 6 codes op. *Verwacht:* waarschuwing op het beginscherm bij 2 of minder.

## D. Toestemming en privacy
- [ ] Toestemmingsscherm: "Lees voor" werkt; knoppen pas actief na het vinkje; "Nee, nu niet" logt uit.
- [ ] Mijn privacy: aantallen kloppen met wat je maakte; datum en wijze van toestemming staan er.
- [ ] Gegevens downloaden (waarschuwing, .json). *Verwacht:* bestand bevat je gegevens, ook tekeningen (base64).
- [ ] Back-up maken; op een andere computer of ander Windows-profiel terugzetten ("Back-up terugzetten"), inloggen. *Verwacht:* gegevens zijn er.
- [ ] Account verwijderen (twee bevestigingen, wachtwoord). *Verwacht:* uitgelogd; inloggen werkt niet meer; map `data` van het account is weg.

## E. Stoplicht, plan, delen
- [ ] Groen, oranje, rood: oranje/rood vragen waarom en wat nodig; rood toont het plan en 112/113; tekst "waarschuwt niemand" staat er.
- [ ] Mijn plan invullen en terugzien bij oranje/rood en in de Rustplek.
- [ ] Delen: kies een melding, maak .html. *Verwacht:* code getoond; bestand opent in **Edge/Chrome op computer en telefoon**; foute code geeft melding; goede code toont de melding.
- [ ] Het .html-bestand als document in WhatsApp sturen en openen. *Verwacht:* opent in browser (anders: handmatig in browser openen).
- [ ] Delen als .mgdeel en openen via "Ik ben begeleider". *Verwacht:* inhoud zichtbaar met de code.
- [ ] "Kopieer als tekst": waarschuwing; na plakken en 60 seconden is het klembord leeg.

## F. Mijn dag
- [ ] Agenda: afspraak vandaag over 5 minuten. *Verwacht:* balk bovenaan binnen een minuut.
- [ ] Mijn dag > Vandaag: eerst/dan kloppen; "Klaar" werkt; "Volgende dag" en "Morgen bekijken" werken.
- [ ] Timer: 5 min, start, pauze, verder, opnieuw. *Verwacht:* kleurvlak wordt kleiner; klaar-melding; stopt bij wegnavigeren.
- [ ] Stappenplan starten, doorlopen, aanpassen, nieuw maken, weggooien. *Verwacht:* voortgangsbalk, voorlezen werkt.

## G. Rust en gevoel
- [ ] Ademhalen met bewegingen aan en uit (Instellingen). *Verwacht:* cirkel beweegt/alleen tellen; stoppen werkt.
- [ ] Rustplek, Prikkelmeter (hoog = vraag naar Rustplek), Mijn lichaam, Gevoelswoorden (voorlezen), Hoe voel ik me?, Weekoverzicht. *Verwacht:* opslaan en terugzien zonder fouten.

## H. Praten
- [ ] Kaarten: tik op kaart (groot), eigen kaart maken en weggooien. Gesprekskaart bewaren, laten zien, voorlezen.

## I. Maken en schrijven
- [ ] Tekenen met muis, en pen/touch indien beschikbaar: kleuren, diktes, markeerstift, gum, ongedaan/opnieuw, bewaren, galerij, bewerken, als plaatje opslaan, vragen om te bewaren bij terug.
- [ ] Van me afschrijven (bewaren/weggooien); Dagboek met gezichtje; Windows-toets + H dicteert in het tekstveld.

## J. Instellingen en toegankelijkheid
- [ ] Letters normaal/groot/extra groot; thema Rustig/Donker/Hoog contrast; lettertype; ruime regelafstand; zachte bewegingen uit. *Verwacht:* alles direct zichtbaar, tekst blijft leesbaar.
- [ ] Alleen toetsenbord (Tab/Enter/Spatie) door login, beginscherm en een groep. *Verwacht:* focusrand zichtbaar, alles bereikbaar.
- [ ] Verteller (Windows Narrator) leest knoppen voor. Windows-schaal 150% en 200%. *Verwacht:* niets valt buiten beeld.
- [ ] Ctrl+H en "Verberg": leeg scherm; elke toets of klik brengt terug; typen gaat niet in verborgen velden.
- [ ] Schermopname blokkeren aan: Knipprogramma of schermdelen toont zwart venster.

## K. Beveiliging (korte controle)
- [ ] Open `%LocalAppData%\MijnGevoel\data\...`: bestanden `.mg` zijn onleesbaar; zoek op een woord uit je dagboek: niet te vinden.
- [ ] `accounts\*.json` bevat geen wachtwoord of leesbare tekst.
- [ ] Twee accounts op dezelfde computer zien elkaars gegevens niet.
- [ ] Afsluiten via Taakbeheer en opnieuw starten: geen kapotte bestanden.

## Fouten doorgeven
Stuur: (1) wat je deed, stap voor stap, (2) wat je verwachtte en wat er gebeurde, (3) een schermafbeelding van verzonnen gegevens, (4) het bestand `%LocalAppData%\MijnGevoel\log.txt` (bevat alleen soort fout en plaats, geen cliëntgegevens), (5) Windows-versie en schaal. Voor foutmeldingen van `bouwen.bat`: kopieer de tekst.
