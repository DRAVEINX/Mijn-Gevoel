# MoodPress 2.2.3 — UI-, invoer- en beveiligingscontrole

## Aangepast in 2.2.3
- **Android-appicoon:** foreground SVG gebruikt nu hetzelfde volledige 456 × 456 canvas als de achtergrond; het logo wordt niet meer door een te nauwe `viewBox` uitvergroot. De foreground scale staat op 1.0 zodat het pictogram netjes binnen de adaptive-icon-veilige zone blijft.
- **Afgekaptte teksten:** grotere minimale knophoogtes, woordafbreking bij koppen en sectienamen, responsiever splashlogo en een scrollbaar privacyscherm.
- **Lange invoer:** tekstvelden groeien mee met ingevoerde tekst in plaats van vast te blijven op hun oorspronkelijke hoogte.
- **Deelbestanden:** maximale bestandsgrootte, pakketvalidatie en grenzen voor invoerwaarden vóór weergave; sleutels en ontsleutelde buffers worden na gebruik gewist.
- **Back-upherstel:** padbeveiliging gebruikt relatieve paden in plaats van een eenvoudige prefixcontrole.
- **Geheugenhygiëne:** de tijdelijke afgeleide sleutel voor een onbekende gebruikersnaam wordt nu gewist.
- **Extra regressietests:** ongeldige/grote deelbestanden en zip-slip-bestanden bij back-upherstel.

## Handmatige acceptatietest die nog op echte telefoons nodig is
1. Installeer de APK op een kleine telefoon en een groter scherm. Controleer het pictogram in het startscherm, de app-lijst, recente apps en meldingen.
2. Omdat Android launchers pictogrammen kunnen cachen: verwijder de vorige testinstallatie, installeer de nieuwe versie en start het toestel/launcher indien nodig opnieuw.
3. Test tekstgrootte in MoodPress op normaal, groot en extra groot. Herhaal met Androids systeemtekst/vergroting hoger ingesteld.
4. Controleer koppen, knoppen, navigatie, dagboek, gevoelens, agenda, routines, stoplicht, delen, instellingen en bevestigingsdialogen in staande stand en liggend.
5. Plak lange tekst in dagboek/notities en controleer dat de tekst zichtbaar en bewerkbaar blijft.
6. Gebruik TalkBack, hoog contrast en grotere tekst; alle acties moeten nog bereikbaar zijn.
7. Test delen met een verkeerde code, een beschadigd bestand en een bestand van meer dan 10 MB. De app moet een begrijpelijke melding tonen en niet crashen.
8. Test back-up maken/herstellen, herstelcode, automatisch vergrendelen, uitloggen/verwijderen en routines/herinneringen.

## Wat deze controle wel/niet bewijst
Dit is een gerichte statische codecontrole met regressietests. Het is **geen garantie dat alle bugs weg zijn**: voor definitieve acceptatie moeten de Android debug- en release-workflows groen zijn en moet de nieuwe APK op echte apparaten worden getest. De checks hierboven zijn expliciet opgenomen zodat ze bij iedere nieuwe release herhaald kunnen worden.
