using System.IO;
using MijnGevoel.Core.Security;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace MijnGevoel.Desktop;

/// <summary>Stoplicht: kleur + pictogram + tekst (nooit alleen kleur, i.v.m. kleurenblindheid).</summary>
static class Light
{
    public static readonly (string Key, string Emoji, string Title, string Sub, string Hex)[] All =
    {
        ("Groen", "🟢", "Groen", "Het gaat goed", "#7BC67E"),
        ("Oranje", "🟠", "Oranje", "Het gaat niet zo goed", "#FFB74D"),
        ("Rood", "🔴", "Rood", "Ik heb hulp nodig", "#EF5350"),
    };
    public static (string Key, string Emoji, string Title, string Sub, string Hex) Of(string key) => All.First(x => x.Key == key);
    public static Brush BrushFor(string key) => new SolidColorBrush((Color)ColorConverter.ConvertFromString(Of(key).Hex));

    public static readonly (string Emoji, string Text)[] Reasons =
    {
        ("😴", "Ik ben moe"), ("😠", "Ik ben boos"), ("😢", "Ik ben verdrietig"), ("😨", "Ik ben bang"),
        ("👥", "Iets met andere mensen"), ("🏫", "School, werk of dagbesteding"), ("🏠", "Thuis of waar ik woon"),
        ("🤕", "Pijn of ziek"), ("🌀", "Te veel drukte of lawaai"), ("🤷", "Ik weet het niet"),
    };
    public static readonly (string Emoji, string Text)[] Needs =
    {
        ("💬", "Ik wil praten met iemand"), ("🤫", "Ik wil rust"), ("🎨", "Ik wil iets leuks doen"),
        ("🚶", "Ik wil even naar buiten"), ("🆘", "Ik wil nu hulp"), ("🤷", "Ik weet het niet"),
    };

    public static Button Big(string key, Action click)
    {
        var l = Of(key);
        var sp = new StackPanel { Margin = new Thickness(0, 8, 0, 8) };
        var e = new TextBlock { Text = l.Emoji, HorizontalAlignment = HorizontalAlignment.Center };
        e.SetResourceReference(TextBlock.FontSizeProperty, "TitleFont");
        sp.Children.Add(e);
        sp.Children.Add(new TextBlock { Text = l.Title, FontWeight = FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Center });
        sp.Children.Add(new TextBlock { Text = l.Sub, TextWrapping = TextWrapping.Wrap, TextAlignment = TextAlignment.Center });
        var b = new Button { Content = sp, Background = BrushFor(key), Foreground = Brushes.Black, Margin = new Thickness(6) };
        System.Windows.Automation.AutomationProperties.SetName(b, $"{l.Title}: {l.Sub}");
        b.Click += (_, _) => click();
        return b;
    }
}

static class RecoverySheet
{
    public static void Print(string username, IEnumerable<string> codes)
    {
        var doc = new FlowDocument { FontFamily = new FontFamily("Segoe UI"), FontSize = 18, PagePadding = new Thickness(60) };
        doc.Blocks.Add(new Paragraph(new Run("MoodPress - herstelcodes")) { FontSize = 28, FontWeight = FontWeights.Bold });
        doc.Blocks.Add(new Paragraph(new Run($"Gebruikersnaam: {username}")));
        doc.Blocks.Add(new Paragraph(new Run("Bewaar dit papier op een veilige plek, niet bij je telefoon. Elke code werkt één keer. Met deze codes kom je weer binnen als je je telefoon of wachtwoord kwijt bent.")));
        foreach (var c in codes) doc.Blocks.Add(new Paragraph(new Run(c)) { FontFamily = new FontFamily("Consolas"), FontSize = 24 });
        var pd = new PrintDialog();
        if (pd.ShowDialog() != true) return;
        doc.PageWidth = pd.PrintableAreaWidth; doc.PageHeight = pd.PrintableAreaHeight; doc.ColumnWidth = pd.PrintableAreaWidth;
        pd.PrintDocument(((IDocumentPaginatorSource)doc).DocumentPaginator, "MoodPress herstelcodes");
    }
}

/// <summary>Zachte bewegingen. Uit te zetten in Instellingen en worden automatisch overgeslagen als Windows animaties uit heeft staan.</summary>
static class Motion
{
    public static bool Enabled => Session.Settings.Animations && SystemParameters.ClientAreaAnimation;

    public static void Scale(Button b, double to)
    {
        if (!Enabled) return;
        if (b.Template?.FindName("B", b) is Border bd && bd.RenderTransform is ScaleTransform st && !st.IsFrozen)
        {
            var a = new DoubleAnimation(to, TimeSpan.FromMilliseconds(120)) { EasingFunction = new QuadraticEase() };
            st.BeginAnimation(ScaleTransform.ScaleXProperty, a);
            st.BeginAnimation(ScaleTransform.ScaleYProperty, a);
        }
    }

    public static void FadeIn(FrameworkElement el)
    {
        if (!Enabled) return;
        var ease = new CubicEase { EasingMode = EasingMode.EaseOut };
        var tt = new TranslateTransform(0, 14);
        el.RenderTransform = tt;
        var fade = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(260)) { EasingFunction = ease };
        var slide = new DoubleAnimation(14, 0, TimeSpan.FromMilliseconds(260)) { EasingFunction = ease };
        slide.Completed += (_, _) => el.RenderTransform = null;
        el.BeginAnimation(UIElement.OpacityProperty, fade);
        tt.BeginAnimation(TranslateTransform.YProperty, slide);
    }
}

/// <summary>Blokkeert screenshots en schermopnames van het venster (Windows 10 versie 2004 of nieuwer). Staat standaard uit; aan te zetten in Instellingen.</summary>
static class Capture
{
    [System.Runtime.InteropServices.DllImport("user32.dll")]
    static extern bool SetWindowDisplayAffinity(IntPtr hWnd, uint dwAffinity);

    public static void Apply(Window w, bool on)
    {
        try
        {
            var h = new System.Windows.Interop.WindowInteropHelper(w).Handle;
            if (h != IntPtr.Zero) SetWindowDisplayAffinity(h, on ? 0x11u : 0u);   // WDA_EXCLUDEFROMCAPTURE
        }
        catch (Exception) { }
    }
}

/// <summary>Foutlogboek zonder persoonlijke inhoud: alleen het soort fout en waar het misging. Handig om fouten snel op te lossen.</summary>
static class Log
{
    static readonly string LogFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MijnGevoel", "log.txt");
    public static string PathName => LogFile;

    public static void Write(Exception ex)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(LogFile)!);
            var fi = new FileInfo(LogFile);
            if (fi.Exists && fi.Length > 200_000) fi.Delete();
            File.AppendAllText(LogFile, $"{DateTime.Now:yyyy-MM-dd HH:mm:ss}  {ex.GetType().FullName}\n{ex.StackTrace}\n\n");
        }
        catch (Exception) { }
    }
}

/// <summary>Waar staan accounts en gegevens? Standaard in %LocalAppData%\MijnGevoel, maar je kunt een andere map kiezen (OneDrive, USB-stick, andere schijf). Alles daarin is versleuteld.</summary>
static class DataLocation
{
    static readonly string Dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MijnGevoel");
    static readonly string ConfigFile = Path.Combine(Dir, "locatie.txt");

    static string? Configured
    {
        get
        {
            try { if (File.Exists(ConfigFile)) { var p = File.ReadAllText(ConfigFile).Trim(); if (p.Length > 0) return p; } }
            catch (Exception) { }
            return null;
        }
    }

    public static string DefaultBase => Dir;
    public static string CurrentBase => Configured ?? Dir;
    public static bool IsCustom => Configured is not null;
    public static bool Missing => Configured is { } c && !Directory.Exists(c);

    public static void Set(string path) { Directory.CreateDirectory(Dir); File.WriteAllText(ConfigFile, path); }
    public static void Reset() { try { File.Delete(ConfigFile); } catch (Exception) { } }
    public static AccountService CreateAccounts() => new AccountService(Path.Combine(CurrentBase, "accounts"));

    /// <summary>Kopieert accounts en gegevens naar een andere map (bestaande bestanden worden niet overschreven).</summary>
    public static void CopyAll(string src, string dst)
    {
        foreach (var sub in new[] { "accounts", "data" })
        {
            var s = Path.Combine(src, sub);
            if (!Directory.Exists(s)) continue;
            foreach (var f in Directory.GetFiles(s, "*", SearchOption.AllDirectories))
            {
                var target = Path.Combine(dst, Path.GetRelativePath(src, f));
                Directory.CreateDirectory(Path.GetDirectoryName(target)!);
                if (!File.Exists(target)) File.Copy(f, target);
            }
        }
    }
}
