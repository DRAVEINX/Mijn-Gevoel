using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using MijnGevoel.Core.Data;

namespace MijnGevoel.Desktop;

/// <summary>Rustig beginscherm: stoplicht en gezichtjes bovenaan, daaronder vijf groepen. Zo zie je niet alles tegelijk.</summary>
sealed class HomeView : ViewBase
{
    public HomeView()
    {
        var saved = Ui.Label("", muted: true);
        var moodRow = new UniformGrid { Columns = 5, Margin = new Thickness(0, 0, 0, 8) };
        for (int i = 0; i < 5; i++)
        {
            int v = i + 1; var m = Moods.All[i];
            moodRow.Children.Add(Ui.MoodButton(m, () =>
            {
                var e = new JournalEntry(Guid.NewGuid(), DateTime.Now, v, "");
                Session.Store!.Save("diary", e.Id, e);
                saved.Text = $"Opgeslagen ✔   Je voelt je: {m.Name}";
            }));
        }

        var lightRow = new UniformGrid { Columns = 3 };
        foreach (var l in Light.All) { var key = l.Key; lightRow.Children.Add(Light.Big(key, () => MainWindow.Current.Navigate(new StoplichtView(key)))); }

        var cats = new UniformGrid { Columns = 2 };
        cats.Children.Add(Group("📅", "Mijn dag",
            new NavItem("🗓️", "Vandaag", () => new DayView(DateTime.Today)),
            new NavItem("🌙", "Morgen bekijken", () => new DayView(DateTime.Today.AddDays(1))),
            new NavItem("📅", "Agenda", () => new AgendaView()),
            new NavItem("⏳", "Timer", () => new TimerView()),
            new NavItem("✅", "Stappenplannen", () => new RoutinesView())));
        cats.Children.Add(Group("🌿", "Rust en gevoel",
            new NavItem("🫁", "Ademhalen", () => new BreathView()),
            new NavItem("🛋️", "Rustplek", () => new CalmView()),
            new NavItem("🎚️", "Prikkelmeter", () => new PrikkelView()),
            new NavItem("🧍", "Mijn lichaam", () => new LichaamView()),
            new NavItem("📊", "Hoe voel ik me?", () => new MoodView()),
            new NavItem("📖", "Gevoelswoorden", () => new WordsView())));
        cats.Children.Add(Group("💬", "Praten en delen",
            new NavItem("🗂️", "Kaarten om te laten zien", () => new CardsView()),
            new NavItem("🗣️", "Gesprekskaart", () => new TalkPrepView()),
            new NavItem("🚦", "Mijn stoplicht-overzicht", () => new StoplichtHistoryView()),
            new NavItem("📤", "Delen met mijn begeleider", () => new ShareView(null)),
            new NavItem("🆘", "Mijn plan", () => new PlanView())));
        cats.Children.Add(Group("🎨", "Maken en schrijven",
            new NavItem("✏️", "Tekenen", () => new DrawView()),
            new NavItem("🖼️", "Mijn tekeningen", () => new GalleryView()),
            new NavItem("📝", "Van me afschrijven", () => new JournalView("note", false, "Van me afschrijven",
                "Schrijf hier op wat je dwarszit. Niemand leest mee. Je kunt het bewaren of weggooien.")),
            new NavItem("📖", "Dagboek", () => new JournalView("diary", true, "Dagboek",
                "Hoe was je dag? Kies een gezichtje en schrijf erbij wat je wilt."))));
        cats.Children.Add(Group("🔐", "Mijn gegevens",
            new NavItem("🔐", "Mijn privacy", () => new PrivacyView()),
            new NavItem("🗒️", "Weekoverzicht", () => new WeekView()),
            new NavItem("⚙️", "Instellingen", () => new SettingsView()),
            new NavItem("❓", "Hulp", () => new HelpView())));

        var kids = new List<UIElement> { Ui.Label($"Hoi {Session.Username}!", title: true) };
        int left = Session.Accounts.RecoveryCodesLeft(Session.Username);
        if (left <= 2) kids.Add(Ui.Label($"⚠️ Je hebt nog maar {left} herstelcode(s). Maak nieuwe codes bij Instellingen."));
        kids.AddRange(new UIElement[] { Ui.Label("Hoe is het nu? (stoplicht)"), lightRow, Ui.Label("Welk gezichtje past bij je?"), moodRow, saved, cats });
        Content = Ui.Page(kids.ToArray());
    }

    static Button Group(string icon, string title, params NavItem[] items) =>
        Tile(icon, title, () => new CategoryView(icon, title, items));

    internal static Button Tile(string icon, string text, Func<UserControl> make)
    {
        var sp = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 14, 0, 14) };
        var ic = new TextBlock { Text = icon, HorizontalAlignment = HorizontalAlignment.Center };
        ic.SetResourceReference(TextBlock.FontSizeProperty, "TitleFont");
        sp.Children.Add(ic);
        sp.Children.Add(new TextBlock { Text = text, TextWrapping = TextWrapping.Wrap, TextAlignment = TextAlignment.Center });
        var b = new Button { Content = sp, Margin = new Thickness(8) };
        b.SetResourceReference(FrameworkElement.StyleProperty, "TileButton");
        System.Windows.Automation.AutomationProperties.SetName(b, text);
        b.Click += (_, _) => MainWindow.Current.Navigate(make());
        return b;
    }
}

sealed class HelpView : ViewBase
{
    public HelpView() => Shell("Hulp", Ui.Page(
        Ui.Label("Wat kan ik hier doen?", title: true),
        Ui.Label("🚦 Stoplicht: laat zien hoe het gaat en waarom. MoodPress waarschuwt zelf niemand. Vertel het aan iemand of deel het."),
        Ui.Label("📅 Mijn dag: zie wat je eerst en dan doet, met een timer en stappenplannen."),
        Ui.Label("🌿 Rust en gevoel: ademhalen, een rustplek, prikkelmeter, je lichaam en gevoelswoorden."),
        Ui.Label("💬 Praten en delen: kaarten om te laten zien, een gesprekskaart en delen met je begeleider."),
        Ui.Label("🎨 Maken en schrijven: tekenen, van je afschrijven en een dagboek."),
        Ui.Label("🙈 Snel verbergen (Ctrl + H) zet een leeg scherm voor je gegevens. 🔒 Vergrendel sluit alles af."),
        Ui.Label("Alles wat je hier maakt is alleen van jou en staat versleuteld op deze computer.", muted: true),
        Ui.Label($"Versie {System.Reflection.Assembly.GetExecutingAssembly().GetName().Version?.ToString(3)}. Foutbestand (zonder persoonlijke gegevens): {Log.PathName}", muted: true),
        Ui.Label("Voel je je heel erg slecht of heb je zorgen over jezelf?", title: true),
        Ui.Label("Praat met iemand die je vertrouwt, zoals je begeleider, familie of je huisarts. Je kunt ook gratis bellen met 113 Zelfmoordpreventie: 0800-0113 (dag en nacht). Is het acuut gevaarlijk? Bel 112.")));
}
