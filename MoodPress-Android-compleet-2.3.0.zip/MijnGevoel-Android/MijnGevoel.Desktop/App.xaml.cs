using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
namespace MijnGevoel.Desktop;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        if (Environment.OSVersion.Version.Build < 22000)   // Windows 11 = build 22000 of hoger
        {
            MessageBox.Show("MoodPress werkt alleen op Windows 11 of nieuwer.", "MoodPress");
            Shutdown();
            return;
        }
        EventManager.RegisterClassHandler(typeof(Button), UIElement.MouseEnterEvent, new MouseEventHandler((s, a) => Motion.Scale((Button)s, 1.03)));
        EventManager.RegisterClassHandler(typeof(Button), UIElement.MouseLeaveEvent, new MouseEventHandler((s, a) => Motion.Scale((Button)s, 1.0)));
        EventManager.RegisterClassHandler(typeof(Button), UIElement.PreviewMouseLeftButtonDownEvent, new MouseButtonEventHandler((s, a) => Motion.Scale((Button)s, 0.97)));
        EventManager.RegisterClassHandler(typeof(Button), UIElement.PreviewMouseLeftButtonUpEvent, new MouseButtonEventHandler((s, a) => Motion.Scale((Button)s, 1.03)));
        base.OnStartup(e);
        // Nooit technische foutmeldingen (met mogelijk gevoelige info) aan de cliënt laten zien.
        AppDomain.CurrentDomain.UnhandledException += (_, a) => { if (a.ExceptionObject is Exception x) Log.Write(x); };
        TaskScheduler.UnobservedTaskException += (_, a) => { Log.Write(a.Exception); a.SetObserved(); };
        DispatcherUnhandledException += (_, a) =>
        {
            Log.Write(a.Exception);
            MessageBox.Show("Er ging iets mis. Je gegevens zijn veilig. Probeer het nog een keer.", "MoodPress");
            a.Handled = true;
        };
    }
}
