#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROJECT="$ROOT/MijnGevoel.Android/MijnGevoel.Android.csproj"
TEST_PROJECT="$ROOT/MijnGevoel.Tests/MijnGevoel.Tests.csproj"

if ! command -v dotnet >/dev/null 2>&1; then
  echo "FOUT: .NET SDK ontbreekt. Installeer .NET 10, de MAUI Android-workload, Java 17 en de Android SDK." >&2
  exit 2
fi

if ! java -version 2>&1 | grep -Eq 'version "(17|21)\.'; then
  echo "WAARSCHUWING: controleer of Java 17 (aanbevolen voor MAUI Android-builds) is ingesteld." >&2
fi

cd "$ROOT"
dotnet workload install maui-android
dotnet restore "$TEST_PROJECT"
dotnet test "$TEST_PROJECT" --configuration Release --no-restore
dotnet restore "$PROJECT"
dotnet publish "$PROJECT" --configuration Debug --framework net10.0-android -p:AndroidPackageFormat=apk

OUT="$ROOT/artifacts"
mkdir -p "$OUT"
APK="$(find "$ROOT/MijnGevoel.Android/bin/Debug/net10.0-android" -type f -name '*.apk' -printf '%T@ %p\n' | sort -nr | head -n 1 | cut -d' ' -f2-)"
if [[ -z "$APK" || ! -f "$APK" ]]; then
  echo "FOUT: de build is geëindigd zonder APK. Bekijk de foutmeldingen van dotnet publish." >&2
  exit 3
fi
cp "$APK" "$OUT/MijnGevoel-Android-debug.apk"
sha256sum "$OUT/MijnGevoel-Android-debug.apk" | tee "$OUT/SHA256SUMS.txt"
echo "APK gemaakt: $OUT/MijnGevoel-Android-debug.apk"
echo "Dit is een debug-APK voor testen. Voor publieke distributie is een eigen release-keystore nodig."
