using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MijnGevoel.Core.Security;

namespace MijnGevoel.Core.Data;

public record SharePackage(int Version, string From, DateTime Created, List<StoplichtEntry> Items);

/// <summary>
/// Delen met een begeleider, alleen als de cliënt dat zelf kiest: een versleuteld deelbestand (.mgdeel) met precies de gekozen meldingen.
/// Sleutel = Argon2id(deelcode). Het bestand en de code moeten via twee verschillende kanalen naar de begeleider.
/// </summary>
public static class ShareService
{
    const string Magic = "MGDEEL1";
    const int MaxShareFileBytes = 10 * 1024 * 1024;
    const int MaxSharedItems = 5_000;
    const int MaxShareTextChars = 20_000;

    public static string NewShareCode()
    {
        const string a = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
        var sb = new StringBuilder();
        for (int i = 0; i < 12; i++) { if (i > 0 && i % 4 == 0) sb.Append('-'); sb.Append(a[RandomNumberGenerator.GetInt32(a.Length)]); }
        return sb.ToString();
    }

    public static byte[] Create(string from, IEnumerable<StoplichtEntry> items, string code)
    {
        var package = PreparePackage(from, items, code);
        var json = JsonSerializer.SerializeToUtf8Bytes(package);
        if (json.Length + Encoding.ASCII.GetByteCount(Magic) + Crypto.SaltSize + Crypto.NonceSize + Crypto.TagSize > MaxShareFileBytes)
        {
            CryptographicOperations.ZeroMemory(json);
            throw new ArgumentException("Het deelbestand is te groot.", nameof(items));
        }
        var salt = Crypto.Random(Crypto.SaltSize);
        byte[]? key = null;
        try
        {
            key = Crypto.DeriveKey(Normalize(code), salt);
            return [.. Encoding.ASCII.GetBytes(Magic), .. salt, .. Crypto.Seal(key, json, Magic)];
        }
        finally
        {
            if (key is not null) CryptographicOperations.ZeroMemory(key);
            CryptographicOperations.ZeroMemory(json);
        }
    }

    static SharePackage PreparePackage(string from, IEnumerable<StoplichtEntry> items, string code)
    {
        if (string.IsNullOrWhiteSpace(code) || Normalize(code).Length < 8)
            throw new ArgumentException("Gebruik een deelcode van minimaal 8 letters of cijfers.", nameof(code));
        var selected = items?.ToList() ?? throw new ArgumentNullException(nameof(items));
        if (selected.Count > MaxSharedItems)
            throw new ArgumentException("Er zijn te veel meldingen geselecteerd.", nameof(items));
        if (selected.Any(x => x is null || string.IsNullOrWhiteSpace(x.Colour)
            || x.Text is null || x.Text.Length > MaxShareTextChars
            || x.Reasons is null || x.Needs is null
            || x.Reasons.Length > 100 || x.Needs.Length > 100
            || x.Reasons.Any(reason => reason is null || reason.Length > 250)
            || x.Needs.Any(need => need is null || need.Length > 250)))
            throw new ArgumentException("Een of meer meldingen bevatten ongeldige gegevens.", nameof(items));
        var safeFrom = from ?? string.Empty;
        if (safeFrom.Length > 120) safeFrom = safeFrom[..120];
        return new SharePackage(1, safeFrom, DateTime.Now, selected);
    }

    /// <summary>Null bij verkeerde code, beschadigd of gemanipuleerd bestand.</summary>
    public static SharePackage? Open(byte[] file, string code)
    {
        var m = Encoding.ASCII.GetBytes(Magic);
        if (file is null || string.IsNullOrWhiteSpace(code) || Normalize(code).Length < 8 || file.Length > MaxShareFileBytes
            || file.Length < m.Length + Crypto.SaltSize + Crypto.NonceSize + Crypto.TagSize) return null;
        if (!file.AsSpan(0, m.Length).SequenceEqual(m)) return null;
        var salt = file[m.Length..(m.Length + Crypto.SaltSize)];
        var blob = file[(m.Length + Crypto.SaltSize)..];
        var key = Crypto.DeriveKey(Normalize(code), salt);
        byte[]? plain = null;
        try
        {
            plain = Crypto.Open(key, blob, Magic);
            return ValidatePackage(JsonSerializer.Deserialize<SharePackage>(plain));
        }
        catch (Exception ex) when (ex is CryptographicException || ex is JsonException || ex is ArgumentException || ex is NotSupportedException) { return null; }
        finally
        {
            CryptographicOperations.ZeroMemory(key);
            if (plain is not null) CryptographicOperations.ZeroMemory(plain);
        }
    }

    const string HtmlAad = "MGDEEL-HTML1";
    const int HtmlIterations = 600_000;

    /// <summary>Leesbaar voor begeleiders zonder programma: een versleutelde HTML-pagina die in elke browser opent (ook op een telefoon, ook via WhatsApp als bijlage).</summary>
    public static string CreateHtml(string from, IEnumerable<StoplichtEntry> items, string code)
    {
        var package = PreparePackage(from, items, code);
        var json = JsonSerializer.SerializeToUtf8Bytes(package);
        if (json.Length > MaxShareFileBytes)
        {
            CryptographicOperations.ZeroMemory(json);
            throw new ArgumentException("Het HTML-deelbestand is te groot.", nameof(items));
        }
        var salt = Crypto.Random(16);
        var nonce = Crypto.Random(12);
        byte[]? pw = null, key = null;
        try
        {
            pw = Encoding.UTF8.GetBytes(Normalize(code));
            key = Rfc2898DeriveBytes.Pbkdf2(pw, salt, HtmlIterations, HashAlgorithmName.SHA256, 32);
            var ct = new byte[json.Length];
            var tag = new byte[16];
            using (var g = new AesGcm(key, 16)) g.Encrypt(nonce, json, ct, tag, Encoding.ASCII.GetBytes(HtmlAad));
            return ShareHtml.Template
                .Replace("{{SALT}}", Convert.ToBase64String(salt))
                .Replace("{{NONCE}}", Convert.ToBase64String(nonce))
                .Replace("{{DATA}}", Convert.ToBase64String(ct.Concat(tag).ToArray()))
                .Replace("{{ITER}}", HtmlIterations.ToString());
        }
        finally
        {
            if (key is not null) CryptographicOperations.ZeroMemory(key);
            if (pw is not null) CryptographicOperations.ZeroMemory(pw);
            CryptographicOperations.ZeroMemory(json);
        }
    }

    /// <summary>Alleen voor tests en controle: leest zo'n HTML-bestand met dezelfde code (de browser doet dit normaal).</summary>
    public static SharePackage? OpenHtml(string html, string code)
    {
        if (string.IsNullOrWhiteSpace(html) || html.Length > 20 * 1024 * 1024 || string.IsNullOrWhiteSpace(code) || Normalize(code).Length < 8) return null;
        string? Get(string n) { var m = System.Text.RegularExpressions.Regex.Match(html, "data-" + n + "=\"([^\"]+)\""); return m.Success ? m.Groups[1].Value : null; }
        var s = Get("s"); var nn = Get("n"); var d = Get("d"); var it = Get("i");
        if (s is null || nn is null || d is null || it is null || !int.TryParse(it, out var iter) || iter < 100_000 || iter > 1_000_000) return null;
        byte[]? pw = null, key = null, plain = null;
        try
        {
            var salt = Convert.FromBase64String(s);
            var nonce = Convert.FromBase64String(nn);
            var data = Convert.FromBase64String(d);
            if (salt.Length != 16 || nonce.Length != 12 || data.Length < 16 || data.Length > MaxShareFileBytes) return null;
            pw = Encoding.UTF8.GetBytes(Normalize(code));
            key = Rfc2898DeriveBytes.Pbkdf2(pw, salt, iter, HashAlgorithmName.SHA256, 32);
            var ct = data[..^16]; var tag = data[^16..]; plain = new byte[ct.Length];
            using var g = new AesGcm(key, 16);
            g.Decrypt(nonce, ct, tag, plain, Encoding.ASCII.GetBytes(HtmlAad));
            return ValidatePackage(JsonSerializer.Deserialize<SharePackage>(plain));
        }
        catch (Exception ex) when (ex is CryptographicException || ex is JsonException || ex is FormatException || ex is ArgumentException || ex is NotSupportedException) { return null; }
        finally
        {
            if (pw is not null) CryptographicOperations.ZeroMemory(pw);
            if (key is not null) CryptographicOperations.ZeroMemory(key);
            if (plain is not null) CryptographicOperations.ZeroMemory(plain);
        }
    }

    static SharePackage? ValidatePackage(SharePackage? package)
    {
        if (package is null || package.Version != 1 || package.From is null || package.From.Length > 120
            || package.Items is null || package.Items.Count > MaxSharedItems) return null;
        foreach (var item in package.Items)
        {
            if (item is null || item.Colour is not ("Groen" or "Oranje" or "Rood")
                || item.Reasons is null || item.Needs is null || item.Text is null || item.Text.Length > MaxShareTextChars
                || item.Reasons.Length > 100 || item.Needs.Length > 100
                || item.Reasons.Any(x => x is null || x.Length > 250) || item.Needs.Any(x => x is null || x.Length > 250))
                return null;
        }
        return package;
    }

    /// <summary>Gewone tekst (NIET versleuteld) om bijvoorbeeld in een chat te plakken. Alleen na uitdrukkelijke keuze van de cliënt.</summary>
    public static string PlainText(string from, IEnumerable<StoplichtEntry> items)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"MoodPress - gedeeld door {from}").AppendLine();
        foreach (var e in items.OrderBy(i => i.Colour == "Rood" ? 0 : i.Colour == "Oranje" ? 1 : 2).ThenByDescending(i => i.Created))
        {
            var em = e.Colour == "Rood" ? "🔴" : e.Colour == "Oranje" ? "🟠" : "🟢";
            sb.AppendLine($"{em} {e.Colour} - {e.Created:dd-MM-yyyy HH:mm}");
            if (e.Reasons.Length > 0) sb.AppendLine("Waarom: " + string.Join(", ", e.Reasons));
            if (e.Needs.Length > 0) sb.AppendLine("Nodig: " + string.Join(", ", e.Needs));
            if (!string.IsNullOrWhiteSpace(e.Text)) sb.AppendLine(e.Text.Trim());
            sb.AppendLine();
        }
        return sb.ToString().TrimEnd();
    }

    static string Normalize(string c) => new string(c.Where(char.IsLetterOrDigit).ToArray()).ToUpperInvariant();
}
