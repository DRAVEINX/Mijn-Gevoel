using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MijnGevoel.Core.Security;

namespace MijnGevoel.Core.Data;

/// <summary>
/// Versleuteld, draagbaar ondersteuningspakket. Het werkt offline via een bestand plus aparte code;
/// het is bewust geen live accountkoppeling of automatische synchronisatie.
/// </summary>
public sealed record SupportSharePackage(
    int Version,
    string From,
    DateTime Created,
    SafetyPlan? HelpPlan,
    List<StoplichtEntry> StoplightEntries,
    List<RoutineSuggestion> RoutineSuggestions)
{
    // Optional properties keep older version-1 packages readable; new packages use version 2.
    public List<MoodCheckInEntry> MoodCheckIns { get; init; } = new();
    public List<YouthSupportEntry> YouthCheckIns { get; init; } = new();
}

public static class SupportShareService
{
    const string Magic = "MGSUP1";
    public const int MaxFileBytes = 10 * 1024 * 1024;
    const int MaxEntries = 250;
    const int MaxRoutines = 50;
    const int MaxText = 8_000;

    public static string NewShareCodeForUi()
    {
        const string alphabet = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
        var result = new StringBuilder();
        for (int i = 0; i < 12; i++) { if (i > 0 && i % 4 == 0) result.Append('-'); result.Append(alphabet[RandomNumberGenerator.GetInt32(alphabet.Length)]); }
        return result.ToString();
    }

    public static byte[] Create(string from, SafetyPlan? plan, IEnumerable<StoplichtEntry>? stoplights,
        IEnumerable<RoutineSuggestion>? routines, string code,
        IEnumerable<MoodCheckInEntry>? moodCheckIns = null, IEnumerable<YouthSupportEntry>? youthCheckIns = null)
    {
        if (string.IsNullOrWhiteSpace(code) || code.Length > 200 || Normalize(code).Length < 8)
            throw new ArgumentException("Gebruik een deelcode van minimaal 8 en maximaal 200 tekens.", nameof(code));
        var safeFrom = (from ?? string.Empty).Trim();
        if (safeFrom.Length > 120) safeFrom = safeFrom[..120];
        var lights = (stoplights ?? Array.Empty<StoplichtEntry>()).ToList();
        var routineList = (routines ?? Array.Empty<RoutineSuggestion>()).ToList();
        var moods = (moodCheckIns ?? Array.Empty<MoodCheckInEntry>()).ToList();
        var youth = (youthCheckIns ?? Array.Empty<YouthSupportEntry>()).ToList();
        if (lights.Count > MaxEntries || routineList.Count > MaxRoutines || moods.Count > MaxEntries || youth.Count > MaxEntries)
            throw new ArgumentException("Er zijn te veel onderdelen geselecteerd.");
        if (plan is not null && !ValidatePlan(plan)) throw new ArgumentException("Het ondersteuningsplan bevat ongeldige of te lange velden.");
        if (lights.Any(x => !ValidateStoplight(x))) throw new ArgumentException("Een stoplichtmelding bevat ongeldige gegevens.");
        if (routineList.Any(x => !ValidateRoutine(x))) throw new ArgumentException("Een routinevoorstel bevat ongeldige gegevens.");
        if (moods.Any(x => !ValidateMoodCheckIn(x))) throw new ArgumentException("Een gevoelscheck-in bevat ongeldige gegevens.");
        if (youth.Any(x => !ValidateYouthCheckIn(x))) throw new ArgumentException("Een jongerencheck-in bevat ongeldige gegevens.");
        if (plan is null && lights.Count == 0 && routineList.Count == 0 && moods.Count == 0 && youth.Count == 0)
            throw new ArgumentException("Selecteer minstens één categorie om te delen.");

        var package = new SupportSharePackage(2, safeFrom, DateTime.Now, plan, lights, routineList)
        { MoodCheckIns = moods, YouthCheckIns = youth };
        var plain = JsonSerializer.SerializeToUtf8Bytes(package);
        var header = Encoding.ASCII.GetBytes(Magic);
        if (plain.Length + header.Length + Crypto.SaltSize + Crypto.NonceSize + Crypto.TagSize > MaxFileBytes)
        {
            CryptographicOperations.ZeroMemory(plain);
            throw new ArgumentException("Het ondersteuningspakket is te groot.");
        }
        var salt = Crypto.Random(Crypto.SaltSize);
        byte[]? key = null;
        try
        {
            key = Crypto.DeriveKey(Normalize(code), salt);
            var sealedData = Crypto.Seal(key, plain, Magic);
            return [.. header, .. salt, .. sealedData];
        }
        finally
        {
            if (key is not null) CryptographicOperations.ZeroMemory(key);
            CryptographicOperations.ZeroMemory(plain);
        }
    }

    public static SupportSharePackage? Open(byte[]? file, string? code)
    {
        var header = Encoding.ASCII.GetBytes(Magic);
        if (file is null || file.Length > MaxFileBytes || file.Length < header.Length + Crypto.SaltSize + Crypto.NonceSize + Crypto.TagSize
            || string.IsNullOrWhiteSpace(code) || code.Length > 200 || Normalize(code).Length < 8) return null;
        if (!file.AsSpan(0, header.Length).SequenceEqual(header)) return null;
        var salt = file[header.Length..(header.Length + Crypto.SaltSize)];
        var blob = file[(header.Length + Crypto.SaltSize)..];
        byte[]? key = null, plain = null;
        try
        {
            key = Crypto.DeriveKey(Normalize(code), salt);
            plain = Crypto.Open(key, blob, Magic);
            var package = JsonSerializer.Deserialize<SupportSharePackage>(plain);
            return ValidatePackage(package) ? package : null;
        }
        catch (Exception ex) when (ex is CryptographicException or JsonException or ArgumentException or NotSupportedException)
        {
            return null;
        }
        finally
        {
            if (key is not null) CryptographicOperations.ZeroMemory(key);
            if (plain is not null) CryptographicOperations.ZeroMemory(plain);
        }
    }

    static bool ValidatePackage(SupportSharePackage? p)
    {
        if (p is null || p.Version is not (1 or 2) || p.From is null || p.From.Length > 120 || p.StoplightEntries is null
            || p.RoutineSuggestions is null || p.MoodCheckIns is null || p.YouthCheckIns is null
            || p.StoplightEntries.Count > MaxEntries || p.RoutineSuggestions.Count > MaxRoutines
            || p.MoodCheckIns.Count > MaxEntries || p.YouthCheckIns.Count > MaxEntries)
            return false;
        if (p.HelpPlan is not null && !ValidatePlan(p.HelpPlan)) return false;
        if (p.StoplightEntries.Any(x => !ValidateStoplight(x)) || p.RoutineSuggestions.Any(x => !ValidateRoutine(x))
            || p.MoodCheckIns.Any(x => !ValidateMoodCheckIn(x)) || p.YouthCheckIns.Any(x => !ValidateYouthCheckIn(x))) return false;
        return p.HelpPlan is not null || p.StoplightEntries.Count > 0 || p.RoutineSuggestions.Count > 0
            || p.MoodCheckIns.Count > 0 || p.YouthCheckIns.Count > 0;
    }

    static bool ValidateStoplight(StoplichtEntry? x) => x is not null
        && (x.Colour is "Groen" or "Oranje" or "Rood")
        && x.Reasons is not null && x.Needs is not null && x.Text is not null && x.Text.Length <= MaxText
        && x.Reasons.Length <= 100 && x.Needs.Length <= 100
        && x.Reasons.All(t => t is not null && t.Length <= 250)
        && x.Needs.All(t => t is not null && t.Length <= 250);

    static bool ValidateRoutine(RoutineSuggestion? r) => r is not null
        && !string.IsNullOrWhiteSpace(r.Title) && r.Title.Length <= 120
        && r.Icon is not null && r.Icon.Length <= 20
        && r.From is not null && r.From.Length <= 120
        && r.Steps is not null && r.Steps.Length is > 0 and <= 100
        && r.Steps.All(s => !string.IsNullOrWhiteSpace(s) && s.Length <= 250);

    static bool ValidateMoodCheckIn(MoodCheckInEntry? x) => x is not null
        && x.Feeling is not null && x.Feeling.Length <= 120 && x.Intensity is >= 0 and <= 10
        && x.Reason is not null && x.Reason.Length <= MaxText && x.Note is not null && x.Note.Length <= MaxText;

    static bool ValidateYouthCheckIn(YouthSupportEntry? x) => x is not null
        && x.Situation is not null && x.Situation.Length <= 120 && x.StressLevel is >= 1 and <= 5
        && x.Need is not null && x.Need.Length <= 250 && x.Note is not null && x.Note.Length <= MaxText;

    static bool ValidatePlan(SafetyPlan p)
    {
        if (p.Contacts is null || p.HelpOptions is null || p.Contacts.Count > 100 || p.HelpOptions.Count > 50) return false;
        foreach (var c in p.Contacts) if (c is null || c.Name is null || c.Name.Length > 200 || c.Phone is null || c.Phone.Length > 100) return false;
        if (p.HelpOptions.Any(x => x is null || x.Length > 100)) return false;
        string[] fields = { p.Helps, p.PersonName, p.EarlySigns, p.Avoid, p.Communication, p.SupportSteps, p.Goals, p.RoutineNotes };
        return fields.All(x => x is not null && x.Length <= MaxText);
    }

    static string Normalize(string c) => new string(c.Where(char.IsLetterOrDigit).ToArray()).ToUpperInvariant();
}
