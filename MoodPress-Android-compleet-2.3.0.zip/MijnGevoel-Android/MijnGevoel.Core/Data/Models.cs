namespace MijnGevoel.Core.Data;

/// <summary>Dagboek (Mood 1-5, 0 = geen) en "van me afschrijven"-briefjes.</summary>
public record JournalEntry(Guid Id, DateTime Created, int Mood, string Text);
/// <summary>De vier herkenbare gevoelens voor snelle, visuele invoer.</summary>
public record FourGFeelingEntry(Guid Id, DateTime Created, string Feeling);
/// <summary>Uitgebreide dagelijkse check-in. De gegevens worden via VaultStore versleuteld opgeslagen.</summary>
public record MoodCheckInEntry(Guid Id, DateTime Created, string Feeling, int Intensity, string Reason, string Note);
/// <summary>Een korte gesproken notitie; AudioData wordt uitsluitend binnen de versleutelde VaultStore bewaard.</summary>
public record VoiceNoteEntry(Guid Id, DateTime Created, string Context, byte[] AudioData);
public record DrawingEntry(Guid Id, DateTime Created, string Title, byte[] Isf, byte[] Png);
public record AgendaItem(Guid Id, DateTime Date, string Time, string Title, string Icon, bool Done);
/// <summary>Checklistvoortgang per routine en dag voor het kindvriendelijke visuele dagschema.</summary>
public record RoutineProgress(Guid Id, DateTime Day, Guid RoutineId, int[] CompletedSteps);

public class UserSettings
{
    public int TextSize { get; set; } = 1;            // 0 normaal, 1 groot, 2 extra groot
    public string Theme { get; set; } = "Rustig";     // Rustig, Donker, Hoog contrast
    public int AutoLockMinutes { get; set; } = 5;
    public bool ReadAloud { get; set; } = true;
    public bool Animations { get; set; } = true;
    public string FontName { get; set; } = "Standaard";   // Standaard, Verdana, Arial, Georgia
    public bool WideLines { get; set; }                  // ruime regelafstand
    public bool BlockCapture { get; set; }               // schermopname/screenshot van het venster blokkeren
    public bool RoutinesSeeded { get; set; }
    /// <summary>Persoonlijk interfaceprofiel: Kind, Jongere, Volwassene of Algemeen.</summary>
    public string AudienceProfile { get; set; } = "Algemeen";
}

/// <summary>Stoplicht: Colour = Groen | Oranje | Rood. Reasons/Needs zijn de gekozen pictogram-teksten.</summary>
public record StoplichtEntry(Guid Id, DateTime Created, string Colour, string[] Reasons, string[] Needs, string Text);
public record ContactPerson(string Name, string Phone);
public class SafetyPlan
{
    public List<ContactPerson> Contacts { get; set; } = new();
    public string Helps { get; set; } = "";
    /// <summary>Vooraf gekozen, concrete helpstappen. Oude bestanden zonder dit veld blijven geldig.</summary>
    public List<string> HelpOptions { get; set; } = new();
    // Extra, optionele velden voor de ondersteuningskaart. Oude back-ups blijven compatibel.
    public string PersonName { get; set; } = "";
    public string EarlySigns { get; set; } = "";
    public string Avoid { get; set; } = "";
    public string Communication { get; set; } = "";
    public string SupportSteps { get; set; } = "";
    public string Goals { get; set; } = "";
    public string RoutineNotes { get; set; } = "";
}

/// <summary>Privé-check-in voor kinderen en jongeren; opgeslagen in de versleutelde gebruikerskluis.</summary>
public record YouthSupportEntry(Guid Id, DateTime Created, string Situation, int StressLevel, string Need, string Note);
/// <summary>Privé-afspraken voor omgaan met online pesten of een onveilige situatie.</summary>
public class YouthSafetyPlan
{
    public string TrustedPerson { get; set; } = "";
    public string SafePlace { get; set; } = "";
    public string NextStep { get; set; } = "";
    public string OnlineSteps { get; set; } = "";
}
/// <summary>Eigen doel voor school, werk, dagbesteding, thuis of sociale contacten.</summary>
public record AdultGoal(Guid Id, DateTime Created, string Area, string Title, string FirstStep, DateTime? TargetDate, bool Done)
{
    /// <summary>Vrijwillige positieve terugblik; geen score of ranglijst. Oudere opgeslagen doelen blijven compatibel.</summary>
    public string Reflection { get; init; } = "";
}
/// <summary>Privé-energiemeting; geen diagnose en niet automatisch gedeeld.</summary>
public record EnergyEntry(Guid Id, DateTime Created, string Context, int EnergyLevel, string Note);
/// <summary>Een routinevoorstel dat de ontvanger eerst expliciet moet goedkeuren.</summary>
public record RoutineSuggestion(Guid Id, string Title, string Icon, string[] Steps, DateTime Created, string From);
/// <summary>Bewijs van de categorieën die de gebruiker bewust heeft geselecteerd voor één deelpakket.</summary>
public record ShareConsentRecord(Guid Id, DateTime Created, string RecipientLabel, string[] Categories, int StoplightCount, int RoutineCount)
{
    public int MoodCheckInCount { get; init; }
    public int YouthCheckInCount { get; init; }
    public string[] SelectedItemLabels { get; init; } = Array.Empty<string>();
}
/// <summary>Lokale gebeurtenis op het apparaat van de ondersteuner; geen online toegangslog.</summary>
public record SupportAuditEntry(Guid Id, DateTime Created, string Action, string Summary);
public record ShareLogEntry(Guid Id, DateTime Created, int Count);

/// <summary>Toestemming van de cliënt voor het gebruik van de app (Mode: "zelf" of "samen" met een vertegenwoordiger/begeleider).</summary>
public record ConsentRecord(Guid Id, DateTime Created, int Version, string Mode);
public static class ConsentInfo { public const int CurrentVersion = 1; }

/// <summary>Stappenplan (routine): een titel, een plaatje en stappen.</summary>
public record Routine(Guid Id, string Title, string Icon, string[] Steps);
/// <summary>Een persoonlijke dagelijkse/wekelijkse routineherinnering met lokaal gekozen pictogram.</summary>
public record RoutineReminder(
    Guid Id,
    string Title,
    string Icon,
    string Time,
    int DaysMask,
    bool Enabled,
    string? PictureBase64 = null,
    bool SoundEnabled = true);
/// <summary>Prikkelmeter en lichaam: Kind = Hoofd | Omgeving | Lichaam. Bij Lichaam is Note bijvoorbeeld "Buik: spanning".</summary>
public record ScaleEntry(Guid Id, DateTime Created, string Kind, int Level, string Note);
/// <summary>Eigen kaart om te laten zien ("Ik wil even rust").</summary>
public record TalkCard(Guid Id, string Emoji, string Text);
/// <summary>Gesprekskaart: voorbereiden wat je wilt zeggen.</summary>
public class TalkPrep { public string Tell { get; set; } = ""; public string Ask { get; set; } = ""; public string Want { get; set; } = ""; }
