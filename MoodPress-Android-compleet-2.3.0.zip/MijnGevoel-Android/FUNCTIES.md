# MoodPress — functies Android 2.0

## Nieuw in Android 2.0

- **Dagelijkse check-in:** kies een gevoel, geef de gevoelssterkte een cijfer van 1 tot 10, kies eventueel een aanleiding en schrijf zo nodig een korte notitie.
- **Gevoelskalender:** blader door de laatste 30 dagen en bekijk de check-ins van een specifieke dag.
- **Mijn inzichten:** neutrale tellingen en gemiddelde gevoelssterkte over de laatste 7 en 30 dagen, met de meest gekozen gevoelens. De app stelt geen diagnose en trekt geen medische conclusies.
- **Tekenen verbeterd:** zes kleuren, drie pendiktes, laatste lijn ongedaan maken en alles wissen. De opgeslagen afbeelding behoudt de gekozen kleuren en diktes.
- **Weekoverzicht:** telt dagelijkse check-ins mee.
- **Privacy en export:** check-ins zijn zichtbaar in de telling van opgeslagen gegevens en worden meegenomen in de leesbare JSON-export. Voorafgaand aan delen/exporteren moet de gebruiker zelf actie ondernemen.
- **Appversie:** Android-weergaveversie `2.0`, version code `20`.

## Overige Android-functies

Inloggen met wachtwoord en authenticatorcode; eenmalige herstelcodes; lokale versleutelde gegevenskluis; privé dagboek en briefjes; vier grote gevoelsknoppen; stoplicht en eigen helpkaart; agenda; vandaag/morgen; timers en stappenplannen; ademhalingsoefening met optionele rustmuziek; rustplek; prikkel- en lichaamsmeter; gevoelswoorden; kaarten om te laten zien; gesprekskaart; spraaknotities; tekeningen en galerij; delen op expliciet verzoek; wie-werkt-er-rooster; weekoverzicht; voorlezen; lettergrootte, thema, lettertype en regelafstand; automatische vergrendeling; optionele biometrische heropening; schermverbergen/schermafbeeldingen blokkeren; export, versleutelde back-up en terugzetten; account- en gegevensverwijdering.

## Privacy in het kort

De functies zijn bedoeld om gegevens lokaal in de versleutelde appkluis te bewaren. Gegevens worden niet automatisch naar begeleiders, ouders of een server verstuurd. Een leesbare JSON-export is **niet versleuteld** en kan gevoelige gegevens bevatten; deel die alleen bewust. Maak vóór het verwijderen of opnieuw installeren een versleutelde back-up als gegevens bewaard moeten blijven.

## Release-status

Deze lijst beschrijft de broncode in dit pakket. De Android 2.0-release moet nog worden gebouwd via de bijgewerkte GitHub Release-workflow en daarna op een echt toestel worden getest. Zie `AFRONDING-STATUS-2.0.md`.
