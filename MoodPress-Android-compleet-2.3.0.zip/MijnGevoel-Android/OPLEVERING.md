# Opleverplan: van pakket naar gebruik door cliënten

| # | Stap | Wie | Klaar als |
|---|---|---|---|
| 1 | `bouwen.bat` draaien, fouten doorgeven en laten herstellen | Beheerder/ICT + ontwikkelaar | .msi gebouwd, tests slagen |
| 2 | Acceptatietest `docs/8` helemaal doorlopen | ICT + 1 begeleider | Alle punten afgevinkt of opgelost |
| 3 | Juridische en privacy-beoordeling: `docs/2`, `docs/6`, `docs/7`, privacyverklaring; rollen, grondslag, uitzonderingsgrond, WhatsApp-beleid, CRA-classificatie | FG/jurist + opdrachtgever | DPIA vastgesteld, register ingevuld, besluiten vastgelegd |
| 4 | Externe beveiligingstoets en hertest (`docs/1`) | Extern bureau | Geen open hoge/kritieke bevindingen |
| 5 | Testen met cliënten en begeleiders (`docs/3`), teksten op taalniveau B1 laten nalopen, inhoud van tips laten nalezen door behandelaar | Behandelaar + begeleiders | Succescriteria gehaald; aanpassingen verwerkt en opnieuw getest |
| 6 | Code-signing-certificaat regelen; .exe en .msi tekenen; `Manufacturer` aanpassen in `installer\Package.wxs` | ICT | Geen SmartScreen-waarschuwing |
| 7 | Alarmprotocol voor rode meldingen, herstelbeleid (`docs/4`), datalek- en verzoekprocedure (`docs/7`), training begeleiders | Zorgmanager + FG | Procedures bekend bij begeleiders |
| 8 | Pilot met een kleine groep (bijv. 5 cliënten, 4 weken) met vaste aanspreekpunten | Begeleiders | Evaluatie gedaan, go/no-go besluit |
| 9 | Uitrol (stille installatie: `msiexec /i MijnGevoel-installatie.msi /qn`) | ICT | Geïnstalleerd; handleiding uitgedeeld |
| 10 | Beheer: updates (nieuwe .msi met hoger versienummer), kwetsbaarhedenbeleid en meldingen (CRA), incidentproces, jaarlijkse evaluatie van DPIA en wetgeving (Data Omnibus, CRA, UAVG) | Beheerder + FG | Vaste jaarkalender |

## Go/no-go: niet uitrollen als
- de beveiligingstoets open hoge of kritieke bevindingen heeft;
- de DPIA of het alarmprotocol voor rood niet is vastgesteld;
- de acceptatietest of cliëntentest veiligheids- of begrijpelijkheidsproblemen laat zien;
- de organisatie niet heeft besloten of WhatsApp/e-mail mag voor delen.

## Minimale bezetting
Een aanspreekpunt voor fouten en een voor privacyvragen, met een afgesproken reactietijd. Cliënten moeten altijd iemand hebben die ze kunnen vragen om hulp bij herstelcodes en delen.


## MoodPress 2.2 — vernieuwde uitstraling

MoodPress heeft een donkerblauwe interface met neonblauwe, cyan-, paarse en roze accenten, een nieuw hart/vinger-logo en de slogan **Jouw gevoel. Jouw verhaal. Jouw app.** De routines en herinneringen en alle bestaande gevoel-, rust-, privacy-, dagboek-, teken- en exportfuncties zijn behouden. Android package-id `nl.mijngevoel.app` is bewust hetzelfde gebleven voor een update over de bestaande installatie.
