using Microsoft.Maui.Storage;
using Microsoft.Maui.Media;
using Microsoft.Maui.ApplicationModel.DataTransfer;
#if ANDROID
using Android.Content;
#endif
using MijnGevoel.Core.Security;
using MijnGevoel.Core.Data;

namespace MijnGevoel.AndroidApp;

public sealed class LoginPage : ContentPage
{
    Entry _username = null!, _password = null!, _totp = null!;
    Label _status = null!;
    CheckBox _rememberMe = null!;
    bool _restoreAttempted;
    bool _unlocking;
    string? _pendingUser, _pendingPassword;

    public LoginPage()
    {
        Title = "MoodPress";
        NavigationPage.SetHasNavigationBar(this, false);
        BackgroundColor = AppUi.Background;
        ShowLogin();
    }

    public void ShowLoginMessage(string? message)
    {
        ShowLogin(message);
        _restoreAttempted = true;
        _ = TryRememberedUnlockAsync();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (_restoreAttempted) return;
        _restoreAttempted = true;
        await TryRememberedUnlockAsync();
    }

    async Task TryRememberedUnlockAsync()
    {
        if (_unlocking || !AppSession.KeepSignedIn) return;
        _unlocking = true;
        try
        {
            if (!await AppSession.HasRememberedSessionAsync())
            {
                _status.Text = "Je kunt veilig inloggen met je gebruikersnaam, wachtwoord en authenticatorcode.";
                return;
            }

            _status.Text = "Ontgrendel MoodPress met de vingerafdruk of gezichtsherkenning van je telefoon. Je kunt ook je gewone inloggegevens gebruiken.";
            var authenticated = await BiometricUnlock.AuthenticateAsync();
            if (!authenticated)
            {
                _status.Text = "Niet ontgrendeld. Gebruik de gewone login hieronder of probeer de biometrische ontgrendeling opnieuw.";
                return;
            }

            var restored = await AppSession.TryRestoreRememberedSessionAsync();
            if (restored)
            {
                await Navigation.PushAsync(new DashboardPage());
                return;
            }

            _status.Text = "De opgeslagen sessie kon niet worden hersteld. Log opnieuw in met je gebruikersnaam, wachtwoord en authenticatorcode.";
        }
        catch (Exception ex)
        {
            AppLog.Write(ex);
            _status.Text = "Ontgrendelen is niet gelukt. Je kunt gewoon inloggen met je gegevens.";
        }
        finally { _unlocking = false; }
    }

    void ShowLogin(string? message = null)
    {
        Title = "MoodPress";
        NavigationPage.SetHasNavigationBar(this, false);
        _username = AppUi.Entry("Gebruikersnaam");
        _password = AppUi.Entry("Wachtwoord", password: true);
        _totp = AppUi.Entry("6-cijferige authenticatorcode", keyboard: Keyboard.Numeric);
        _totp.MaxLength = 6;
        var show = new CheckBox();
        show.CheckedChanged += (_, e) => _password.IsPassword = !e.Value;
        _rememberMe = new CheckBox { IsChecked = AppSession.KeepSignedIn, Color = AppUi.Accent, VerticalOptions = LayoutOptions.Center };
        _status = AppUi.Label(message ?? "Je gegevens blijven op dit apparaat en worden versleuteld opgeslagen.");

        var biometricUnlockButton = AppUi.AsyncButton("🔓 Ontgrendelen met vingerafdruk of gezicht", async () => await TryRememberedUnlockAsync(), quiet: true);
        biometricUnlockButton.IsVisible = AppSession.KeepSignedIn;

        var content = AppUi.Stack(
            AppUi.BrandLockup(),
            AppUi.Card(new VerticalStackLayout { Spacing = 8, Children = {
                AppUi.Title("Inloggen"),
            _username,
            _password,
            new HorizontalStackLayout { Spacing = 8, Children = { show, AppUi.Label("Wachtwoord laten zien") } },
            _totp,
            new HorizontalStackLayout { Spacing = 8, Children = { _rememberMe, AppUi.Label("Op dit toestel ingelogd blijven", title: true) } },
            AppUi.Label("Alleen aanvinken op je eigen, vergrendelde toestel. Je wachtwoord en authenticatorcode worden niet opgeslagen. Na de automatische vergrendeling kun je met de telefoonbeveiliging opnieuw openen.", muted: true),
            biometricUnlockButton
            }}),
            AppUi.AsyncButton("🔐 Inloggen", LoginAsync),
            _status,
            AppUi.Button("➕ Nieuw account maken", ShowRegister),
            AppUi.Button("🔑 Ik ben mijn wachtwoord/telefoon kwijt", ShowRecovery, quiet: true),
            AppUi.AsyncButton("📦 Back-up terugzetten op deze telefoon", RestoreBackupAsync, quiet: true),
            AppUi.Button("📂 Deelbestand van een begeleider openen", () => Navigation.PushAsync(new ShareOpenPage()), quiet: true),
            AppUi.Button("🧭 Ouder / voogd / begeleider", () => Navigation.PushAsync(new SupporterCenterPage()), quiet: true),
            AppUi.Label("Tip: je hebt je authenticator-app nodig. Bewaar je herstelcodes op een veilige plek.", muted: true),
            AppUi.Copyright());
        Content = new ScrollView { Content = content };
    }

    async Task LoginAsync()
    {
        var user = _username.Text?.Trim() ?? "";
        var password = _password.Text ?? "";
        var code = _totp.Text ?? "";
        if (user.Length == 0 || password.Length == 0 || code.Length != 6)
        {
            _status.Text = "Vul je gebruikersnaam, wachtwoord en de 6-cijferige code in.";
            return;
        }
        try
        {
            _status.Text = "Bezig met veilig inloggen…";
            var result = await Task.Run(() => AppSession.Accounts.Login(user, password, code));
            if (!result.Success || result.VaultKey is null)
            {
                _status.Text = result.Message;
                return;
            }
            var rememberRequested = _rememberMe.IsChecked;
            bool remembered = rememberRequested
                ? await AppSession.SaveRememberedSessionAsync(user, result.VaultKey)
                : false;
            if (!rememberRequested) await AppSession.ClearRememberedSessionAsync();

            AppSession.Start(user, result.VaultKey);
            if (remembered) await AppSession.UpdateRememberedSessionPolicyAsync();
            if (rememberRequested && !AppSession.KeepSignedIn)
            {
                _status.Text = "Je bent ingelogd, maar ingelogd blijven kon niet worden ingesteld. Je kunt de app wel gewoon gebruiken.";
                _rememberMe.IsChecked = false;
            }
            await Navigation.PushAsync(new DashboardPage());
        }
        catch (Exception ex)
        {
            _status.Text = "Inloggen lukte niet. Controleer je gegevens en probeer opnieuw.";
            AppLog.Write(ex);
        }
    }

    async Task RestoreBackupAsync()
    {
        var picked = await FilePicker.Default.PickAsync(new PickOptions { PickerTitle = "Kies je versleutelde MoodPress-back-up (.zip)" });
        if (picked is null) return;
        var temp = Path.Combine(FileSystem.CacheDirectory, "mg-login-restore-" + Guid.NewGuid().ToString("N") + ".zip");
        try
        {
            await using (var source = await picked.OpenReadAsync())
            await using (var target = File.Create(temp)) await source.CopyToAsync(target);
            var count = await Task.Run(() => BackupService.Restore(AppSession.Accounts, temp));
            _status.Text = count > 0 ? "Back-up teruggezet. Je kunt nu inloggen met het herstelde account." : "Er zijn geen nieuwe bestanden teruggezet. Controleer of je de juiste back-up kiest of dat het account al bestaat.";
            await DisplayAlertAsync("Back-up terugzetten", _status.Text, "OK");
        }
        catch (Exception ex)
        {
            AppLog.Write(ex);
            _status.Text = "Terugzetten is niet gelukt. Kies een geldige MoodPress-back-up.";
            await DisplayAlertAsync("Back-up niet verwerkt", _status.Text, "OK");
        }
        finally { try { File.Delete(temp); } catch { } }
    }

    void ShowRegister()
    {
        Title = "Account aanmaken";
        var username = AppUi.Entry("Kies een gebruikersnaam (minimaal 3 tekens)");
        var password = AppUi.Entry("Kies een sterk wachtwoord (minimaal 10 tekens)", password: true);
        var password2 = AppUi.Entry("Herhaal het wachtwoord", password: true);
        var status = AppUi.Label("Na het aanmaken koppel je een authenticator-app en bewaar je de herstelcodes.");
        Content = new ScrollView { Content = AppUi.Stack(
            AppUi.Title("Nieuw account"),
            AppUi.Label("Gebruik een wachtwoord dat je niet op andere plekken gebruikt."),
            username, password, password2,
            AppUi.AsyncButton("Account aanmaken en authenticator koppelen", async () =>
            {
                var u = username.Text?.Trim() ?? "";
                var p = password.Text ?? "";
                if (p != password2.Text) { status.Text = "De wachtwoorden zijn niet gelijk."; return; }
                try
                {
                    status.Text = "Account veilig aanmaken…";
                    var registration = await Task.Run(() => AppSession.Accounts.Register(u, p));
                    _pendingUser = u; _pendingPassword = p;
                    ShowRegistration(registration, u, p, "Bewaar de herstelcodes. Elke code werkt één keer.");
                }
                catch (Exception ex) { status.Text = ex.Message; }
            }),
            status,
            AppUi.Button("← Terug naar inloggen", () => ShowLogin())) };
    }

    void ShowRecovery()
    {
        Title = "Toegang herstellen";
        var username = AppUi.Entry("Gebruikersnaam");
        var code = AppUi.Entry("Een ongebruikte herstelcode");
        var newPassword = AppUi.Entry("Nieuw wachtwoord (minimaal 10 tekens)", password: true);
        var newPassword2 = AppUi.Entry("Herhaal het nieuwe wachtwoord", password: true);
        var status = AppUi.Label("Met een herstelcode wordt je authenticator opnieuw gekoppeld. Je oude herstelcodes vervallen.");
        Content = new ScrollView { Content = AppUi.Stack(
            AppUi.Title("Toegang herstellen"), username, code, newPassword, newPassword2,
            AppUi.AsyncButton("Herstellen en opnieuw koppelen", async () =>
            {
                var u = username.Text?.Trim() ?? "";
                var p = newPassword.Text ?? "";
                if (p != newPassword2.Text) { status.Text = "De wachtwoorden zijn niet gelijk."; return; }
                try
                {
                    var registration = await Task.Run(() => AppSession.Accounts.RecoverAccess(u, code.Text ?? "", p));
                    if (registration is null) { status.Text = "Herstellen lukte niet. Controleer de gebruikersnaam en herstelcode."; return; }
                    _pendingUser = u; _pendingPassword = p;
                    ShowRegistration(registration, u, p, "Je toegang wordt hersteld. Bewaar de nieuwe codes; de oude werken niet meer.");
                }
                catch (Exception ex) { status.Text = ex.Message; }
            }),
            status,
            AppUi.Button("← Terug naar inloggen", () => ShowLogin())) };
    }

    void ShowRegistration(Registration registration, string username, string password, string lead)
    {
        Title = "Authenticator koppelen";
        var otp = AppUi.Entry("Eerste 6-cijferige code uit je authenticator", keyboard: Keyboard.Numeric);
        otp.MaxLength = 6;
        var codes = string.Join("\n", registration.RecoveryCodes);
        var status = AppUi.Label(lead);
        var qrBytes = registration.QrPng;
        var qr = new Image
        {
            Source = ImageSource.FromStream(() => new MemoryStream(qrBytes)),
            HeightRequest = 230,
            WidthRequest = 230,
            Aspect = Aspect.AspectFit,
            HorizontalOptions = LayoutOptions.Center
        };
        var secretValue = registration.SecretForManualEntry.Trim().Replace(" ", "").ToUpperInvariant();
        var secretEntry = new Entry
        {
            Text = secretValue,
            IsReadOnly = true,
            Keyboard = Keyboard.Text,
            IsTextPredictionEnabled = false,
            IsSpellCheckEnabled = false,
            FontFamily = "monospace",
            FontSize = 18,
            TextColor = AppUi.Foreground,
            BackgroundColor = AppUi.Surface,
            ClearButtonVisibility = ClearButtonVisibility.Never,
            HorizontalOptions = LayoutOptions.Fill,
            Margin = new Thickness(0, 2, 0, 6)
        };
        var secretHelp = AppUi.Label($"Accountnaam in Google Authenticator: MoodPress ({username})\nType: tijdgebaseerd (TOTP). Je kunt de sleutel hieronder ook lang indrukken en kopiëren.");
        var copySecret = AppUi.AsyncButton("📋 Kopieer handmatige instelsleutel", async () =>
        {
            try
            {
                await CopySecretToClipboardAsync("MoodPress authenticator-sleutel", secretValue);
                await DisplayAlertAsync("Sleutel gekopieerd", "Open Google Authenticator. Tik op +, kies 'Een instelsleutel invoeren', vul als naam MoodPress in, plak de sleutel bij 'Je sleutel' en kies 'Tijdgebaseerd'. Deel deze sleutel met niemand.", "OK");
            }
            catch (Exception ex)
            {
                AppLog.Write(ex);
                await DisplayAlertAsync("Kopiëren niet bevestigd", "De sleutel staat geselecteerd in het veld. Houd de tekst ingedrukt en kies Kopiëren; plak hem daarna in Google Authenticator.", "OK");
            }
        });
        var recovery = AppUi.Card(AppUi.Label(codes));
        Content = new ScrollView { Content = AppUi.Stack(
            AppUi.Title("Koppel je authenticator"),
            AppUi.Label("1. Open een authenticator-app.\n2. Scan de QR-code. Lukt scannen niet op dezelfde telefoon? Gebruik dan de kopieerknop en kies in Google Authenticator '+' → 'Een instelsleutel invoeren'.\n3. Plak de sleutel, kies 'Tijdgebaseerd' en typ de actuele 6-cijferige code hieronder."),
            qr,
            AppUi.Label("Handmatige instelsleutel", title: true), secretHelp, secretEntry, copySecret,
            AppUi.Title("Bewaar deze herstelcodes"),
            AppUi.Label("Bewaar ze buiten deze telefoon. Iedere code werkt één keer; deel ze met niemand."),
            recovery,
            AppUi.AsyncButton("📋 Herstelcodes kopiëren", async () => { await Clipboard.Default.SetTextAsync(codes); await DisplayAlertAsync("Gekopieerd", "Bewaar de codes op een veilige plek buiten deze telefoon.", "OK"); }),
            otp,
            AppUi.AsyncButton("Authenticator bevestigen", async () =>
            {
                var ok = await Task.Run(() => AppSession.Accounts.ConfirmRegistration(username, password, otp.Text ?? ""));
                if (!ok) { status.Text = "De code klopt niet. Controleer of de tijd op je telefoon goed staat en probeer een nieuwe code."; return; }
                await DisplayAlertAsync("Account klaar", "Je account is aangemaakt. Log nu in met je wachtwoord en authenticatorcode.", "Naar inloggen");
                ShowLogin("Account ingesteld. Je kunt nu inloggen.");
            }),
            status,
            AppUi.Button("Annuleren en terug", () => ShowLogin())) };
    }

    static async Task CopySecretToClipboardAsync(string label, string value)
    {
        if (string.IsNullOrWhiteSpace(value)) throw new InvalidOperationException("De instelsleutel is leeg.");
#if ANDROID
        var context = Android.App.Application.Context;
        var manager = context.GetSystemService(Android.Content.Context.ClipboardService) as Android.Content.ClipboardManager;
        if (manager is null) throw new InvalidOperationException("Het klembord is niet beschikbaar.");
        manager.PrimaryClip = ClipData.NewPlainText(label, value);
        var copied = manager.PrimaryClip?.GetItemAt(0)?.CoerceToText(context)?.ToString();
        if (!string.Equals(copied, value, StringComparison.Ordinal))
            throw new InvalidOperationException("Android heeft de instelsleutel niet op het klembord bevestigd.");
        await Task.CompletedTask;
#else
        await Clipboard.Default.SetTextAsync(value);
        var copied = await Clipboard.Default.GetTextAsync();
        if (!string.Equals(copied, value, StringComparison.Ordinal))
            throw new InvalidOperationException("De instelsleutel staat niet op het klembord.");
#endif
    }
}

internal static class AppLog
{
    public static void Write(Exception ex)
    {
        try
        {
            var path = Path.Combine(FileSystem.AppDataDirectory, "log.txt");
            var fi = new FileInfo(path);
            if (fi.Exists && fi.Length > 200_000) fi.Delete();
            File.AppendAllText(path, $"{DateTime.UtcNow:O} {ex.GetType().FullName}\n{ex.StackTrace}\n\n");
        }
        catch { }
    }
}
