using Microsoft.Maui;
using Microsoft.Maui.ApplicationModel;
using Microsoft.Maui.Graphics;
using Microsoft.Maui.Controls;

namespace MijnGevoel.AndroidApp;

public partial class App : Application
{
    public App()
    {
        InitializeComponent();
        StartAutoLockMonitor();
    }

    protected override Window CreateWindow(IActivationState? activationState)
    {
        var navigation = new NavigationPage(new BrandSplashPage())
        {
            BarBackgroundColor = Color.FromArgb("#0B1530"),
            BarTextColor = Colors.White
        };
        return new Window(navigation);
    }

    void StartAutoLockMonitor()
    {
        Dispatcher.StartTimer(TimeSpan.FromSeconds(15), () =>
        {
            var store = AppSession.Store;
            if (store is null) return true;
            var limit = Math.Max(1, AppSession.Settings.AutoLockMinutes);
            if (DateTime.UtcNow - AppSession.LastActivityUtc >= TimeSpan.FromMinutes(limit))
                MainThread.BeginInvokeOnMainThread(async () => await LockToLoginAsync("Je sessie is automatisch vergrendeld."));

            // Agenda-items blijven beschikbaar in het overzicht. Er verschijnen geen onverwachte
            // modal pop-ups of aftellende herinneringen, om onrust te voorkomen.
            return true;
        });
    }

    public async Task LockToLoginAsync(string? message = null, bool forgetRemembered = false)
    {
        // Bij 'ingelogd blijven' wordt de sessie alleen uit het geheugen vergrendeld.
        // De versleutelde herstelsleutel blijft bewaard en vraagt bij terugkeer biometrische bevestiging.
        if (forgetRemembered || !AppSession.KeepSignedIn)
            await AppSession.ClearRememberedSessionAsync();
        AppSession.End();
        if (Windows.FirstOrDefault()?.Page is NavigationPage nav)
        {
            await nav.PopToRootAsync(false);
            if (nav.Navigation.NavigationStack.FirstOrDefault() is LoginPage login)
                login.ShowLoginMessage(message);
        }
        AndroidScreenPrivacy.Apply(false);
    }

    protected override void OnSleep()
    {
        if (AppSession.Store is not null)
        {
            if (AppSession.KeepSignedIn)
                _ = AppSession.PersistRememberedActivityAsync(force: true);
            else
                MainThread.BeginInvokeOnMainThread(async () => await LockToLoginAsync("Je sessie is vergrendeld omdat de app naar de achtergrond ging."));
        }
        base.OnSleep();
    }

    protected override void OnResume()
    {
        base.OnResume();
        if (AppSession.Store is null) return;
        var limit = TimeSpan.FromMinutes(Math.Max(1, AppSession.Settings.AutoLockMinutes));
        if (DateTime.UtcNow - AppSession.LastActivityUtc >= limit)
            MainThread.BeginInvokeOnMainThread(async () => await LockToLoginAsync("Je sessie is automatisch vergrendeld na inactiviteit."));
        else if (AppSession.KeepSignedIn)
            _ = AppSession.PersistRememberedActivityAsync(force: true);
    }
}
