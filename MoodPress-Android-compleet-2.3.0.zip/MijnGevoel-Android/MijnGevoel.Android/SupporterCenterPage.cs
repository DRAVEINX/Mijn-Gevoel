using System.Text;
using Microsoft.Maui.ApplicationModel.DataTransfer;
using Microsoft.Maui.Storage;
using MijnGevoel.Core.Data;

namespace MijnGevoel.AndroidApp;

/// <summary>Lokale ondersteunersomgeving. Geen verborgen meekijkfunctie of live synchronisatie.</summary>
public sealed class SupporterCenterPage : ContentPage
{
    bool _unlocked;
    Entry _pin = null!, _confirm = null!;
    Label _status = null!;

    public SupporterCenterPage()
    {
        Title = "Ouder / voogd / begeleider";
        BackgroundColor = AppUi.Background;
        BuildLocked();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (_unlocked) return;
        if (await SupporterLocalStore.HasPinAsync()) BuildLocked(); else BuildCreatePin();
    }

    void BuildLocked()
    {
        _pin = AppUi.Entry("Lokale toegangscode", password: true);
        _status = AppUi.Label("Je gegevens blijven op dit toestel. De code voor deze omgeving staat los van het MoodPress-account.");
        Content = new ScrollView { Content = AppUi.Stack(
            AppUi.BrandLockup(true), AppUi.Title("Ondersteunersomgeving vergrendeld"),
            AppUi.Label("Voer de lokale toegangscode in om het ondersteuningsplan en het lokale logboek te openen."),
            _pin, _status,
            AppUi.AsyncButton("🔓 Open ondersteunersomgeving", UnlockAsync),
            AppUi.Button("Toegangscode vergeten? Wis uitsluitend lokale ondersteunerdata", ResetLocalAsync, quiet:true),
            AppUi.Button("Gedeeld bestand openen", () => Navigation.PushAsync(new ShareOpenPage()), quiet:true),
            AppUi.Button("← Terug naar MoodPress", () => Navigation.PopAsync(), quiet:true)) };
    }

    void BuildCreatePin()
    {
        _pin = AppUi.Entry("Nieuwe toegangscode (minimaal 8 tekens)", password: true);
        _confirm = AppUi.Entry("Toegangscode herhalen", password: true);
        _status = AppUi.Label("Maak een aparte lokale code. Deel deze niet. Als je de code vergeet, kun je het lokale ondersteuningsplan wissen maar niet terughalen.");
        Content = new ScrollView { Content = AppUi.Stack(
            AppUi.BrandLockup(true), AppUi.Title("Ondersteunersomgeving instellen"),
            AppUi.Label("Deze code beschermt alleen het plan en logboek die in deze ondersteuneromgeving worden bewaard. Het is geen accountkoppeling met de cliënt."),
            _pin, _confirm, _status,
            AppUi.AsyncButton("🔐 Code instellen en openen", CreatePinAsync),
            AppUi.Button("Gedeeld bestand openen", () => Navigation.PushAsync(new ShareOpenPage()), quiet:true),
            AppUi.Button("← Terug naar MoodPress", () => Navigation.PopAsync(), quiet:true)) };
    }

    async Task CreatePinAsync()
    {
        var pin = _pin.Text ?? "";
        if (pin.Length < 8) { _status.Text = "De code moet minimaal 8 tekens bevatten."; return; }
        if (pin != (_confirm.Text ?? "")) { _status.Text = "De codes zijn niet gelijk."; return; }
        try { await SupporterLocalStore.SetPinAsync(pin); _unlocked = true; await SupporterLocalStore.AddAuditAsync("Ondersteunercode ingesteld", "Lokale code aangemaakt"); await BuildHomeAsync(); }
        catch (Exception ex) { AppLog.Write(ex); _status.Text = "Opslaan in beveiligde opslag lukte niet. Controleer of schermvergrendeling op de telefoon actief is."; }
    }

    async Task UnlockAsync()
    {
        if (!await SupporterLocalStore.VerifyPinAsync(_pin.Text ?? "")) { _status.Text = "De code klopt niet. Probeer opnieuw."; return; }
        _unlocked = true;
        await SupporterLocalStore.AddAuditAsync("Ondersteunersomgeving geopend", "Lokale toegangscode geaccepteerd");
        await BuildHomeAsync();
    }

    async Task BuildHomeAsync()
    {
        Title = "MoodPress Ondersteuning";
        var plan = await SupporterLocalStore.LoadPlanAsync();
        var root = AppUi.Stack(
            AppUi.BrandLockup(true),
            AppUi.Title("Ondersteuning"),
            AppUi.Label("Gebruik dit gedeelte om iemand te ondersteunen op basis van informatie die die persoon bewust heeft gedeeld."),
            AppUi.Card(AppUi.Stack(
                AppUi.Title("Belangrijk om te weten"),
                AppUi.Label("Een rood stoplicht wordt niet automatisch door een mens gelezen. MoodPress is geen alarmcentrale. Bij direct gevaar: bel 112. Vraag eerst wat iemand zelf nodig heeft; ga niet uit van een diagnose."))),
            AppUi.Card(AppUi.Stack(
                AppUi.Label(string.IsNullOrWhiteSpace(plan.PersonName) ? "Er is nog geen lokaal ondersteuningsplan ingevuld." : "Plan voor: " + plan.PersonName, title:true),
                AppUi.Label(string.IsNullOrWhiteSpace(plan.Helps) ? "Vul in wat helpt, wat niet helpt en hoe je goed kunt communiceren." : "Wat helpt: " + plan.Helps))),
            AppUi.AsyncButton("📂 Gedeeld bestand / ondersteuningspakket openen", async () => await Navigation.PushAsync(new ShareOpenPage())),
            AppUi.AsyncButton("📝 Ondersteuningsplan maken of bewerken", async () => await Navigation.PushAsync(new SupportPlanEditorPage())),
            AppUi.AsyncButton("🗓️ Routine voorstellen aan de cliënt", async () => await Navigation.PushAsync(new SupporterRoutineProposalPage())),
            AppUi.AsyncButton("🚦 Uitleg over stoplicht en stressniveaus", async () => await Navigation.PushAsync(new SupporterColorGuidePage())),
            AppUi.AsyncButton("💬 Gespreksvragen en ondersteuningstips", async () => await Navigation.PushAsync(new SupportConversationGuidePage())),
            AppUi.AsyncButton("📜 Lokaal toegangslogboek bekijken", async () => await Navigation.PushAsync(new SupportAuditPage())),
            AppUi.Button("🔒 Ondersteunersomgeving vergrendelen", () => { _unlocked = false; BuildLocked(); }, quiet:true),
            AppUi.Button("← Terug", () => Navigation.PopAsync(), quiet:true),
            AppUi.Label("Privacy: gegevens worden niet online gesynchroniseerd. Deelbestanden kunnen alleen worden geopend met de afzonderlijk ontvangen deelcode.", muted:true));
        Content = new ScrollView { Content = root };
    }

    async Task ResetLocalAsync()
    {
        bool ok = await DisplayAlertAsync("Lokale ondersteunerdata wissen?", "Dit wist de lokale toegangscode, het lokale plan en het lokale logboek. Dit verwijdert geen gegevens uit een MoodPress-cliëntaccount.", "Wissen", "Annuleren");
        if (!ok) return;
        SupporterLocalStore.ResetLocalData(); _unlocked = false; BuildCreatePin();
    }
}

public sealed class SupportPlanEditorPage : ContentPage
{
    readonly Entry _name;
    readonly Editor _signs, _helps, _avoid, _communication, _steps, _goals, _routines, _contacts;
    readonly Label _status;
    SafetyPlan _loaded = new();

    public SupportPlanEditorPage()
    {
        Title = "Ondersteuningsplan"; BackgroundColor = AppUi.Background;
        _name = AppUi.Entry("Naam of gekozen aanspreeknaam");
        _signs = AppUi.Editor("Vroege signalen dat het moeilijk wordt", height:100);
        _helps = AppUi.Editor("Wat helpt deze persoon?", height:120);
        _avoid = AppUi.Editor("Wat werkt niet of kun je beter vermijden?", height:100);
        _communication = AppUi.Editor("Hoe communiceer je prettig? (tijd, korte zinnen, stilte…)", height:100);
        _steps = AppUi.Editor("Concrete helpstappen in volgorde", height:120);
        _goals = AppUi.Editor("Afspraken of doelen waar samen aan gewerkt wordt", height:100);
        _routines = AppUi.Editor("Dagritme, overgangsmomenten en rust", height:100);
        _contacts = AppUi.Editor("Contacten: één per regel als Naam | telefoonnummer", height:100);
        _status = AppUi.Label("Bewaar alleen wat echt nodig is en waarvoor je toestemming hebt.");
        Content = new ScrollView { Content = AppUi.Stack(
            AppUi.Title("Persoonlijk ondersteuningsplan"),
            AppUi.Label("Schrijf samen met de persoon zelf. Dit plan blijft lokaal in de beveiligde opslag van de ondersteunersomgeving."),
            AppUi.Label("Naam / aanspreeknaam", title:true), _name,
            AppUi.Label("Vroege signalen", title:true), _signs,
            AppUi.Label("Wat helpt?", title:true), _helps,
            AppUi.Label("Wat liever niet?", title:true), _avoid,
            AppUi.Label("Communicatie", title:true), _communication,
            AppUi.Label("Concrete stappen", title:true), _steps,
            AppUi.Label("Doelen en afspraken", title:true), _goals,
            AppUi.Label("Dagritme en rust", title:true), _routines,
            AppUi.Label("Contacten", title:true), _contacts, _status,
            AppUi.AsyncButton("💾 Plan versleuteld bewaren", SaveAsync),
            AppUi.AsyncButton("🔐 Versleuteld planpakket voor de cliënt maken", SharePlanAsync, quiet:true),
            AppUi.AsyncButton("📄 Plan als leesbare tekst bewaren/delen", SharePlainTextAsync, quiet:true),
            AppUi.Button("← Terug", () => Navigation.PopAsync(), quiet:true)) };
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing(); _loaded = await SupporterLocalStore.LoadPlanAsync();
        _name.Text = _loaded.PersonName; _signs.Text = _loaded.EarlySigns; _helps.Text = _loaded.Helps;
        _avoid.Text = _loaded.Avoid; _communication.Text = _loaded.Communication; _steps.Text = _loaded.SupportSteps;
        _goals.Text = _loaded.Goals; _routines.Text = _loaded.RoutineNotes;
        _contacts.Text = string.Join("\n", _loaded.Contacts.Select(c => c.Name + " | " + c.Phone));
    }

    SafetyPlan ComposePlan()
    {
        var contacts = (_contacts.Text ?? "").Split('\n').Select(x => x.Trim()).Where(x => x.Length > 0).Take(100).Select(x => {
            var p = x.Split('|',2); return new ContactPerson(p[0].Trim(), p.Length > 1 ? p[1].Trim() : "");
        }).ToList();
        return new SafetyPlan { PersonName = (_name.Text ?? "").Trim(), EarlySigns = (_signs.Text ?? "").Trim(), Helps = (_helps.Text ?? "").Trim(), Avoid = (_avoid.Text ?? "").Trim(), Communication = (_communication.Text ?? "").Trim(), SupportSteps = (_steps.Text ?? "").Trim(), Goals = (_goals.Text ?? "").Trim(), RoutineNotes = (_routines.Text ?? "").Trim(), Contacts = contacts, HelpOptions = _loaded.HelpOptions ?? new() };
    }

    async Task SaveAsync()
    {
        var plan = ComposePlan();
        if (new[] { plan.PersonName, plan.EarlySigns, plan.Helps, plan.Avoid, plan.Communication, plan.SupportSteps, plan.Goals, plan.RoutineNotes }.Any(x => x.Length > 8000))
        { _status.Text = "Een veld is te lang. Houd elk onderdeel onder 8.000 tekens."; return; }
        try { await SupporterLocalStore.SavePlanAsync(plan); await SupporterLocalStore.AddAuditAsync("Ondersteuningsplan opgeslagen", "Lokaal plan bijgewerkt"); _loaded = plan; _status.Text = "Versleuteld opgeslagen ✔"; }
        catch (Exception ex) { AppLog.Write(ex); _status.Text = "Opslaan is mislukt. Controleer de beveiligde opslag op dit toestel."; }
    }

    async Task SharePlainTextAsync()
    {
        var plan=ComposePlan();
        if(!await DisplayAlertAsync("Leesbare tekst delen?","Een tekstbestand is niet versleuteld. Iedereen die het bestand ontvangt kan het lezen. Gebruik liever het versleutelde pakket als je twijfelt.","Doorgaan","Annuleren"))return;
        try
        {
            var text=$"MoodPress ondersteuningsplan\nNaam: {plan.PersonName}\n\nVroege signalen\n{plan.EarlySigns}\n\nWat helpt\n{plan.Helps}\n\nWat liever niet\n{plan.Avoid}\n\nCommunicatie\n{plan.Communication}\n\nHelpstappen\n{plan.SupportSteps}\n\nDoelen\n{plan.Goals}\n\nDagritme\n{plan.RoutineNotes}\n\nContacten\n{string.Join("\n",plan.Contacts.Select(c=>c.Name+" | "+c.Phone))}";
            var path=Path.Combine(FileSystem.CacheDirectory,$"MoodPress-ondersteuningsplan-{DateTime.Now:yyyyMMdd-HHmmss}.txt");
            await File.WriteAllTextAsync(path,text,new System.Text.UTF8Encoding(false));
            await Share.Default.RequestAsync(new ShareFileRequest{Title="MoodPress ondersteuningsplan (niet versleuteld)",File=new ShareFile(path)});
            await SupporterLocalStore.AddAuditAsync("Leesbaar plan gedeeld", "Niet-versleuteld tekstdocument aangemaakt");
        }
        catch(Exception ex){AppLog.Write(ex);await DisplayAlertAsync("Delen niet gelukt","Het leesbare plan kon niet worden gemaakt.","OK");}
    }

    async Task SharePlanAsync()
    {
        var plan = ComposePlan();
        if (string.IsNullOrWhiteSpace(plan.PersonName) && string.IsNullOrWhiteSpace(plan.Helps) && string.IsNullOrWhiteSpace(plan.SupportSteps))
        { _status.Text = "Vul eerst enkele planonderdelen in."; return; }
        if (!await DisplayAlertAsync("Versleuteld planpakket maken?", "Alleen de onderdelen van dit ondersteuningsplan worden meegestuurd. Het bestand en de deelcode moeten apart worden verstuurd. Deel alleen met toestemming.", "Doorgaan", "Annuleren")) return;
        try
        {
            var code = SupportShareService.NewShareCodeForUi();
            var bytes = SupportShareService.Create("Ondersteuner", plan, Array.Empty<StoplichtEntry>(), Array.Empty<RoutineSuggestion>(), code);
            var path = Path.Combine(FileSystem.CacheDirectory, $"MoodPress-ondersteuningsplan-{DateTime.Now:yyyyMMdd-HHmmss}.mgsupport");
            await File.WriteAllBytesAsync(path, bytes);
            await Share.Default.RequestAsync(new ShareFileRequest { Title = "Versleuteld MoodPress-ondersteuningsplan", File = new ShareFile(path) });
            await Clipboard.Default.SetTextAsync(code);
            await SupporterLocalStore.AddAuditAsync("Ondersteuningsplan gedeeld", "Versleuteld planpakket aangemaakt");
            await DisplayAlertAsync("Deelcode", "De code staat op het klembord. Verstuur deze via een ander kanaal dan het bestand:\n\n" + code, "OK");
            _status.Text = "Versleuteld planpakket aangemaakt.";
        }
        catch (Exception ex) { AppLog.Write(ex); _status.Text = "Het planpakket kon niet worden gemaakt. Controleer of de velden niet te lang zijn."; }
    }
}

public sealed class SupporterRoutineProposalPage : ContentPage
{
    readonly Entry _title, _icon;
    readonly Editor _steps;
    readonly Label _status;
    public SupporterRoutineProposalPage()
    {
        Title = "Routine voorstellen"; BackgroundColor = AppUi.Background;
        _title = AppUi.Entry("Naam van de routine (bijv. rustige ochtend)"); _icon = AppUi.Entry("Pictogram (bijv. 🌤️)", "✅"); _steps = AppUi.Editor("Eén stap per regel", height:180); _status = AppUi.Label("");
        Content = new ScrollView { Content = AppUi.Stack(
            AppUi.Title("Routine voorstellen"),
            AppUi.Label("De cliënt beslist zelf of de routine wordt toegevoegd. Het voorstel verschijnt nooit automatisch in diens app."),
            AppUi.Label("Naam", title:true), _title, AppUi.Label("Pictogram", title:true), _icon,
            AppUi.Label("Stappen", title:true), _steps, _status,
            AppUi.AsyncButton("📤 Versleuteld routinevoorstel delen", ShareAsync),
            AppUi.Button("← Terug", () => Navigation.PopAsync(), quiet:true)) };
    }
    async Task ShareAsync()
    {
        var title = (_title.Text ?? "").Trim(); var steps = (_steps.Text ?? "").Split('\n').Select(x=>x.Trim()).Where(x=>x.Length>0).Take(100).ToArray();
        if (title.Length is < 2 or > 120 || steps.Length == 0 || steps.Any(x=>x.Length>250)) { _status.Text = "Vul een naam (2–120 tekens) en minstens één stap in. Elke stap mag maximaal 250 tekens zijn."; return; }
        if (!await DisplayAlertAsync("Voorstel delen?", "De cliënt ontvangt een versleuteld bestand en beslist zelf of die de routine accepteert.", "Delen", "Annuleren")) return;
        try
        {
            var code = SupportShareService.NewShareCodeForUi();
            var item = new RoutineSuggestion(Guid.NewGuid(), title, string.IsNullOrWhiteSpace(_icon.Text) ? "✅" : _icon.Text.Trim()[..Math.Min(_icon.Text.Trim().Length, 20)], steps, DateTime.Now, "Ondersteuner");
            var bytes = SupportShareService.Create("Ondersteuner", null, Array.Empty<StoplichtEntry>(), new[] { item }, code);
            var path = Path.Combine(FileSystem.CacheDirectory, $"MoodPress-routinevoorstel-{DateTime.Now:yyyyMMdd-HHmmss}.mgsupport");
            await File.WriteAllBytesAsync(path, bytes);
            await Share.Default.RequestAsync(new ShareFileRequest { Title = "MoodPress routinevoorstel", File = new ShareFile(path) });
            await Clipboard.Default.SetTextAsync(code);
            await SupporterLocalStore.AddAuditAsync("Routinevoorstel gedeeld", title);
            _status.Text = "Voorstel gedeeld. De deelcode is naar het klembord gekopieerd.";
            await DisplayAlertAsync("Deelcode", "Stuur de code via een ander kanaal dan het bestand:\n\n" + code, "OK");
        }
        catch (Exception ex) { AppLog.Write(ex); _status.Text = "Het voorstel kon niet worden gedeeld. Controleer de invoer."; }
    }
}

public sealed class SupportConversationGuidePage : ContentPage
{
    public SupportConversationGuidePage()
    {
        Title="Gespreksvragen"; BackgroundColor=AppUi.Background;
        var root=AppUi.Stack(AppUi.Title("Vragen die ruimte geven"),
            AppUi.Label("Begin rustig. Vraag wat iemand nodig heeft in plaats van meteen een oplossing te geven."),
            AppUi.Card(AppUi.Stack(AppUi.Label("Wat merk je zelf?",title:true),AppUi.Label("Wat voelt op dit moment het moeilijkst?\nWat gebeurde er vlak hiervoor?\nWil je praten, samen iets doen of liever rust?"))),
            AppUi.Card(AppUi.Stack(AppUi.Label("Wat helpt wel en niet?",title:true),AppUi.Label("Wil je dat ik luister of met je meedenk?\nIs het fijner als ik korte vragen stel?\nIs aanraken of dichtbij komen oké?\nWelke stap voelt haalbaar?"))),
            AppUi.Card(AppUi.Stack(AppUi.Label("Als praten moeilijk is",title:true),AppUi.Label("Bied twee eenvoudige keuzes, laat tijd om te antwoorden en accepteer wijzen, schrijven of een communicatiekaart. Forceer geen oogcontact."))),
            AppUi.Card(AppUi.Stack(AppUi.Label("Wanneer er direct gevaar is",title:true),AppUi.Label("MoodPress monitort niet en waarschuwt niemand automatisch. Blijf waar mogelijk bij de persoon en schakel passende hulp in. Bel bij direct gevaar 112."))),
            AppUi.Button("Voorlezen",()=>AppUi.Speak("Wat merk je zelf? Wil je praten, samen iets doen of liever rust? Wat helpt wel en niet? Bied keuzes en geef tijd om te antwoorden."),quiet:true),
            AppUi.Button("← Terug",()=>Navigation.PopAsync(),quiet:true));
        Content=new ScrollView{Content=root};
    }
}

public sealed class SupportAuditPage : ContentPage
{
    public SupportAuditPage() { Title="Lokaal logboek"; BackgroundColor=AppUi.Background; Content=new ScrollView{Content=AppUi.Stack(AppUi.Title("Lokaal logboek"),AppUi.Label("Dit overzicht bestaat alleen op dit toestel. Het is geen gedeeld online toegangslog en vertelt de cliënt niet of een pakket is geopend."),AppUi.Label("Laden…"),AppUi.Button("← Terug",()=>Navigation.PopAsync(),quiet:true))}; }
    protected override async void OnAppearing() { base.OnAppearing(); var items=await SupporterLocalStore.GetAuditAsync(); var root=AppUi.Stack(AppUi.Title("Lokaal logboek"),AppUi.Label("Alleen lokale gebeurtenissen, maximaal 50. Er wordt niets naar de cliënt teruggestuurd.")); if(items.Count==0)root.Children.Add(AppUi.Label("Nog geen gebeurtenissen.")); foreach(var item in items) root.Children.Add(AppUi.Card(AppUi.Stack(AppUi.Label(item.Action,title:true),AppUi.Label(item.Created.ToString("dd-MM-yyyy HH:mm"),muted:true),AppUi.Label(item.Summary)))); root.Children.Add(AppUi.Button("← Terug",()=>Navigation.PopAsync(),quiet:true)); Content=new ScrollView{Content=root}; }
}


/// <summary>Neutrale uitleg voor ondersteuners; kleur of getal is geen diagnose of automatische melding.</summary>
public sealed class SupporterColorGuidePage : ContentPage
{
    public SupporterColorGuidePage()
    {
        Title = "Uitleg stoplicht"; BackgroundColor = AppUi.Background;
        var root = AppUi.Stack(AppUi.Title("🚦 Stoplicht en stressniveau"),
            AppUi.Label("Gebruik de kleur of het cijfer als startpunt voor een gesprek. Vraag de persoon zelf wat het voor haar of hem betekent."),
            AppUi.Card(AppUi.Stack(AppUi.Label("🟢 Groen",title:true),AppUi.Label("Vraag wat goed gaat en wat iemand wil vasthouden. Maak er geen beoordeling of beloning van."))),
            AppUi.Card(AppUi.Stack(AppUi.Label("🟠 Oranje",title:true),AppUi.Label("Vraag rustig of luisteren, rust, praktische hulp of samen plannen prettig is. Geef tijd om te reageren en bied niet te veel keuzes tegelijk."))),
            AppUi.Card(AppUi.Stack(AppUi.Label("🔴 Rood",title:true),AppUi.Label("Vraag welke stap nu helpt. MoodPress stuurt geen waarschuwing naar iemand anders. Bij direct gevaar schakel je direct hulp in; in Nederland bel je 112."))),
            AppUi.Card(AppUi.Stack(AppUi.Label("Stressniveau 1–5",title:true),AppUi.Label("Het getal is alleen wat de gebruiker op dat moment heeft ingevuld. Het is geen diagnose, risicoscore of bewijs dat iemand liegt. Vergelijk liever niet tussen mensen."))),
            AppUi.Button("🔊 Lees de belangrijkste uitleg voor",()=>AppUi.Speak("Vraag de persoon zelf wat de kleur of het cijfer betekent. Groen: vraag wat goed gaat. Oranje: vraag of rust of luisteren helpt. Rood: vraag welke stap nu helpt. MoodPress waarschuwt niemand automatisch. Bij direct gevaar bel je 112."),quiet:true),
            AppUi.Button("← Terug",()=>Navigation.PopAsync(),quiet:true));
        Content = new ScrollView { Content = root };
    }
}
