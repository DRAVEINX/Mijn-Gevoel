using Plugin.Maui.Audio;

namespace MijnGevoel.AndroidApp;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder.UseMauiApp<App>();
        builder.AddAudio();
        return builder.Build();
    }
}
