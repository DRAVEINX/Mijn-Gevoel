using Microsoft.Maui.Storage;
using MijnGevoel.Core.Data;

namespace MijnGevoel.AndroidApp;

/// <summary>Begeleiderweergave: opent alleen het bewust gedeelde bestand in het geheugen; het slaat niets op in het account.</summary>
public sealed class ShareOpenPage : ContentPage
{
    const int MaximumShareFileBytes = 10 * 1024 * 1024;
    byte[]? _fileBytes;
    readonly Entry _code;
    readonly Label _status;
    readonly Label _fileName;

    public ShareOpenPage()
    {
        Title = "Gedeeld bestand openen";
        BackgroundColor = AppUi.Background;
        _code = AppUi.Entry("Deelcode van de cliënt");
        _status = AppUi.Label("Kies het .mgdeel-bestand en voer daarna de code in.");
        _fileName = AppUi.Label("Nog geen bestand gekozen.", muted: true);
        Content = new ScrollView
        {
            Content = AppUi.Stack(
                AppUi.Title("Voor begeleiders"),
                AppUi.Label("Hiervoor is geen account nodig. Het bestand en de deelcode moeten apart van elkaar zijn ontvangen. Het geopende bestand wordt niet in MoodPress opgeslagen."),
                AppUi.AsyncButton("📂 Kies een deelbestand", PickAsync),
                _fileName,
                _code,
                AppUi.AsyncButton("🔓 Open versleuteld bestand", OpenAsync),
                _status,
                AppUi.Button("← Terug", async () => await Navigation.PopAsync(), quiet: true))
        };
    }

    async Task PickAsync()
    {
        var picked = await FilePicker.Default.PickAsync(new PickOptions { PickerTitle = "Kies het gedeelde .mgdeel-bestand" });
        if (picked is null) return;
        try
        {
            await using var stream = await picked.OpenReadAsync();
            using var memory = new MemoryStream();
            var buffer = new byte[64 * 1024];
            while (true)
            {
                var read = await stream.ReadAsync(buffer.AsMemory(0, buffer.Length));
                if (read == 0) break;
                if (memory.Length + read > MaximumShareFileBytes)
                {
                    _fileBytes = null;
                    _fileName.Text = "Bestand te groot";
                    _status.Text = "Dit deelbestand is te groot om veilig te openen. Kies een MoodPress-deelbestand kleiner dan 10 MB.";
                    return;
                }
                memory.Write(buffer, 0, read);
            }
            _fileBytes = memory.ToArray();
            _fileName.Text = picked.FileName;
            _status.Text = "Bestand klaar. Vul de deelcode in die je apart hebt ontvangen.";
        }
        catch (Exception ex)
        {
            AppLog.Write(ex);
            _fileBytes = null;
            _status.Text = "Het bestand kon niet worden gelezen. Kies een geldig MoodPress-deelbestand.";
        }
    }

    async Task OpenAsync()
    {
        if (_fileBytes is null) { _status.Text = "Kies eerst het deelbestand."; return; }
        if (string.IsNullOrWhiteSpace(_code.Text)) { _status.Text = "Vul de deelcode in."; return; }
        if ((_fileName.Text ?? "").EndsWith(".mgsupport", StringComparison.OrdinalIgnoreCase))
        {
            var sharedSupport = await Task.Run(() => SupportShareService.Open(_fileBytes, _code.Text));
            if (sharedSupport is null) { _status.Text = "Openen lukte niet. Controleer het ondersteuningspakket en de deelcode."; return; }
            await SupporterLocalStore.AddAuditAsync("Gedeeld pakket geopend", $"Stoplicht: {sharedSupport.StoplightEntries.Count}, routines: {sharedSupport.RoutineSuggestions.Count}, gevoelscheck-ins: {sharedSupport.MoodCheckIns.Count}, stresscheck-ins: {sharedSupport.YouthCheckIns.Count}, plan: {(sharedSupport.HelpPlan is null ? "nee" : "ja")}");
            ShowSupportPackage(sharedSupport);
            return;
        }
        var package = await Task.Run(() => ShareService.Open(_fileBytes, _code.Text));
        if (package is null) { _status.Text = "Openen lukte niet. Controleer het bestand en de deelcode."; return; }

        Title = "Gedeelde meldingen";
        var root = new VerticalStackLayout { Padding = 16, Spacing = 10, BackgroundColor = AppUi.Background };
        root.Children.Add(AppUi.Title("Gedeeld door " + package.From));
        root.Children.Add(AppUi.Label($"Ontvangen deelbestand · gemaakt op {package.Created:dd-MM-yyyy HH:mm}. De cliënt heeft zelf geselecteerd wat gedeeld werd. Dit scherm bewaart de inhoud niet."));
        foreach (var entry in package.Items.OrderBy(x => x.Colour == "Rood" ? 0 : x.Colour == "Oranje" ? 1 : 2).ThenByDescending(x => x.Created))
        {
            var emoji = entry.Colour == "Rood" ? "🔴" : entry.Colour == "Oranje" ? "🟠" : "🟢";
            var lines = new VerticalStackLayout { Spacing = 4 };
            lines.Children.Add(AppUi.Label($"{emoji} {entry.Colour} — {entry.Created:dd-MM-yyyy HH:mm}", title: true));
            var reasons = entry.Reasons ?? Array.Empty<string>();
            var needs = entry.Needs ?? Array.Empty<string>();
            if (reasons.Length > 0) lines.Children.Add(AppUi.Label("Waarom: " + string.Join(", ", reasons)));
            if (needs.Length > 0) lines.Children.Add(AppUi.Label("Nodig: " + string.Join(", ", needs)));
            if (!string.IsNullOrWhiteSpace(entry.Text)) lines.Children.Add(AppUi.Label(entry.Text));
            root.Children.Add(AppUi.Card(lines));
        }
        root.Children.Add(AppUi.Button("Sluiten", async () => await Navigation.PopAsync()));
        Content = new ScrollView { Content = root };
        _fileBytes = null;
        _code.Text = "";
    }

    void ShowSupportPackage(SupportSharePackage package)
    {
        Title = "Ondersteuningspakket";
        var root = AppUi.Stack(AppUi.Title("Pakket van " + package.From),
            AppUi.Label($"Gemaakt op {package.Created:dd-MM-yyyy HH:mm}. Alleen gekozen onderdelen zijn opgenomen. Deze weergave slaat de cliëntgegevens niet op."));
        if (package.HelpPlan is not null)
        {
            var p = package.HelpPlan;
            root.Children.Add(AppUi.Card(AppUi.Stack(AppUi.Label("Ondersteuningsplan",title:true),
                AppUi.Label("Vroege signalen: " + p.EarlySigns), AppUi.Label("Wat helpt: " + p.Helps), AppUi.Label("Wat liever niet: " + p.Avoid),
                AppUi.Label("Communicatie: " + p.Communication), AppUi.Label("Helpstappen: " + p.SupportSteps), AppUi.Label("Doelen: " + p.Goals),
                AppUi.Label("Dagritme: " + p.RoutineNotes), AppUi.Label("Contacten: " + string.Join("; ",p.Contacts.Select(c=>c.Name+(string.IsNullOrWhiteSpace(c.Phone)?"":" — "+c.Phone)))))));
        }
        foreach (var e in package.StoplightEntries)
        {
            var hint = e.Colour == "Rood" ? "Vraag rustig wat nu nodig is. Help met een afgesproken stap; bij direct gevaar schakel je direct hulp in." : e.Colour == "Oranje" ? "Vraag of rust, praktische hulp of luisteren prettig is. Geef tijd om te reageren." : "Vraag wat goed ging en wat iemand wil vasthouden. Maak er geen beoordeling van.";
            root.Children.Add(AppUi.Card(AppUi.Stack(AppUi.Label($"{(e.Colour=="Rood"?"🔴":e.Colour=="Oranje"?"🟠":"🟢")} {e.Colour} — {e.Created:dd-MM-yyyy HH:mm}",title:true),AppUi.Label("Waarom: "+string.Join(", ",e.Reasons)),AppUi.Label("Nodig: "+string.Join(", ",e.Needs)),AppUi.Label(e.Text),AppUi.Label("Gesprekssuggestie: "+hint))));
        }
        foreach (var m in package.MoodCheckIns) root.Children.Add(AppUi.Card(AppUi.Stack(AppUi.Label($"Gevoelscheck-in — {m.Created:dd-MM-yyyy HH:mm}",title:true),AppUi.Label($"{m.Feeling} · intensiteit {m.Intensity}/10"),AppUi.Label(m.Reason),AppUi.Label(m.Note),AppUi.Label("Vraag: wil je hier samen over praten of wil je liever rust?"))));
        foreach (var y in package.YouthCheckIns) root.Children.Add(AppUi.Card(AppUi.Stack(AppUi.Label($"Stresscheck-in — {y.Created:dd-MM-yyyy HH:mm}",title:true),AppUi.Label($"{y.Situation} · stress {y.StressLevel}/5"),AppUi.Label("Nodig: "+y.Need),AppUi.Label(y.Note),AppUi.Label("Vraag: wat zou jou nu het meest helpen?"))));
        foreach (var routine in package.RoutineSuggestions)
            root.Children.Add(AppUi.Card(AppUi.Stack(AppUi.Label($"{routine.Icon} {routine.Title}",title:true),AppUi.Label(string.Join("\n",routine.Steps.Select((x,i)=>$"{i+1}. {x}"))))));
        root.Children.Add(AppUi.Label("Dit pakket is een momentopname. Het creëert geen live koppeling, stuurt geen melding terug en vertelt de cliënt niet dat je het hebt geopend."));
        root.Children.Add(AppUi.Button("Sluiten", async () => await Navigation.PopAsync()));
        Content = new ScrollView { Content = root };
        _fileBytes = null; _code.Text = "";
    }

}
