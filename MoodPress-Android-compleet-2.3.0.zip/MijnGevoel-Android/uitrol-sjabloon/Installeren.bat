@echo off
setlocal
cd /d "%~dp0"
set "DEST=%LocalAppData%\Programs\MoodPress"
echo MoodPress wordt geinstalleerd voor jouw Windows-account. Je hebt geen beheerder nodig.
if not exist "%DEST%" mkdir "%DEST%"
taskkill /im MijnGevoel.exe /f >nul 2>&1
copy /y "%~dp0MijnGevoel.exe" "%DEST%\MijnGevoel.exe" >nul
if errorlevel 1 goto :fout
powershell -NoProfile -Command "Unblock-File -LiteralPath '%DEST%\MijnGevoel.exe'; $sh=New-Object -ComObject WScript.Shell; foreach($dir in @([Environment]::GetFolderPath('Programs'),[Environment]::GetFolderPath('Desktop'))){ $l=$sh.CreateShortcut((Join-Path $dir 'MoodPress.lnk')); $l.TargetPath='%DEST%\MijnGevoel.exe'; $l.WorkingDirectory='%DEST%'; $l.Description='MoodPress'; $l.Save() }"
if errorlevel 1 goto :fout
echo.
echo Klaar! Je vindt MoodPress in het startmenu en op het bureaublad.
start "" "%DEST%\MijnGevoel.exe"
pause
exit /b 0
:fout
echo.
echo Installeren is niet gelukt. Maak een schermafbeelding van dit venster en stuur die naar degene die je dit pakket gaf.
pause
exit /b 1
