@echo off
setlocal
set "DEST=%LocalAppData%\Programs\MoodPress"
taskkill /im MijnGevoel.exe /f >nul 2>&1
if exist "%DEST%" rmdir /s /q "%DEST%"
powershell -NoProfile -Command "foreach($dir in @([Environment]::GetFolderPath('Programs'),[Environment]::GetFolderPath('Desktop'))){ Remove-Item -LiteralPath (Join-Path $dir 'MoodPress.lnk') -ErrorAction SilentlyContinue }"
echo.
echo Het programma is verwijderd.
echo Je eigen gegevens blijven bewaard in de map %LocalAppData%\MijnGevoel
echo Verwijder die map alleen als je alles definitief wilt wissen.
pause
