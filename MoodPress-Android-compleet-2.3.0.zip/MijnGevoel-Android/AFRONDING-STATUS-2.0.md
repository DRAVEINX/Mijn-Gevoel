# MoodPress Android 2.0 — afrondingsstatus

## In deze broncode-update

- Android-weergaveversie verhoogd naar `2.0`, version code naar `20`.
- Dagelijkse check-in, gevoelskalender en 7-/30-dageninzichten zijn gekoppeld aan het dashboard en de feature-router.
- Check-ins zijn zichtbaar in het weekoverzicht en de privacytelling en worden opgenomen in de JSON-export.
- Inzichtfilters begrenzen de telling tot de huidige dag plus de voorgaande 6 of 29 kalenderdagen.
- Tekenen bewaart kleur en pendikte per lijn; ongedaan maken en wissen werken op de parallelle lijsten.
- Exporttest uitgebreid om opslag en export van een check-in te controleren.
- Debugworkflow, lokale buildscript en releaseworkflow afgestemd op `.NET 10` / `net10.0-android`.
- Releaseworkflow vraagt expliciet om `MijnGevoel-Android-compleet-2.0.zip` en controleert displayversie/code.

## Controles uitgevoerd in deze werkomgeving

- Bron-ZIP uitgepakt en bestandsstructuur gelezen.
- Android-projectversie en releaseworkflowversie gecontroleerd op `2.0` / `20`.
- Referenties naar check-in, kalender en inzichten gecontroleerd in dashboard en router.
- Testbron uitgebreid om bewaren en export van check-ins te controleren.
- Releaseworkflow en buildscript aangepast aan de projecttarget.

## Niet als geslaagd gemeld

De `.NET SDK` is niet geïnstalleerd in deze werkomgeving. Er is daarom **geen echte C#-compilatie of APK/AAB-build uitgevoerd**. Er is ook geen fysieke Android-toesteltest uitgevoerd. Deze status bevestigt geen runtime-werking of productiegeschiktheid. Laat GitHub Actions bouwen en test daarna de APK volgens `ANDROID-ACCEPTATIETEST.md`.

## Volgende stappen

1. Upload de projectinhoud naar GitHub en plaats `MijnGevoel-Android-compleet-2.0.zip` in de hoofdmap.
2. Plaats `android-release.yml` als `.github/workflows/android-release.yml` en commit de wijzigingen.
3. Controleer de bestaande ondertekeningssecrets, start de Release-workflow en controleer dat de build groen is.
4. Download de artifact, controleer `SHA256SUMS.txt` en installeer de APK op een testtelefoon.
5. Voer de volledige acceptatietest uit met testgegevens. Maak eerst een back-up voordat je een bestaande installatie vervangt.
