## MoodPress 2.2.3 — bugfixes en toegankelijkheid

Bekijk `UPDATE-2.2.3-LEES-MIJ.txt`, de UI-acceptatiechecklist in `docs/12-UI-BUGAUDIT-EN-TOEGANKELIJKHEID.md` en de roadmap in `docs/13-ROADMAP-BEGELEIDER-LEEFTIJDSGROEPEN.md`.

# Start hier - MoodPress (versie 1.0.8)

## In 3 stappen naar het installatiebestand
1. Installeer de **.NET 8 SDK** op een Windows 11-computer met internet: https://dotnet.microsoft.com/download
2. Pak deze zip uit in een **lege map** en dubbelklik op **`bouwen.bat`**. Het duurt een paar minuten.
3. Staat er "KLAAR!" in beeld, dan staat `MijnGevoel-installatie.msi` in dezelfde map. Dubbelklik om te installeren.

## Delen met anderen
Zie `DELEN.md`: draagbaar zip-bestand (geen beheerder nodig) of laten bouwen in de cloud met een downloadlink.

## Gaat er iets mis?
Het script bewaart alles in **`bouwlog.txt`** (zelfde map). Stuur dat bestand naar mij. Daarmee kan ik fouten gericht oplossen en een nieuwe zip maken.
Crasht het programma later? Stuur `%LocalAppData%\MijnGevoel\log.txt` (bevat geen cliëntgegevens).

## Eerlijk over de stand van zaken
- Het programma is geschreven zonder het te kunnen compileren of draaien. De eerste build kan dus nog kleine fouten laten zien. Het leesbare deelbestand (.html) is wel in een echte browser getest.
- Gebruik het **niet bij cliënten** voordat de acceptatietest, de juridische beoordeling, de beveiligingstoets en de test met cliënten klaar zijn (zie `OPLEVERING.md`).

## Wat zit waar
| Bestand/map | Wat |
|---|---|
| `bouwen.bat` | Bouwt tests, programma en .msi, en schrijft `bouwlog.txt` |
| `MijnGevoel.Core` | Beveiliging, versleutelde opslag, delen, back-up |
| `MijnGevoel.Desktop` | Het programma (schermen, uiterlijk) |
| `MijnGevoel.Tests` | Automatische tests |
| `installer` | Instellingen voor de .msi (pas `Manufacturer` aan) |
| `docs` | Beveiligingstoets, DPIA, testplan, herstelbeleid, delen, wetgeving, modellen, acceptatietest |
| `FUNCTIES.md` | Wat er wel en bewust niet in zit |
| `OPLEVERING.md` | Stappenplan van bouwen tot gebruik |
| `HANDLEIDING.md`, `PRIVACY-CONCEPT.md` | Voor cliënten en begeleiders (concept) |
| `MijnGevoel-voorbeeld-deelbestand.html` | Voorbeeld van het deelbestand (code `DEMO-2027-TEST`) |


## MoodPress 2.2.2 — vernieuwde uitstraling

MoodPress heeft een donkerblauwe interface met neonblauwe, cyan-, paarse en roze accenten, een nieuw hart/vinger-logo en de slogan **Jouw gevoel. Jouw verhaal. Jouw app.** De routines en herinneringen en alle bestaande gevoel-, rust-, privacy-, dagboek-, teken- en exportfuncties zijn behouden. Android package-id `nl.mijngevoel.app` is bewust hetzelfde gebleven voor een update over de bestaande installatie.
