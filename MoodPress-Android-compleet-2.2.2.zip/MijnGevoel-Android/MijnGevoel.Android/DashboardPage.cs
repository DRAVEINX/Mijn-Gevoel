using System.Globalization;
using System.Text.RegularExpressions;
using MijnGevoel.Core.Data;
using Microsoft.Maui.ApplicationModel.Communication;

namespace MijnGevoel.AndroidApp;

public enum FeatureKind
{
    Stoplicht, DayToday, DayTomorrow, Agenda, Timer, Routines, RoutineReminders,
    Breath, Calm, Sensory, Body, MoodHistory, FeelingWords,
    Cards, TalkPrep, StoplichtHistory, Share, SafetyPlan,
    Draw, Gallery, Notes, Journal, Privacy, Week, Settings, Help, WhoWorks, DailyCheckIn, MoodCalendar, MoodInsights
}

public sealed class DashboardPage : ContentPage
{
    bool _consentPrompted;
    static readonly (string Name, string Icon, FeatureKind Kind)[][] Groups =
    {
        new[] { ("Vandaag", "🗓️", FeatureKind.DayToday), ("Wie werkt er?", "👥", FeatureKind.WhoWorks), ("Morgen bekijken", "🌙", FeatureKind.DayTomorrow), ("Agenda", "📅", FeatureKind.Agenda), ("Timer", "⏳", FeatureKind.Timer), ("Stappenplannen", "✅", FeatureKind.Routines), ("Routines en herinneringen", "⏰", FeatureKind.RoutineReminders) },
        new[] { ("Mijn gevoel", "😊", FeatureKind.DailyCheckIn), ("Rust en ontspanning", "🌬️", FeatureKind.Breath), ("Rustplek", "🌲", FeatureKind.Calm), ("Prikkelmeter", "🎚️", FeatureKind.Sensory), ("Mijn lichaam", "🧍", FeatureKind.Body), ("Hoe voel ik me?", "📊", FeatureKind.MoodHistory), ("Gevoelswoorden", "📖", FeatureKind.FeelingWords), ("Gevoelskalender", "🗓️", FeatureKind.MoodCalendar), ("Mijn inzichten", "📈", FeatureKind.MoodInsights) },
        new[] { ("Communicatiekaarten", "💬", FeatureKind.Cards), ("Gesprekskaart", "🗣️", FeatureKind.TalkPrep), ("Mijn stoplicht", "🚦", FeatureKind.Stoplicht), ("Stoplicht-overzicht", "📊", FeatureKind.StoplichtHistory), ("Delen met mijn begeleider", "📤", FeatureKind.Share), ("Mijn helpkaart / plan", "🆘", FeatureKind.SafetyPlan) },
        new[] { ("Tekenen", "🎨", FeatureKind.Draw), ("Mijn tekeningen", "🖼️", FeatureKind.Gallery), ("Van me afschrijven", "📝", FeatureKind.Notes), ("Dagboek", "📓", FeatureKind.Journal) },
        new[] { ("Mijn privacy", "🔐", FeatureKind.Privacy), ("Weekoverzicht", "🗒️", FeatureKind.Week), ("Instellingen", "⚙️", FeatureKind.Settings), ("Hulp", "❓", FeatureKind.Help) }
    };
    static readonly string[] GroupNames = { "MIJN DAG", "RUST EN GEVOEL", "PRATEN EN DELEN", "MAKEN EN SCHRIJVEN", "MIJN GEGEVENS" };

    public DashboardPage()
    {
        Title = "MoodPress";
        BackgroundColor = AppUi.Background;
        ToolbarItems.Add(new ToolbarItem("🔒", null, async () => await ((App)Application.Current!).LockToLoginAsync("Je sessie is vergrendeld.")));
        ToolbarItems.Add(new ToolbarItem("🙈", null, async () => await Navigation.PushAsync(new PrivacyCoverPage())));
        Build();
        if (AppSession.Store is not null)
            RoutineReminderNotifications.Sync(Android.App.Application.Context, AppSession.Store.All<RoutineReminder>("routinereminder"));
    }

    void Build()
    {
        NavigationPage.SetHasNavigationBar(this, false);
        var root = new VerticalStackLayout
        {
            Padding = new Thickness(16, 12, 16, 24),
            Spacing = 16,
            BackgroundColor = AppUi.Background
        };

        // Home header: welcoming, branded, and laid out without hard-coded text widths.
        var hello = new VerticalStackLayout
        {
            Spacing = 1,
            VerticalOptions = LayoutOptions.Center,
            Children =
            {
                AppUi.Label("Hallo,", muted: true),
                AppUi.Label("Fijn dat je er bent!", title: true)
            }
        };
        var mark = new Image
        {
            Source = "moodpress_mark.png",
            WidthRequest = 46,
            HeightRequest = 46,
            Aspect = Aspect.AspectFit,
            VerticalOptions = LayoutOptions.Center
        };
        var quickSettings = SmallHeaderButton("⚙", "Instellingen", () => Navigate(FeatureKind.Settings));
        var quickPrivacy = SmallHeaderButton("🙈", "Scherm verbergen", () => _ = Navigation.PushAsync(new PrivacyCoverPage()));
        var actionButtons = new HorizontalStackLayout
        {
            Spacing = 5,
            VerticalOptions = LayoutOptions.Center,
            Children = { quickSettings, quickPrivacy }
        };
        var top = new Grid
        {
            ColumnDefinitions =
            {
                new ColumnDefinition(GridLength.Auto),
                new ColumnDefinition(GridLength.Star),
                new ColumnDefinition(GridLength.Auto)
            },
            ColumnSpacing = 10,
            Children = { mark, hello, actionButtons }
        };
        Grid.SetColumn(hello, 1);
        Grid.SetColumn(actionButtons, 2);
        root.Children.Add(top);

        // Main check-in banner from the reference design.
        var checkinText = new VerticalStackLayout
        {
            Spacing = 3,
            VerticalOptions = LayoutOptions.Center,
            Children =
            {
                new Label { Text = "Hoe voel je je vandaag?", FontFamily = AppUi.FontFamily, FontSize = Math.Max(15, AppUi.BaseFont * 0.82), FontAttributes = FontAttributes.Bold, TextColor = Colors.White, LineBreakMode = LineBreakMode.WordWrap },
                new Label { Text = "Kies je gevoel of druk op de knop.", FontFamily = AppUi.FontFamily, FontSize = Math.Max(11, AppUi.BaseFont * 0.62), TextColor = Color.FromArgb("#D2E2FF"), LineBreakMode = LineBreakMode.WordWrap }
            }
        };
        var checkinChevron = new Label
        {
            Text = "›",
            FontSize = 28,
            TextColor = Colors.White,
            VerticalTextAlignment = TextAlignment.Center,
            HorizontalTextAlignment = TextAlignment.Center
        };
        var checkinContent = new Grid
        {
            Padding = new Thickness(14, 14),
            ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) },
            ColumnSpacing = 12,
            Children =
            {
                new Label { Text = "😊", FontSize = 33, VerticalTextAlignment = TextAlignment.Center },
                checkinText,
                checkinChevron
            }
        };
        Grid.SetColumn(checkinText, 1);
        Grid.SetColumn(checkinChevron, 2);
        var checkinCard = new Border
        {
            Content = checkinContent,
            Background = new LinearGradientBrush(new GradientStopCollection
            {
                new GradientStop(Color.FromArgb("#173E83"), 0),
                new GradientStop(Color.FromArgb("#102653"), 1)
            }, new Point(0, 0), new Point(1, 1)),
            Stroke = new SolidColorBrush(Color.FromArgb("#315DBB")),
            StrokeThickness = 1,
            Padding = 0,
            StrokeShape = new RoundRectangle { CornerRadius = 19 },
            MinimumHeightRequest = 82
        };
        AddTap(checkinCard, () => Navigate(FeatureKind.DailyCheckIn));
        root.Children.Add(checkinCard);

        root.Children.Add(SectionHeading("Snelle acties"));
        var quick = new Grid
        {
            ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) },
            RowDefinitions = { new RowDefinition(GridLength.Auto), new RowDefinition(GridLength.Auto) },
            ColumnSpacing = 10,
            RowSpacing = 10
        };
        AddQuickTile(quick, "😊", "Mijn gevoel", "Kies je emotie", "#2D4FC2", FeatureKind.DailyCheckIn, 0, 0);
        AddQuickTile(quick, "🌬️", "Rust & ontspanning", "Kom tot jezelf", "#078C78", FeatureKind.Breath, 1, 0);
        AddQuickTile(quick, "💬", "Communicatie", "Laat weten wat je nodig hebt", "#B93479", FeatureKind.Cards, 0, 1);
        AddQuickTile(quick, "▦", "Mijn dag", "Overzicht & planning", "#C57A27", FeatureKind.DayToday, 1, 1);
        root.Children.Add(quick);

        // Today card; label length is dynamic and never relies on trailing spaces.
        var dateText = DateTime.Today.ToString("dddd d MMMM", CultureInfo.GetCultureInfo("nl-NL"));
        if (dateText.Length > 0) dateText = char.ToUpper(dateText[0], CultureInfo.GetCultureInfo("nl-NL")) + dateText[1..];
        var todayInfo = new VerticalStackLayout
        {
            Spacing = 3,
            VerticalOptions = LayoutOptions.Center,
            Children =
            {
                new Label { Text = dateText, FontFamily = AppUi.FontFamily, FontSize = Math.Max(15, AppUi.BaseFont * 0.78), FontAttributes = FontAttributes.Bold, TextColor = AppUi.Foreground, LineBreakMode = LineBreakMode.WordWrap },
                new Label { Text = "Overzicht en planning voor vandaag", FontFamily = AppUi.FontFamily, FontSize = Math.Max(11, AppUi.BaseFont * 0.62), TextColor = AppUi.Muted, LineBreakMode = LineBreakMode.WordWrap }
            }
        };
        var todayChevron = new Label
        {
            Text = "›",
            FontSize = 27,
            TextColor = AppUi.Foreground,
            VerticalTextAlignment = TextAlignment.Center
        };
        var todayIcon = new Border
        {
            Content = new Label { Text = "▦", FontSize = 24, TextColor = Colors.White, HorizontalTextAlignment = TextAlignment.Center, VerticalTextAlignment = TextAlignment.Center },
            BackgroundColor = Color.FromArgb("#6745E8"),
            Stroke = new SolidColorBrush(Color.FromArgb("#866AFF")),
            StrokeShape = new RoundRectangle { CornerRadius = 13 },
            Padding = new Thickness(7),
            WidthRequest = 48,
            HeightRequest = 48,
            VerticalOptions = LayoutOptions.Center
        };
        var todayContent = new Grid
        {
            Padding = new Thickness(13),
            ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) },
            ColumnSpacing = 12,
            Children = { todayIcon, todayInfo, todayChevron }
        };
        Grid.SetColumn(todayInfo, 1);
        Grid.SetColumn(todayChevron, 2);
        var todayCard = new Border
        {
            Content = todayContent,
            BackgroundColor = Color.FromArgb("#102753"),
            Stroke = new SolidColorBrush(Color.FromArgb("#3157A6")),
            StrokeThickness = 1,
            StrokeShape = new RoundRectangle { CornerRadius = 19 },
            Padding = 0,
            MinimumHeightRequest = 78
        };
        AddTap(todayCard, () => Navigate(FeatureKind.DayToday));
        root.Children.Add(SectionHeading("Vandaag"));
        root.Children.Add(todayCard);

        // Preserve the fast feeling-save behaviour, but place it below the key home cards.
        root.Children.Add(SectionHeading("Snel je gevoel opslaan"));
        var fastStatus = AppUi.Label("");
        var fastHelpPanel = new VerticalStackLayout { IsVisible = false, Spacing = 8, Padding = 12, BackgroundColor = AppUi.Surface };
        var fastGrid = new Grid
        {
            ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) },
            RowDefinitions = { new RowDefinition(GridLength.Auto), new RowDefinition(GridLength.Auto) },
            ColumnSpacing = 8,
            RowSpacing = 8
        };
        var fastFeelings = new[]
        {
            (Key: "Blij", Label: "😊  Blij", Color: "#176B60"),
            (Key: "Bedroefd", Label: "😢  Verdrietig", Color: "#244D93"),
            (Key: "Boos", Label: "😠  Boos", Color: "#8A3155"),
            (Key: "Bang", Label: "😨  Bang", Color: "#5739A6")
        };
        for (int i = 0; i < fastFeelings.Length; i++)
        {
            var feeling = fastFeelings[i];
            var button = AppUi.Button(feeling.Label, () => _ = SaveFourGFeelingAsync(feeling.Key, fastStatus, fastHelpPanel));
            button.MinimumHeightRequest = 60;
            button.FontSize = Math.Max(14, AppUi.BaseFont * 0.75);
            button.BackgroundColor = Color.FromArgb(feeling.Color);
            button.BorderColor = Color.FromArgb(feeling.Color);
            fastGrid.Add(button, i % 2, i / 2);
        }
        root.Children.Add(fastGrid);
        root.Children.Add(fastStatus);
        root.Children.Add(AppUi.Card(fastHelpPanel));

        // All previous features remain available in responsive, content-sized tiles.
        root.Children.Add(SectionHeading("Alle functies"));
        for (int groupIndex = 0; groupIndex < Groups.Length; groupIndex++)
        {
            var groupHeader = new Label
            {
                Text = GroupNames[groupIndex],
                FontFamily = "sans-serif-medium",
                FontSize = Math.Max(12, AppUi.BaseFont * 0.62),
                CharacterSpacing = 1.1,
                FontAttributes = FontAttributes.Bold,
                TextColor = Color.FromArgb("#83A9F4"),
                Margin = new Thickness(0, 1, 0, 5)
            };
            var grid = new Grid
            {
                ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) },
                ColumnSpacing = 8,
                RowSpacing = 8
            };
            var items = Groups[groupIndex];
            for (int row = 0; row < (items.Length + 1) / 2; row++) grid.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
            for (int i = 0; i < items.Length; i++)
            {
                var item = items[i];
                var color = groupIndex switch { 0 => "#142A56", 1 => "#102B4A", 2 => "#261C4D", 3 => "#202449", _ => "#13243F" };
                var tile = CreateFeatureTile(item.Icon, item.Name, color, () => Navigate(item.Kind));
                grid.Add(tile, i % 2, i / 2);
            }
            var groupStack = new VerticalStackLayout { Spacing = 6, Children = { groupHeader, grid } };
            root.Children.Add(AppUi.Card(groupStack));
        }

        root.Children.Add(AppUi.Label("Je gegevens blijven privé en versleuteld. Jij kiest zelf wat je deelt.", muted: true));
        root.Children.Add(AppUi.Button("🔒 Sessie vergrendelen", async () => await ((App)Application.Current!).LockToLoginAsync(), danger: true));
        root.Children.Add(AppUi.AsyncButton("🚪 Uitloggen en sessie vergeten", async () =>
        {
            if (await DisplayAlertAsync("Uitloggen?", "Je opgeslagen sessie wordt verwijderd. Je moet daarna opnieuw inloggen met je gegevens.", "Uitloggen", "Annuleren"))
                await ((App)Application.Current!).LockToLoginAsync("Je bent uitgelogd. Log opnieuw in met je gegevens.", forgetRemembered: true);
        }, quiet: true));
        root.Children.Add(AppUi.Copyright());
        Content = AppUi.WithBottomNavigation(this, new ScrollView { Content = root, BackgroundColor = AppUi.Background }, "home");
    }

    static Label SectionHeading(string text)
    {
        return new Label
        {
            Text = text,
            FontFamily = "sans-serif-medium",
            FontSize = Math.Max(17, AppUi.BaseFont * 0.9),
            FontAttributes = FontAttributes.Bold,
            TextColor = AppUi.Foreground,
            LineBreakMode = LineBreakMode.WordWrap,
            Margin = new Thickness(0, 2, 0, 0)
        };
    }

    Button SmallHeaderButton(string text, string description, Action action)
    {
        var button = new Button
        {
            Text = text,
            FontSize = 19,
            FontFamily = "sans-serif",
            TextColor = AppUi.Foreground,
            BackgroundColor = Color.FromArgb("#101F44"),
            BorderColor = Color.FromArgb("#2B4B83"),
            BorderWidth = 1,
            CornerRadius = 14,
            Padding = new Thickness(7, 4),
            WidthRequest = 42,
            HeightRequest = 42,
            MinimumHeightRequest = 42,
        };
        SemanticProperties.SetDescription(button, description);
        button.Clicked += (_, _) => action();
        return button;
    }

    static void AddTap(View view, Action action)
    {
        var tap = new TapGestureRecognizer();
        tap.Tapped += (_, _) =>
        {
            AppSession.Touch();
            action();
        };
        view.GestureRecognizers.Add(tap);
    }

    static Border CreateFeatureTile(string icon, string title, string color, Action action)
    {
        var iconLabel = new Label
        {
            Text = icon,
            FontSize = 22,
            VerticalTextAlignment = TextAlignment.Center,
            HorizontalTextAlignment = TextAlignment.Center,
            WidthRequest = 30
        };
        var textLabel = new Label
        {
            Text = title,
            FontFamily = AppUi.FontFamily,
            FontSize = Math.Max(13, AppUi.BaseFont * 0.70),
            TextColor = AppUi.Foreground,
            LineBreakMode = LineBreakMode.WordWrap,
            VerticalTextAlignment = TextAlignment.Center,
            LineHeight = 1.12
        };
        var row = new Grid
        {
            ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star) },
            ColumnSpacing = 8,
            Padding = new Thickness(10, 9),
            Children = { iconLabel, textLabel }
        };
        Grid.SetColumn(textLabel, 1);
        var border = new Border
        {
            Content = row,
            BackgroundColor = Color.FromArgb(color),
            Stroke = new SolidColorBrush(Color.FromArgb("#294779")),
            StrokeThickness = 1,
            StrokeShape = new RoundRectangle { CornerRadius = 16 },
            Padding = 0,
            MinimumHeightRequest = 66,
            HorizontalOptions = LayoutOptions.Fill
        };
        border.AutomationId = "feature_" + Regex.Replace(title.ToLowerInvariant(), "[^a-z0-9]+", "_").Trim('_');
        AddTap(border, action);
        return border;
    }

    void AddQuickTile(Grid grid, string icon, string title, string subtitle, string color, FeatureKind kind, int col, int row)
    {
        var iconLabel = new Label
        {
            Text = icon,
            FontSize = 28,
            HorizontalTextAlignment = TextAlignment.Start,
            VerticalTextAlignment = TextAlignment.Center,
            Margin = new Thickness(0, 0, 0, 1)
        };
        var titleLabel = new Label
        {
            Text = title,
            FontSize = Math.Max(14, AppUi.BaseFont * 0.76),
            FontFamily = "sans-serif-medium",
            FontAttributes = FontAttributes.Bold,
            TextColor = Colors.White,
            LineBreakMode = LineBreakMode.WordWrap,
            FontAutoScalingEnabled = true,
            LineHeight = 1.1
        };
        var subtitleLabel = new Label
        {
            Text = subtitle,
            FontSize = Math.Max(11, AppUi.BaseFont * 0.60),
            FontFamily = AppUi.FontFamily,
            TextColor = Color.FromArgb("#F0F5FF"),
            LineBreakMode = LineBreakMode.WordWrap,
            FontAutoScalingEnabled = true,
            LineHeight = 1.1
        };
        var stack = new VerticalStackLayout
        {
            Spacing = 4,
            Padding = new Thickness(12, 11),
            Children = { iconLabel, titleLabel, subtitleLabel }
        };
        var tile = new Border
        {
            Content = stack,
            BackgroundColor = Color.FromArgb(color),
            Stroke = new SolidColorBrush(Color.FromArgb(color)),
            StrokeThickness = 1,
            StrokeShape = new RoundRectangle { CornerRadius = 19 },
            Padding = 0,
            MinimumHeightRequest = 116,
            HorizontalOptions = LayoutOptions.Fill,
            VerticalOptions = LayoutOptions.Fill
        };
        AddTap(tile, () => Navigate(kind));
        grid.Add(tile, col, row);
    }

    void Navigate(FeatureKind kind)
    {
        if (kind == FeatureKind.WhoWorks) _ = Navigation.PushAsync(new WieWerktErPage());
        else _ = Navigation.PushAsync(new FeaturePage(kind));
    }

    async Task SaveFourGFeelingAsync(string feeling, Label status, VerticalStackLayout helpPanel)
    {
        var record = new FourGFeelingEntry(Guid.NewGuid(), DateTime.Now, feeling);
        AppSession.Store!.Save("feeling4g", record.Id, record);
        status.Text = $"Opgeslagen: {FeelingEmoji(feeling)} {feeling}.";
        AppUi.Speak($"Je hebt {feeling} gekozen. Dit is opgeslagen. Er wordt niets automatisch gedeeld.");
        helpPanel.Children.Clear();
        helpPanel.Children.Add(AppUi.Title(feeling == "Blij" ? "Fijn dat je dit deelt" : "Wat kan nu helpen?"));
        if (feeling == "Blij")
        {
            helpPanel.Children.Add(AppUi.Label("Je gevoel is bewaard. Je hoeft verder niets te doen."));
            helpPanel.IsVisible = true;
            return;
        }

        var plan = AppSession.Store.Load<SafetyPlan>("plan", Guid.Empty) ?? new SafetyPlan();
        var options = plan.HelpOptions?.Where(x => !string.IsNullOrWhiteSpace(x)).Distinct().ToList() ?? new List<string>();
        if (options.Count == 0) options = new List<string> { "breath", "calm", "stressball", "walk" };
        foreach (var option in options) helpPanel.Children.Add(AppUi.AsyncButton(HelpOptionLabel(option), async () => await RunHelpOptionAsync(option), quiet: true));
        helpPanel.Children.Add(AppUi.Button("👥 Wie werkt er vandaag?", () => Navigation.PushAsync(new WieWerktErPage()), quiet: true));
        helpPanel.Children.Add(AppUi.Button("🆘 Mijn helpkaart bekijken", () => Navigate(FeatureKind.SafetyPlan), quiet: true));
        helpPanel.Children.Add(AppUi.AsyncButton("📱 Een seintje aan mijn contact voorbereiden", SendSignalAsync, quiet: true));
        helpPanel.Children.Add(AppUi.Label("Er wordt niets automatisch verzonden. Jij kiest zelf of je een bericht opent en verstuurt.", muted: true));
        helpPanel.IsVisible = true;
    }

    static string FeelingEmoji(string feeling) => feeling switch { "Blij" => "😄", "Bedroefd" => "😢", "Boos" => "😠", "Bang" => "😨", _ => "🙂" };
    static string HelpOptionLabel(string key) => key switch
    {
        "breath" => "🫁 Samen rustig ademhalen", "calm" => "🛋️ Naar mijn rustplek", "music" => "🎧 Rustige muziek luisteren",
        "stressball" => "🧸 Pak mijn stressbal", "walk" => "🚶 Even rustig wandelen", "talk" => "💬 Met iemand praten", _ => "🆘 Mijn helpkaart openen"
    };

    async Task RunHelpOptionAsync(string key)
    {
        switch (key)
        {
            case "breath": await Navigation.PushAsync(new FeaturePage(FeatureKind.Breath)); break;
            case "calm": await Navigation.PushAsync(new FeaturePage(FeatureKind.Calm)); break;
            case "music": await Navigation.PushAsync(new FeaturePage(FeatureKind.Breath)); break;
            case "walk": AppUi.Speak("Als het veilig kan, loop rustig een klein rondje. Vraag hulp als je niet alleen naar buiten kunt."); await DisplayAlertAsync("Een kleine stap", "Als het veilig kan, loop rustig een klein rondje. Vraag hulp als je niet alleen naar buiten kunt.", "OK"); break;
            case "stressball": AppUi.Speak("Pak je stressbal. Knijp rustig een paar keer en voel je voeten op de grond."); await DisplayAlertAsync("Een kleine stap", "Pak je stressbal. Knijp rustig een paar keer en voel je voeten op de grond.", "OK"); break;
            case "talk": await Navigation.PushAsync(new WieWerktErPage()); break;
            default: await Navigation.PushAsync(new FeaturePage(FeatureKind.SafetyPlan)); break;
        }
    }

    async Task SendSignalAsync()
    {
        var plan = AppSession.Store?.Load<SafetyPlan>("plan", Guid.Empty) ?? new SafetyPlan();
        var contact = plan.Contacts.FirstOrDefault(c => !string.IsNullOrWhiteSpace(c.Phone));
        if (contact is null)
        {
            await DisplayAlertAsync("Eerst een contact toevoegen", "Vul bij 'Mijn helpkaart / plan' de naam en het telefoonnummer in van iemand die je vertrouwt.", "Mijn helpkaart openen");
            await Navigation.PushAsync(new FeaturePage(FeatureKind.SafetyPlan)); return;
        }
        const string body = "Hoi, ik heb het nu moeilijk. Kun je contact met mij opnemen?";
        bool proceed = await DisplayAlertAsync("Een seintje voorbereiden", $"Er wordt een sms klaargezet voor {contact.Name}. De app verstuurt niets vanzelf. Je kunt in de Berichten-app zelf nog kiezen om te versturen.", "Sms openen", "Annuleren");
        if (!proceed) return;
        try { await Sms.Default.ComposeAsync(new SmsMessage(body, new[] { contact.Phone })); }
        catch (Exception ex) { AppLog.Write(ex); await DisplayAlertAsync("Sms niet geopend", "Je kunt je contact ook zelf bellen of een bericht sturen.", "OK"); }
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (AppSession.Store is not null) Build();
        AppSession.Touch();
        if (AppSession.Settings.Animations) { Opacity = 0; _ = this.FadeToAsync(1, 180, Easing.CubicOut); }
        if (_consentPrompted || AppSession.Store is null) return;
        if (AppSession.Store.All<ConsentRecord>("consent").Any(c => c.Version >= ConsentInfo.CurrentVersion)) { _consentPrompted = true; return; }
        _consentPrompted = true;
        const string text = "MoodPress is voor jou. Je dagboek, tekeningen, agenda en andere gegevens worden versleuteld op deze telefoon bewaard. Je begeleider ziet alleen wat jij zelf deelt. De app waarschuwt niemand en belt niemand. Je mag je gegevens meenemen of verwijderen. Vraag je begeleider wie verantwoordelijk is voor je gegevens en waar de privacyverklaring staat.";
        await DisplayAlertAsync("Voordat je begint", text, "Ik heb dit gelezen");
        var choice = await DisplayActionSheetAsync("Met wie gebruik je MoodPress?", "Nu niet", null, "Zelf", "Samen met mijn vertegenwoordiger of begeleider");
        if (choice == "Zelf" || choice == "Samen met mijn vertegenwoordiger of begeleider")
        {
            var consent = new ConsentRecord(Guid.NewGuid(), DateTime.Now, ConsentInfo.CurrentVersion, choice == "Zelf" ? "zelf" : "samen");
            AppSession.Store.Save("consent", consent.Id, consent);
        }
        else await ((App)Application.Current!).LockToLoginAsync("Je kunt later toestemming geven door opnieuw in te loggen.");
    }
}
