using Microsoft.Maui.ApplicationModel;
using Microsoft.Maui.Controls;
using Microsoft.Maui.Graphics;

namespace MijnGevoel.AndroidApp;

/// <summary>Branded MoodPress welcome screen shown before the sign-in page.</summary>
public sealed class BrandSplashPage : ContentPage
{
    bool _transitioning;

    public BrandSplashPage()
    {
        NavigationPage.SetHasNavigationBar(this, false);
        BackgroundColor = Color.FromArgb("#050A18");
        var pageContent = BuildContent();
        Content = pageContent;

        var tap = new TapGestureRecognizer();
        tap.Tapped += (_, _) => _ = ContinueAsync();
        pageContent.GestureRecognizers.Add(tap);
    }

    View BuildContent()
    {
        var root = new Grid
        {
            Padding = new Thickness(24, 28, 24, 24),
            RowDefinitions =
            {
                new RowDefinition(new GridLength(1.1, GridUnitType.Star)),
                new RowDefinition(GridLength.Auto),
                new RowDefinition(new GridLength(1.0, GridUnitType.Star))
            },
            BackgroundColor = Color.FromArgb("#050A18")
        };

        var backgroundArtwork = new Image
        {
            Source = "moodpress_splash_bg.png",
            Aspect = Aspect.AspectFill,
            HorizontalOptions = LayoutOptions.Fill,
            VerticalOptions = LayoutOptions.Fill,
            InputTransparent = true
        };
        root.Add(backgroundArtwork);
        Grid.SetRowSpan(backgroundArtwork, 3);

        var titleSize = 42d;
        var wordmark = new HorizontalStackLayout
        {
            Spacing = 0,
            HorizontalOptions = LayoutOptions.Center,
            VerticalOptions = LayoutOptions.Center,
            Children =
            {
                new Label
                {
                    Text = "Mood",
                    FontFamily = "sans-serif-black",
                    FontSize = titleSize,
                    FontAttributes = FontAttributes.Bold,
                    CharacterSpacing = -0.7,
                    TextColor = Colors.White,
                    VerticalTextAlignment = TextAlignment.Center
                },
                new Label
                {
                    Text = "Press",
                    FontFamily = "sans-serif-black",
                    FontSize = titleSize,
                    FontAttributes = FontAttributes.Bold,
                    CharacterSpacing = -0.7,
                    TextColor = Color.FromArgb("#6292FF"),
                    VerticalTextAlignment = TextAlignment.Center
                }
            }
        };

        var logo = new Image
        {
            Source = "moodpress_mark.png",
            WidthRequest = 150,
            HeightRequest = 150,
            Aspect = Aspect.AspectFit,
            HorizontalOptions = LayoutOptions.Center
        };
        var explainer = new Label
        {
            Text = "Druk op je gevoel",
            FontFamily = "sans-serif-medium",
            FontSize = 17,
            TextColor = Color.FromArgb("#F4F7FF"),
            HorizontalTextAlignment = TextAlignment.Center,
            Margin = new Thickness(0, 2, 0, 0)
        };
        var brand = new VerticalStackLayout
        {
            Spacing = 4,
            HorizontalOptions = LayoutOptions.Center,
            VerticalOptions = LayoutOptions.Center,
            Children = { logo, wordmark, explainer }
        };
        root.Add(brand, 0, 1);

        var slogan = new Label
        {
            Text = "Jouw gevoel.\nJouw verhaal.\nJouw app.",
            FontFamily = "cursive",
            FontSize = 25,
            FontAttributes = FontAttributes.Italic,
            CharacterSpacing = 0.6,
            LineHeight = 1.17,
            TextColor = Color.FromArgb("#D4DDF7"),
            Rotation = -4,
            HorizontalTextAlignment = TextAlignment.Center,
            VerticalTextAlignment = TextAlignment.Center,
            Margin = new Thickness(0, 0, 0, 18)
        };
        var hint = new Label
        {
            Text = "Tik om verder te gaan",
            FontFamily = "sans-serif",
            FontSize = 12,
            TextColor = Color.FromArgb("#7E95C4"),
            HorizontalTextAlignment = TextAlignment.Center,
            Margin = new Thickness(0, 12, 0, 4)
        };
        var footer = new VerticalStackLayout
        {
            Spacing = 0,
            VerticalOptions = LayoutOptions.End,
            HorizontalOptions = LayoutOptions.Center,
            Children = { slogan, hint }
        };
        root.Add(footer, 0, 2);
        return root;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await Task.Delay(2300);
        await ContinueAsync();
    }

    async Task ContinueAsync()
    {
        if (_transitioning) return;
        _transitioning = true;
        try
        {
            await MainThread.InvokeOnMainThreadAsync(async () =>
            {
                await Navigation.PushAsync(new LoginPage(), false);
                Navigation.RemovePage(this);
            });
        }
        catch (Exception ex)
        {
            AppLog.Write(ex);
            _transitioning = false;
        }
    }
}
