using Microsoft.Maui;
using Microsoft.Maui.ApplicationModel;
using MijnGevoel.Core.Data;
using Microsoft.Maui.Graphics;
using Microsoft.Maui.Controls;

namespace MijnGevoel.AndroidApp;

public partial class App : Application
{
    readonly HashSet<Guid> _announcedAgenda = new();
    bool _reminderDialogShowing;
    public App()
    {
        InitializeComponent();
        StartAutoLockMonitor();
    }

    protected override Window CreateWindow(IActivationState? activationState)
    {
        var navigation = new NavigationPage(new LoginPage())
        {
            BarBackgroundColor = Color.FromArgb("#3C7A89"),
            BarTextColor = Colors.White
        };
        return new Window(navigation);
    }

    void StartAutoLockMonitor()
    {
        Dispatcher.StartTimer(TimeSpan.FromSeconds(15), () =>
        {
            var store = AppSession.Store;
            if (store is null) return true;
            var limit = Math.Max(1, AppSession.Settings.AutoLockMinutes);
            if (DateTime.UtcNow - AppSession.LastActivityUtc >= TimeSpan.FromMinutes(limit))
            {
                MainThread.BeginInvokeOnMainThread(async () => await LockToLoginAsync("Je sessie is automatisch vergrendeld."));
                return true;
            }

            // Zelfde zachte agenda-herinnering als in de Windows-versie, zolang de app open is.
            var now = DateTime.Now;
            if (!_reminderDialogShowing)
            {
                var due = store.All<AgendaItem>("agenda")
                    .Where(a => !a.Done && a.Date.Date == now.Date && TimeOnly.TryParse(a.Time, out _) &&
                                (TimeOnly.Parse(a.Time).ToTimeSpan() - now.TimeOfDay).TotalMinutes is >= -1 and <= 10)
                    .FirstOrDefault(a => _announcedAgenda.Add(a.Id));
                if (due is not null)
                {
                    _reminderDialogShowing = true;
                    MainThread.BeginInvokeOnMainThread(async () =>
                    {
                        try
                        {
                            var page = Windows.FirstOrDefault()?.Page;
                            if (AppSession.Store is not null && page is not null)
                                await page.DisplayAlertAsync("Agenda-herinnering", $"⏰ {due.Icon} {due.Title} — om {due.Time}", "OK");
                        }
                        finally { _reminderDialogShowing = false; }
                    });
                }
            }
            return true;
        });
    }

    public async Task LockToLoginAsync(string? message = null)
    {
        await AppSession.ClearRememberedSessionAsync();
        AppSession.End();
        _announcedAgenda.Clear();
        if (Windows.FirstOrDefault()?.Page is NavigationPage nav)
        {
            await nav.PopToRootAsync(false);
            if (nav.Navigation.NavigationStack.FirstOrDefault() is LoginPage login)
                login.ShowLoginMessage(message);
        }
        AndroidScreenPrivacy.Apply(false);
    }

    protected override void OnSleep()
    {
        if (AppSession.Store is not null)
        {
            if (AppSession.KeepSignedIn)
                _ = AppSession.PersistRememberedActivityAsync(force: true);
            else
                MainThread.BeginInvokeOnMainThread(async () => await LockToLoginAsync("Je sessie is vergrendeld omdat de app naar de achtergrond ging."));
        }
        base.OnSleep();
    }

    protected override void OnResume()
    {
        base.OnResume();
        if (AppSession.Store is null) return;
        var limit = TimeSpan.FromMinutes(Math.Max(1, AppSession.Settings.AutoLockMinutes));
        if (DateTime.UtcNow - AppSession.LastActivityUtc >= limit)
            MainThread.BeginInvokeOnMainThread(async () => await LockToLoginAsync("Je sessie is automatisch vergrendeld na inactiviteit."));
        else if (AppSession.KeepSignedIn)
            _ = AppSession.PersistRememberedActivityAsync(force: true);
    }
}
