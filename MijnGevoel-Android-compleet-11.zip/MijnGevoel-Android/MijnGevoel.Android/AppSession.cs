using Microsoft.Maui.Storage;
using System.Globalization;
using System.Security.Cryptography;
using MijnGevoel.Core.Data;
using MijnGevoel.Core.Security;

namespace MijnGevoel.AndroidApp;

/// <summary>Beheert de actieve sessie. De optionele herstelsleutel wordt uitsluitend via MAUI SecureStorage opgeslagen.</summary>
public static class AppSession
{
    static AccountService? _accounts;
    static DateTime _lastRememberWriteUtc = DateTime.MinValue;
    const string RememberPreference = "mg.keep-signed-in";
    const string RememberUsernameKey = "mg.remember.username";
    const string RememberVaultKey = "mg.remember.vault-key";
    const string RememberActivityKey = "mg.remember.last-activity";
    const string RememberAutoLockKey = "mg.remember.auto-lock-minutes";

    public static AccountService Accounts => _accounts ??= new AccountService(Path.Combine(FileSystem.AppDataDirectory, "accounts"));
    public static VaultStore? Store { get; private set; }
    public static string Username { get; private set; } = "";
    public static UserSettings Settings { get; private set; } = new();
    public static DateTime LastActivityUtc { get; private set; } = DateTime.UtcNow;
    public static bool IsUnlocked => Store is not null;
    public static bool KeepSignedIn => Preferences.Default.Get(RememberPreference, false);

    public static void Start(string username, byte[] vaultKey)
    {
        End();
        Username = username;
        // VaultStore owns its key array and wipes it when the session ends.
        Store = new VaultStore((byte[])vaultKey.Clone(), Accounts.DataFolder(username));
        CryptographicOperations.ZeroMemory(vaultKey);
        Settings = Store.Load<UserSettings>("settings", Guid.Empty) ?? new UserSettings();
        LastActivityUtc = DateTime.UtcNow;
        _lastRememberWriteUtc = DateTime.MinValue;
        AndroidScreenPrivacy.Apply(Settings.BlockCapture);
    }

    /// <summary>Bewaar alleen de reeds geverifieerde vaultsleutel in SecureStorage; nooit wachtwoord of authenticatorcode.</summary>
    public static async Task<bool> SaveRememberedSessionAsync(string username, byte[] vaultKey)
    {
        if (vaultKey is null || vaultKey.Length != Crypto.KeySize) return false;
        try
        {
            await SecureStorage.Default.SetAsync(RememberUsernameKey, username);
            await SecureStorage.Default.SetAsync(RememberVaultKey, Convert.ToBase64String(vaultKey));
            await SecureStorage.Default.SetAsync(RememberActivityKey, DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture));
            await SecureStorage.Default.SetAsync(RememberAutoLockKey, "5");
            Preferences.Default.Set(RememberPreference, true);
            _lastRememberWriteUtc = DateTime.UtcNow;
            return true;
        }
        catch
        {
            await ClearRememberedSessionAsync();
            return false;
        }
    }

    public static async Task UpdateRememberedSessionPolicyAsync()
    {
        if (!KeepSignedIn || Store is null) return;
        try
        {
            await SecureStorage.Default.SetAsync(RememberAutoLockKey, Math.Clamp(Settings.AutoLockMinutes, 1, 30).ToString(CultureInfo.InvariantCulture));
            await PersistRememberedActivityAsync(force: true);
        }
        catch
        {
            await ClearRememberedSessionAsync();
        }
    }

    /// <summary>Herstel alleen als de beveiligde sleutel bestaat én de ingestelde automatische vergrendeltijd nog niet verstreken is.</summary>
    public static async Task<bool> TryRestoreRememberedSessionAsync()
    {
        if (!KeepSignedIn) return false;
        byte[]? key = null;
        try
        {
            var username = await SecureStorage.Default.GetAsync(RememberUsernameKey);
            var encodedKey = await SecureStorage.Default.GetAsync(RememberVaultKey);
            var activityText = await SecureStorage.Default.GetAsync(RememberActivityKey);
            var lockText = await SecureStorage.Default.GetAsync(RememberAutoLockKey);
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(encodedKey) ||
                string.IsNullOrWhiteSpace(activityText) ||
                !DateTime.TryParse(activityText, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var lastActivity))
            {
                await ClearRememberedSessionAsync();
                return false;
            }

            int lockMinutes = int.TryParse(lockText, NumberStyles.Integer, CultureInfo.InvariantCulture, out var configured) ? Math.Clamp(configured, 1, 30) : 5;
            var lastUtc = lastActivity.Kind == DateTimeKind.Utc ? lastActivity : lastActivity.ToUniversalTime();
            if (DateTime.UtcNow - lastUtc >= TimeSpan.FromMinutes(lockMinutes))
            {
                await ClearRememberedSessionAsync();
                return false;
            }

            key = Convert.FromBase64String(encodedKey);
            if (key.Length != Crypto.KeySize)
            {
                CryptographicOperations.ZeroMemory(key);
                key = null;
                await ClearRememberedSessionAsync();
                return false;
            }

            Start(username, key); // Start maakt een eigen kopie en wist de buffer.
            key = null;
            Touch();
            await UpdateRememberedSessionPolicyAsync();
            return Store is not null;
        }
        catch
        {
            if (key is not null) CryptographicOperations.ZeroMemory(key);
            End();
            await ClearRememberedSessionAsync();
            return false;
        }
    }

    public static async Task ClearRememberedSessionAsync()
    {
        try
        {
            SecureStorage.Default.Remove(RememberUsernameKey);
            SecureStorage.Default.Remove(RememberVaultKey);
            SecureStorage.Default.Remove(RememberActivityKey);
            SecureStorage.Default.Remove(RememberAutoLockKey);
        }
        catch { /* Als SecureStorage al door Android is gewist, is de sessie alsnog niet herstelbaar. */ }
        try { Preferences.Default.Set(RememberPreference, false); } catch { }
        _lastRememberWriteUtc = DateTime.MinValue;
        await Task.CompletedTask;
    }

    public static Task PersistRememberedActivityAsync(bool force = false)
    {
        if (!KeepSignedIn) return Task.CompletedTask;
        var now = DateTime.UtcNow;
        if (!force && now - _lastRememberWriteUtc < TimeSpan.FromSeconds(30)) return Task.CompletedTask;
        return PersistCoreAsync();

        async Task PersistCoreAsync()
        {
            try
            {
                await SecureStorage.Default.SetAsync(RememberActivityKey, LastActivityUtc.ToString("O", CultureInfo.InvariantCulture));
                _lastRememberWriteUtc = DateTime.UtcNow;
            }
            catch { await ClearRememberedSessionAsync(); }
        }
    }

    public static void SaveSettings() => Store?.Save("settings", Guid.Empty, Settings);

    public static void Touch()
    {
        LastActivityUtc = DateTime.UtcNow;
        if (KeepSignedIn) _ = PersistRememberedActivityAsync();
    }

    public static void End()
    {
        Store?.Dispose();
        Store = null;
        Username = "";
        Settings = new UserSettings();
        LastActivityUtc = DateTime.UtcNow;
        AndroidScreenPrivacy.Apply(false);
    }
}

public static class AndroidScreenPrivacy
{
    public static void Apply(bool enabled)
    {
#if ANDROID
        try
        {
            var activity = Microsoft.Maui.ApplicationModel.Platform.CurrentActivity;
            var window = activity?.Window;
            if (window is null) return;
            if (enabled) window.AddFlags(Android.Views.WindowManagerFlags.Secure);
            else window.ClearFlags(Android.Views.WindowManagerFlags.Secure);
        }
        catch { /* platform privacy setting must not crash the app */ }
#endif
    }
}
