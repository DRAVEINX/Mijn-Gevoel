# Releasewijzigingen — Mijn Gevoel 1.0.5 (versionCode 6)

- **Authenticatie makkelijker instellen:** de handmatige TOTP-sleutel staat nu in een leesbaar, selecteerbaar veld. De kopieerknop gebruikt het Android-klembord direct en controleert dat de tekst is gekopieerd. De instructies leggen uit hoe je in Google Authenticator een instelsleutel invoert wanneer scannen niet lukt.
- **Eigen app-pictogram:** de Android-manifest verwijst nu expliciet naar launcher- en round-icons met het Mijn Gevoel-hartlogo, in verschillende Android-dichtheden en als adaptive icon.
- **Ademhalingsmuziek:** de speler krijgt expliciete media/audio-eigenschappen en meer hoorbaar app-volume. Er is een knop om de muziek vijf seconden te testen; de fysieke mediavolume-instelling blijft bij de gebruiker.
- **Ingelogd blijven op dit toestel (optioneel):** na een geslaagde login kan de cliënt kiezen om op dit privétoestel ingelogd te blijven. Alleen de reeds geverifieerde vaultsleutel wordt via MAUI SecureStorage opgeslagen; het wachtwoord en de authenticatorcode worden niet opgeslagen. De automatische inactiviteitsvergrendeling blijft actief. Handmatig vergrendelen en automatisch vergrendelen wissen het opgeslagen sessietoken.
- Alle bestaande 17 unit/security-tests blijven onderdeel van de CI-build.

Deze bronupdate moet nog door GitHub Actions worden gecompileerd en daarna op een Android-telefoon worden getest.
