using MijnGevoel.Core.Data;
using Xunit;

public sealed class FeatureVisibilityServiceTests
{
    [Fact]
    public void LegacySettingsShowEveryFeature()
    {
        Assert.True(FeatureVisibilityService.IsEnabled(new UserSettings(), "Agenda"));
    }

    [Fact]
    public void ConfiguredSettingsShowOnlyExplicitlyEnabledFeatures()
    {
        var settings = new UserSettings { FeatureVisibilityConfigured = true, EnabledFeatures = new() { "Agenda", "Timer" } };
        Assert.True(FeatureVisibilityService.IsEnabled(settings, "Agenda"));
        Assert.False(FeatureVisibilityService.IsEnabled(settings, "Journal"));
    }

    [Fact]
    public void NormalizationRemovesUnknownAndDuplicateFeatures()
    {
        var result = FeatureVisibilityService.NormalizeEnabled(new[] { "Agenda", "Agenda", "Fake", "Timer" }, new[] { "Agenda", "Timer" });
        Assert.Equal(new[] { "Agenda", "Timer" }, result);
    }
}
