using System.Text.RegularExpressions;
using MijnGevoel.Core.Data;
using Microsoft.Maui.Controls.Shapes;

namespace MijnGevoel.AndroidApp;

/// <summary>Searchable, categorized directory for the functions that do not need to occupy Home.</summary>
public sealed class MorePage : ContentPage
{
    readonly VerticalStackLayout _root;
    readonly VerticalStackLayout _results;
    readonly Entry _search;
    int _columns = 2;

    public MorePage()
    {
        Title = "Meer";
        BackgroundColor = AppUi.Background;
        var header = new VerticalStackLayout
        {
            Spacing = 4,
            Children =
            {
                AppUi.Label("Meer functies", title: true),
                AppUi.Label("Alles staat bij elkaar in herkenbare groepen. Zoek op naam of onderwerp.", muted: true)
            }
        };
        _search = AppUi.Entry("Zoek bijvoorbeeld: agenda, rust, dagboek…");
        _search.ReturnType = ReturnType.Search;
        _search.MaxLength = 80;
        _search.AutomationId = "more_search";
        SemanticProperties.SetDescription(_search, "Zoek in alle MoodPress-functies");
        SemanticProperties.SetHint(_search, "Typ een functienaam of onderwerp. Resultaten worden direct gefilterd.");
        _search.TextChanged += (_, _) => RenderResults();
        _results = new VerticalStackLayout { Spacing = 12 };
        _root = new VerticalStackLayout
        {
            Padding = new Thickness(16, 14, 16, 24),
            Spacing = 14,
            BackgroundColor = AppUi.Background,
            Children = { header, _search, _results }
        };
        Content = AppUi.WithBottomNavigation(this, new ScrollView { Content = _root, BackgroundColor = AppUi.Background }, "more");
        ToolbarItems.Add(new ToolbarItem("🔒", null, async () => await ((App)Application.Current!).LockToLoginAsync("Je sessie is vergrendeld.")));
        ToolbarItems.Add(new ToolbarItem("🙈", null, async () => await Navigation.PushAsync(new PrivacyCoverPage())));
        RenderResults();
    }

    protected override void OnSizeAllocated(double width, double height)
    {
        base.OnSizeAllocated(width, height);
        var columns = width >= 1200 ? 4 : width >= 760 ? 3 : 2;
        if (columns == _columns) return;
        _columns = columns;
        if (_results is not null) RenderResults();
    }

    void RenderResults()
    {
        _results.Children.Clear();
        var query = (_search.Text ?? string.Empty).Trim();
        var all = FeatureCatalog.All;
        var matches = all.Where(item => item.Kind == FeatureKind.Settings || FeatureVisibilityService.IsEnabled(AppSession.Settings, item.Kind.ToString()))
            .Where(item => string.IsNullOrWhiteSpace(query)
                || item.Label.Contains(query, StringComparison.CurrentCultureIgnoreCase)
                || item.Group.Contains(query, StringComparison.CurrentCultureIgnoreCase)
                || item.Description.Contains(query, StringComparison.CurrentCultureIgnoreCase))
            .ToArray();

        if (matches.Length == 0)
        {
            _results.Children.Add(AppUi.Card(new VerticalStackLayout
            {
                Spacing = 6,
                Children = { AppUi.Label("Geen functie gevonden", title: true), AppUi.Label("Probeer een ander woord of maak de zoekopdracht korter.", muted: true) }
            }));
        }
        else
        {
            foreach (var group in matches.GroupBy(x => x.Group))
            {
                _results.Children.Add(AppUi.Label(group.Key, title: true));
                var columns = Math.Clamp(_columns, 2, 4);
                var grid = new Grid { ColumnSpacing = 9, RowSpacing = 9, HorizontalOptions = LayoutOptions.Fill };
                for (int column = 0; column < columns; column++) grid.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));
                var items = group.OrderBy(x => x.Kind == FeatureKind.Settings ? 0 : 1).ThenBy(x => x.Label, StringComparer.CurrentCulture).ToArray();
                for (int row = 0; row < (items.Length + columns - 1) / columns; row++) grid.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
                for (int i = 0; i < items.Length; i++)
                {
                    var item = items[i];
                    grid.Add(CreateCard(item), i % columns, i / columns);
                }
                _results.Children.Add(grid);
            }
        }

        _results.Children.Add(AppUi.Label("Je gegevens blijven privé. Een functie delen gebeurt alleen na jouw keuze.", muted: true));
        _results.Children.Add(AppUi.Button("🔒 Sessie vergrendelen", async () => await ((App)Application.Current!).LockToLoginAsync(), danger: true));
        _results.Children.Add(AppUi.AsyncButton("🚪 Uitloggen en sessie vergeten", async () =>
        {
            if (await DisplayAlertAsync("Uitloggen?", "Je opgeslagen sessie wordt verwijderd. Je moet daarna opnieuw inloggen.", "Uitloggen", "Annuleren"))
                await ((App)Application.Current!).LockToLoginAsync("Je bent uitgelogd. Log opnieuw in.", forgetRemembered: true);
        }, quiet: true));
    }

    Border CreateCard(FeatureCatalogItem item)
    {
        var openButton = AppUi.Button("Openen", () => _ = OpenFeatureAsync(item.Kind), quiet: true);
        var featureKey = Regex.Replace(item.Kind.ToString(), "[^a-zA-Z0-9]+", "_").ToLowerInvariant();
        openButton.AutomationId = "open_more_" + featureKey;
        SemanticProperties.SetDescription(openButton, $"Open {item.Label}");
        SemanticProperties.SetHint(openButton, $"Opent de functie {item.Label}.");

        var stack = new VerticalStackLayout
        {
            Spacing = 5,
            Padding = new Thickness(12, 12),
            Children =
            {
                AppUi.Label(item.Icon, title: true),
                AppUi.Label(item.Label, title: true),
                AppUi.Label(item.Description, muted: true),
                openButton
            }
        };
        var card = new Border
        {
            Content = stack,
            BackgroundColor = AppUi.Surface,
            Stroke = new SolidColorBrush(AppUi.Border),
            StrokeThickness = 1,
            StrokeShape = new RoundRectangle { CornerRadius = 16 },
            Padding = 0,
            MinimumHeightRequest = 120,
            HorizontalOptions = LayoutOptions.Fill
        };
        card.AutomationId = "more_" + Regex.Replace(item.Kind.ToString(), "[^a-zA-Z0-9]+", "_").ToLowerInvariant();
        // The explicit button is keyboard- and screen-reader-focusable; the surrounding card is not a hidden tap target.
        SemanticProperties.SetDescription(card, $"{item.Label}. {item.Description}");
        return card;
    }

    async Task OpenFeatureAsync(FeatureKind kind)
    {
        AppSession.Touch();
        try
        {
            switch (kind)
            {
                case FeatureKind.WhoWorks: await Navigation.PushAsync(new WieWerktErPage()); break;
                case FeatureKind.ChildSchedule: await Navigation.PushAsync(new ChildSchedulePage()); break;
                case FeatureKind.ShareSupport: await Navigation.PushAsync(new SupportPackageSharePage()); break;
                case FeatureKind.ReceiveSupport: await Navigation.PushAsync(new ReceiveSupportPackagePage()); break;
                default: await Navigation.PushAsync(new FeaturePage(kind)); break;
            }
        }
        catch (Exception ex) { AppLog.Write(ex); await DisplayAlertAsync("Functie niet geopend", "Probeer het nogmaals. Als dit blijft gebeuren, meld het via feedback.", "OK"); }
    }
}
