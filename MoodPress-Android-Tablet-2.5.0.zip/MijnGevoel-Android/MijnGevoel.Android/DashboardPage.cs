using System.Globalization;
using System.Text.RegularExpressions;
using MijnGevoel.Core.Data;
using Microsoft.Maui.ApplicationModel.Communication;
using Microsoft.Maui.Controls.Shapes;

namespace MijnGevoel.AndroidApp;

public enum FeatureKind
{
    Stoplicht, DayToday, DayTomorrow, Agenda, Timer, Routines, RoutineReminders,
    Breath, Calm, Sensory, Body, MoodHistory, FeelingWords,
    Cards, TalkPrep, StoplichtHistory, Share, SafetyPlan,
    Draw, Gallery, Notes, Journal, Privacy, Week, Settings, Help, WhoWorks, DailyCheckIn, MoodCalendar, MoodInsights, YouthSupport, AdultPlanning, Wellbeing, Profile, ShareSupport, ReceiveSupport, ChildSchedule
}

public sealed class DashboardPage : ContentPage
{
    bool _consentPrompted;
    int _shortcutColumns = 2;
    public DashboardPage()
    {
        Title = "MoodPress";
        BackgroundColor = AppUi.Background;
        ToolbarItems.Add(new ToolbarItem("🔒", null, async () => await ((App)Application.Current!).LockToLoginAsync("Je sessie is vergrendeld.")));
        ToolbarItems.Add(new ToolbarItem("🙈", null, async () => await Navigation.PushAsync(new PrivacyCoverPage())));
        Build();
        if (AppSession.Store is not null)
        {
            RoutineReminderNotifications.Sync(Android.App.Application.Context, AppSession.Store.All<RoutineReminder>("routinereminder"));
            FocusTimerNotifications.SyncFromState(Android.App.Application.Context, AppSession.Store.Load<TimerSessionState>("timer", Guid.Empty));
        }
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        AppSession.Touch();
        // Reflect changed feature visibility and the new day after returning from another page.
        if (AppSession.Store is not null) Build();
    }

    protected override void OnSizeAllocated(double width, double height)
    {
        base.OnSizeAllocated(width, height);
        var columns = width >= 1200 ? 4 : width >= 760 ? 3 : 2;
        if (columns == _shortcutColumns || AppSession.Store is null) return;
        _shortcutColumns = columns;
        Build();
    }

    void Build()
    {
        NavigationPage.SetHasNavigationBar(this, false);
        var root = new VerticalStackLayout
        {
            Padding = new Thickness(16, 12, 16, 24),
            Spacing = 16,
            BackgroundColor = AppUi.Background
        };

        // Compact header; the Home screen stays calm and keeps every secondary function under Meer.
        var hello = new VerticalStackLayout
        {
            Spacing = 1,
            VerticalOptions = LayoutOptions.Center,
            Children = { AppUi.Label("Hallo,", muted: true), AppUi.Label("Fijn dat je er bent!", title: true) }
        };
        var mark = new Image
        {
            Source = "moodpress_mark.png", WidthRequest = 44, HeightRequest = 44,
            Aspect = Aspect.AspectFit, VerticalOptions = LayoutOptions.Center
        };
        var actions = new HorizontalStackLayout
        {
            Spacing = 5,
            VerticalOptions = LayoutOptions.Center,
            Children =
            {
                SmallHeaderButton("⚙", "Instellingen", () => Navigate(FeatureKind.Settings)),
                SmallHeaderButton("🙈", "Scherm verbergen", () => _ = Navigation.PushAsync(new PrivacyCoverPage()))
            }
        };
        var top = new Grid
        {
            ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) },
            ColumnSpacing = 10,
            Children = { mark, hello, actions }
        };
        Grid.SetColumn(hello, 1);
        Grid.SetColumn(actions, 2);
        root.Children.Add(top);

        root.Children.Add(SectionHeading("Waar wil je naartoe?"));
        var knownFeatures = FeatureCatalog.All.Select(x => x.Kind.ToString()).ToArray();
        var shortcutKinds = HomeShortcutService.GetVisible(AppSession.Settings, knownFeatures)
            .Select(key => Enum.TryParse<FeatureKind>(key, out var kind) ? (FeatureKind?)kind : null)
            .Where(kind => kind.HasValue)
            .Select(kind => kind!.Value)
            .Where(IsFeatureEnabled)
            .ToArray();
        var shortcuts = shortcutKinds.Select(kind =>
        {
            var item = FeatureCatalog.Get(kind);
            return (Icon: item.Icon, Title: item.Label, Subtitle: item.Description, Color: TileColorFor(item.Group), Kind: item.Kind);
        }).ToArray();

        if (shortcuts.Length > 0)
        {
            var columns = Math.Clamp(_shortcutColumns, 2, 4);
            var grid = new Grid { ColumnSpacing = 10, RowSpacing = 10, HorizontalOptions = LayoutOptions.Fill };
            for (int column = 0; column < columns; column++) grid.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));
            for (int row = 0; row < (shortcuts.Length + columns - 1) / columns; row++) grid.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
            for (int i = 0; i < shortcuts.Length; i++)
            {
                var item = shortcuts[i];
                AddQuickTile(grid, item.Icon, item.Title, item.Subtitle, item.Color, item.Kind, i % columns, i / columns);
            }
            root.Children.Add(grid);
        }
        else
        {
            root.Children.Add(AppUi.Card(new VerticalStackLayout
            {
                Spacing = 6,
                Children = { AppUi.Label("Er zijn nog geen snelkoppelingen zichtbaar.", title: true), AppUi.Label("Kies één tot vier ingangen in Instellingen, of open Meer om de functies te doorzoeken.", muted: true), AppUi.Button("☰ Alle functies openen", () => _ = Navigation.PushAsync(new MorePage()), quiet: true) }
            }));
        }

        if (!AppSession.Settings.SimplifiedMode && IsFeatureEnabled(FeatureKind.DayToday))
        {
            var nl = CultureInfo.GetCultureInfo("nl-NL");
            var dateText = DateTime.Today.ToString("dddd d MMMM", nl);
            if (dateText.Length > 0) dateText = char.ToUpper(dateText[0], nl) + dateText[1..];
            root.Children.Add(SectionHeading("Vandaag"));
            root.Children.Add(AppUi.Card(new VerticalStackLayout
            {
                Spacing = 6,
                Children =
                {
                    AppUi.Label(dateText, title: true),
                    AppUi.Label("Bekijk je planning of voeg iets toe als je dat wilt.", muted: true),
                    AppUi.Button("🗓️ Dagoverzicht openen", () => Navigate(FeatureKind.DayToday), quiet: true)
                }
            }));
        }

        if (IsFeatureEnabled(FeatureKind.Agenda)) AddNextActivitySummary(root);

        if (AppSession.Store is { ReadErrorCount: > 0 })
        {
            root.Children.Add(AppUi.Card(new VerticalStackLayout
            {
                Spacing = 8,
                Children =
                {
                    AppUi.Label("Niet alle eerder opgeslagen gegevens konden worden gelezen.", title: true),
                    AppUi.Label("MoodPress verwijdert deze gegevens niet automatisch. Controleer je back-up en herstelopties voordat je iets wist of de app verwijdert.", muted: true),
                    AppUi.Button("Privacy en back-up bekijken", () => Navigate(FeatureKind.Privacy), quiet: true)
                }
            }));
        }

        if (!AppSession.Settings.SimplifiedMode)
        {
            root.Children.Add(AppUi.Card(new VerticalStackLayout
            {
                Spacing = 6,
                Children =
                {
                    AppUi.Label("Meer functies", title: true),
                    AppUi.Label("Rust, communicatie, doelen, dagboek, privacy en instellingen vind je overzichtelijk bij elkaar onder Meer.", muted: true),
                    AppUi.Button("☰ Bekijk alle functies", () => _ = Navigation.PushAsync(new MorePage()), quiet: true)
                }
            }));
        }
        root.Children.Add(AppUi.Label("Je gegevens blijven privé. Jij kiest zelf wat je deelt.", muted: true));
        root.Children.Add(AppUi.Copyright());
        Content = AppUi.WithBottomNavigation(this, new ScrollView { Content = root, BackgroundColor = AppUi.Background }, "home");
    }

    void AddNextActivitySummary(VerticalStackLayout root)
    {
        root.Children.Add(SectionHeading("Eerstvolgende activiteit"));

        var next = AgendaSummaryService.FindNext(
            AppSession.Store?.All<AgendaItem>("agenda"),
            DateTime.Now);

        if (next is null)
        {
            var emptyCard = AppUi.Card(new VerticalStackLayout
            {
                Spacing = 6,
                Children =
                {
                    AppUi.Label("Er staat nog niets gepland.", title: true),
                    AppUi.Label("Je kunt zelf een activiteit toevoegen wanneer je daar klaar voor bent.", muted: true),
                    AppUi.Button("➕ Activiteit toevoegen", () => Navigate(FeatureKind.Agenda), quiet: true)
                }
            });
            root.Children.Add(emptyCard);
            return;
        }

        var today = DateTime.Today;
        string dayLabel = next.Date.Date == today
            ? "Vandaag"
            : next.Date.Date == today.AddDays(1)
                ? "Morgen"
                : next.Date.ToString("dddd d MMMM", CultureInfo.GetCultureInfo("nl-NL"));
        if (dayLabel.Length > 0)
            dayLabel = char.ToUpper(dayLabel[0], CultureInfo.GetCultureInfo("nl-NL")) + dayLabel[1..];

        string timeLabel = TimeOnly.TryParse(
            (next.Time ?? string.Empty).Trim().Replace('.', ':'),
            CultureInfo.InvariantCulture,
            DateTimeStyles.None,
            out var parsedTime)
                ? parsedTime.ToString("HH:mm", CultureInfo.InvariantCulture)
                : "tijd niet ingesteld";

        var card = AppUi.Card(new VerticalStackLayout
        {
            Spacing = 6,
            Children =
            {
                AppUi.Label($"{next.Icon} {next.Title}", title: true),
                AppUi.Label($"{dayLabel} · {timeLabel}", muted: true),
                AppUi.Label($"Status: {next.CurrentStatus}", muted: true),
                AppUi.Button("📅 Agenda bekijken", () => Navigate(FeatureKind.Agenda), quiet: true)
            }
        });
        root.Children.Add(card);
    }

    static string TileColorFor(string group) => group switch
    {
        "Mijn dag en planning" => "#1D478F",
        "Mijn gevoel en rust" => "#075E52",
        "Communicatie en steun" => "#84244F",
        "Doelen en zelfstandigheid" => "#79430E",
        "Creatief en dagboek" => "#4C368F",
        "Profiel, privacy en hulp" => "#263754",
        _ => "#24477C"
    };

    static Label SectionHeading(string text)
    {
        return new Label
        {
            Text = text,
            FontFamily = "sans-serif-medium",
            FontSize = Math.Max(17, AppUi.BaseFont * 0.9),
            FontAttributes = FontAttributes.Bold,
            TextColor = AppUi.Foreground,
            LineBreakMode = LineBreakMode.WordWrap,
            Margin = new Thickness(0, 2, 0, 0)
        };
    }

    Button SmallHeaderButton(string text, string description, Action action)
    {
        var button = new Button
        {
            Text = text,
            FontSize = 19,
            FontFamily = "sans-serif",
            TextColor = AppUi.Foreground,
            BackgroundColor = Color.FromArgb("#101F44"),
            BorderColor = Color.FromArgb("#2B4B83"),
            BorderWidth = 1,
            CornerRadius = 14,
            Padding = new Thickness(7, 4),
            WidthRequest = 42,
            HeightRequest = 42,
            MinimumHeightRequest = 42,
        };
        SemanticProperties.SetDescription(button, description);
        button.Clicked += (_, _) => action();
        return button;
    }

    static void AddTap(View view, Action action)
    {
        var tap = new TapGestureRecognizer();
        tap.Tapped += (_, _) =>
        {
            AppSession.Touch();
            action();
        };
        view.GestureRecognizers.Add(tap);
    }

    static Border CreateFeatureTile(string icon, string title, string color, Action action)
    {
        var iconLabel = new Label
        {
            Text = icon,
            FontSize = 22,
            VerticalTextAlignment = TextAlignment.Center,
            HorizontalTextAlignment = TextAlignment.Center,
            WidthRequest = 30,
            FontAutoScalingEnabled = false
        };
        var textLabel = new Label
        {
            Text = title,
            FontFamily = AppUi.FontFamily,
            FontSize = Math.Max(13, AppUi.BaseFont * 0.70),
            TextColor = AppUi.Foreground,
            LineBreakMode = LineBreakMode.WordWrap,
            FontAutoScalingEnabled = true,
            HorizontalOptions = LayoutOptions.Fill,
            VerticalTextAlignment = TextAlignment.Center,
            LineHeight = 1.12
        };
        var row = new Grid
        {
            ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star) },
            ColumnSpacing = 8,
            Padding = new Thickness(10, 9),
            Children = { iconLabel, textLabel }
        };
        Grid.SetColumn(textLabel, 1);
        var border = new Border
        {
            Content = row,
            BackgroundColor = Color.FromArgb(color),
            Stroke = new SolidColorBrush(Color.FromArgb("#294779")),
            StrokeThickness = 1,
            StrokeShape = new RoundRectangle { CornerRadius = 16 },
            Padding = 0,
            MinimumHeightRequest = 74,
            HorizontalOptions = LayoutOptions.Fill
        };
        border.AutomationId = "feature_" + Regex.Replace(title.ToLowerInvariant(), "[^a-z0-9]+", "_").Trim('_');
        AddTap(border, action);
        return border;
    }

    void AddQuickTile(Grid grid, string icon, string title, string subtitle, string color, FeatureKind kind, int col, int row)
    {
        var iconLabel = new Label
        {
            Text = icon,
            FontSize = 28,
            HorizontalTextAlignment = TextAlignment.Start,
            VerticalTextAlignment = TextAlignment.Center,
            FontAutoScalingEnabled = false,
            Margin = new Thickness(0, 0, 0, 1)
        };
        var titleLabel = new Label
        {
            Text = title,
            FontSize = Math.Max(14, AppUi.BaseFont * 0.76),
            FontFamily = "sans-serif-medium",
            FontAttributes = FontAttributes.Bold,
            TextColor = Colors.White,
            LineBreakMode = LineBreakMode.WordWrap,
            FontAutoScalingEnabled = true,
            LineHeight = 1.1
        };
        var subtitleLabel = new Label
        {
            Text = subtitle,
            FontSize = Math.Max(11, AppUi.BaseFont * 0.60),
            FontFamily = AppUi.FontFamily,
            TextColor = Color.FromArgb("#F0F5FF"),
            LineBreakMode = LineBreakMode.WordWrap,
            FontAutoScalingEnabled = true,
            LineHeight = 1.1
        };
        var stack = new VerticalStackLayout
        {
            Spacing = 4,
            Padding = new Thickness(12, 11),
            Children = { iconLabel, titleLabel, subtitleLabel }
        };
        var tile = new Border
        {
            Content = stack,
            BackgroundColor = Color.FromArgb(color),
            Stroke = new SolidColorBrush(Color.FromArgb(color)),
            StrokeThickness = 1,
            StrokeShape = new RoundRectangle { CornerRadius = 19 },
            Padding = 0,
            MinimumHeightRequest = 116,
            HorizontalOptions = LayoutOptions.Fill,
            VerticalOptions = LayoutOptions.Fill
        };
        tile.AutomationId = "home_shortcut_" + kind.ToString().ToLowerInvariant();
        SemanticProperties.SetDescription(tile, $"{title}. {subtitle}");
        SemanticProperties.SetHint(tile, $"Tik om {title} te openen.");
        AddTap(tile, () => Navigate(kind));
        grid.Add(tile, col, row);
    }

    bool IsFeatureEnabled(FeatureKind kind) => FeatureVisibilityService.IsEnabled(AppSession.Settings, kind.ToString());

    void Navigate(FeatureKind kind)
    {
        if (kind == FeatureKind.WhoWorks) _ = Navigation.PushAsync(new WieWerktErPage());
        else if (kind == FeatureKind.ChildSchedule) _ = Navigation.PushAsync(new ChildSchedulePage());
        else if (kind == FeatureKind.ShareSupport) _ = Navigation.PushAsync(new SupportPackageSharePage());
        else if (kind == FeatureKind.ReceiveSupport) _ = Navigation.PushAsync(new ReceiveSupportPackagePage());
        else _ = Navigation.PushAsync(new FeaturePage(kind));
    }

    async Task SaveFourGFeelingAsync(string feeling, Label status, VerticalStackLayout helpPanel)
    {
        var record = new FourGFeelingEntry(Guid.NewGuid(), DateTime.Now, feeling);
        AppSession.Store!.Save("feeling4g", record.Id, record);
        status.Text = $"Opgeslagen: {FeelingEmoji(feeling)} {feeling}.";
        AppUi.Speak($"Je hebt {feeling} gekozen. Dit is opgeslagen. Er wordt niets automatisch gedeeld.");
        helpPanel.Children.Clear();
        helpPanel.Children.Add(AppUi.Title(feeling == "Blij" ? "Fijn dat je dit deelt" : "Wat kan nu helpen?"));
        if (feeling == "Blij")
        {
            helpPanel.Children.Add(AppUi.Label("Je gevoel is bewaard. Je hoeft verder niets te doen."));
            helpPanel.IsVisible = true;
            return;
        }

        var plan = AppSession.Store.Load<SafetyPlan>("plan", Guid.Empty) ?? new SafetyPlan();
        var options = plan.HelpOptions?.Where(x => !string.IsNullOrWhiteSpace(x)).Distinct().ToList() ?? new List<string>();
        if (options.Count == 0) options = new List<string> { "breath", "calm", "stressball", "walk" };
        foreach (var option in options) helpPanel.Children.Add(AppUi.AsyncButton(HelpOptionLabel(option), async () => await RunHelpOptionAsync(option), quiet: true));
        helpPanel.Children.Add(AppUi.Button("👥 Wie werkt er vandaag?", () => Navigation.PushAsync(new WieWerktErPage()), quiet: true));
        helpPanel.Children.Add(AppUi.Button("🆘 Mijn helpkaart bekijken", () => Navigate(FeatureKind.SafetyPlan), quiet: true));
        helpPanel.Children.Add(AppUi.AsyncButton("📱 Een seintje aan mijn contact voorbereiden", SendSignalAsync, quiet: true));
        helpPanel.Children.Add(AppUi.Label("Er wordt niets automatisch verzonden. Jij kiest zelf of je een bericht opent en verstuurt.", muted: true));
        helpPanel.IsVisible = true;
    }

    static string FeelingEmoji(string feeling) => feeling switch { "Blij" => "😄", "Bedroefd" => "😢", "Boos" => "😠", "Bang" => "😨", _ => "🙂" };
    static string HelpOptionLabel(string key) => key switch
    {
        "breath" => "🫁 Samen rustig ademhalen", "calm" => "🛋️ Naar mijn rustplek", "music" => "🎧 Rustige muziek luisteren",
        "stressball" => "🧸 Pak mijn stressbal", "walk" => "🚶 Even rustig wandelen", "talk" => "💬 Met iemand praten", _ => "🆘 Mijn helpkaart openen"
    };

    async Task RunHelpOptionAsync(string key)
    {
        switch (key)
        {
            case "breath": await Navigation.PushAsync(new FeaturePage(FeatureKind.Breath)); break;
            case "calm": await Navigation.PushAsync(new FeaturePage(FeatureKind.Calm)); break;
            case "music": await Navigation.PushAsync(new FeaturePage(FeatureKind.Breath)); break;
            case "walk": AppUi.Speak("Als het veilig kan, loop rustig een klein rondje. Vraag hulp als je niet alleen naar buiten kunt."); await DisplayAlertAsync("Een kleine stap", "Als het veilig kan, loop rustig een klein rondje. Vraag hulp als je niet alleen naar buiten kunt.", "OK"); break;
            case "stressball": AppUi.Speak("Pak je stressbal. Knijp rustig een paar keer en voel je voeten op de grond."); await DisplayAlertAsync("Een kleine stap", "Pak je stressbal. Knijp rustig een paar keer en voel je voeten op de grond.", "OK"); break;
            case "talk": await Navigation.PushAsync(new WieWerktErPage()); break;
            default: await Navigation.PushAsync(new FeaturePage(FeatureKind.SafetyPlan)); break;
        }
    }

    async Task SendSignalAsync()
    {
        var plan = AppSession.Store?.Load<SafetyPlan>("plan", Guid.Empty) ?? new SafetyPlan();
        var contact = plan.Contacts.FirstOrDefault(c => !string.IsNullOrWhiteSpace(c.Phone));
        if (contact is null)
        {
            await DisplayAlertAsync("Eerst een contact toevoegen", "Vul bij 'Mijn helpkaart / plan' de naam en het telefoonnummer in van iemand die je vertrouwt.", "Mijn helpkaart openen");
            await Navigation.PushAsync(new FeaturePage(FeatureKind.SafetyPlan)); return;
        }
        const string body = "Hoi, ik heb het nu moeilijk. Kun je contact met mij opnemen?";
        bool proceed = await DisplayAlertAsync("Een seintje voorbereiden", $"Er wordt een sms klaargezet voor {contact.Name}. De app verstuurt niets vanzelf. Je kunt in de Berichten-app zelf nog kiezen om te versturen.", "Sms openen", "Annuleren");
        if (!proceed) return;
        try { await Sms.Default.ComposeAsync(new SmsMessage(body, new[] { contact.Phone })); }
        catch (Exception ex) { AppLog.Write(ex); await DisplayAlertAsync("Sms niet geopend", "Je kunt je contact ook zelf bellen of een bericht sturen.", "OK"); }
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (AppSession.Store is not null) Build();
        AppSession.Touch();
        if (AppSession.Settings.Animations) { Opacity = 0; _ = this.FadeToAsync(1, 180, Easing.CubicOut); }
        if (_consentPrompted || AppSession.Store is null) return;
        if (AppSession.Store.All<ConsentRecord>("consent").Any(c => c.Version >= ConsentInfo.CurrentVersion)) { _consentPrompted = true; return; }
        _consentPrompted = true;
        const string text = "MoodPress is voor jou. Je dagboek, tekeningen, agenda en andere gegevens worden versleuteld op deze telefoon bewaard. Je begeleider ziet alleen wat jij zelf deelt. De app waarschuwt niemand en belt niemand. Je mag je gegevens meenemen of verwijderen. Vraag je begeleider wie verantwoordelijk is voor je gegevens en waar de privacyverklaring staat.";
        await DisplayAlertAsync("Voordat je begint", text, "Ik heb dit gelezen");
        var choice = await DisplayActionSheetAsync("Met wie gebruik je MoodPress?", "Nu niet", null, "Zelf", "Samen met mijn vertegenwoordiger of begeleider");
        if (choice == "Zelf" || choice == "Samen met mijn vertegenwoordiger of begeleider")
        {
            var consent = new ConsentRecord(Guid.NewGuid(), DateTime.Now, ConsentInfo.CurrentVersion, choice == "Zelf" ? "zelf" : "samen");
            AppSession.Store.Save("consent", consent.Id, consent);
        }
        else await ((App)Application.Current!).LockToLoginAsync("Je kunt later toestemming geven door opnieuw in te loggen.");
    }
}
