using Microsoft.Maui.ApplicationModel.Communication;
using System.Globalization;
using System.Text;
using System.Text.Json;
using MijnGevoel.Core.Data;
using MijnGevoel.Core.Security;
using SkiaSharp;
using Microsoft.Maui.ApplicationModel.DataTransfer;
using Microsoft.Maui.Storage;
using Microsoft.Maui.Media;
using Microsoft.Maui.Controls.Shapes;
using Microsoft.Maui.ApplicationModel;
using Plugin.Maui.Audio;
using PointF = Microsoft.Maui.Graphics.PointF;

namespace MijnGevoel.AndroidApp;

/// <summary>Mobiele schermen voor de volledige kernfunctionaliteit. Gegevens lopen altijd via de versleutelde VaultStore.</summary>
public sealed partial class FeaturePage : ContentPage
{
    readonly FeatureKind _kind;
    public FeatureKind CurrentKind => _kind;
    readonly Guid? _targetShareId;
    readonly VerticalStackLayout _root;
    IDispatcherTimer? _timer;
    int _timerRemaining;
    int _timerTotal;
    TimerSessionState? _timerState;
    Label? _timerDisplay;
    Label? _timerStatus;
    Picker? _timerMinutes;
    readonly Guid? _editingMoodCheckInId;
    IDispatcherTimer? _breathTimer;
    Android.Media.MediaPlayer? _breathingMusicPlayer;
    bool _breathIn = true;
    int _calmTipIndex;
    Routine? _runningRoutine;
    int _routineStep;
    Guid? _editingRoutineId;
    Guid? _editingAdultGoalId;
    Entry? _routineName, _routineIcon;
    Editor? _routineSteps;
    readonly List<List<PointF>> _strokes = new();
    readonly List<string> _strokeColors = new();
    readonly List<float> _strokeWidths = new();
    string _drawingColorHex = "#202020";
    float _drawingStrokeWidth = 4f;
    string _drawingTitle = "Mijn tekening";
    FreeDrawDrawable? _freeDrawDrawable;
    List<PointF>? _activeStroke;
    GraphicsView? _drawingView;
    readonly List<CheckBox> _shareChecks = new();
    IAudioRecorder? _voiceRecorder;
    IAudioPlayer? _voicePlayer;
    Stream? _voicePlaybackStream;
    IDispatcherTimer? _voiceRecordTimer;
    string? _voiceRecordingPath;
    Button? _voiceRecordButton;
    Label? _voiceRecordStatus;
    VerticalStackLayout? _voiceNoteList;
    string _voiceContext = "diary";
    bool _voiceRecording;
    bool _stoppingVoiceRecording;

    static readonly (string Emoji, string Name, string Hex)[] Moods =
    {
        ("😄", "Blij", "#8FD694"), ("🙂", "Goed", "#C5E384"), ("😐", "Gaat wel", "#F4E285"),
        ("😟", "Niet fijn", "#F5B971"), ("😢", "Verdrietig", "#E88B8B")
    };
    static readonly (string Emoji, string Text)[] Reasons =
    {
        ("😴", "Ik ben moe"), ("😠", "Ik ben boos"), ("😢", "Ik ben verdrietig"), ("😨", "Ik ben bang"),
        ("👥", "Iets met andere mensen"), ("🏫", "School, werk of dagbesteding"), ("🏠", "Thuis of waar ik woon"),
        ("🤕", "Pijn of ziek"), ("🌀", "Te veel drukte of lawaai"), ("🤷", "Ik weet het niet")
    };
    static readonly (string Emoji, string Text)[] Needs =
    {
        ("💬", "Ik wil praten met iemand"), ("🤫", "Ik wil rust"), ("🎨", "Ik wil iets leuks doen"),
        ("🚶", "Ik wil even naar buiten"), ("🆘", "Ik wil nu hulp"), ("🤷", "Ik weet het niet")
    };
    static readonly (string Emoji, string Name, string Description)[] FeelingWords =
    {
        ("😊", "Blij", "Je voelt je fijn. Je hebt zin in dingen."), ("😌", "Rustig", "Je lijf en je hoofd zijn kalm. Je hoeft niets."),
        ("🥳", "Trots", "Je hebt iets gedaan wat je moeilijk vond, en het is gelukt."), ("😢", "Verdrietig", "Je voelt je zwaar of leeg. Soms moet je huilen."),
        ("😠", "Boos", "Je voelt je warm en gespannen. Je vindt iets niet eerlijk."), ("😨", "Bang", "Je denkt dat er iets ergs gebeurt. Je hart gaat snel."),
        ("😬", "Zenuwachtig", "Je buik kriebelt. Er komt iets spannends aan."), ("🥺", "Eenzaam", "Je wilt graag bij iemand zijn, maar je voelt je alleen."),
        ("😴", "Moe", "Je hebt weinig energie. Je wilt rusten."), ("🤯", "Overprikkeld", "Er komt te veel tegelijk binnen: geluid, licht of mensen."),
        ("😞", "Teleurgesteld", "Je had iets anders verwacht en het ging anders."), ("😳", "Beschaamd", "Je wilt even niet bekeken worden."),
        ("😕", "Verward", "Je snapt het even niet. Je weet niet wat je moet doen."), ("😮‍💨", "Opgelucht", "Iets spannends is voorbij. Je mag ontspannen."),
        ("🙏", "Dankbaar", "Je vindt het fijn dat iemand iets goeds voor je deed."), ("😒", "Jaloers", "Een ander heeft iets wat jij ook graag zou willen.")
    };
    static readonly (string Emoji, string Text)[] BasicCards =
    {
        ("🤫", "Ik wil even rust"), ("🙋", "Ik heb hulp nodig"), ("❓", "Ik snap het niet"), ("🔁", "Kun je het nog een keer zeggen?"),
        ("🐢", "Kun je langzamer praten?"), ("🚻", "Ik moet naar de wc"), ("🥤", "Ik heb dorst"), ("🍽️", "Ik heb honger"),
        ("🔇", "Het is te druk of te hard"), ("✋", "Ik wil niet aangeraakt worden"), ("💬", "Ik wil praten"), ("🏠", "Ik wil naar huis")
    };
    static readonly (string Emoji, string Name)[] AgendaIcons =
    {
        ("🏥", "Dokter"), ("👥", "Afspraak"), ("💊", "Medicijnen"), ("🍽️", "Eten"), ("🚌", "Reizen"),
        ("🏃", "Sporten"), ("📞", "Bellen"), ("🎉", "Feest"), ("⭐", "Anders")
    };
    static readonly string[] CalmTips =
    {
        "Je bent veilig. Je hoeft nu niets.", "Kijk om je heen. Noem 3 dingen die je ziet.", "Voel je voeten op de grond.",
        "Adem rustig in en uit.", "Drink een slokje water.", "Dit gevoel gaat voorbij. Het blijft niet zo."
    };
    static readonly (FeatureKind Kind, string Label, string Group)[] FeatureVisibilityOptions =
        FeatureCatalog.All.Select(x => (Kind: x.Kind, Label: x.Label, Group: x.Group)).ToArray();

    public FeaturePage(FeatureKind kind, Guid? targetShareId = null, Guid? editingMoodCheckInId = null)
    {
        _kind = kind;
        _targetShareId = targetShareId;
        _editingMoodCheckInId = editingMoodCheckInId;
        Title = TitleFor(kind);
        BackgroundColor = AppUi.Background;
        _root = new VerticalStackLayout { Padding = new Thickness(16), Spacing = 10, BackgroundColor = AppUi.Background };
        Content = new ScrollView { Content = _root };
        Build();
        var body = Content ?? new ScrollView { Content = _root };
        Content = AppUi.WithBottomNavigation(this, body, ActiveTabFor(_kind));
        ToolbarItems.Add(new ToolbarItem("🙈 Scherm verbergen", null, async () => await Navigation.PushAsync(new PrivacyCoverPage())));
        ToolbarItems.Add(new ToolbarItem("🔒 Vergrendel", null, async () => await ((App)Application.Current!).LockToLoginAsync()));
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        AppSession.Touch();
        if (_kind == FeatureKind.Timer)
        {
            RefreshTimerState(announceCompletion: true);
            if (_timerState?.IsRunning == true) StartTimerTick();
        }
        if (AppSession.Settings.Animations)
        {
            Opacity = 0;
            _ = this.FadeToAsync(1, 180, Easing.CubicOut);
        }
    }

    protected override void OnDisappearing()
    {
        // Stop alleen de scherm-update. De timerstatus bewaart een eindtijd in de versleutelde kluis,
        // zodat de tijd blijft doorlopen als de gebruiker naar een ander scherm gaat.
        _timer?.Stop();
        _breathTimer?.Stop();
        StopBreathingMusic();
        _voiceRecordTimer?.Stop();
        if (_voiceRecording) _ = StopVoiceRecordingAsync(save: false);
        StopVoicePlayback();
        base.OnDisappearing();
    }

    static string ActiveTabFor(FeatureKind kind) => kind switch
    {
        FeatureKind.DayToday or FeatureKind.DayTomorrow or FeatureKind.Agenda or FeatureKind.Timer or FeatureKind.Routines or FeatureKind.RoutineReminders => "day",
        FeatureKind.DailyCheckIn or FeatureKind.MoodHistory or FeatureKind.MoodCalendar or FeatureKind.MoodInsights or FeatureKind.FeelingWords => "feeling",
        _ => "more"
    };

    static string TitleFor(FeatureKind kind) => kind switch
    {
        FeatureKind.Stoplicht => "Mijn stoplicht", FeatureKind.DayToday => "Vandaag", FeatureKind.DayTomorrow => "Morgen",
        FeatureKind.Agenda => "Agenda", FeatureKind.Timer => "Timer", FeatureKind.Routines => "Stappenplannen", FeatureKind.RoutineReminders => "Routines en herinneringen",
        FeatureKind.Breath => "Ademhalen", FeatureKind.Calm => "Rustplek", FeatureKind.Sensory => "Prikkelmeter",
        FeatureKind.Body => "Mijn lichaam", FeatureKind.MoodHistory => "Hoe voel ik me?", FeatureKind.FeelingWords => "Gevoelswoorden",
        FeatureKind.Cards => "Kaarten om te laten zien", FeatureKind.TalkPrep => "Gesprekskaart", FeatureKind.StoplichtHistory => "Stoplicht-overzicht",
        FeatureKind.Share => "Delen met mijn begeleider", FeatureKind.SafetyPlan => "Mijn plan", FeatureKind.Draw => "Tekenen",
        FeatureKind.YouthSupport => "Stress en grenzen", FeatureKind.AdultPlanning => "Werk, dagbesteding en doelen", FeatureKind.Wellbeing => "Mijn welzijn", FeatureKind.Profile => "Mijn profiel",
        FeatureKind.DailyCheckIn => "Dagelijkse check-in", FeatureKind.MoodCalendar => "Gevoelskalender", FeatureKind.MoodInsights => "Mijn inzichten",
        FeatureKind.Gallery => "Mijn tekeningen", FeatureKind.Notes => "Van me afschrijven", FeatureKind.Journal => "Dagboek",
        FeatureKind.Privacy => "Mijn privacy", FeatureKind.Week => "Weekoverzicht", FeatureKind.Settings => "Instellingen", _ => "Hulp"
    };

    void Build()
    {
        _root.Children.Clear();
        switch (_kind)
        {
            case FeatureKind.Stoplicht: BuildStoplicht(); break;
            case FeatureKind.DayToday: BuildDay(DateTime.Today); break;
            case FeatureKind.DayTomorrow: BuildDay(DateTime.Today.AddDays(1)); break;
            case FeatureKind.Agenda: BuildAgenda(); break;
            case FeatureKind.Timer: BuildTimer(); break;
            case FeatureKind.Routines: BuildRoutines(); break;
            case FeatureKind.RoutineReminders: BuildRoutineReminders(); break;
            case FeatureKind.Breath: BuildBreath(); break;
            case FeatureKind.Calm: BuildCalm(); break;
            case FeatureKind.Sensory: BuildSensory(); break;
            case FeatureKind.Body: BuildBody(); break;
            case FeatureKind.MoodHistory: BuildMoodHistory(); break;
            case FeatureKind.DailyCheckIn: BuildDailyCheckIn(); break;
            case FeatureKind.MoodCalendar: BuildMoodCalendar(); break;
            case FeatureKind.MoodInsights: BuildMoodInsights(); break;
            case FeatureKind.FeelingWords: BuildFeelingWords(); break;
            case FeatureKind.Cards: BuildCards(); break;
            case FeatureKind.TalkPrep: BuildTalkPrep(); break;
            case FeatureKind.StoplichtHistory: BuildStoplichtHistory(); break;
            case FeatureKind.Share: BuildShare(); break;
            case FeatureKind.ShareSupport: AddAsyncButton("Ondersteuningspakket openen", async () => await Navigation.PushAsync(new SupportPackageSharePage())); break;
            case FeatureKind.ReceiveSupport: AddAsyncButton("Voorstel ontvangen", async () => await Navigation.PushAsync(new ReceiveSupportPackagePage())); break;
            case FeatureKind.YouthSupport: BuildYouthSupport(); break;
            case FeatureKind.AdultPlanning: BuildAdultPlanning(); break;
            case FeatureKind.Wellbeing: BuildWellbeing(); break;
            case FeatureKind.Profile: BuildProfile(); break;
            case FeatureKind.SafetyPlan: BuildSafetyPlan(); break;
            case FeatureKind.Draw: BuildDraw(); break;
            case FeatureKind.Gallery: BuildGallery(); break;
            case FeatureKind.Notes: BuildJournal(false); break;
            case FeatureKind.Journal: BuildJournal(true); break;
            case FeatureKind.Privacy: BuildPrivacy(); break;
            case FeatureKind.Week: BuildWeek(); break;
            case FeatureKind.Settings: BuildSettings(); break;
            default: BuildHelp(); break;
        }
    }

    void Header(string title, string description)
    {
        _root.Children.Add(AppUi.Title(title));
        _root.Children.Add(AppUi.Label(description));
        if (AppSession.Settings.ReadAloud)
        {
            _root.Children.Add(AppUi.AsyncButton("🔊 Lees deze uitleg voor", async () =>
            {
                try { await TextToSpeech.Default.SpeakAsync($"{title}. {description}"); }
                catch (Exception ex) { AppLog.Write(ex); await DisplayAlertAsync("Voorlezen niet beschikbaar", "Je kunt de tekst op het scherm rustig lezen.", "OK"); }
            }, quiet: true));
        }
    }

    void Add(View view) => _root.Children.Add(view);
    void AddLabel(string text, bool title = false, bool muted = false) => Add(AppUi.Label(text, title, muted));
    void AddButton(string text, Action action, bool quiet = false, bool danger = false) => Add(AppUi.Button(text, action, quiet, danger));
    void AddAsyncButton(string text, Func<Task> action, bool quiet = false, bool danger = false) => Add(AppUi.AsyncButton(text, action, quiet, danger));
    void AddField(string label, View control) { Add(AppUi.Label(label)); Add(control); }
    VaultStore Store => AppSession.Store ?? throw new InvalidOperationException("Sessie is vergrendeld.");

    // ---------- Stoplicht ----------
    void BuildStoplicht()
    {
        Header("Hoe is het nu?", "Kies de kleur die bij jou past. Dit wordt niet automatisch naar iemand gestuurd.");
        var colour = AppUi.Picker("Kies een kleur", new[] { "Groen", "Oranje", "Rood" }, "Groen");
        AddField("Mijn kleur", colour);
        AddLabel("Waarom? Je mag meer dan één ding kiezen.", title: true);
        var reasonChecks = new List<(string Text, CheckBox Box)>();
        foreach (var item in Reasons)
        {
            var cb = new CheckBox { Color = AppUi.Accent };
            cb.CheckedChanged += (_, _) => AppSession.Touch();
            reasonChecks.Add((item.Text, cb));
            Add(new HorizontalStackLayout { Spacing = 8, Children = { cb, AppUi.Label(item.Emoji + "  " + item.Text) } });
        }
        AddLabel("Wat heb ik nodig?", title: true);
        var needChecks = new List<(string Text, CheckBox Box)>();
        foreach (var item in Needs)
        {
            var cb = new CheckBox { Color = AppUi.Accent };
            cb.CheckedChanged += (_, _) => AppSession.Touch();
            needChecks.Add((item.Text, cb));
            Add(new HorizontalStackLayout { Spacing = 8, Children = { cb, AppUi.Label(item.Emoji + "  " + item.Text) } });
        }
        var note = AppUi.Editor("Wil je er iets bij schrijven? (mag leeg blijven)", height: 130);
        AddField("Extra tekst", note);
        AddAsyncButton("💾 Stoplicht opslaan", async () =>
        {
            var c = colour.SelectedItem?.ToString() ?? "Groen";
            var entry = new StoplichtEntry(Guid.NewGuid(), DateTime.Now, c,
                reasonChecks.Where(x => x.Box.IsChecked).Select(x => x.Text).ToArray(),
                needChecks.Where(x => x.Box.IsChecked).Select(x => x.Text).ToArray(), note.Text ?? "");
            Store.Save("light", entry.Id, entry);
            var message = c == "Rood"
                ? "Je hebt rood gekozen. Je hoeft dit niet alleen te doen. MoodPress waarschuwt niemand automatisch. Vertel iemand die je vertrouwt dat je hulp nodig hebt. Bij direct gevaar bel je 112. Je kunt ook 113 Zelfmoordpreventie bellen op 0800-0113."
                : c == "Oranje" ? "Je hebt oranje gekozen. Je kunt even rust nemen, je plan bekijken of dit delen met iemand die je vertrouwt." : "Fijn dat het groen gaat.";
            await DisplayAlertAsync("Stoplicht opgeslagen", message, "OK");
            Build();
        });
        AddButton("📤 Dit delen met mijn begeleider", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Share)), quiet: true);
        AddButton("🆘 Mijn plan bekijken", () => Navigation.PushAsync(new FeaturePage(FeatureKind.SafetyPlan)), quiet: true);
    }

    void BuildStoplichtHistory()
    {
        Header("Mijn stoplicht-overzicht", "Je eerdere meldingen. Alleen jij ziet deze gegevens totdat je zelf iets deelt.");
        AddButton("🚦 Nieuwe stoplicht-melding", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Stoplicht)));
        AddButton("📤 Delen met mijn begeleider", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Share)), quiet: true);
        var logs = Store.All<ShareLogEntry>("sharelog").OrderByDescending(x => x.Created).ToList();
        AddLabel(logs.Count == 0 ? "Je hebt nog niets gedeeld." : $"Je hebt {logs.Count} keer gedeeld. Laatste keer: {logs[0].Created:dd-MM-yyyy HH:mm}.", muted: true);
        var items = Store.All<StoplichtEntry>("light").OrderByDescending(x => x.Created).ToList();
        if (items.Count == 0) AddLabel("Je hebt nog niets ingevuld.", muted: true);
        foreach (var e in items)
        {
            var colour = e.Colour switch { "Rood" => "🔴", "Oranje" => "🟠", _ => "🟢" };
            var layout = new VerticalStackLayout { Spacing = 5 };
            layout.Children.Add(AppUi.Label($"{colour} {e.Colour} — {e.Created:dddd d MMMM yyyy HH:mm}", title: true));
            var reasons = e.Reasons ?? Array.Empty<string>();
            var needs = e.Needs ?? Array.Empty<string>();
            if (reasons.Length > 0) layout.Children.Add(AppUi.Label("Waarom: " + string.Join(", ", reasons)));
            if (needs.Length > 0) layout.Children.Add(AppUi.Label("Nodig: " + string.Join(", ", needs)));
            if (!string.IsNullOrWhiteSpace(e.Text)) layout.Children.Add(AppUi.Label(e.Text));
            layout.Children.Add(AppUi.Button("📤 Dit delen", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Share, e.Id)), quiet: true));
            layout.Children.Add(AppUi.Button("🗑 Weggooien", async () =>
            {
                if (await DisplayAlertAsync("Weggooien?", "Deze melding definitief verwijderen?", "Verwijderen", "Annuleren")) { Store.Delete("light", e.Id); Build(); }
            }, danger: true));
            Add(AppUi.Card(layout));
        }
    }

    // ---------- Dagboek en briefjes ----------
    void BuildJournal(bool withMood)
    {
        string kind = withMood ? "diary" : "note";
        Header(withMood ? "Dagboek" : "Van me afschrijven", withMood
            ? "Hoe was je dag? Kies eventueel een gezichtje en schrijf wat je wilt."
            : "Schrijf op wat je dwarszit. Je kunt het bewaren of weer weggooien.");
        var mood = AppUi.Picker("Hoe voel ik me?", new[] { "Geen gezichtje", "😄 Blij", "🙂 Goed", "😐 Gaat wel", "😟 Niet fijn", "😢 Verdrietig" }, "Geen gezichtje");
        if (withMood) AddField("Gevoel", mood);
        var text = AppUi.Editor("Schrijf hier…", height: 180);
        AddField("Tekst", text);
        var status = AppUi.Label("");
        Guid? current = null;
        _voiceContext = kind;
        var voiceHelp = AppUi.Label("Je kunt ook een kort spraakbericht opnemen. Je opname wordt versleuteld op deze telefoon bewaard en niet verstuurd.", muted: true);
        _voiceRecordStatus = AppUi.Label("Nog geen opname gestart.");
        _voiceRecordButton = AppUi.AsyncButton("🎙 Spraakbericht opnemen (max. 60 seconden)", async () =>
        {
            if (_voiceRecording) await StopVoiceRecordingAsync(save: true);
            else await StartVoiceRecordingAsync();
        });
        _voiceNoteList = new VerticalStackLayout { Spacing = 6 };
        void ReloadList(VerticalStackLayout list)
        {
            list.Children.Clear();
            var entries = Store.All<JournalEntry>(kind).OrderByDescending(x => x.Created).ToList();
            if (entries.Count == 0) list.Children.Add(AppUi.Label("Nog niets opgeschreven.", muted: true));
            foreach (var e in entries)
            {
                string snip = e.Text.Replace('\n', ' ').Replace('\r', ' ');
                if (snip.Length > 56) snip = snip[..56] + "…";
                var emoji = e.Mood > 0 ? Moods[e.Mood - 1].Emoji + " " : "";
                list.Children.Add(AppUi.Button($"{e.Created:dd-MM-yyyy HH:mm}  {emoji}{(snip.Length == 0 ? "(alleen gevoel)" : snip)}", () =>
                {
                    current = e.Id; text.Text = e.Text;
                    if (withMood) mood.SelectedIndex = e.Mood;
                    status.Text = "Geselecteerd om te bekijken of aan te passen.";
                }, quiet: true));
            }
        }
        var list = new VerticalStackLayout { Spacing = 4 };
        AddAsyncButton("💾 Bewaren", async () =>
        {
            int mv = withMood ? Math.Clamp(mood.SelectedIndex, 0, 5) : 0;
            if (string.IsNullOrWhiteSpace(text.Text) && mv == 0) { status.Text = "Schrijf eerst iets op of kies een gezichtje."; return; }
            JournalEntry? old = current is Guid id ? Store.Load<JournalEntry>(kind, id) : null;
            var entry = old is null ? new JournalEntry(Guid.NewGuid(), DateTime.Now, mv, text.Text ?? "") : old with { Mood = mv, Text = text.Text ?? "" };
            Store.Save(kind, entry.Id, entry); current = entry.Id; status.Text = "Opgeslagen ✔"; ReloadList(list);
        });
        AddButton("✨ Nieuw", () => { current = null; text.Text = ""; if (withMood) mood.SelectedIndex = 0; status.Text = ""; }, quiet: true);
        AddAsyncButton("🗑 Geselecteerde verwijderen", async () =>
        {
            if (current is not Guid id) { status.Text = "Kies eerst een eerder stukje."; return; }
            if (await DisplayAlertAsync("Definitief verwijderen?", "Deze tekst kan niet worden teruggehaald.", "Verwijderen", "Annuleren")) { Store.Delete(kind, id); current = null; text.Text = ""; status.Text = "Verwijderd."; ReloadList(list); }
        }, danger: true);
        AddButton("🔊 Voorlezen", () => { if (!string.IsNullOrWhiteSpace(text.Text)) AppUi.Speak(text.Text); }, quiet: true);
        Add(status);
        AddLabel("Spraakbericht", title: true);
        Add(voiceHelp);
        Add(_voiceRecordButton);
        Add(_voiceRecordStatus);
        Add(_voiceNoteList);
        ReloadVoiceNotes();
        AddLabel("Eerder opgeschreven", title: true);
        Add(list);
        ReloadList(list);
    }

    async Task StartVoiceRecordingAsync()
    {
        try
        {
            var permission = await Permissions.RequestAsync<Permissions.Microphone>();
            if (permission != PermissionStatus.Granted)
            {
                if (_voiceRecordStatus is not null) _voiceRecordStatus.Text = "Microfoontoegang is niet toegestaan. Je kunt ook typen.";
                return;
            }

            StopVoicePlayback();
            var recordingPath = System.IO.Path.Combine(FileSystem.CacheDirectory, "mg-voice-" + Guid.NewGuid().ToString("N") + ".wav");
            _voiceRecordingPath = recordingPath;
            _voiceRecorder = AudioManager.Current.CreateRecorder(new AudioRecorderOptions
            {
                Encoding = Plugin.Maui.Audio.Encoding.Wav,
                Channels = ChannelType.Mono,
                SampleRate = 16000,
                BitDepth = Plugin.Maui.Audio.BitDepth.Pcm16bit
            });
            if (!_voiceRecorder.CanRecordAudio)
            {
                (_voiceRecorder as IDisposable)?.Dispose(); _voiceRecorder = null;
                _voiceRecordingPath = null;
                if (_voiceRecordStatus is not null) _voiceRecordStatus.Text = "Opnemen kan niet op dit toestel. Je kunt ook typen.";
                return;
            }
            await _voiceRecorder.StartAsync(recordingPath);
            _voiceRecording = true;
            _stoppingVoiceRecording = false;
            if (_voiceRecordButton is not null) _voiceRecordButton.Text = "⏹ Stoppen en bewaren";
            if (_voiceRecordStatus is not null) _voiceRecordStatus.Text = "🔴 Ik luister… Tik op stoppen als je klaar bent. Na 60 seconden stopt de opname automatisch.";

            _voiceRecordTimer?.Stop();
            _voiceRecordTimer = Dispatcher.CreateTimer();
            _voiceRecordTimer.Interval = TimeSpan.FromSeconds(60);
            _voiceRecordTimer.Tick += async (_, _) =>
            {
                if (_voiceRecording && !_stoppingVoiceRecording)
                    await StopVoiceRecordingAsync(save: true);
            };
            _voiceRecordTimer.Start();
        }
        catch (Exception ex)
        {
            AppLog.Write(ex);
            _voiceRecording = false;
            _voiceRecordTimer?.Stop();
            (_voiceRecorder as IDisposable)?.Dispose(); _voiceRecorder = null;
            if (!string.IsNullOrWhiteSpace(_voiceRecordingPath)) MijnGevoel.Core.Data.VaultStore.SecureDelete(_voiceRecordingPath);
            _voiceRecordingPath = null;
            if (_voiceRecordButton is not null) _voiceRecordButton.Text = "🎙 Spraakbericht opnemen (max. 60 seconden)";
            if (_voiceRecordStatus is not null) _voiceRecordStatus.Text = "Opnemen lukte niet. Je kunt ook een tekstnotitie maken.";
        }
    }

    async Task StopVoiceRecordingAsync(bool save)
    {
        if (!_voiceRecording || _stoppingVoiceRecording || _voiceRecorder is null) return;
        _stoppingVoiceRecording = true;
        _voiceRecordTimer?.Stop();
        string? temporaryPath = _voiceRecordingPath;
        try
        {
            await _voiceRecorder.StopAsync();
            _voiceRecording = false;
            if (save && !string.IsNullOrWhiteSpace(temporaryPath) && File.Exists(temporaryPath))
            {
                var audioBytes = await File.ReadAllBytesAsync(temporaryPath);
                if (audioBytes.Length > 0)
                {
                    var entry = new VoiceNoteEntry(Guid.NewGuid(), DateTime.Now, _voiceContext, audioBytes);
                    Store.Save("voice-note", entry.Id, entry); // VaultStore versleutelt het volledige audiobestand.
                    System.Security.Cryptography.CryptographicOperations.ZeroMemory(audioBytes);
                    if (_voiceRecordStatus is not null) _voiceRecordStatus.Text = "Spraakbericht veilig opgeslagen ✔";
                    ReloadVoiceNotes();
                }
                else if (_voiceRecordStatus is not null) _voiceRecordStatus.Text = "Er is geen geluid opgenomen. Probeer het nog een keer.";
            }
            else if (_voiceRecordStatus is not null) _voiceRecordStatus.Text = save ? "De opname is niet opgeslagen." : "Opname geannuleerd.";
        }
        catch (Exception ex)
        {
            AppLog.Write(ex);
            if (_voiceRecordStatus is not null) _voiceRecordStatus.Text = "De opname kon niet veilig worden opgeslagen. Je kunt ook typen.";
        }
        finally
        {
            if (!string.IsNullOrWhiteSpace(temporaryPath)) MijnGevoel.Core.Data.VaultStore.SecureDelete(temporaryPath);
            (_voiceRecorder as IDisposable)?.Dispose();
            _voiceRecorder = null;
            _voiceRecording = false;
            _voiceRecordingPath = null;
            _stoppingVoiceRecording = false;
            if (_voiceRecordButton is not null) _voiceRecordButton.Text = "🎙 Spraakbericht opnemen (max. 60 seconden)";
        }
    }

    void ReloadVoiceNotes()
    {
        if (_voiceNoteList is null || AppSession.Store is null) return;
        _voiceNoteList.Children.Clear();
        var entries = Store.All<VoiceNoteEntry>("voice-note")
            .Where(x => x.Context == _voiceContext)
            .OrderByDescending(x => x.Created).ToList();
        if (entries.Count == 0)
        {
            _voiceNoteList.Children.Add(AppUi.Label("Nog geen spraakberichten.", muted: true));
            return;
        }
        foreach (var entry in entries)
        {
            var row = new Grid
            {
                ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) },
                ColumnSpacing = 6
            };
            var playButton = AppUi.AsyncButton($"▶ Afspelen · {entry.Created:dd-MM HH:mm}", async () => await PlayVoiceNoteAsync(entry), quiet: true);
            var deleteButton = AppUi.AsyncButton("🗑", async () =>
            {
                if (await DisplayAlertAsync("Spraakbericht verwijderen?", "Dit bericht wordt definitief van deze telefoon verwijderd.", "Verwijderen", "Annuleren"))
                {
                    Store.Delete("voice-note", entry.Id);
                    System.Security.Cryptography.CryptographicOperations.ZeroMemory(entry.AudioData);
                    ReloadVoiceNotes();
                }
            }, quiet: true, danger: true);
            row.Add(playButton, 0, 0);
            row.Add(deleteButton, 1, 0);
            _voiceNoteList.Children.Add(row);
        }
    }

    async Task PlayVoiceNoteAsync(VoiceNoteEntry entry)
    {
        try
        {
            StopVoicePlayback();
            _voicePlaybackStream = new MemoryStream(entry.AudioData, writable: false);
            _voicePlayer = AudioManager.Current.CreatePlayer(_voicePlaybackStream);
            _voicePlayer.Play();
            AppSession.Touch();
            await Task.CompletedTask;
        }
        catch (Exception ex)
        {
            AppLog.Write(ex);
            await DisplayAlertAsync("Afspelen niet gelukt", "Dit spraakbericht kon niet worden afgespeeld.", "OK");
            StopVoicePlayback();
        }
    }

    void StopVoicePlayback()
    {
        try { _voicePlayer?.Stop(); } catch { }
        try { (_voicePlayer as IDisposable)?.Dispose(); } catch { }
        _voicePlayer = null;
        try { _voicePlaybackStream?.Dispose(); } catch { }
        _voicePlaybackStream = null;
    }

    // ---------- Dag en agenda ----------
    void BuildAgenda()
    {
        Header("Agenda", "Plan afspraken en activiteiten. Je kunt afspraken aanpassen, verplaatsen of verwijderen.");
        var date = new DatePicker { Date = DateTime.Today, FontSize = AppUi.BaseFont, TextColor = AppUi.Foreground, BackgroundColor = AppUi.Surface };
        var title = AppUi.Entry("Wat ga je doen?");
        var time = AppUi.Entry("Hoe laat? Bijvoorbeeld 14:30 (mag leeg blijven)", keyboard: Keyboard.Text);
        var location = AppUi.Entry("Waar? (optioneel)"); location.MaxLength = 250;
        var note = AppUi.Editor("Notitie over deze activiteit (optioneel)", height: 80); note.MaxLength = 1000;
        var iconPicker = AppUi.Picker("Plaatje kiezen", AgendaIcons.Select(x => x.Emoji + " " + x.Name), "⭐ Anders");
        var status = AppUi.Label("");
        var list = new VerticalStackLayout { Spacing = 6 };
        Guid? editingId = null;
        Button? saveButton = null;
        Button? cancelEditButton = null;

        void Reload()
        {
            list.Children.Clear();
            var selectedDay = (date.Date ?? DateTime.Today).Date;
            var items = Store.All<AgendaItem>("agenda").Where(a => a.Date.Date == selectedDay).OrderBy(a => a.Time.Length == 0 ? "99:99" : a.Time).ToList();
            if (items.Count == 0) list.Children.Add(AppUi.Label("Niets gepland voor deze dag. Voeg een activiteit toe wanneer je daar klaar voor bent.", muted: true));
            foreach (var item in items)
            {
                var row = new VerticalStackLayout { Spacing = 4 };
                row.Children.Add(AppUi.Label($"{item.Icon} {(item.Time.Length > 0 ? item.Time + "  " : "")}{item.Title}", title: true));
                row.Children.Add(AppUi.Label("Status: " + item.CurrentStatus, muted: true));
                if (!string.IsNullOrWhiteSpace(item.Location)) row.Children.Add(AppUi.Label("📍 " + item.Location));
                if (!string.IsNullOrWhiteSpace(item.Note)) row.Children.Add(AppUi.Label("Notitie: " + item.Note));
                if (!string.IsNullOrWhiteSpace(item.ChangeSummary)) row.Children.Add(AppUi.Label("Wat is gewijzigd: " + item.ChangeSummary, muted: true));

                var statePicker = AppUi.Picker("Status van deze activiteit", AgendaStatusService.Statuses, item.CurrentStatus);
                statePicker.SelectedIndexChanged += (_, _) =>
                {
                    if (statePicker.SelectedItem?.ToString() is not string selectedStatus) return;
                    Store.Save("agenda", item.Id, AgendaStatusService.WithStatus(item, selectedStatus));
                    AppSession.Touch();
                    Reload();
                };
                row.Children.Add(statePicker);
                var actions = new VerticalStackLayout { Spacing = 2 };
                actions.Children.Add(AppUi.Button("✏️ Aanpassen", () =>
                {
                    editingId = item.Id;
                    date.Date = item.Date.Date;
                    title.Text = item.Title;
                    time.Text = item.Time;
                    location.Text = item.Location;
                    note.Text = item.Note;
                    var iconIndex = Array.FindIndex(AgendaIcons, x => x.Emoji == item.Icon);
                    iconPicker.SelectedIndex = iconIndex >= 0 ? iconIndex : AgendaIcons.Length - 1;
                    if (saveButton is not null) saveButton.Text = "💾 Wijzigingen opslaan";
                    if (cancelEditButton is not null) cancelEditButton.IsVisible = true;
                    status.Text = "Je past nu deze afspraak aan. Veranderingen in datum of inhoud worden bewaard bij de afspraak.";
                    Reload();
                }, quiet: true));
                actions.Children.Add(AppUi.Button("🗑 Verwijderen", async () =>
                {
                    if (await DisplayAlertAsync("Verwijderen?", "Deze afspraak weghalen?", "Verwijderen", "Annuleren"))
                    {
                        Store.Delete("agenda", item.Id);
                        if (editingId == item.Id) ResetEditor();
                        Reload();
                    }
                }, quiet: true));
                row.Children.Add(actions);
                list.Children.Add(AppUi.Card(row));
            }
        }

        void ResetEditor()
        {
            editingId = null;
            title.Text = "";
            time.Text = "";
            location.Text = "";
            note.Text = "";
            iconPicker.SelectedIndex = Math.Max(0, AgendaIcons.Length - 1);
            if (saveButton is not null) saveButton.Text = "➕ Toevoegen";
            if (cancelEditButton is not null) cancelEditButton.IsVisible = false;
            status.Text = "";
        }

        date.DateSelected += (_, _) => Reload();
        AddField("Dag", date); AddField("Activiteit", title); AddField("Tijd", time); AddField("Locatie", location); AddField("Notitie", note); AddField("Plaatje", iconPicker);
        saveButton = AppUi.AsyncButton("➕ Toevoegen", async () =>
        {
            var t = title.Text?.Trim() ?? "";
            if (t.Length == 0) { status.Text = "Schrijf eerst op wat je gaat doen."; return; }
            if (t.Length > 160) { status.Text = "Gebruik maximaal 160 tekens voor de naam."; return; }
            string timeText = (time.Text ?? "").Trim().Replace('.', ':');
            if (timeText.Length > 0 && !TimeOnly.TryParse(timeText, CultureInfo.InvariantCulture, DateTimeStyles.None, out _)) { status.Text = "Gebruik bijvoorbeeld 14:30 als tijd."; return; }
            if (timeText.Length > 5) { status.Text = "Gebruik een tijd in het formaat UU:MM."; return; }
            var locationText = (location.Text ?? "").Trim();
            var noteText = (note.Text ?? "").Trim();
            if (locationText.Length > 250 || noteText.Length > 1000) { status.Text = "De locatie of notitie is te lang."; return; }
            AgendaItem? old = editingId is Guid currentId ? Store.Load<AgendaItem>("agenda", currentId) : null;
            if (editingId is not null && old is null) { status.Text = "Deze afspraak bestaat niet meer. Kies een afspraak uit de lijst."; ResetEditor(); return; }
            var icon = AgendaIcons[Math.Clamp(iconPicker.SelectedIndex, 0, AgendaIcons.Length - 1)].Emoji;
            var id = old?.Id ?? Guid.NewGuid();
            var candidate = new AgendaItem(id, (date.Date ?? DateTime.Today).Date, timeText, t, icon, old?.Done ?? false, old?.CurrentStatus ?? "Gepland")
            {
                Location = locationText,
                Note = noteText,
                ChangeSummary = old?.ChangeSummary ?? ""
            };
            var changes = AgendaChangeService.DescribeChanges(old, candidate);
            string savedStatus;
            string changeSummary = candidate.ChangeSummary;
            bool done;
            if (old is null)
            {
                savedStatus = "Gepland"; done = false; changeSummary = "";
            }
            else if (changes.Length > 0)
            {
                savedStatus = "Gewijzigd"; done = false; changeSummary = string.Join("; ", changes);
            }
            else
            {
                savedStatus = old.CurrentStatus; done = savedStatus == "Afgerond";
            }
            var saved = candidate with { Status = savedStatus, Done = done, ChangeSummary = changeSummary };
            Store.Save("agenda", id, saved);
            AppSession.Touch();
            var confirmation = old is null ? "Toegevoegd ✔" : changes.Length > 0 ? "Wijzigingen opgeslagen ✔ · " + changeSummary : "Afspraak ongewijzigd opgeslagen ✔";
            ResetEditor();
            status.Text = confirmation;
            Reload();
            await Task.CompletedTask;
        });
        Add(saveButton);
        cancelEditButton = AppUi.Button("Annuleren", ResetEditor, quiet: true);
        cancelEditButton.IsVisible = false;
        Add(cancelEditButton);
        Add(status); AddLabel("Activiteiten op deze dag", title: true); Add(list); Reload();
    }

    void BuildDay(DateTime day)
    {
        Header(day.Date == DateTime.Today ? "Vandaag" : "Morgen bekijken", "Eerst-dan overzicht. Je kunt alvast zien wat er op de planning staat.");
        var items = Store.All<AgendaItem>("agenda").Where(a => a.Date.Date == day.Date).OrderBy(a => a.Time.Length == 0 ? "99:99" : a.Time).ToList();
        AddLabel(day.ToString("dddd d MMMM yyyy", CultureInfo.GetCultureInfo("nl-NL")), title: true);
        var next = items.FirstOrDefault(AgendaStatusService.IsActive);
        string firstLabel = next is null
            ? "Er staat geen volgende activiteit gepland."
            : $"{next.Icon} {(next.Time.Length > 0 ? next.Time + "  " : "")}{next.Title}";
        var second = next is null ? null : items.FirstOrDefault(x => AgendaStatusService.IsActive(x) && x.Id != next.Id);
        string secondLabel = second is null
            ? "Je volgende stap verschijnt hier als je agenda is ingevuld."
            : $"{second.Icon} {second.Title}";
        Add(AppUi.Card(new VerticalStackLayout { Children = {
            AppUi.Label("Eerst", title: true), AppUi.Label(firstLabel),
            AppUi.Label("Daarna", title: true), AppUi.Label(secondLabel)
        } }));
        foreach (var item in items)
        {
            var statePicker = AppUi.Picker("Status", AgendaStatusService.Statuses, item.CurrentStatus);
            statePicker.SelectedIndexChanged += (_, _) =>
            {
                if (statePicker.SelectedItem?.ToString() is not string selectedStatus) return;
                Store.Save("agenda", item.Id, AgendaStatusService.WithStatus(item, selectedStatus));
                AppSession.Touch();
                Build();
            };
            var activityCard = AppUi.Stack(
                AppUi.Label($"{item.Icon} {(item.Time.Length > 0 ? item.Time + "  " : "")}{item.Title}", title: true),
                statePicker);
            if (!string.IsNullOrWhiteSpace(item.Location)) activityCard.Children.Add(AppUi.Label("📍 " + item.Location));
            if (!string.IsNullOrWhiteSpace(item.Note)) activityCard.Children.Add(AppUi.Label("Notitie: " + item.Note));
            if (!string.IsNullOrWhiteSpace(item.ChangeSummary)) activityCard.Children.Add(AppUi.Label("Wat is gewijzigd: " + item.ChangeSummary, muted: true));
            Add(AppUi.Card(activityCard));
        }
        AddButton("📅 Agenda openen", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Agenda)));
        AddButton("✅ Stappenplannen", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Routines)), quiet: true);
        AddButton("⏳ Timer", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Timer)), quiet: true);
    }

    // ---------- Stappenplannen ----------
    void SeedRoutines()
    {
        if (AppSession.Settings.RoutinesSeeded) return;
        foreach (var r in new[]
        {
            new Routine(Guid.NewGuid(), "Ochtend", "☀️", new[] { "Opstaan", "Naar de wc", "Gezicht wassen", "Tanden poetsen", "Aankleden", "Ontbijten" }),
            new Routine(Guid.NewGuid(), "Tanden poetsen", "🦷", new[] { "Tandpasta op de tandenborstel", "Boven poetsen", "Onder poetsen", "Tong poetsen", "Mond spoelen" }),
            new Routine(Guid.NewGuid(), "Avond", "🌙", new[] { "Tas voor morgen klaarzetten", "Tanden poetsen", "Pyjama aan", "Licht uit" })
        }) Store.Save("routine", r.Id, r);
        AppSession.Settings.RoutinesSeeded = true; AppSession.SaveSettings();
    }

    void BuildRoutines()
    {
        SeedRoutines();
        Header("Stappenplannen", "Doe iets stap voor stap. Je kunt bestaande plannen aanpassen of je eigen plan maken.");
        AddButton("📥 Voorstel van ouder / begeleider ontvangen", () => Navigation.PushAsync(new ReceiveSupportPackagePage()), quiet: true);
        var list = new VerticalStackLayout { Spacing = 6 };
        void Reload()
        {
            list.Children.Clear();
            foreach (var r in Store.All<Routine>("routine").OrderBy(x => x.Title))
            {
                var routine = r;
                var editDeleteGrid = new Grid
                {
                    ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) },
                    ColumnSpacing = 6
                };
                editDeleteGrid.Add(AppUi.Button("✏️ Aanpassen", () => FillRoutineEditor(routine), quiet: true), 0, 0);
                editDeleteGrid.Add(AppUi.Button("🗑", async () =>
                {
                    if (await DisplayAlertAsync("Verwijderen?", "Dit stappenplan weggooien?", "Verwijderen", "Annuleren"))
                    {
                        Store.Delete("routine", routine.Id);
                        Store.Delete("routinerunprogress", routine.Id);
                        Reload();
                    }
                }, quiet: true), 1, 0);
                var row = new VerticalStackLayout
                {
                    Spacing = 4,
                    Children =
                    {
                        AppUi.AsyncButton($"{routine.Icon} {routine.Title} ({routine.Steps.Length} stappen)", async () =>
                        {
                            if (routine.Steps is null || routine.Steps.Length == 0)
                            {
                                await DisplayAlertAsync("Stappenplan niet beschikbaar", "Dit stappenplan bevat nog geen stappen. Pas het eerst aan.", "OK");
                                return;
                            }
                            _runningRoutine = routine;
                            var progress = Store.Load<RoutineRunProgress>("routinerunprogress", routine.Id);
                            _routineStep = RoutineRunProgressService.ResumeStep(progress, routine.Steps.Length);
                            SaveRoutineRunProgress(routine, _routineStep);
                            ShowRoutineRun();
                        }),
                        editDeleteGrid
                    }
                };
                list.Children.Add(AppUi.Card(row));
            }
        }
        Add(list); Reload();
        AddLabel("Stappenplan maken of aanpassen", title: true);
        _routineName = AppUi.Entry("Naam van het stappenplan"); _routineName.MaxLength = RoutineDefinitionService.MaximumTitleLength;
        _routineIcon = AppUi.Entry("Emoji (bijvoorbeeld ✅", "📝"); _routineIcon.MaxLength = RoutineDefinitionService.MaximumIconLength;
        _routineSteps = AppUi.Editor("Elke stap op een nieuwe regel", height: 140); _routineSteps.MaxLength = RoutineDefinitionService.MaximumTotalStepCharacters;
        AddField("Naam", _routineName); AddField("Plaatje", _routineIcon); AddField("Stappen", _routineSteps);
        AddAsyncButton("💾 Stappenplan bewaren", async () =>
        {
            var wasEditing = _editingRoutineId is not null;
            Routine r;
            try
            {
                r = RoutineDefinitionService.Create(_editingRoutineId ?? Guid.NewGuid(), _routineName.Text, _routineIcon.Text, _routineSteps.Text);
            }
            catch (ArgumentException ex)
            {
                await DisplayAlertAsync("Controleer je stappenplan", ex.Message, "OK");
                return;
            }
            Store.Save("routine", r.Id, r);
            if (wasEditing) Store.Delete("routinerunprogress", r.Id); // gewijzigde stappen beginnen met schone voortgang
            _editingRoutineId = null; _routineName.Text = ""; _routineIcon.Text = "📝"; _routineSteps.Text = ""; Reload();
        });
    }

    void FillRoutineEditor(Routine r)
    {
        _editingRoutineId = r.Id;
        if (_routineName is not null) _routineName.Text = r.Title;
        if (_routineIcon is not null) _routineIcon.Text = r.Icon;
        if (_routineSteps is not null) _routineSteps.Text = string.Join("\n", r.Steps);
    }

    void SaveRoutineRunProgress(Routine routine, int step, bool completed = false)
    {
        var progress = completed
            ? RoutineRunProgressService.Complete(routine.Id, step, routine.Steps.Length, DateTime.Now)
            : RoutineRunProgressService.AtStep(routine.Id, step, routine.Steps.Length, DateTime.Now);
        Store.Save("routinerunprogress", routine.Id, progress);
    }

    void ShowRoutineRun()
    {
        var routine = _runningRoutine;
        if (routine is null) return;
        if (routine.Steps is null || routine.Steps.Length == 0)
        {
            _runningRoutine = null;
            Build();
            return;
        }
        _routineStep = Math.Clamp(_routineStep, 0, routine.Steps.Length - 1);
        SaveRoutineRunProgress(routine, _routineStep);
        _root.Children.Clear();
        Header($"{routine.Icon} {routine.Title}", $"Stap {_routineStep + 1} van {routine.Steps.Length}");
        Add(AppUi.Card(new VerticalStackLayout { VerticalOptions = LayoutOptions.Center, MinimumHeightRequest = 190, Children = {
            AppUi.Label(routine.Steps[_routineStep], title: true)
        } }));
        var buttons = new Grid
        {
            ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) },
            ColumnSpacing = 8
        };
        buttons.Add(AppUi.Button("← Vorige", () =>
        {
            if (_routineStep > 0)
            {
                _routineStep--;
                SaveRoutineRunProgress(routine, _routineStep);
                ShowRoutineRun();
            }
        }, quiet: true), 0, 0);
        buttons.Add(AppUi.Button(_routineStep == routine.Steps.Length - 1 ? "Klaar ✔" : "Volgende →", async () =>
        {
            if (_routineStep >= routine.Steps.Length - 1)
            {
                SaveRoutineRunProgress(routine, _routineStep, completed: true);
                await DisplayAlertAsync("Goed gedaan", "Je hebt alle stappen gedaan.", "Klaar");
                _runningRoutine = null;
                _routineStep = 0;
                Build();
            }
            else
            {
                _routineStep++;
                SaveRoutineRunProgress(routine, _routineStep);
                ShowRoutineRun();
            }
        }), 1, 0);
        Add(buttons);
        AddButton("Stoppen en terug", () =>
        {
            SaveRoutineRunProgress(routine, _routineStep);
            _runningRoutine = null;
            Build();
        }, quiet: true);
    }

    // ---------- Routines en meldingen ----------
    static readonly (string Icon, string Name)[] ReminderIcons =
    {
        ("💊", "Medicatie"), ("🛏️", "Naar bed"), ("🪥", "Tanden poetsen"), ("🚿", "Douchen"),
        ("🍽️", "Eten"), ("🚌", "Naar werk"), ("👕", "Aankleden"), ("🥣", "Ontbijten"),
        ("💧", "Water drinken"), ("🧹", "Opruimen"), ("🧘", "Rust nemen"), ("🐕", "Hond uitlaten"),
        ("🧴", "Verzorging"), ("👜", "Tas klaarzetten"), ("🏠", "Thuiskomen"), ("⭐", "Anders")
    };
    static readonly (string Title, string Icon)[] ReminderTemplates =
    {
        ("Medicatie innemen", "💊"), ("Nu naar bed", "🛏️"), ("Tanden poetsen", "🪥"),
        ("Douchen", "🚿"), ("Ontbijten", "🥣"), ("Naar mijn werk gaan", "🚌"),
        ("Aankleden", "👕"), ("Eten", "🍽️"), ("Water drinken", "💧"),
        ("Even pauze nemen", "🧘"), ("Tas klaarzetten", "👜"), ("Hond uitlaten", "🐕"),
        ("Thuiskomen", "🏠"), ("Opruimen", "🧹"), ("Gezicht wassen", "🧴"), ("Eigen routine", "⭐")
    };
    static readonly DayOfWeek[] ReminderDays =
    {
        DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday,
        DayOfWeek.Friday, DayOfWeek.Saturday, DayOfWeek.Sunday
    };
    static readonly string[] ReminderDayLabels = { "Ma", "Di", "Wo", "Do", "Vr", "Za", "Zo" };

    void BuildRoutineReminders()
    {
        Header("Routines en herinneringen", "Stel vaste momenten in voor dingen die je wilt onthouden. Je telefoon kan je op de gekozen dagen een melding met geluid geven.");
        AddLabel("Voorbeelden: medicatie innemen, tanden poetsen, naar bed gaan, naar werk vertrekken, eten, douchen of een eigen routine.");
        AddLabel("Let op: een melding helpt je herinneren, maar controleert niet of iets echt is gedaan. Vertrouw voor belangrijke medicatie niet alleen op deze app.", muted: true);

        var list = new VerticalStackLayout { Spacing = 8 };
        var name = AppUi.Entry("Bijvoorbeeld: medicatie innemen");
        var template = AppUi.Picker("Kies een voorbeeld om snel te beginnen", new[] { "Kies een voorbeeld" }.Concat(ReminderTemplates.Select(x => x.Icon + " " + x.Title)), "Kies een voorbeeld");
        var iconPicker = AppUi.Picker("Kies een picto", ReminderIcons.Select(x => x.Icon + "  " + x.Name), "💊  Medicatie");
        var timePicker = new TimePicker { Time = new TimeSpan(8, 0, 0), FontSize = AppUi.BaseFont, TextColor = AppUi.Foreground, BackgroundColor = AppUi.Surface, HorizontalOptions = LayoutOptions.Fill };
        var enabledSwitch = new Switch { IsToggled = true, OnColor = AppUi.Accent, HorizontalOptions = LayoutOptions.Start };
        var soundSwitch = new Switch { IsToggled = true, OnColor = AppUi.Accent, HorizontalOptions = LayoutOptions.Start };
        var pictoPreview = new Image { WidthRequest = 78, HeightRequest = 78, Aspect = Aspect.AspectFit, IsVisible = false, HorizontalOptions = LayoutOptions.Start };
        string? customPicto = null;
        Guid? editingId = null;
        var days = new Dictionary<DayOfWeek, CheckBox>();
        // Use a Grid rather than FlexLayout so the week selector works on all supported MAUI targets.
        var daysLayout = new Grid { ColumnSpacing = 8, RowSpacing = 2 };
        for (int column = 0; column < 4; column++) daysLayout.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Auto));
        for (int row = 0; row < 2; row++) daysLayout.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
        for (int i = 0; i < ReminderDays.Length; i++)
        {
            var day = ReminderDays[i];
            var check = new CheckBox { IsChecked = true, Color = AppUi.Accent, VerticalOptions = LayoutOptions.Center };
            days[day] = check;
            var dayItem = new HorizontalStackLayout { Spacing = 2, Margin = new Thickness(0, 0, 8, 0), Children = { check, AppUi.Label(ReminderDayLabels[i]) } };
            Grid.SetColumn(dayItem, i % 4);
            Grid.SetRow(dayItem, i / 4);
            daysLayout.Children.Add(dayItem);
        }
        var status = AppUi.Label("");
        Button saveButton = null!;
        saveButton = AppUi.Button("💾 Routine bewaren", async () =>
        {
            var title = (name.Text ?? "").Trim();
            var selectedDays = days.Where(x => x.Value.IsChecked).Aggregate(0, (mask, entry) => mask | (1 << (int)entry.Key));
            if (title.Length == 0) { status.Text = "Vul eerst een naam in."; return; }
            if (selectedDays == 0) { status.Text = "Kies minstens één dag."; return; }
            bool notificationPermission = true;
            if (enabledSwitch.IsToggled)
                notificationPermission = await RoutineReminderNotifications.EnsurePermissionAsync();
            var icon = ReminderIcons[Math.Clamp(iconPicker.SelectedIndex, 0, ReminderIcons.Length - 1)].Icon;
            var selectedTime = timePicker.Time is TimeSpan pickedTime ? pickedTime : new TimeSpan(8, 0, 0);
            var timeText = selectedTime.ToString(@"hh\:mm", CultureInfo.InvariantCulture);
            var reminder = new RoutineReminder(editingId ?? Guid.NewGuid(), title, icon, timeText, selectedDays, enabledSwitch.IsToggled, customPicto, soundSwitch.IsToggled);
            Store.Save("routinereminder", reminder.Id, reminder);
            RoutineReminderNotifications.Sync(Android.App.Application.Context, Store.All<RoutineReminder>("routinereminder"));
            editingId = null;
            name.Text = ""; template.SelectedIndex = 0; iconPicker.SelectedIndex = 0; timePicker.Time = new TimeSpan(8, 0, 0);
            enabledSwitch.IsToggled = true; soundSwitch.IsToggled = true; customPicto = null; pictoPreview.Source = null; pictoPreview.IsVisible = false;
            foreach (var box in days.Values) box.IsChecked = true;
            saveButton.Text = "💾 Routine bewaren";
            status.Text = notificationPermission
                ? "Routine opgeslagen. Je telefoon kan je op de gekozen dagen herinneren ✔"
                : "Routine opgeslagen, maar meldingen zijn niet toegestaan. Zet meldingen aan in de Android-instellingen van MoodPress.";
            Reload();
        });

        template.SelectedIndexChanged += (_, _) =>
        {
            var index = template.SelectedIndex - 1;
            if (index < 0 || index >= ReminderTemplates.Length) return;
            name.Text = ReminderTemplates[index].Title;
            var pickIndex = Array.FindIndex(ReminderIcons, x => x.Icon == ReminderTemplates[index].Icon);
            if (pickIndex >= 0) iconPicker.SelectedIndex = pickIndex;
        };

        async Task PickCustomPictoAsync()
        {
            var picked = await FilePicker.Default.PickAsync(new PickOptions { PickerTitle = "Kies een eigen picto of afbeelding", FileTypes = FilePickerFileType.Images });
            if (picked is null) return;
            await using var input = await picked.OpenReadAsync();
            using var memory = new MemoryStream();
            await input.CopyToAsync(memory);
            if (memory.Length > 8 * 1024 * 1024) { await DisplayAlertAsync("Afbeelding te groot", "Kies een afbeelding kleiner dan 8 MB.", "OK"); return; }
            using var original = SKBitmap.Decode(memory.ToArray());
            if (original is null || original.Width < 1 || original.Height < 1) { await DisplayAlertAsync("Afbeelding niet gelezen", "Kies een JPG-, PNG- of WebP-afbeelding.", "OK"); return; }
            using var square = new SKBitmap(new SKImageInfo(96, 96, SKColorType.Rgba8888, SKAlphaType.Premul));
            using (var canvas = new SKCanvas(square))
            {
                canvas.Clear(SKColors.White);
                float scale = Math.Min(88f / original.Width, 88f / original.Height);
                float width = original.Width * scale, height = original.Height * scale;
                var dest = new SKRect((96 - width) / 2, (96 - height) / 2, (96 + width) / 2, (96 + height) / 2);
                canvas.DrawBitmap(original, dest);
            }
            using var image = SKImage.FromBitmap(square);
            using var encoded = image.Encode(SKEncodedImageFormat.Jpeg, 65);
            if (encoded is null) { await DisplayAlertAsync("Niet gelukt", "Deze afbeelding kon niet worden verwerkt.", "OK"); return; }
            customPicto = Convert.ToBase64String(encoded.ToArray());
            var previewImageData = customPicto;
            pictoPreview.Source = ImageSource.FromStream(() => new MemoryStream(Convert.FromBase64String(previewImageData!)));
            pictoPreview.IsVisible = true;
            status.Text = "Eigen picto toegevoegd. Deze wordt lokaal en versleuteld bewaard.";
        }

        async Task FillEditorAsync(RoutineReminder item)
        {
            editingId = item.Id;
            name.Text = item.Title;
            timePicker.Time = TimeOnly.TryParse(item.Time, CultureInfo.InvariantCulture, out var t) ? t.ToTimeSpan() : new TimeSpan(8, 0, 0);
            int iconIndex = Array.FindIndex(ReminderIcons, x => x.Icon == item.Icon);
            iconPicker.SelectedIndex = iconIndex >= 0 ? iconIndex : ReminderIcons.Length - 1;
            enabledSwitch.IsToggled = item.Enabled; soundSwitch.IsToggled = item.SoundEnabled;
            foreach (var day in ReminderDays) days[day].IsChecked = (item.DaysMask & (1 << (int)day)) != 0;
            customPicto = item.PictureBase64;
            var previewImageData = customPicto;
            pictoPreview.Source = string.IsNullOrWhiteSpace(previewImageData) ? null : ImageSource.FromStream(() => new MemoryStream(Convert.FromBase64String(previewImageData!)));
            pictoPreview.IsVisible = !string.IsNullOrWhiteSpace(customPicto);
            template.SelectedIndex = 0;
            saveButton.Text = "💾 Wijzigingen bewaren";
            name.Focus();
            await Task.CompletedTask;
        }

        void Reload()
        {
            list.Children.Clear();
            var items = Store.All<RoutineReminder>("routinereminder").OrderBy(x => x.Time).ThenBy(x => x.Title).ToList();
            if (items.Count == 0) list.Children.Add(AppUi.Card(AppUi.Label("Je hebt nog geen routines. Kies hieronder een voorbeeld of maak je eigen routine.")));
            foreach (var item in items)
            {
                var reminder = item;
                var chosenDays = ReminderDays.Select((day, index) => (day, index)).Where(x => (reminder.DaysMask & (1 << (int)x.day)) != 0).Select(x => ReminderDayLabels[x.index]).ToArray();
                var visual = new Grid
                {
                    ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star) },
                    ColumnSpacing = 10,
                    VerticalOptions = LayoutOptions.Center
                };
                View pictoView;
                if (!string.IsNullOrWhiteSpace(reminder.PictureBase64))
                {
                    var itemPictureData = reminder.PictureBase64;
                    pictoView = new Image { Source = ImageSource.FromStream(() => new MemoryStream(Convert.FromBase64String(itemPictureData!))), WidthRequest = 52, HeightRequest = 52, Aspect = Aspect.AspectFit, VerticalOptions = LayoutOptions.Center };
                }
                else
                    pictoView = AppUi.Label(reminder.Icon, title: true);
                var details = new VerticalStackLayout { Spacing = 2, VerticalOptions = LayoutOptions.Center, HorizontalOptions = LayoutOptions.Fill };
                details.Children.Add(AppUi.Label(reminder.Title, title: true));
                details.Children.Add(AppUi.Label($"{reminder.Time}  ·  {string.Join(", ", chosenDays)}", muted: true));
                details.Children.Add(AppUi.Label(reminder.Enabled ? (reminder.SoundEnabled ? "🔔 Melding met geluid aan" : "🔕 Melding zonder geluid") : "⏸️ Melding uit", muted: true));
                visual.Add(pictoView, 0, 0);
                visual.Add(details, 1, 0);
                var actions = new Grid
                {
                    ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) },
                    ColumnSpacing = 6
                };
                actions.Add(AppUi.Button("✏️ Wijzigen", async () => await FillEditorAsync(reminder), quiet: true), 0, 0);
                actions.Add(AppUi.Button(reminder.Enabled ? "⏸ Uit" : "▶ Aan", async () =>
                {
                    Store.Save("routinereminder", reminder.Id, reminder with { Enabled = !reminder.Enabled });
                    RoutineReminderNotifications.Sync(Android.App.Application.Context, Store.All<RoutineReminder>("routinereminder"));
                    Reload();
                    await Task.CompletedTask;
                }, quiet: true), 1, 0);
                actions.Add(AppUi.Button("🗑 Weg", async () =>
                {
                    if (!await DisplayAlertAsync("Routine verwijderen?", $"Wil je '{reminder.Title}' en de bijbehorende herinnering verwijderen?", "Verwijderen", "Annuleren")) return;
                    Store.Delete("routinereminder", reminder.Id);
                    RoutineReminderNotifications.Sync(Android.App.Application.Context, Store.All<RoutineReminder>("routinereminder"));
                    if (editingId == reminder.Id) { editingId = null; name.Text = ""; customPicto = null; pictoPreview.Source = null; pictoPreview.IsVisible = false; saveButton.Text = "💾 Routine bewaren"; }
                    Reload();
                }, quiet: true), 2, 0);
                list.Children.Add(AppUi.Card(new VerticalStackLayout { Spacing = 8, Children = { visual, actions } }));
            }
        }

        Add(list);
        AddLabel("Nieuwe routine maken of aanpassen", title: true);
        AddField("Voorbeeld (optioneel)", template);
        AddField("Naam van de routine", name);
        AddField("Picto kiezen", iconPicker);
        AddAsyncButton("🖼️ Eigen picto of afbeelding kiezen", PickCustomPictoAsync, quiet: true);
        AddAsyncButton("🧹 Eigen picto verwijderen", () =>
        {
            customPicto = null;
            pictoPreview.Source = null;
            pictoPreview.IsVisible = false;
            status.Text = "Eigen afbeelding verwijderd. De gekozen emoji-picto wordt gebruikt.";
            return Task.CompletedTask;
        }, quiet: true);
        Add(pictoPreview);
        AddField("Tijd van de melding", timePicker);
        AddLabel("Op welke dagen wil je een melding?", title: true);
        Add(daysLayout);
        Add(new HorizontalStackLayout { Spacing = 10, Children = { enabledSwitch, AppUi.Label("Herinnering actief") } });
        Add(new HorizontalStackLayout { Spacing = 10, Children = { soundSwitch, AppUi.Label("Melding met geluid") } });
        Add(saveButton); Add(status);
        AddLabel("Handig om te weten", title: true);
        AddLabel("Android kan een melding als pop-up tonen als meldingen zijn toegestaan en je meldingsinstellingen dit toelaten. Zet meldingen voor MoodPress op 'Waarschuwen' en geef toestemming voor meldingen. Geluid kan worden tegengehouden door stille modus of Niet storen.", muted: true);
        Reload();
    }

    // ---------- Timer, ademhalen, rustplek ----------
    void BuildTimer()
    {
        Header("Timer", "Gebruik een rustige timer voor een taak of pauze.");
        _timerState = Store.Load<TimerSessionState>("timer", Guid.Empty) ?? TimerSessionService.CreateIdle(300);
        var options = new[] { "1", "2", "3", "5", "10", "15", "20", "30" };
        var initialMinutes = options.Contains((_timerState.TotalSeconds / 60).ToString(CultureInfo.InvariantCulture))
            ? (_timerState.TotalSeconds / 60).ToString(CultureInfo.InvariantCulture) : "5";
        _timerMinutes = AppUi.Picker("Hoeveel minuten?", options, initialMinutes);
        _timerDisplay = AppUi.Title("05:00");
        _timerDisplay.HorizontalTextAlignment = TextAlignment.Center;
        _timerDisplay.FontSize = AppUi.TitleFont * 1.6;
        _timerStatus = AppUi.Label("Kies de tijd en druk op start.");
        AddField("Tijd", _timerMinutes);
        Add(_timerDisplay);
        Add(_timerStatus);
        AddLabel("Je timer blijft tijd bijhouden wanneer je naar een ander scherm gaat en vraagt Android om een melding wanneer de tijd om is. Android kan meldingen uitstellen of blokkeren door batterijinstellingen, Niet storen of ontbrekende meldingsrechten.", muted: true);
        RefreshTimerState(announceCompletion: true);

        AddAsyncButton("▶ Start / pauze", async () =>
        {
            if (_timerState is null) _timerState = TimerSessionService.CreateIdle(300);
            var now = DateTime.Now;
            var current = TimerSessionService.Reconcile(_timerState, now);
            _timerState = current.State;
            if (current.CompletedNow)
            {
                Store.Save("timer", Guid.Empty, _timerState);
                FocusTimerNotifications.Cancel(Android.App.Application.Context, clearNotification: false);
                _timer?.Stop();
                RenderTimer();
                if (_timerStatus is not null) _timerStatus.Text = "⏰ De tijd is om!";
                AppUi.Speak("De tijd is om.");
                return;
            }

            if (_timerState.IsRunning)
            {
                _timerState = TimerSessionService.Pause(_timerState, now);
                _timer?.Stop();
                FocusTimerNotifications.Cancel(Android.App.Application.Context);
                Store.Save("timer", Guid.Empty, _timerState);
                RenderTimer();
                if (_timerStatus is not null) _timerStatus.Text = _timerState.CompletedAt is not null ? "⏰ De tijd is om!" : "Gepauzeerd.";
                return;
            }

            var notificationsAllowed = await RoutineReminderNotifications.EnsurePermissionAsync();
            var selectedSeconds = int.Parse(_timerMinutes?.SelectedItem?.ToString() ?? "5", CultureInfo.InvariantCulture) * 60;
            _timerState = TimerSessionService.Start(_timerState, selectedSeconds, now);
            Store.Save("timer", Guid.Empty, _timerState);
            if (_timerState.EndsAt is DateTime endAt) FocusTimerNotifications.Schedule(Android.App.Application.Context, endAt);
            RefreshTimerState(announceCompletion: false);
            StartTimerTick();
            if (_timerStatus is not null) _timerStatus.Text = notificationsAllowed
                ? "De timer loopt. Je kunt naar een ander scherm gaan; Android probeert een melding te tonen als de tijd om is."
                : "De timer loopt. Meldingen zijn niet toegestaan; je ziet de eindtijd wanneer je terugkomt.";
        });
        AddButton("↻ Opnieuw", () =>
        {
            var selectedSeconds = int.Parse(_timerMinutes?.SelectedItem?.ToString() ?? "5", CultureInfo.InvariantCulture) * 60;
            _timerState = TimerSessionService.Reset(selectedSeconds);
            _timer?.Stop();
            FocusTimerNotifications.Cancel(Android.App.Application.Context);
            Store.Save("timer", Guid.Empty, _timerState);
            RenderTimer();
            if (_timerStatus is not null) _timerStatus.Text = "Klaar om te starten.";
        }, quiet: true);
    }

    void StartTimerTick()
    {
        if (_timerState?.IsRunning != true) return;
        if (_timer is null)
        {
            _timer = Dispatcher.CreateTimer();
            _timer.Interval = TimeSpan.FromSeconds(1);
            _timer.Tick += OnTimerTick;
        }
        if (!_timer.IsRunning) _timer.Start();
    }

    void OnTimerTick(object? sender, EventArgs e)
    {
        if (_timerState is null) { _timer?.Stop(); return; }
        var result = TimerSessionService.Reconcile(_timerState, DateTime.Now);
        _timerState = result.State;
        _timerRemaining = _timerState.RemainingSeconds;
        _timerTotal = _timerState.TotalSeconds;
        RenderTimer();
        if (result.CompletedNow)
        {
            Store.Save("timer", Guid.Empty, _timerState);
            FocusTimerNotifications.Cancel(Android.App.Application.Context, clearNotification: false);
            _timer?.Stop();
            if (_timerStatus is not null) _timerStatus.Text = "⏰ De tijd is om!";
            AppUi.Speak("De tijd is om.");
        }
        else if (!_timerState.IsRunning)
        {
            _timer?.Stop();
        }
    }

    void RefreshTimerState(bool announceCompletion)
    {
        if (_kind != FeatureKind.Timer) return;
        var saved = Store.Load<TimerSessionState>("timer", Guid.Empty) ?? TimerSessionService.CreateIdle(300);
        var result = TimerSessionService.Reconcile(saved, DateTime.Now);
        _timerState = result.State;
        _timerRemaining = _timerState.RemainingSeconds;
        _timerTotal = _timerState.TotalSeconds;
        if (saved != _timerState) Store.Save("timer", Guid.Empty, _timerState);
        if (_timerState.IsRunning && _timerState.EndsAt is DateTime endAt)
            FocusTimerNotifications.Schedule(Android.App.Application.Context, endAt);
        else if (_timerState.CompletedAt is not null)
            FocusTimerNotifications.Cancel(Android.App.Application.Context, clearNotification: false);
        RenderTimer();
        if (_timerStatus is not null)
        {
            if (result.CompletedNow || _timerState.CompletedAt is not null) _timerStatus.Text = "⏰ De tijd is om!";
            else if (_timerState.IsRunning) _timerStatus.Text = "De timer loopt. Je kunt naar een ander scherm gaan.";
            else if (_timerState.RemainingSeconds < _timerState.TotalSeconds) _timerStatus.Text = "Gepauzeerd.";
            else _timerStatus.Text = "Kies de tijd en druk op start.";
        }
        if (result.CompletedNow && announceCompletion) AppUi.Speak("De tijd is om.");
    }

    void RenderTimer()
    {
        if (_timerState is not null)
        {
            _timerRemaining = Math.Clamp(_timerState.RemainingSeconds, 0, Math.Max(1, _timerState.TotalSeconds));
            _timerTotal = _timerState.TotalSeconds;
        }
        if (_timerDisplay is not null)
            _timerDisplay.Text = $"{_timerRemaining / 60:00}:{_timerRemaining % 60:00}";
    }

    void BuildBreath()
    {
        Header("Samen rustig ademhalen", "Adem gewoon rustig in en uit. Houd je adem niet vast. Stop als je duizelig wordt of het onprettig voelt.");
        var phase = AppUi.Title("Druk op Start als je er klaar voor bent"); phase.HorizontalTextAlignment = TextAlignment.Center; phase.FontSize = AppUi.TitleFont;
        var countdown = AppUi.Title(""); countdown.HorizontalTextAlignment = TextAlignment.Center;
        var breathCircle = new Border
        {
            WidthRequest = 128,
            HeightRequest = 128,
            Scale = 0.82,
            StrokeShape = new Ellipse(),
            Stroke = Color.FromArgb("#3C7A89"),
            StrokeThickness = 2,
            BackgroundColor = Color.FromArgb("#C9EAE6"),
            HorizontalOptions = LayoutOptions.Center,
            VerticalOptions = LayoutOptions.Center,
            Content = AppUi.Label("🌬️", title: true)
        };
        var musicEnabled = new CheckBox { IsChecked = true, Color = AppUi.Accent, VerticalOptions = LayoutOptions.Center };
        var musicRow = new HorizontalStackLayout { Spacing = 8, VerticalOptions = LayoutOptions.Center };
        musicRow.Children.Add(musicEnabled);
        musicRow.Children.Add(AppUi.Label("🎵 Rustgevende achtergrondmuziek", muted: true));
        var musicStatus = AppUi.Label("De zachte muziek start samen met de oefening.", muted: true);
        musicEnabled.CheckedChanged += (_, e) =>
        {
            if (_breathTimer is { IsRunning: true })
            {
                if (e.Value)
                    musicStatus.Text = StartBreathingMusic() ? "🎵 De rustgevende muziek speelt." : "De muziek kon niet starten. De oefening werkt wel.";
                else
                {
                    StopBreathingMusic();
                    musicStatus.Text = "De muziek staat uit.";
                }
            }
            else
            {
                musicStatus.Text = e.Value ? "De zachte muziek start samen met de oefening." : "De muziek staat uit.";
            }
        };
        AddAsyncButton("🔊 Test de muziek (5 seconden)", async () =>
        {
            var started = StartBreathingMusic();
            musicStatus.Text = started ? "🎵 De muziek speelt. Zet het mediavolume van je telefoon hoger als je niets hoort." : "De muziek kon niet starten. Controleer of de update volledig is geïnstalleerd.";
            if (started)
            {
                await Task.Delay(TimeSpan.FromSeconds(5));
                if (_breathTimer is not { IsRunning: true }) StopBreathingMusic();
            }
        }, quiet: true);
        var start = AppUi.Button("▶ Start rustig ritme", () =>
        {
            _breathTimer?.Stop();
            StopBreathingMusic();
            if (musicEnabled.IsChecked)
                musicStatus.Text = StartBreathingMusic() ? "🎵 De rustgevende muziek speelt zacht op de achtergrond." : "De muziek kon niet starten. De oefening werkt wel.";
            else
                musicStatus.Text = "De muziek staat uit.";
            _breathIn = true; int count = 4;
            phase.Text = "Adem rustig in"; countdown.Text = count.ToString();
            breathCircle.Content = AppUi.Label("IN", title: true);
            _ = breathCircle.ScaleToAsync(1.22, 3600, Easing.SinInOut);
            _breathTimer = Dispatcher.CreateTimer(); _breathTimer.Interval = TimeSpan.FromSeconds(1);
            _breathTimer.Tick += (_, _) =>
            {
                count--; countdown.Text = count > 0 ? count.ToString() : "";
                if (count <= 0)
                {
                    _breathIn = !_breathIn;
                    count = 4;
                    phase.Text = _breathIn ? "Adem rustig in" : "Adem rustig uit";
                    breathCircle.Content = AppUi.Label(_breathIn ? "IN" : "UIT", title: true);
                    _ = breathCircle.ScaleToAsync(_breathIn ? 1.22 : 0.82, 3600, Easing.SinInOut);
                    countdown.Text = "4";
                }
            };
            _breathTimer.Start();
        });
        Add(phase); Add(breathCircle); Add(countdown); Add(musicRow); Add(musicStatus); Add(start);
        AddButton("■ Stop", () =>
        {
            _breathTimer?.Stop(); _breathTimer = null; StopBreathingMusic();
            phase.Text = "Neem de tijd die je nodig hebt."; countdown.Text = "";
            breathCircle.Content = AppUi.Label("🌬️", title: true);
            _ = breathCircle.ScaleToAsync(1, 250, Easing.CubicOut);
            musicStatus.Text = musicEnabled.IsChecked ? "De muziek is gestopt." : "De muziek staat uit.";
        }, quiet: true);
        AddButton("🌿 Naar de rustplek", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Calm)));
    }

    bool StartBreathingMusic()
    {
        StopBreathingMusic();
        try
        {
            var player = Android.Media.MediaPlayer.Create(Android.App.Application.Context!, Resource.Raw.breathing_calm);
            if (player is null) return false;
            _breathingMusicPlayer = player;
            player.Looping = true;
            // Gebruik de builder-stappen afzonderlijk. Sommige Android-bindings annoteren
            // de fluent-returnwaarde als mogelijk null, ook al verandert de builder zelf.
            var audioAttributesBuilder = new Android.Media.AudioAttributes.Builder();
            audioAttributesBuilder.SetUsage(Android.Media.AudioUsageKind.Media);
            audioAttributesBuilder.SetContentType(Android.Media.AudioContentType.Music);
            var audioAttributes = audioAttributesBuilder.Build();
            if (audioAttributes is null)
            {
                StopBreathingMusic();
                return false;
            }
            player.SetAudioAttributes(audioAttributes);
            // Zet alleen het app-volume duidelijk hoorbaar; de fysieke mediavolume-instelling blijft van de gebruiker.
            player.SetVolume(0.85f, 0.85f);
            player.Start();
            return true;
        }
        catch
        {
            StopBreathingMusic();
            return false;
        }
    }

    void StopBreathingMusic()
    {
        var player = _breathingMusicPlayer;
        _breathingMusicPlayer = null;
        if (player is null) return;
        try { if (player.IsPlaying) player.Stop(); } catch { }
        try { player.Release(); } catch { }
        try { player.Dispose(); } catch { }
    }

    void BuildCalm()
    {
        Header("Rustplek", "Kies een kleine stap om even te landen. Je hoeft niets perfect te doen.");
        var tip = AppUi.Label(CalmTips[0], title: true); tip.HorizontalTextAlignment = TextAlignment.Center;
        Add(AppUi.Card(new VerticalStackLayout { Padding = 18, MinimumHeightRequest = 150, VerticalOptions = LayoutOptions.Center, Children = { tip } }));
        AddButton("Volgende rusttip", () => { _calmTipIndex = (_calmTipIndex + 1) % CalmTips.Length; tip.Text = CalmTips[_calmTipIndex]; });
        AddButton("🫁 Samen ademhalen", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Breath)));
        AddButton("🚦 Mijn stoplicht invullen", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Stoplicht)), quiet: true);
        AddButton("🆘 Mijn plan bekijken", () => Navigation.PushAsync(new FeaturePage(FeatureKind.SafetyPlan)), quiet: true);
        var plan = Store.Load<SafetyPlan>("plan", Guid.Empty) ?? new SafetyPlan();
        AddLabel("Wat kan mij helpen?", title: true);
        AddLabel(string.IsNullOrWhiteSpace(plan.Helps) ? "Je hebt nog niets ingevuld bij Mijn plan." : plan.Helps);
        foreach (var contact in plan.Contacts.Where(x => !string.IsNullOrWhiteSpace(x.Name))) AddLabel($"📞 {contact.Name} {contact.Phone}");

        AddLabel("Mijn eigen rustlijst", title: true);
        AddLabel("Bewaar zelfgekozen dingen die jou soms helpen. Deze lijst is privé op dit apparaat en wordt niet automatisch gedeeld.", muted: true);
        var optionTitle = AppUi.Entry("Wat helpt mij? (bijv. thee zetten, rustige muziek)");
        optionTitle.MaxLength = 160;
        var optionNote = AppUi.Editor("Extra uitleg of wat ik nodig heb (optioneel)", height: 75);
        optionNote.MaxLength = 800;
        var optionStatus = AppUi.Label("");
        var optionList = new VerticalStackLayout { Spacing = 6 };
        Guid? editingOptionId = null;
        Button? saveOption = null;
        Button? cancelOption = null;

        void ResetOptionEditor()
        {
            editingOptionId = null;
            optionTitle.Text = "";
            optionNote.Text = "";
            if (saveOption is not null) saveOption.Text = "➕ Rustoptie toevoegen";
            if (cancelOption is not null) cancelOption.IsVisible = false;
            optionStatus.Text = "";
        }

        void ReloadOptions()
        {
            optionList.Children.Clear();
            var options = Store.All<CalmOptionEntry>("calmoption").OrderByDescending(x => x.Updated).Take(100).ToList();
            if (options.Count == 0) optionList.Children.Add(AppUi.Label("Je eigen rustlijst is nog leeg. Voeg iets toe dat bij jou past.", muted: true));
            foreach (var savedOption in options)
            {
                var local = savedOption;
                var content = AppUi.Stack(AppUi.Label("🌿 " + local.Title, title: true));
                if (!string.IsNullOrWhiteSpace(local.Note)) content.Children.Add(AppUi.Label(local.Note));
                content.Children.Add(AppUi.Label("Bijgewerkt: " + local.Updated.ToString("dd-MM-yyyy HH:mm"), muted: true));
                var buttons = new VerticalStackLayout { Spacing = 2 };
                buttons.Children.Add(AppUi.Button("✏️ Aanpassen", () =>
                {
                    editingOptionId = local.Id;
                    optionTitle.Text = local.Title;
                    optionNote.Text = local.Note;
                    if (saveOption is not null) saveOption.Text = "💾 Rustoptie opslaan";
                    if (cancelOption is not null) cancelOption.IsVisible = true;
                    optionStatus.Text = "Je past een bestaande rustoptie aan.";
                }, quiet: true));
                buttons.Children.Add(AppUi.AsyncButton("🗑 Verwijderen", async () =>
                {
                    if (!await DisplayAlertAsync("Rustoptie verwijderen?", "Deze rustoptie wordt van dit apparaat verwijderd.", "Verwijderen", "Annuleren")) return;
                    Store.Delete("calmoption", local.Id);
                    if (editingOptionId == local.Id) ResetOptionEditor();
                    AppSession.Touch();
                    ReloadOptions();
                }, quiet: true));
                content.Children.Add(buttons);
                optionList.Children.Add(AppUi.Card(content));
            }
        }

        AddField("Mijn rustoptie", optionTitle); AddField("Notitie", optionNote);
        saveOption = AppUi.AsyncButton("➕ Rustoptie toevoegen", async () =>
        {
            var t = (optionTitle.Text ?? "").Trim();
            var n = (optionNote.Text ?? "").Trim();
            if (t.Length < 2 || t.Length > 160) { optionStatus.Text = "Gebruik een titel van 2 tot 160 tekens."; return; }
            if (n.Length > 800) { optionStatus.Text = "De uitleg mag maximaal 800 tekens bevatten."; return; }
            var old = editingOptionId is Guid editId ? Store.Load<CalmOptionEntry>("calmoption", editId) : null;
            if (editingOptionId is not null && old is null) { optionStatus.Text = "Deze rustoptie bestaat niet meer. Kies een optie uit de lijst."; ResetOptionEditor(); return; }
            var id = old?.Id ?? Guid.NewGuid();
            var saved = new CalmOptionEntry(id, t, n, old?.Created ?? DateTime.Now, DateTime.Now);
            Store.Save("calmoption", id, saved);
            AppSession.Touch();
            ResetOptionEditor(); ReloadOptions();
            optionStatus.Text = old is null ? "Rustoptie privé opgeslagen ✔" : "Rustoptie aangepast ✔";
            await Task.CompletedTask;
        });
        Add(saveOption);
        cancelOption = AppUi.Button("Bewerken annuleren", ResetOptionEditor, quiet: true);
        cancelOption.IsVisible = false;
        Add(cancelOption); Add(optionStatus); Add(optionList); ReloadOptions();
    }

    // ---------- Prikkels, lichaam en gevoelswoorden ----------
    void BuildSensory()
    {
        Header("Prikkelmeter", "Hoe druk is het in mijn hoofd en om me heen? Kies een cijfer van 1 (rustig) tot 5 (veel te druk).");
        var head = new Slider { Minimum = 1, Maximum = 5, Value = 3, ThumbColor = AppUi.Accent, MinimumTrackColor = AppUi.Accent };
        var room = new Slider { Minimum = 1, Maximum = 5, Value = 3, ThumbColor = AppUi.Accent, MinimumTrackColor = AppUi.Accent };
        bool headTouched = false, roomTouched = false;
        var headLabel = AppUi.Label("3 — Gaat wel (raak de schuif aan om op te slaan)"); var roomLabel = AppUi.Label("3 — Gaat wel (raak de schuif aan om op te slaan)");
        string[] levels = { "", "Heel rustig", "Rustig", "Gaat wel", "Druk", "Veel te druk" };
        head.ValueChanged += (_, e) => { headTouched = true; headLabel.Text = $"{(int)Math.Round(e.NewValue)} — {levels[(int)Math.Round(e.NewValue)]}"; AppSession.Touch(); };
        room.ValueChanged += (_, e) => { roomTouched = true; roomLabel.Text = $"{(int)Math.Round(e.NewValue)} — {levels[(int)Math.Round(e.NewValue)]}"; AppSession.Touch(); };
        AddLabel("In mijn hoofd", title: true); Add(head); Add(headLabel);
        AddLabel("Om me heen (geluid, licht, mensen)", title: true); Add(room); Add(roomLabel);
        var status = AppUi.Label(""); Add(status);
        AddAsyncButton("💾 Metingen opslaan", async () =>
        {
            if (!headTouched && !roomTouched) { status.Text = "Raak eerst minstens één schuif aan."; return; }
            int h = (int)Math.Round(head.Value), r = (int)Math.Round(room.Value);
            if (headTouched) { var headId = Guid.NewGuid(); Store.Save("scale", headId, new ScaleEntry(headId, DateTime.Now, "Hoofd", h, "")); }
            if (roomTouched) { var roomId = Guid.NewGuid(); Store.Save("scale", roomId, new ScaleEntry(roomId, DateTime.Now, "Omgeving", r, "")); }
            status.Text = "Opgeslagen ✔";
            if ((headTouched && h >= 4) || (roomTouched && r >= 4)) await DisplayAlertAsync("Veel prikkels", "Misschien helpt het om naar de Rustplek te gaan of iemand te vertellen wat je nodig hebt.", "OK");
        });
        AddButton("🌿 Naar de rustplek", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Calm)), quiet: true);
    }

    void BuildBody()
    {
        Header("Mijn lichaam", "Waar merk je iets in je lijf? Kies een plek, beschrijf het kort en sla het op.");
        var area = AppUi.Picker("Waar voel ik iets?", new[] { "Hoofd", "Schouders", "Borst", "Buik", "Hart", "Handen", "Benen", "Hele lichaam", "Anders" }, "Buik");
        var feeling = AppUi.Picker("Wat merk ik?", new[] { "Spanning", "Pijn", "Onrust", "Warmte", "Koude", "Tintelingen", "Rust", "Anders" }, "Spanning");
        var level = AppUi.Picker("Hoe sterk?", new[] { "1 — Heel weinig", "2 — Een beetje", "3 — Gemiddeld", "4 — Veel", "5 — Heel veel" }, "3 — Gemiddeld");
        var note = AppUi.Editor("Extra uitleg (mag leeg blijven)", height: 90);
        var status = AppUi.Label("");
        AddField("Plek", area); AddField("Gevoel", feeling); AddField("Sterkte", level); AddField("Notitie", note); Add(status);
        AddAsyncButton("💾 Opslaan", async () =>
        {
            var n = $"{area.SelectedItem}: {feeling.SelectedItem}" + (string.IsNullOrWhiteSpace(note.Text) ? "" : " — " + note.Text.Trim());
            var id = Guid.NewGuid();
            Store.Save("scale", id, new ScaleEntry(id, DateTime.Now, "Lichaam", Math.Clamp(level.SelectedIndex + 1, 1, 5), n));
            status.Text = "Opgeslagen ✔";
            await Task.CompletedTask;
        });
    }

    void BuildMoodHistory()
    {
        Header("Hoe voel ik me?", "Een rustig overzicht van de laatste 14 dagen. Dit is geen oordeel en geen diagnose.");
        var entries = Store.All<JournalEntry>("diary").Where(e => e.Mood > 0).ToList();
        for (int d = 13; d >= 0; d--)
        {
            var day = DateTime.Today.AddDays(-d);
            var list = entries.Where(e => e.Created.Date == day).ToList();
            if (list.Count == 0) Add(AppUi.Card(AppUi.Label(day.ToString("ddd d MMM", CultureInfo.GetCultureInfo("nl-NL")) + "   —")));
            else
            {
                double avg = list.Average(e => e.Mood);
                int mood = Math.Clamp((int)Math.Round(avg), 1, 5);
                Add(AppUi.Card(AppUi.Label($"{day.ToString("ddd d MMM", CultureInfo.GetCultureInfo("nl-NL"))}   {Moods[mood - 1].Emoji} {Moods[mood - 1].Name}   ({list.Count} keer)")));
            }
        }
        AddLabel("Een lange balk betekent niet automatisch dat alles goed is; kijk vooral wat jij zelf herkent.", muted: true);
        AddButton("📖 Naar mijn dagboek", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Journal)), quiet: true);
    }

    void BuildDailyCheckIn()
    {
        var existing = _editingMoodCheckInId is Guid editId ? Store.Load<MoodCheckInEntry>("moodcheckin", editId) : null;
        var isEditing = _editingMoodCheckInId is not null;
        Header("Mijn gevoel", "Sta even stil bij hoe je je voelt. Tik op een picto die het beste bij je past.");
        AddLabel("Snel kiezen", title: true);
        AddLabel("Je kunt met één tik een kort gevoel opslaan, of hieronder uitgebreider registreren.", muted: true);
        var quickStatus = AppUi.Label("");
        var quickHelp = new VerticalStackLayout { Spacing = 8, IsVisible = false };
        var quickGrid = new Grid
        {
            ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) },
            RowDefinitions = { new RowDefinition(GridLength.Auto), new RowDefinition(GridLength.Auto) },
            ColumnSpacing = 8,
            RowSpacing = 8
        };
        var quickFeelings = new[]
        {
            (Key: "Blij", Text: "😊  Blij", Color: "#176B60"),
            (Key: "Bedroefd", Text: "😢  Verdrietig", Color: "#244D93"),
            (Key: "Boos", Text: "😠  Boos", Color: "#8A3155"),
            (Key: "Bang", Text: "😨  Bang", Color: "#5739A6")
        };
        for (int i = 0; i < quickFeelings.Length; i++)
        {
            var feeling = quickFeelings[i];
            var button = AppUi.Button(feeling.Text, () => _ = SaveQuickFeelingAsync(feeling.Key, quickStatus, quickHelp), quiet: true);
            button.MinimumHeightRequest = 58;
            button.BackgroundColor = Color.FromArgb(feeling.Color);
            button.BorderColor = Color.FromArgb(feeling.Color);
            button.TextColor = Colors.White;
            quickGrid.Add(button, i % 2, i / 2);
        }
        Add(quickGrid);
        Add(quickStatus);
        Add(AppUi.Card(quickHelp));

        var feelings = new (string Emoji, string Name, string Hex)[]
        {
            ("😊", "Blij", "#174F49"), ("❔", "Ik weet het niet", "#31415E"), ("😢", "Verdrietig", "#193C70"),
            ("😠", "Boos", "#6B2944"), ("😨", "Bang", "#402C76"),
            ("😟", "Gespannen", "#6A3C2B"), ("😮‍💨", "Moe", "#12465A"),
            ("😌", "Rustig", "#15564E"), ("😐", "Gaat wel", "#2B3A5A"),
            ("🥺", "Eenzaam", "#2B326B"), ("😬", "Zenuwachtig", "#57315F"),
            ("🤯", "Overprikkeld", "#59314A"), ("😕", "Verward", "#303C60"),
            ("❔", "Anders", "#21314B")
        };
        string selectedFeeling = existing?.Feeling ?? "Gaat wel";
        var initialMood = feelings.FirstOrDefault(x => x.Name == selectedFeeling);
        var selectedLabel = AppUi.Label($"Gekozen: {initialMood.Emoji ?? "😐"} {selectedFeeling}", title: true);
        var moodGrid = new Grid
        {
            ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) },
            ColumnSpacing = 9, RowSpacing = 9
        };
        for (int row = 0; row < (feelings.Length + 1) / 2; row++) moodGrid.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
        var moodButtons = new List<(string Name, Button Button)>();
        foreach (var item in feelings.Select((mood, index) => (mood, index)))
        {
            var mood = item.mood;
            var button = AppUi.Button($"{mood.Emoji}\n{mood.Name}", () =>
            {
                selectedFeeling = mood.Name;
                selectedLabel.Text = $"Gekozen: {mood.Emoji} {mood.Name}";
                foreach (var pair in moodButtons)
                {
                    pair.Button.BorderColor = pair.Name == selectedFeeling ? AppUi.Cyan : AppUi.Border;
                    pair.Button.BorderWidth = pair.Name == selectedFeeling ? 3 : 1;
                }
                AppSession.Touch();
            }, quiet: true);
            button.MinimumHeightRequest = 82;
            button.FontSize = Math.Max(15, AppUi.BaseFont * 0.82);
            button.Padding = new Thickness(7, 8);
            button.BackgroundColor = Color.FromArgb(mood.Hex);
            button.BorderColor = mood.Name == selectedFeeling ? AppUi.Cyan : AppUi.Border;
            button.BorderWidth = mood.Name == selectedFeeling ? 3 : 1;
            button.TextColor = Colors.White;
            moodButtons.Add((mood.Name, button));
            moodGrid.Add(button, item.index % 2, item.index / 2);
        }
        AddLabel(isEditing ? "Pas je check-in aan" : "Hoe voel ik me nu?", title: true);
        if (isEditing && existing is null)
        {
            AddLabel("Deze check-in bestaat niet meer. Ga terug naar de gevoelskalender.");
            AddButton("Terug", async () => await Navigation.PopAsync());
            return;
        }
        Add(moodGrid);
        Add(selectedLabel);

        var includeIntensity = new Switch { IsToggled = (existing?.Intensity ?? 0) > 0, OnColor = AppUi.Accent };
        var intensity = new Slider { Minimum = 1, Maximum = 10, Value = Math.Clamp((existing?.Intensity ?? 0) > 0 ? existing!.Intensity : 5, 1, 10), MinimumTrackColor = AppUi.Accent, MaximumTrackColor = Color.FromArgb("#273858"), ThumbColor = AppUi.Cyan, IsEnabled = includeIntensity.IsToggled };
        var intensityLabel = AppUi.Label(includeIntensity.IsToggled ? $"Sterkte: {(int)Math.Round(intensity.Value)} van 10" : "Sterkte overslaan", title: true);
        includeIntensity.Toggled += (_, e) => { intensity.IsEnabled = e.Value; intensityLabel.Text = e.Value ? $"Sterkte: {(int)Math.Round(intensity.Value)} van 10" : "Sterkte overslaan"; AppSession.Touch(); };
        intensity.ValueChanged += (_, e) => intensityLabel.Text = $"Sterkte: {(int)Math.Round(e.NewValue)} van 10";
        var reasons = new[] { "Ik weet het niet", "Werk, school of dagbesteding", "Thuis", "Andere mensen", "Drukte of lawaai", "Vermoeidheid", "Pijn of niet lekker", "Iets leuks gebeurd", "Iets vervelends gebeurd", "Anders" };
        var reason = AppUi.Picker("Wat speelt mee? (mag je overslaan)", reasons, existing?.Reason ?? reasons[0]);
        var note = AppUi.Editor("Wil ik er iets bij schrijven? (mag leeg blijven)", existing?.Note, height: 100);
        var status = AppUi.Label("");
        AddLabel("Sterkte is optioneel", title: true);
        Add(new HorizontalStackLayout { Spacing = 8, Children = { includeIntensity, AppUi.Label("Ik wil de sterkte aangeven (1 tot 10)") } });
        Add(intensity); Add(intensityLabel); AddField("Wat speelt mee? (optioneel)", reason); AddField("Notitie (optioneel)", note); Add(status);
        AddAsyncButton(isEditing ? "✓  Wijzigingen opslaan" : "✓  Check-in privé opslaan", async () =>
        {
            MoodCheckInEntry item;
            if (isEditing)
            {
                if (_editingMoodCheckInId is not Guid id)
                {
                    status.Text = "Deze check-in kan niet worden geïdentificeerd.";
                    return;
                }
                var old = Store.Load<MoodCheckInEntry>("moodcheckin", id);
                if (old is null)
                {
                    status.Text = "Deze check-in bestaat niet meer. Ga terug naar de kalender.";
                    return;
                }
                item = old with
                {
                    Feeling = selectedFeeling,
                    Intensity = includeIntensity.IsToggled ? (int)Math.Round(intensity.Value) : 0,
                    Reason = reason.SelectedItem?.ToString() ?? "Ik weet het niet",
                    Note = note.Text?.Trim() ?? ""
                };
            }
            else
            {
                var id = Guid.NewGuid();
                item = new MoodCheckInEntry(id, DateTime.Now, selectedFeeling, includeIntensity.IsToggled ? (int)Math.Round(intensity.Value) : 0, reason.SelectedItem?.ToString() ?? "Ik weet het niet", note.Text?.Trim() ?? "");
            }
            Store.Save("moodcheckin", item.Id, item);
            AppSession.Touch();
            if (isEditing)
            {
                await DisplayAlertAsync("Opgeslagen", "Je check-in is bijgewerkt. Er wordt niets automatisch gedeeld.", "OK");
                await Navigation.PopAsync();
                return;
            }
            status.Text = "Je check-in is privé opgeslagen.";
            AppUi.Speak("Je check-in is opgeslagen. Er wordt niets automatisch gedeeld.");
        });
        if (isEditing) AddButton("Annuleren", async () => await Navigation.PopAsync(), quiet: true);
        AddButton("Overslaan — niets opslaan", async () =>
        {
            if (isEditing) await Navigation.PopAsync();
            else await Navigation.PopToRootAsync();
        }, quiet: true);
        AddButton("🗓️ Bekijk mijn gevoelskalender", () => Navigation.PushAsync(new FeaturePage(FeatureKind.MoodCalendar)), quiet: true);
    }

    async Task SaveQuickFeelingAsync(string feeling, Label status, VerticalStackLayout helpPanel)
    {
        var record = new FourGFeelingEntry(Guid.NewGuid(), DateTime.Now, feeling);
        Store.Save("feeling4g", record.Id, record);
        AppSession.Touch();
        status.Text = $"Opgeslagen: {QuickFeelingEmoji(feeling)} {feeling}. Dit wordt niet automatisch gedeeld.";
        AppUi.Speak($"Je hebt {feeling} gekozen. Dit is opgeslagen. Er wordt niets automatisch gedeeld.");
        helpPanel.Children.Clear();
        helpPanel.Children.Add(AppUi.Label(feeling == "Blij" ? "Fijn dat je dit deelt. Je hoeft verder niets te doen." : "Wat kan nu helpen? Kies zelf een volgende stap.", title: true));
        if (feeling != "Blij")
        {
            helpPanel.Children.Add(AppUi.Button("🌬️ Rustig ademhalen", () => _ = Navigation.PushAsync(new FeaturePage(FeatureKind.Breath)), quiet: true));
            helpPanel.Children.Add(AppUi.Button("🌲 Naar mijn rustplek", () => _ = Navigation.PushAsync(new FeaturePage(FeatureKind.Calm)), quiet: true));
            helpPanel.Children.Add(AppUi.Button("🆘 Mijn helpkaart bekijken", () => _ = Navigation.PushAsync(new FeaturePage(FeatureKind.SafetyPlan)), quiet: true));
            helpPanel.Children.Add(AppUi.Button("👥 Wie werkt er vandaag?", () => _ = Navigation.PushAsync(new WieWerktErPage()), quiet: true));
            helpPanel.Children.Add(AppUi.AsyncButton("📱 Een seintje aan mijn contact voorbereiden", SendQuickSignalAsync, quiet: true));
            helpPanel.Children.Add(AppUi.Label("Er wordt niets automatisch verzonden. Je kiest zelf of je het bericht verstuurt.", muted: true));
        }
        helpPanel.IsVisible = true;
    }

    static string QuickFeelingEmoji(string feeling) => feeling switch
    {
        "Blij" => "😄", "Bedroefd" => "😢", "Boos" => "😠", "Bang" => "😨", _ => "🙂"
    };

    async Task SendQuickSignalAsync()
    {
        var plan = Store.Load<SafetyPlan>("plan", Guid.Empty) ?? new SafetyPlan();
        var contact = plan.Contacts.FirstOrDefault(c => !string.IsNullOrWhiteSpace(c.Phone));
        if (contact is null)
        {
            await DisplayAlertAsync("Eerst een contact toevoegen", "Vul bij 'Mijn helpkaart / plan' de naam en het telefoonnummer in van iemand die je vertrouwt.", "Helpkaart openen");
            await Navigation.PushAsync(new FeaturePage(FeatureKind.SafetyPlan));
            return;
        }
        const string body = "Hoi, ik heb het nu moeilijk. Kun je contact met mij opnemen?";
        if (!await DisplayAlertAsync("Een seintje voorbereiden", $"Er wordt een sms klaargezet voor {contact.Name}. De app verstuurt niets vanzelf; je kiest zelf of je verstuurt.", "Sms openen", "Annuleren")) return;
        try { await Sms.Default.ComposeAsync(new SmsMessage(body, new[] { contact.Phone })); }
        catch (Exception ex)
        {
            AppLog.Write(ex);
            await DisplayAlertAsync("Sms niet geopend", "Je kunt je contact ook zelf bellen of een bericht sturen.", "OK");
        }
    }

    async Task ManageMoodCheckInAsync(MoodCheckInEntry chosen)
    {
        var action = await DisplayActionSheetAsync($"Check-in van {chosen.Created:HH:mm}", "Annuleren", "Verwijderen", "Bekijken", "Aanpassen");
        if (action == "Bekijken")
        {
            var intensityLabel = chosen.Intensity > 0 ? $" ({chosen.Intensity}/10)" : " (sterkte niet ingevuld)";
            var text = $"{chosen.Created:HH:mm} — {chosen.Feeling}{intensityLabel}\nAanleiding: {chosen.Reason}" + (string.IsNullOrWhiteSpace(chosen.Note) ? "" : $"\nNotitie: {chosen.Note}");
            await DisplayAlertAsync(chosen.Created.ToString("dddd d MMMM yyyy", CultureInfo.GetCultureInfo("nl-NL")), text, "Sluiten");
        }
        else if (action == "Aanpassen")
        {
            var editorPage = new FeaturePage(FeatureKind.DailyCheckIn, editingMoodCheckInId: chosen.Id);
            editorPage.Disappearing += (_, _) => Build();
            await Navigation.PushAsync(editorPage);
        }
        else if (action == "Verwijderen")
        {
            if (await DisplayAlertAsync("Check-in verwijderen?", "Deze gevoelsregistratie wordt definitief verwijderd. Dit kan niet ongedaan worden gemaakt.", "Verwijderen", "Annuleren"))
            {
                Store.Delete("moodcheckin", chosen.Id);
                Build();
            }
        }
    }

    void BuildMoodCalendar()
    {
        Header("Gevoelskalender", "Je ziet je opgeslagen check-ins. Tik op een dag om een check-in te bekijken, aan te passen of te verwijderen.");
        var entries = Store.All<MoodCheckInEntry>("moodcheckin");
        var today = DateTime.Today;
        var start = today.AddDays(-29);
        for (int offset = 0; offset < 30; offset++)
        {
            var date = start.AddDays(offset);
            var dayEntries = entries.Where(x => x.Created.Date == date).OrderByDescending(x => x.Created).ToList();
            var latest = dayEntries.FirstOrDefault();
            var label = dayEntries.Count == 0 ? "— Nog geen check-in" : $"{latest!.Feeling}" + (latest.Intensity > 0 ? $" · sterkte {latest.Intensity}/10" : " · sterkte overgeslagen") + $" · {dayEntries.Count} check-in(s)";
            var day = date;
            AddAsyncButton($"{date.ToString("ddd d MMM", CultureInfo.GetCultureInfo("nl-NL"))}   {label}", async () =>
            {
                var selected = entries.Where(x => x.Created.Date == day).OrderByDescending(x => x.Created).ToList();
                if (selected.Count == 0) { await DisplayAlertAsync("Geen check-in", "Je hebt op deze dag niets opgeslagen.", "OK"); return; }
                MoodCheckInEntry chosen;
                if (selected.Count == 1) chosen = selected[0];
                else
                {
                    var choices = selected.Select((x, i) => $"{i + 1}. {x.Created:HH:mm} — {x.Feeling}" + (x.Intensity > 0 ? $" ({x.Intensity}/10)" : " (sterkte overgeslagen)")).ToArray();
                    var picked = await DisplayActionSheetAsync("Kies een check-in", "Annuleren", null, choices);
                    if (picked is null || picked == "Annuleren") return;
                    var chosenIndex = Array.IndexOf(choices, picked);
                    if (chosenIndex < 0 || chosenIndex >= selected.Count) return;
                    chosen = selected[chosenIndex];
                }
                await ManageMoodCheckInAsync(chosen);
            }, quiet: true);
        }
        var olderEntries = entries.Where(x => x.Created.Date < start).OrderByDescending(x => x.Created).ToList();
        if (olderEntries.Count > 0)
        {
            AddLabel("Oudere check-ins", title: true);
            foreach (var entry in olderEntries)
            {
                var saved = entry;
                Add(AppUi.Card(new VerticalStackLayout
                {
                    Spacing = 4,
                    Children =
                    {
                        AppUi.Label($"{saved.Created:dd-MM-yyyy HH:mm} · {saved.Feeling}" + (saved.Intensity > 0 ? $" · {saved.Intensity}/10" : " · sterkte overgeslagen"), title: true),
                        string.IsNullOrWhiteSpace(saved.Note) ? AppUi.Label("Geen notitie", muted: true) : AppUi.Label(saved.Note),
                        AppUi.AsyncButton("Bekijken, aanpassen of verwijderen", () => ManageMoodCheckInAsync(saved), quiet: true)
                    }
                }));
            }
        }
        AddLabel("Dit overzicht toont alleen gegevens die je zelf hebt opgeslagen. Een leeg vak betekent niet dat er iets mis is.", muted: true);
    }

    void BuildMoodInsights()
    {
        Header("Mijn inzichten", "Een neutraal overzicht van jouw check-ins. Dit is geen diagnose en vertelt niet waarom je je zo voelt.");
        var all = Store.All<MoodCheckInEntry>("moodcheckin");
        var today = DateTime.Today;
        var since7 = all.Where(x => x.Created.Date >= today.AddDays(-6) && x.Created.Date <= today).ToList();
        var since30 = all.Where(x => x.Created.Date >= today.AddDays(-29) && x.Created.Date <= today).ToList();
        var intensity7 = since7.Where(x => x.Intensity > 0).Select(x => x.Intensity).ToList();
        var intensity30 = since30.Where(x => x.Intensity > 0).Select(x => x.Intensity).ToList();
        Add(AppUi.Card(AppUi.Label($"Afgelopen 7 dagen\nCheck-ins: {since7.Count}\nGemiddelde gevoelssterkte: {(intensity7.Count == 0 ? "niet ingevuld" : intensity7.Average().ToString("0.0", CultureInfo.GetCultureInfo("nl-NL")) + " van 10")}\n\nAfgelopen 30 dagen\nCheck-ins: {since30.Count}\nGemiddelde gevoelssterkte: {(intensity30.Count == 0 ? "niet ingevuld" : intensity30.Average().ToString("0.0", CultureInfo.GetCultureInfo("nl-NL")) + " van 10")}", title: true)));
        AddLabel("Meest gekozen gevoelens (afgelopen 30 dagen)", title: true);
        if (since30.Count == 0) AddLabel("Je hebt nog geen check-ins opgeslagen.");
        else foreach (var group in since30.GroupBy(x => x.Feeling).OrderByDescending(g => g.Count()).Take(6))
            Add(AppUi.Card(AppUi.Label($"{group.Key}: {group.Count()} keer")));
        AddLabel("Deze cijfers beschrijven alleen wat jij hebt ingevuld. Ze geven geen medische conclusie.", muted: true);
        AddButton("➕ Nieuwe check-in", () => Navigation.PushAsync(new FeaturePage(FeatureKind.DailyCheckIn)), quiet: true);
    }

    void BuildFeelingWords()
    {
        Header("Gevoelswoorden", "Hier lees je wat gevoelens kunnen betekenen. Kies woorden die bij je passen.");
        foreach (var w in FeelingWords)
        {
            var item = w;
            Add(AppUi.Card(new VerticalStackLayout { Spacing = 5, Children = {
                AppUi.Label($"{item.Emoji} {item.Name}", title: true), AppUi.Label(item.Description),
                AppUi.Button("🔊 Voorlezen", () => AppUi.Speak(item.Name + ". " + item.Description), quiet: true)
            } }));
        }
    }

    // ---------- Kaarten, gesprekskaart, veiligheidsplan ----------
    void BuildCards()
    {
        Header("Kaarten om te laten zien", "Tik op een kaart om de tekst groot op het scherm te tonen. Handig als praten lastig is.");
        foreach (var c in BasicCards) Add(AppUi.Button($"{c.Emoji}   {c.Text}", async () => await ShowBigCard(c.Emoji, c.Text), quiet: true));
        AddLabel("Mijn eigen kaarten", title: true);
        var emoji = AppUi.Entry("Emoji", "💬");
        var text = AppUi.Entry("Tekst op de kaart");
        Guid? editingCardId = null;
        var editorStatus = AppUi.Label("");
        var list = new VerticalStackLayout { Spacing = 6 };
        void ResetEditor()
        {
            editingCardId = null; emoji.Text = "💬"; text.Text = "";
            editorStatus.Text = "Nieuwe kaart.";
        }
        foreach (var card in Store.All<TalkCard>("card").OrderBy(x => x.Text))
        {
            var c = card;
            var panel = new VerticalStackLayout { Spacing = 4, Children =
            {
                AppUi.Button($"{c.Emoji}   {c.Text}", async () => await ShowBigCard(c.Emoji, c.Text)),
                AppUi.Button("✏️ Aanpassen", () =>
                {
                    editingCardId = c.Id; emoji.Text = c.Emoji; text.Text = c.Text;
                    editorStatus.Text = "Je past deze kaart aan. Bewaar je wijzigingen of kies Nieuw.";
                }, quiet: true),
                AppUi.Button("🗑 Verwijderen", async () =>
                {
                    if (!await DisplayAlertAsync("Verwijderen?", "Deze kaart definitief verwijderen?", "Verwijderen", "Annuleren")) return;
                    Store.Delete("card", c.Id);
                    if (editingCardId == c.Id) ResetEditor();
                    Build();
                }, quiet: true)
            }};
            list.Children.Add(AppUi.Card(panel));
        }
        if (list.Children.Count == 0) list.Children.Add(AppUi.Label("Je hebt nog geen eigen kaarten gemaakt.", muted: true));
        Add(list);
        AddLabel("Eigen kaart maken of aanpassen", title: true);
        AddField("Plaatje", emoji); AddField("Tekst", text);
        AddAsyncButton("💾 Kaart bewaren", async () =>
        {
            var label = text.Text?.Trim() ?? "";
            var symbol = string.IsNullOrWhiteSpace(emoji.Text) ? "💬" : emoji.Text.Trim();
            if (label.Length == 0)
            {
                await DisplayAlertAsync("Tekst ontbreekt", "Vul eerst tekst in voor de kaart.", "OK");
                return;
            }
            if (label.Length > 180 || symbol.Length > 16)
            {
                await DisplayAlertAsync("Te veel tekst", "De kaarttekst mag maximaal 180 tekens zijn en het pictogram maximaal 16 tekens.", "OK");
                return;
            }
            var id = editingCardId ?? Guid.NewGuid();
            Store.Save("card", id, new TalkCard(id, symbol, label));
            AppSession.Touch();
            Build();
        });
        AddButton("➕ Nieuwe kaart", ResetEditor, quiet: true);
        Add(editorStatus);
    }

    async Task ShowBigCard(string emoji, string text)
    {
        var page = new ContentPage { Title = "Kaart", BackgroundColor = AppUi.Background };
        var label = AppUi.Label(text, title: true); label.FontSize = AppUi.TitleFont * 1.6; label.HorizontalTextAlignment = TextAlignment.Center; label.VerticalTextAlignment = TextAlignment.Center;
        var em = AppUi.Label(emoji, title: true); em.FontSize = AppUi.TitleFont * 3; em.HorizontalTextAlignment = TextAlignment.Center;
        page.Content = new ScrollView { Content = AppUi.Stack(em, label, AppUi.Button("🔊 Voorlezen", () => AppUi.Speak(text)), AppUi.Button("Terug", async () => await Navigation.PopAsync(), quiet: true)) };
        await Navigation.PushAsync(page);
    }

    void BuildTalkPrep()
    {
        Header("Gesprekskaart", "Een gesprek met je begeleider of dokter? Schrijf van tevoren op wat je wilt zeggen.");
        var current = Store.Load<TalkPrep>("talk", Guid.Empty) ?? new TalkPrep();
        var tell = AppUi.Editor("Wat wil ik vertellen?", current.Tell, 100);
        var ask = AppUi.Editor("Wat wil ik vragen?", current.Ask, 100);
        var want = AppUi.Editor("Wat wil ik dat er gebeurt?", current.Want, 100);
        var status = AppUi.Label("");
        string Compose() => $"Ik wil vertellen:\n{tell.Text?.Trim()}\n\nIk wil vragen:\n{ask.Text?.Trim()}\n\nIk wil dat:\n{want.Text?.Trim()}";
        AddField("Wat wil ik vertellen?", tell); AddField("Wat wil ik vragen?", ask); AddField("Wat wil ik dat er gebeurt?", want);
        AddButton("💾 Bewaren", () => { Store.Save("talk", Guid.Empty, new TalkPrep { Tell = tell.Text ?? "", Ask = ask.Text ?? "", Want = want.Text ?? "" }); status.Text = "Opgeslagen ✔"; });
        AddButton("👀 Laat dit zien", async () => await ShowBigCard("🗣️", Compose()), quiet: true);
        AddButton("🔊 Voorlezen", () => AppUi.Speak(Compose()), quiet: true);
        AddButton("📤 Delen…", async () => await Share.Default.RequestAsync(new ShareTextRequest { Title = "Mijn gesprekskaart", Text = Compose() }), quiet: true);
        AddButton("🧹 Leegmaken", () => { tell.Text = ""; ask.Text = ""; want.Text = ""; status.Text = "Niet opgeslagen."; }, quiet: true);
        Add(status);
    }

    void BuildSafetyPlan()
    {
        Header("Mijn plan", "Wie kan ik bellen of aanspreken? Wat helpt mij? Je plan wordt getoond als je oranje of rood kiest.");
        var plan = Store.Load<SafetyPlan>("plan", Guid.Empty) ?? new SafetyPlan();
        var contactsText = AppUi.Editor("Eén contact per regel, in dit formaat: Naam | telefoonnummer", string.Join("\n", plan.Contacts.Select(x => x.Name + " | " + x.Phone)), 120);
        var helps = AppUi.Editor("Wat helpt mij? (bijvoorbeeld rustige plek, water, muziek of wandelen)", plan.Helps, 120);
        var signs = AppUi.Editor("Welke signalen merk ik als het moeilijk wordt?", plan.EarlySigns, 85);
        var avoid = AppUi.Editor("Wat helpt niet / wat wil ik liever vermijden?", plan.Avoid, 85);
        var communication = AppUi.Editor("Hoe kan iemand prettig met mij communiceren?", plan.Communication, 85);
        var helpSteps = AppUi.Editor("Concrete helpstappen (één stap per regel)", plan.SupportSteps, 100);
        var helpChoices = new (string Key, string Label)[]
        {
            ("breath", "🫁 Samen rustig ademhalen"), ("calm", "🛋️ Naar mijn rustplek"),
            ("music", "🎧 Rustige muziek luisteren"), ("stressball", "🧸 Mijn stressbal gebruiken"),
            ("walk", "🚶 Even rustig wandelen"), ("talk", "💬 Met iemand praten")
        };
        var helpChecks = helpChoices.Select(option =>
        {
            var check = new CheckBox { Color = AppUi.Accent, IsChecked = plan.HelpOptions?.Contains(option.Key) == true };
            return (option.Key, option.Label, check);
        }).ToList();
        var status = AppUi.Label("");
        AddField("Contactpersonen", contactsText); AddField("Wat helpt mij", helps);
        AddField("Vroege signalen", signs); AddField("Wat liever niet", avoid); AddField("Communicatie", communication); AddField("Helpstappen", helpSteps);
        AddLabel("Mijn vaste helpkaart", title: true);
        AddLabel("Vink aan wat jou kan helpen. Als je bedroefd, boos of bang kiest, verschijnen deze knoppen.", muted: true);
        foreach (var option in helpChecks)
            Add(new HorizontalStackLayout { Spacing = 8, Children = { option.check, AppUi.Label(option.Label) } });
        AddButton("💾 Plan bewaren", () =>
        {
            var contacts = contactsText.Text!.Split('\n').Select(line => line.Trim()).Where(line => line.Length > 0).Select(line =>
            {
                var parts = line.Split('|', 2);
                return new ContactPerson(parts[0].Trim(), parts.Length > 1 ? parts[1].Trim() : "");
            }).ToList();
            Store.Save("plan", Guid.Empty, new SafetyPlan
            {
                Contacts = contacts,
                Helps = helps.Text ?? "",
                EarlySigns = signs.Text ?? "",
                Avoid = avoid.Text ?? "",
                Communication = communication.Text ?? "",
                SupportSteps = helpSteps.Text ?? "",
                HelpOptions = helpChecks.Where(x => x.check.IsChecked).Select(x => x.Key).ToList()
            });
            status.Text = "Opgeslagen ✔ Je helpknoppen zijn aangepast.";
        });
        Add(status);
        if (plan.Contacts.Count > 0)
        {
            AddLabel("Contactpersonen", title: true);
            foreach (var savedContact in plan.Contacts.Where(x => !string.IsNullOrWhiteSpace(x.Name)))
            {
                var contact = savedContact;
                Add(AppUi.Card(AppUi.Stack(
                    AppUi.Label(contact.Name, title: true),
                    AppUi.Label(contact.Phone, muted: true),
                    AppUi.AsyncButton("📞 Open telefoon", async () =>
                    {
                        var number = new string((contact.Phone ?? string.Empty).Where(ch => char.IsDigit(ch) || ch == '+').ToArray());
                        if (number.Count(char.IsDigit) < 3)
                        {
                            await DisplayAlertAsync("Telefoonnummer ontbreekt", "Vul eerst een bruikbaar telefoonnummer in en bewaar het plan.", "OK");
                            return;
                        }
                        try { await Launcher.Default.OpenAsync(new Uri("tel:" + Uri.EscapeDataString(number))); }
                        catch (Exception ex) { AppLog.Write(ex); await DisplayAlertAsync("Bellen niet beschikbaar", "Je toestel kon de telefoon-app niet openen. Je kunt het nummer handmatig kiezen.", "OK"); }
                    }, quiet: true))));
            }
        }
        AddLabel("Belangrijk", title: true);
        AddLabel("MoodPress belt niemand automatisch en verstuurt geen noodmelding. De telefoonknop opent alleen de telefoon-app nadat jij erop tikt. Bij direct gevaar bel je 112. In Nederland kun je ook 113 Zelfmoordpreventie bellen op 0800-0113.");
    }

    // ---------- Delen met begeleider ----------
    void BuildShare()
    {
        Header("Delen met mijn begeleider", "Jij kiest wat je deelt. Deel het bestand en de code via verschillende kanalen. Deelcodes zijn geen wachtwoorden van je account.");
        AddButton("📜 Mijn deelgeschiedenis bekijken", () => Navigation.PushAsync(new ShareHistoryPage()), quiet: true);
        var all = Store.All<StoplichtEntry>("light").OrderByDescending(x => x.Created).Take(40).ToList();
        if (all.Count == 0) { AddLabel("Je hebt nog geen stoplicht-meldingen om te delen."); AddButton("🔐 Ander pakket delen (helpplan, routines of check-ins)", () => Navigation.PushAsync(new SupportPackageSharePage()), quiet:true); return; }
        var checks = new List<(StoplichtEntry Entry, CheckBox Check)>();
        foreach (var item in all)
        {
            var cb = new CheckBox { IsChecked = _targetShareId is Guid id && id == item.Id, Color = AppUi.Accent };
            cb.CheckedChanged += (_, _) => AppSession.Touch();
            checks.Add((item, cb));
            var sub = string.Join(", ", item.Reasons ?? Array.Empty<string>());
            Add(AppUi.Card(new HorizontalStackLayout { Spacing = 8, Children = {
                cb,
                new VerticalStackLayout { Spacing = 2, Children = {
                    AppUi.Label($"{(item.Colour == "Rood" ? "🔴" : item.Colour == "Oranje" ? "🟠" : "🟢")} {item.Colour} — {item.Created:dd-MM-yyyy HH:mm}", title: true),
                    AppUi.Label(string.IsNullOrWhiteSpace(sub) ? (item.Text.Length > 0 ? item.Text : "Geen extra tekst") : sub, muted: true)
                } }
            } }));
        }
        var format = AppUi.Picker("Bestandsvorm", new[] { "Versleuteld deelbestand (.mgdeel)", "Versleutelde HTML-pagina", "Gewone tekst (niet versleuteld)" }, "Versleuteld deelbestand (.mgdeel)");
        var codeEntry = AppUi.Entry("Eigen deelcode (leeg = automatisch maken)");
        var status = AppUi.Label("");
        AddField("Hoe wil je delen?", format);
        AddField("Deelcode", codeEntry);
        AddLabel("Bij gewone tekst kan iedereen de inhoud lezen. Gebruik dat alleen als je dit echt wilt.", muted: true);
        Add(status);
        AddAsyncButton("📤 Geselecteerde meldingen delen", async () =>
        {
            var selected = checks.Where(x => x.Check.IsChecked).Select(x => x.Entry).ToList();
            if (selected.Count == 0) { status.Text = "Kies eerst minstens één melding."; return; }
            int f = Math.Max(0, format.SelectedIndex);
            if (f == 2 && !await DisplayAlertAsync("Let op: gewone tekst", "Dit bestand is niet versleuteld. Iedereen die het bestand krijgt kan het lezen. Wil je doorgaan?", "Delen", "Annuleren")) return;
            string code = (codeEntry.Text ?? "").Trim();
            if (f < 2 && string.IsNullOrWhiteSpace(code)) code = ShareService.NewShareCode();
            string path;
            if (f == 0)
            {
                path = System.IO.Path.Combine(FileSystem.CacheDirectory, $"MijnGevoel-deel-{DateTime.Now:yyyyMMdd-HHmmss}.mgdeel");
                await File.WriteAllBytesAsync(path, ShareService.Create(AppSession.Username, selected, code));
            }
            else if (f == 1)
            {
                path = System.IO.Path.Combine(FileSystem.CacheDirectory, $"MijnGevoel-deel-{DateTime.Now:yyyyMMdd-HHmmss}.html");
                await File.WriteAllTextAsync(path, ShareService.CreateHtml(AppSession.Username, selected, code), new UTF8Encoding(false));
            }
            else
            {
                path = System.IO.Path.Combine(FileSystem.CacheDirectory, $"MijnGevoel-deel-{DateTime.Now:yyyyMMdd-HHmmss}.txt");
                await File.WriteAllTextAsync(path, ShareService.PlainText(AppSession.Username, selected), new UTF8Encoding(false));
            }
            var log = new ShareLogEntry(Guid.NewGuid(), DateTime.Now, selected.Count);
            Store.Save("sharelog", log.Id, log);
            await Share.Default.RequestAsync(new ShareFileRequest { Title = "MoodPress delen", File = new ShareFile(path) });
            if (f < 2)
            {
                await Clipboard.Default.SetTextAsync(code);
                await DisplayAlertAsync("Deelcode", $"De deelcode is gekopieerd naar je klembord:\n\n{code}\n\nStuur de code via een ander kanaal dan het bestand. Deel deze code niet met anderen.", "OK");
            }
            else status.Text = "Het tekstbestand is gedeeld. Onthoud dat het niet versleuteld is.";
        });
        AddButton("Selecteer alles", () => { foreach (var c in checks) c.Check.IsChecked = true; }, quiet: true);
        AddButton("Selecteer niets", () => { foreach (var c in checks) c.Check.IsChecked = false; }, quiet: true);
        AddButton("🔐 Ander pakket delen (helpplan en routines apart kiezen)", () => Navigation.PushAsync(new SupportPackageSharePage()), quiet: true);
    }

    // ---------- Tekenen en galerij ----------
    void BuildDraw(bool resetDrawing = true)
    {
        if (resetDrawing)
        {
            _strokes.Clear();
            _strokeColors.Clear();
            _strokeWidths.Clear();
            _activeStroke = null;
            _drawingTitle = "Mijn tekening";
        }

        _drawingView = null;
        _freeDrawDrawable = null;
        Header("Tekenen", "Kies eerst je kleur en pendikte. Tik daarna op ‘Begin met tekenen’ om het grote witte tekenvak te openen.");

        var title = AppUi.Entry("Naam van de tekening", _drawingTitle);
        title.TextChanged += (_, e) => _drawingTitle = e.NewTextValue ?? "";

        string selectedColor = _drawingColorHex switch
        {
            "#1769AA" => "Blauw",
            "#C62828" => "Rood",
            "#238636" => "Groen",
            "#7B2CBF" => "Paars",
            "#E87516" => "Oranje",
            _ => "Zwart"
        };
        var colors = AppUi.Picker("Tekenkleur", new[] { "Zwart", "Blauw", "Rood", "Groen", "Paars", "Oranje" }, selectedColor);
        var selectedWidth = _drawingStrokeWidth <= 2f ? "Dun" : _drawingStrokeWidth >= 8f ? "Dik" : "Normaal";
        var widths = AppUi.Picker("Pendikte", new[] { "Dun", "Normaal", "Dik" }, selectedWidth);

        colors.SelectedIndexChanged += (_, _) =>
        {
            _drawingColorHex = colors.SelectedItem?.ToString() switch
            {
                "Blauw" => "#1769AA", "Rood" => "#C62828", "Groen" => "#238636",
                "Paars" => "#7B2CBF", "Oranje" => "#E87516", _ => "#202020"
            };
            _drawingView?.Invalidate();
        };
        widths.SelectedIndexChanged += (_, _) =>
        {
            _drawingStrokeWidth = widths.SelectedIndex switch { 0 => 2f, 2 => 8f, _ => 4f };
            _drawingView?.Invalidate();
        };

        AddField("Naam", title);
        AddField("Tekenkleur", colors);
        AddField("Pendikte", widths);
        AddButton("✏️ Begin met tekenen", () => ShowDrawingWorkspace(title.Text));
        AddLabel("Daarna kun je met je vinger in het witte vak tekenen. Je kunt je tekening bewaren of opnieuw beginnen.", muted: true);
        AddButton("🖼️ Mijn tekeningen bekijken", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Gallery)), quiet: true);
    }

    void ShowDrawingWorkspace(string? title)
    {
        _drawingTitle = string.IsNullOrWhiteSpace(title) ? "Mijn tekening" : title.Trim();
        _activeStroke = null;

        var drawingView = new GraphicsView
        {
            Drawable = _freeDrawDrawable = new FreeDrawDrawable(_strokes, _strokeColors, _strokeWidths),
            MinimumHeightRequest = 220,
            BackgroundColor = Colors.White,
            HorizontalOptions = LayoutOptions.Fill,
            VerticalOptions = LayoutOptions.Fill,
            InputTransparent = false
        };
        _drawingView = drawingView;
        drawingView.StartInteraction += (_, e) =>
        {
            var touches = e.Touches.ToArray();
            if (touches.Length == 0) return;
            var p = touches[0];
            _activeStroke = new List<PointF> { new((float)p.X, (float)p.Y) };
            _strokes.Add(_activeStroke);
            _strokeColors.Add(_drawingColorHex);
            _strokeWidths.Add(_drawingStrokeWidth);
            drawingView.Invalidate();
            AppSession.Touch();
        };
        drawingView.DragInteraction += (_, e) =>
        {
            if (_activeStroke is null) return;
            foreach (var p in e.Touches)
                _activeStroke.Add(new PointF((float)p.X, (float)p.Y));
            drawingView.Invalidate();
            AppSession.Touch();
        };
        drawingView.EndInteraction += (_, _) => { _activeStroke = null; drawingView.Invalidate(); };
        drawingView.CancelInteraction += (_, _) => { _activeStroke = null; drawingView.Invalidate(); };

        // Het tekenvak staat rechtstreeks in een Grid, niet in een ScrollView.
        // De sterrij gebruikt de beschikbare schermhoogte, zodat de vingerbeweging
        // niet door scrollen wordt overgenomen en het witte vak zichtbaar blijft.
        var workspace = new Grid
        {
            Padding = new Thickness(12),
            RowSpacing = 8,
            BackgroundColor = AppUi.Background,
            ColumnDefinitions = { new ColumnDefinition(GridLength.Star) },
            RowDefinitions =
            {
                new RowDefinition(GridLength.Auto),
                new RowDefinition(new GridLength(1, GridUnitType.Star)),
                new RowDefinition(GridLength.Auto),
                new RowDefinition(GridLength.Auto),
                new RowDefinition(GridLength.Auto)
            }
        };
        workspace.Add(AppUi.Label("Teken met je vinger in het witte vak hieronder.", title: true), 0, 0);
        workspace.Add(drawingView, 0, 1);

        var drawingActions = new Grid
        {
            ColumnSpacing = 8,
            ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) }
        };
        drawingActions.Add(AppUi.Button("↶ Ongedaan maken", () =>
        {
            if (_strokes.Count > 0)
            {
                _strokes.RemoveAt(_strokes.Count - 1);
                _strokeColors.RemoveAt(_strokeColors.Count - 1);
                _strokeWidths.RemoveAt(_strokeWidths.Count - 1);
            }
            _activeStroke = null;
            _drawingView?.Invalidate();
        }, quiet: true), 0, 0);
        drawingActions.Add(AppUi.Button("🧹 Alles wissen", () =>
        {
            _strokes.Clear();
            _strokeColors.Clear();
            _strokeWidths.Clear();
            _activeStroke = null;
            _drawingView?.Invalidate();
        }, quiet: true), 1, 0);
        workspace.Add(drawingActions, 0, 2);

        workspace.Add(AppUi.AsyncButton("💾 Tekening bewaren", SaveCurrentDrawingAsync), 0, 3);

        var bottomActions = new Grid
        {
            ColumnSpacing = 8,
            ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) }
        };
        bottomActions.Add(AppUi.Button("← Terug naar kleur en dikte", () =>
        {
            _activeStroke = null;
            _drawingView = null;
            _freeDrawDrawable = null;
            _root.Children.Clear();
            BuildDraw(resetDrawing: false);
            Content = AppUi.WithBottomNavigation(this, new ScrollView { Content = _root, BackgroundColor = AppUi.Background }, ActiveTabFor(_kind));
        }, quiet: true), 0, 0);
        bottomActions.Add(AppUi.Button("🖼️ Mijn tekeningen", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Gallery)), quiet: true), 1, 0);
        workspace.Add(bottomActions, 0, 4);

        Content = AppUi.WithBottomNavigation(this, workspace, ActiveTabFor(_kind));
        drawingView.Invalidate();
    }

    async Task SaveCurrentDrawingAsync()
    {
        if (_strokes.Count == 0)
        {
            await DisplayAlertAsync("Leeg tekenvlak", "Teken eerst iets in het witte vak.", "OK");
            return;
        }

        var name = string.IsNullOrWhiteSpace(_drawingTitle) ? "Mijn tekening" : _drawingTitle.Trim();
        var data = JsonSerializer.SerializeToUtf8Bytes(_strokes.Select(s => s.Select(p => new[] { p.X, p.Y }).ToArray()).ToArray());
        byte[] png = CreateDrawingPng(_strokes, _strokeColors, _strokeWidths,
            Math.Max(1, (float)(_drawingView?.Width ?? 320)), Math.Max(1, (float)(_drawingView?.Height ?? 360)));
        var item = new DrawingEntry(Guid.NewGuid(), DateTime.Now, name, data, png);
        Store.Save("drawing", item.Id, item);
        await DisplayAlertAsync("Bewaard", "Je tekening is versleuteld opgeslagen.", "OK");
        _strokes.Clear();
        _strokeColors.Clear();
        _strokeWidths.Clear();
        _activeStroke = null;
        _drawingTitle = "Mijn tekening";
        _drawingView?.Invalidate();
    }

    static byte[] CreateDrawingPng(List<List<PointF>> strokes, List<string> strokeColors, List<float> strokeWidths, float viewWidth, float viewHeight)
    {
        using var bitmap = new SKBitmap(900, 1000);
        using var canvas = new SKCanvas(bitmap);
        canvas.Clear(SKColors.White);
        float sx = 900f / viewWidth, sy = 1000f / viewHeight;
        for (int index = 0; index < strokes.Count; index++)
        {
            var stroke = strokes[index];
            using var paint = new SKPaint { Color = SKColor.Parse(index < strokeColors.Count ? strokeColors[index] : "#202020"), StrokeWidth = Math.Max(2, (index < strokeWidths.Count ? strokeWidths[index] : 4f) * 1.75f), IsAntialias = true, Style = SKPaintStyle.Stroke, StrokeCap = SKStrokeCap.Round, StrokeJoin = SKStrokeJoin.Round };
            if (stroke.Count == 1) { canvas.DrawCircle(stroke[0].X * sx, stroke[0].Y * sy, paint.StrokeWidth / 2, paint); continue; }
            for (int i = 1; i < stroke.Count; i++) canvas.DrawLine(stroke[i - 1].X * sx, stroke[i - 1].Y * sy, stroke[i].X * sx, stroke[i].Y * sy, paint);
        }
        using var image = SKImage.FromBitmap(bitmap);
        using var data = image.Encode(SKEncodedImageFormat.Png, 95);
        return data.ToArray();
    }

    void BuildGallery()
    {
        Header("Mijn tekeningen", "Je tekeningen staan privé op je telefoon. Tik op een tekening om hem groter te bekijken.");
        var items = Store.All<DrawingEntry>("drawing").OrderByDescending(x => x.Created).ToList();
        if (items.Count == 0) AddLabel("Je hebt nog geen tekeningen.");
        foreach (var drawing in items)
        {
            var d = drawing;
            var wrap = new VerticalStackLayout { Spacing = 6, Children = { AppUi.Label($"{d.Title} — {d.Created:dd-MM-yyyy HH:mm}", title: true) } };
            if (d.Png is { Length: > 0 })
            {
                var png = d.Png;
                wrap.Children.Add(new Image { Source = ImageSource.FromStream(() => new MemoryStream(png)), Aspect = Aspect.AspectFit, HeightRequest = 240, BackgroundColor = Colors.White });
            }
            wrap.Children.Add(AppUi.Button("🗑 Verwijderen", async () => { if (await DisplayAlertAsync("Verwijderen?", "Deze tekening definitief verwijderen?", "Verwijderen", "Annuleren")) { Store.Delete("drawing", d.Id); Build(); } }, danger: true));
            Add(AppUi.Card(wrap));
        }
        AddButton("✏️ Nieuwe tekening maken", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Draw)));
    }

    sealed class FreeDrawDrawable : IDrawable
    {
        readonly List<List<PointF>> _strokes;
        readonly List<string> _strokeColors;
        readonly List<float> _strokeWidths;
        public FreeDrawDrawable(List<List<PointF>> strokes, List<string> strokeColors, List<float> strokeWidths) { _strokes = strokes; _strokeColors = strokeColors; _strokeWidths = strokeWidths; }
        public void Draw(ICanvas canvas, RectF dirtyRect)
        {
            canvas.FillColor = Colors.White; canvas.FillRectangle(dirtyRect);
            for (int index = 0; index < _strokes.Count; index++)
            {
                var stroke = _strokes[index];
                var color = Microsoft.Maui.Graphics.Color.FromArgb(index < _strokeColors.Count ? _strokeColors[index] : "#202020");
                var width = index < _strokeWidths.Count ? _strokeWidths[index] : 4f;
                canvas.StrokeColor = color; canvas.StrokeSize = width; canvas.StrokeLineCap = LineCap.Round;
                if (stroke.Count == 1) { canvas.FillColor = color; canvas.FillCircle(stroke[0].X, stroke[0].Y, width / 2); continue; }
                for (int i = 1; i < stroke.Count; i++) canvas.DrawLine(stroke[i - 1].X, stroke[i - 1].Y, stroke[i].X, stroke[i].Y);
            }
        }
    }

    // ---------- Privacy, weekoverzicht, instellingen, hulp ----------
    void BuildPrivacy()
    {
        Header("Mijn privacy", "Je kunt zien wat er bewaard is, je gegevens meenemen of je account en gegevens verwijderen.");
        var consent = Store.All<ConsentRecord>("consent").OrderByDescending(x => x.Created).FirstOrDefault();
        var counts = new[]
        {
            $"Dagboek: {Store.All<JournalEntry>("diary").Count} stukjes",
            $"Van me afschrijven: {Store.All<JournalEntry>("note").Count} briefjes",
            $"Stoplicht: {Store.All<StoplichtEntry>("light").Count} meldingen",
            $"Tekeningen: {Store.All<DrawingEntry>("drawing").Count}",
            $"Agenda: {Store.All<AgendaItem>("agenda").Count} activiteiten",
            $"Stappenplannen: {Store.All<Routine>("routine").Count}",
            $"Meters: {Store.All<ScaleEntry>("scale").Count} metingen",
            $"Gevoelscheck-ins: {Store.All<MoodCheckInEntry>("moodcheckin").Count}",
            $"Stresscheck-ins: {Store.All<YouthSupportEntry>("youthsupport").Count}",
            $"Persoonlijke doelen: {Store.All<AdultGoal>("adultgoal").Count}",
            $"Energiemetingen: {Store.All<EnergyEntry>("energy").Count}",
            $"Welzijnsregistraties: {Store.All<WellbeingEntry>("wellbeing").Count}",
            $"Dagschema-checklists: {Store.All<RoutineProgress>("routineprogress").Count}",
            $"Eigen kaarten: {Store.All<TalkCard>("card").Count}",
            $"Delen met begeleider: {Store.All<ShareLogEntry>("sharelog").Count} keer"
        };
        Add(AppUi.Card(AppUi.Label(string.Join("\n", counts))));
        AddLabel(consent is null ? "Er is nog geen toestemming vastgelegd." : $"Toestemming: {consent.Created:dd-MM-yyyy} ({(consent.Mode == "samen" ? "samen met een vertegenwoordiger/begeleider" : "zelf")}).", muted: true);
        AddLabel("Je gegevens worden versleuteld opgeslagen in de privé-appmap van Android. Als je de app verwijdert, kan Android die map verwijderen. Maak eerst een back-up als je gegevens wilt bewaren.");
        AddAsyncButton("📥 Mijn gegevens exporteren (leesbaar JSON-bestand)", ExportDataAsync, quiet: true);
        AddButton("📜 Deelgeschiedenis bekijken", () => Navigation.PushAsync(new ShareHistoryPage()), quiet:true);
        AddAsyncButton("💾 Back-up maken", CreateBackupAsync, quiet: true);
        AddAsyncButton("📦 Back-up terugzetten", RestoreBackupAsync, quiet: true);
        AddButton("⚙️ Account- en privacy-instellingen", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Settings)));
        AddAsyncButton("Toestemming opnieuw lezen", async () =>
        {
            await DisplayAlertAsync("Toestemming", "Je dagboek, tekeningen, agenda en andere gegevens worden versleuteld op dit apparaat opgeslagen. Je begeleider ziet alleen wat jij zelf deelt. Er worden geen begeleiders automatisch gewaarschuwd; je eigen routineherinneringen kunnen wel meldingen tonen. Je kunt je gegevens exporteren of verwijderen.", "Begrepen");
        }, quiet: true);
        AddLabel("Vragen of klachten? Vraag je begeleider wie verantwoordelijk is voor je gegevens en waar de privacyverklaring staat. Je kunt ook informatie vinden bij de Autoriteit Persoonsgegevens: autoriteitpersoonsgegevens.nl.");
    }

    void BuildWeek()
    {
        Header("Mijn week", "Een overzicht van wat je de afgelopen zeven dagen hebt bijgehouden. Er is geen goed of fout.");
        var since = DateTime.Today.AddDays(-6);
        var lights = Store.All<StoplichtEntry>("light").Where(x => x.Created.Date >= since).ToList();
        var moods = Store.All<JournalEntry>("diary").Where(x => x.Created.Date >= since && x.Mood > 0).ToList();
        var agenda = Store.All<AgendaItem>("agenda").Where(x => x.Date.Date >= since && x.Date.Date <= DateTime.Today).ToList();
        var fourG = Store.All<FourGFeelingEntry>("feeling4g").Where(x => x.Created.Date >= since && x.Created.Date <= DateTime.Today).ToList();
        var checkins = Store.All<MoodCheckInEntry>("moodcheckin").Where(x => x.Created.Date >= since && x.Created.Date <= DateTime.Today).ToList();
        var most = moods.Count == 0 ? "nog niets gekozen" : Moods[moods.GroupBy(m => m.Mood).OrderByDescending(g => g.Count()).First().Key - 1].Name;
        AddLabel("Mijn gevoelens in de afgelopen zeven dagen", title: true);
        var feelingDays = new VerticalStackLayout { Spacing = 6 };
        for (int offset = 0; offset < 7; offset++)
        {
            var date = since.AddDays(offset);
            var dayItems = fourG.Where(x => x.Created.Date == date).OrderByDescending(x => x.Created).ToList();
            var latest = dayItems.FirstOrDefault();
            string label = latest is null ? "Nog niet ingevuld" : $"{FourGEmoji(latest.Feeling)} {latest.Feeling}";
            string color = latest?.Feeling switch
            {
                "Blij" => "#164D45", "Bedroefd" => "#193C70", "Boos" => "#6B2944", "Bang" => "#402C76", _ => "#142441"
            };
            var dayCard = new Border
            {
                Padding = new Thickness(12, 8),
                StrokeShape = new RoundRectangle { CornerRadius = new CornerRadius(12) },
                BackgroundColor = Color.FromArgb(color),
                Stroke = Color.FromArgb(color),
                Content = AppUi.Label($"{date.ToString("ddd d MMM", CultureInfo.GetCultureInfo("nl-NL"))}     {label}")
            };
            feelingDays.Children.Add(dayCard);
        }
        Add(feelingDays);
        var lines = new[]
        {
            $"🟢 Groen: {lights.Count(x => x.Colour == "Groen")}     🟠 Oranje: {lights.Count(x => x.Colour == "Oranje")}     🔴 Rood: {lights.Count(x => x.Colour == "Rood")}",
            $"Gevoelsknoppen gebruikt: {fourG.Count}. Ook het dagboek-gezichtje is {moods.Count} keer gebruikt.",
            $"Dagelijkse check-ins: {checkins.Count}.",
            $"Meest gekozen dagboek-gezichtje: {most}.",
            $"Agenda: {agenda.Count(x => x.Done)} van {agenda.Count} afgevinkt.",
            $"Dagboek: {Store.All<JournalEntry>("diary").Count(x => x.Created.Date >= since && x.Text.Length > 0)} keer geschreven.",
            $"Van me afschrijven: {Store.All<JournalEntry>("note").Count(x => x.Created.Date >= since)} briefjes.",
            $"Tekeningen gemaakt: {Store.All<DrawingEntry>("drawing").Count(x => x.Created.Date >= since)}.",
            $"Prikkelmeter en lichaam: {Store.All<ScaleEntry>("scale").Count(x => x.Created.Date >= since)} keer ingevuld."
        };
        Add(AppUi.Card(AppUi.Label(string.Join("\n\n", lines))));
        AddLabel($"Periode: {since:dd MMMM} t/m {DateTime.Today:dd MMMM}. Dit overzicht blijft van jou, tenzij je zelf iets deelt.", muted: true);
        AddLabel("Zelf kiezen wat je tijdens een weekgesprek wilt bespreken",title:true);
        var includeFeelings=new CheckBox{Color=AppUi.Accent}; var includeLights=new CheckBox{Color=AppUi.Accent}; var includeActivities=new CheckBox{Color=AppUi.Accent}; var includeCheckins=new CheckBox{Color=AppUi.Accent};
        Add(new HorizontalStackLayout{Spacing=8,Children={includeFeelings,AppUi.Label("Gevoelskeuzes en dagboekstemming")}});
        Add(new HorizontalStackLayout{Spacing=8,Children={includeLights,AppUi.Label("Aantallen stoplichtmeldingen")}});
        Add(new HorizontalStackLayout{Spacing=8,Children={includeActivities,AppUi.Label("Agenda: hoeveel activiteiten klaar zijn")}});
        Add(new HorizontalStackLayout{Spacing=8,Children={includeCheckins,AppUi.Label("Aantal gevoelscheck-ins")}});
        AddAsyncButton("📤 Geselecteerd weekoverzicht delen", async () =>
        {
            var selected=new List<string>();
            if(includeFeelings.IsChecked)selected.Add($"Gevoelsknoppen: {fourG.Count}; dagboekstemming ingevuld: {moods.Count}; meest gekozen gezichtje: {most}.");
            if(includeLights.IsChecked)selected.Add($"Stoplichtmeldingen deze week: groen {lights.Count(x=>x.Colour=="Groen")}, oranje {lights.Count(x=>x.Colour=="Oranje")}, rood {lights.Count(x=>x.Colour=="Rood")}.");
            if(includeActivities.IsChecked)selected.Add($"Agenda-activiteiten: {agenda.Count(x=>x.Done)} van {agenda.Count} afgevinkt.");
            if(includeCheckins.IsChecked)selected.Add($"Gevoelscheck-ins: {checkins.Count}.");
            if(selected.Count==0){await DisplayAlertAsync("Kies eerst iets","Vink aan welke samenvatting je wilt delen.","OK");return;}
            var payload=$"Mijn MoodPress weekoverzicht ({since:dd-MM-yyyy} t/m {DateTime.Today:dd-MM-yyyy})\n\n"+string.Join("\n\n",selected);
            if(await DisplayAlertAsync("Controleer wat je deelt",payload+"\n\nDit is gewone tekst, niet versleuteld. Iedereen die dit bericht ontvangt kan het lezen.","Delen","Annuleren"))
                await Share.Default.RequestAsync(new ShareTextRequest{Title="MoodPress - geselecteerd weekoverzicht",Text=payload});
        },quiet:true);
    }

    static string FourGEmoji(string feeling) => feeling switch { "Blij" => "😄", "Bedroefd" => "😢", "Boos" => "😠", "Bang" => "😨", _ => "🙂" };

    void BuildSettings()
    {
        Header("Instellingen", "Pas de app aan zodat hij prettig voor jou werkt. Vergrendelen wist je gegevens niet.");
        var size = AppUi.Picker("Lettergrootte", new[] { "Normaal", "Groot", "Extra groot" }, new[] { "Normaal", "Groot", "Extra groot" }[Math.Clamp(AppSession.Settings.TextSize, 0, 2)]);
        var theme = AppUi.Picker("Kleuren", new[] { "Rustig", "Donker", "Hoog contrast" }, AppSession.Settings.Theme);
        var autoLockOptions = new[] { "1 minuut", "5 minuten", "10 minuten", "30 minuten" };
        var selectedAutoLock = AppSession.Settings.AutoLockMinutes switch { 1 => "1 minuut", 10 => "10 minuten", 30 => "30 minuten", _ => "5 minuten" };
        var autoLock = AppUi.Picker("Automatisch vergrendelen na", autoLockOptions, selectedAutoLock);
        var font = AppUi.Picker("Lettertype", new[] { "Standaard", "Verdana", "Arial", "Georgia" }, AppSession.Settings.FontName);
        var profileOptions = new[] { "Algemeen", "Kind", "Jongere", "Volwassene" };
        var profile = AppUi.Picker("Mijn profiel / leeftijdsgroep", profileOptions, profileOptions.Contains(AppSession.Settings.AudienceProfile) ? AppSession.Settings.AudienceProfile : "Algemeen");
        var wide = new Switch { IsToggled = AppSession.Settings.WideLines, OnColor = AppUi.Accent };
        var read = new Switch { IsToggled = AppSession.Settings.ReadAloud, OnColor = AppUi.Accent };
        var anim = new Switch { IsToggled = AppSession.Settings.Animations, OnColor = AppUi.Accent };
        var capture = new Switch { IsToggled = AppSession.Settings.BlockCapture, OnColor = AppUi.Accent };
        var simplified = new Switch { IsToggled = AppSession.Settings.SimplifiedMode, OnColor = AppUi.Accent };
        wide.Toggled += (_, _) => AppSession.Touch();
        read.Toggled += (_, _) => AppSession.Touch();
        anim.Toggled += (_, _) => AppSession.Touch();
        capture.Toggled += (_, _) => AppSession.Touch();
        simplified.Toggled += (_, _) => AppSession.Touch();
        AddField("Lettergrootte", size); AddField("Kleuren", theme); AddField("Automatisch vergrendelen", autoLock); AddField("Lettertype", font); AddField("Mijn profiel", profile);
        AddLabel("Het profiel verandert de snelle ingangen en hulpmiddelen. Het geeft niemand anders toegang tot je gegevens en stelt geen diagnose.", muted: true);
        Add(new HorizontalStackLayout { Spacing = 8, Children = { wide, AppUi.Label("Ruime regelafstand") } });
        Add(new HorizontalStackLayout { Spacing = 8, Children = { read, AppUi.Label("Voorlezen beschikbaar maken") } });
        Add(new HorizontalStackLayout { Spacing = 8, Children = { anim, AppUi.Label("Animaties toestaan") } });
        Add(new HorizontalStackLayout { Spacing = 8, Children = { capture, AppUi.Label("Schermafbeeldingen blokkeren") } });
        Add(new HorizontalStackLayout { Spacing = 8, Children = { simplified, AppUi.Label("Vereenvoudigde startpagina") } });
        AddLabel("De vereenvoudigde startpagina toont minder tegels. Je andere gegevens en functies blijven bewaard en zijn via Instellingen weer zichtbaar te maken.", muted: true);
        AddLabel("Op Android voorkomt deze optie de meeste screenshots en schermopnames via de beveiligde vensterinstelling. Een tweede camera kan dit niet voorkomen.", muted: true);

        AddLabel("Snelkoppelingen op Home", title: true);
        var knownHomeKeys = FeatureCatalog.All.Select(x => x.Kind.ToString()).ToArray();
        var chosenHomeItems = HomeShortcutService.GetConfiguredOrDefault(AppSession.Settings, knownHomeKeys)
            .Select(key => FeatureCatalog.All.FirstOrDefault(x => x.Kind.ToString() == key))
            .Where(item => item is not null)
            .Select(item => item!.Icon + " " + item.Label)
            .ToArray();
        AddLabel(chosenHomeItems.Length == 0
            ? "Er zijn geen Home-snelkoppelingen gekozen."
            : "Huidige keuze: " + string.Join(" · ", chosenHomeItems), muted: true);
        AddLabel("Stel de volgorde en inhoud van je maximaal vier Home-tegels apart in. Zo blijft dit instellingenscherm overzichtelijk.", muted: true);
        AddButton("🧭 Home-snelkoppelingen instellen", () => _ = Navigation.PushAsync(new HomeShortcutSettingsPage()), quiet: true);

        AddLabel("Zichtbare functies", title: true);
        AddLabel("Vink aan wat je in de lijst met functies wilt zien. Verbergen verwijdert geen gegevens; Instellingen blijft ook via het tandwiel bereikbaar.", muted: true);
        var featureChecks = new List<(FeatureKind Kind, CheckBox CheckBox)>();
        foreach (var group in FeatureVisibilityOptions.GroupBy(x => x.Group))
        {
            AddLabel(group.Key, title: true);
            foreach (var option in group)
            {
                var check = new CheckBox { IsChecked = FeatureVisibilityService.IsEnabled(AppSession.Settings, option.Kind.ToString()), Color = AppUi.Accent, VerticalOptions = LayoutOptions.Center };
                featureChecks.Add((option.Kind, check));
                Add(new HorizontalStackLayout { Spacing = 8, Children = { check, AppUi.Label(option.Label) } });
            }
        }
        AddButton("Alles zichtbaar maken", () => { foreach (var item in featureChecks) item.CheckBox.IsChecked = true; }, quiet: true);
        AddAsyncButton("💾 Instellingen toepassen", async () =>
        {
            AppSession.Settings.TextSize = Math.Clamp(size.SelectedIndex, 0, 2);
            AppSession.Settings.Theme = theme.SelectedItem?.ToString() ?? "Rustig";
            AppSession.Settings.AutoLockMinutes = new[] { 1, 5, 10, 30 }[Math.Clamp(autoLock.SelectedIndex, 0, 3)];
            AppSession.Settings.FontName = font.SelectedItem?.ToString() ?? "Standaard";
            AppSession.Settings.AudienceProfile = profile.SelectedItem?.ToString() ?? "Algemeen";
            AppSession.Settings.WideLines = wide.IsToggled;
            AppSession.Settings.ReadAloud = read.IsToggled;
            AppSession.Settings.Animations = anim.IsToggled;
            AppSession.Settings.BlockCapture = capture.IsToggled;
            AppSession.Settings.SimplifiedMode = simplified.IsToggled;
            var allKeys = FeatureCatalog.All.Select(x => x.Kind.ToString()).ToArray();
            var pinnedHomeShortcuts = HomeShortcutService.GetConfiguredOrDefault(AppSession.Settings, allKeys);
            AppSession.Settings.FeatureVisibilityConfigured = true;
            // A Home shortcut must remain discoverable under Meer too, even if the visibility checkbox was unchecked.
            AppSession.Settings.EnabledFeatures = FeatureVisibilityService.NormalizeEnabled(
                featureChecks.Where(x => x.CheckBox.IsChecked).Select(x => x.Kind.ToString()).Concat(pinnedHomeShortcuts),
                allKeys);
            AppSession.SaveSettings(); AndroidScreenPrivacy.Apply(capture.IsToggled);
            await AppSession.UpdateRememberedSessionPolicyAsync();
            BackgroundColor = AppUi.Background; _root.BackgroundColor = AppUi.Background;
            Build();
            await DisplayAlertAsync("Opgeslagen", "Je instellingen zijn opgeslagen en toegepast.", "OK");
        });

        AddLabel("Wachtwoord wijzigen", title: true);
        var oldPassword = AppUi.Entry("Huidig wachtwoord", password: true);
        var newPassword = AppUi.Entry("Nieuw wachtwoord (minimaal 10 tekens)", password: true);
        var newPassword2 = AppUi.Entry("Nieuw wachtwoord herhalen", password: true);
        var pwStatus = AppUi.Label("");
        AddField("Huidig wachtwoord", oldPassword); AddField("Nieuw wachtwoord", newPassword); AddField("Herhaal nieuw wachtwoord", newPassword2); Add(pwStatus);
        AddAsyncButton("Wachtwoord wijzigen", async () =>
        {
            if (newPassword.Text != newPassword2.Text) { pwStatus.Text = "De nieuwe wachtwoorden zijn niet gelijk."; return; }
            bool ok = await Task.Run(() => AppSession.Accounts.ChangePassword(AppSession.Username, oldPassword.Text ?? "", newPassword.Text ?? ""));
            if (ok)
            {
                await AppSession.ClearRememberedSessionAsync();
                pwStatus.Text = "Wachtwoord gewijzigd ✔. Bij een volgende login kun je 'ingelogd blijven' opnieuw inschakelen.";
                oldPassword.Text = ""; newPassword.Text = ""; newPassword2.Text = "";
            }
            else
            {
                pwStatus.Text = "Niet gelukt. Controleer je huidige wachtwoord en gebruik minimaal 10 tekens.";
            }
        });

        AddLabel("Herstelcodes", title: true);
        AddLabel($"Je hebt nog {AppSession.Accounts.RecoveryCodesLeft(AppSession.Username)} herstelcode(s). Maak nieuwe codes als je er weinig over hebt. Oude codes vervallen.");
        var recoveryPassword = AppUi.Entry("Wachtwoord om herstelcodes te vernieuwen", password: true);
        AddField("Bevestig met wachtwoord", recoveryPassword);
        AddAsyncButton("🔑 Nieuwe herstelcodes maken", async () =>
        {
            var codes = await Task.Run(() => AppSession.Accounts.RegenerateRecoveryCodes(AppSession.Username, recoveryPassword.Text ?? ""));
            if (codes is null) { await DisplayAlertAsync("Niet gelukt", "Controleer je wachtwoord en probeer opnieuw.", "OK"); return; }
            string all = string.Join("\n", codes);
            await Clipboard.Default.SetTextAsync(all);
            await DisplayAlertAsync("Nieuwe herstelcodes", all + "\n\nDe codes zijn ook naar je klembord gekopieerd. Bewaar ze veilig, buiten deze telefoon.", "OK");
            recoveryPassword.Text = "";
        }, quiet: true);

        AddLabel("Back-up en gegevens", title: true);
        AddButton("📜 Deelgeschiedenis bekijken", () => Navigation.PushAsync(new ShareHistoryPage()), quiet:true);
        AddAsyncButton("💾 Back-up maken", CreateBackupAsync, quiet: true);
        AddAsyncButton("📦 Back-up terugzetten", RestoreBackupAsync, quiet: true);
        AddAsyncButton("📥 Leesbare gegevens exporteren", ExportDataAsync, quiet: true);
        AddLabel("Account verwijderen", title: true);
        var deletePassword = AppUi.Entry("Wachtwoord om definitief te verwijderen", password: true);
        AddField("Bevestig met wachtwoord", deletePassword);
        AddAsyncButton("🗑 Mijn account en alle gegevens verwijderen", async () =>
        {
            if (!await DisplayAlertAsync("Alles verwijderen?", "Je account, dagboek, tekeningen, agenda en andere gegevens worden definitief verwijderd. Maak eerst een back-up als je iets wilt bewaren.", "Verwijderen", "Annuleren")) return;
            if (!await DisplayAlertAsync("Weet je het zeker?", "Dit kan niet ongedaan worden gemaakt.", "Ja, definitief verwijderen", "Annuleren")) return;
            var ok = await Task.Run(() => AppSession.Accounts.DeleteAccount(AppSession.Username, deletePassword.Text ?? ""));
            if (ok)
            {
                // Een verwijderd account mag geen oude lokale timer- of routineherinneringen blijven activeren.
                FocusTimerNotifications.Cancel(Android.App.Application.Context);
                RoutineReminderNotifications.Sync(Android.App.Application.Context, Array.Empty<RoutineReminder>());
                await ((App)Application.Current!).LockToLoginAsync("Je account is verwijderd.", forgetRemembered: true);
            }
            else await DisplayAlertAsync("Niet gelukt", "Het account is niet verwijderd. Controleer je wachtwoord.", "OK");
        }, danger: true);

        AddLabel("Over MoodPress", title: true);
        AddLabel($"Versie {AppInfo.Current.VersionString}", muted: true);
        Add(AppUi.Copyright());
    }

    async Task CreateBackupAsync()
    {
        var path = System.IO.Path.Combine(FileSystem.CacheDirectory, $"MijnGevoel-backup-{DateTime.Now:yyyy-MM-dd-HHmm}.zip");
        await Task.Run(() => BackupService.Create(AppSession.Accounts, AppSession.Username, path));
        await DisplayAlertAsync("Bewaar de back-up privé", "De persoonlijke kluisbestanden zijn versleuteld, maar het ZIP-bestand zelf heeft geen apart wachtwoord. Deel het niet openbaar en bewaar het op een veilige plek.", "Verder");
        await Share.Default.RequestAsync(new ShareFileRequest { Title = "Bewaar je MoodPress-back-up privé", File = new ShareFile(path) });
    }

    async Task RestoreBackupAsync()
    {
        var result = await FilePicker.Default.PickAsync(new PickOptions { PickerTitle = "Kies een MoodPress-back-up (.zip)" });
        if (result is null) return;
        var temp = System.IO.Path.Combine(FileSystem.CacheDirectory, "mg-restore-" + Guid.NewGuid().ToString("N") + ".zip");
        try
        {
            await using (var src = await result.OpenReadAsync())
            await using (var dst = File.Create(temp))
            {
                var buffer = new byte[81920];
                long copied = 0;
                int read;
                while ((read = await src.ReadAsync(buffer)) > 0)
                {
                    copied += read;
                    if (copied > 512L * 1024 * 1024) throw new InvalidDataException("De back-up is groter dan 512 MB.");
                    await dst.WriteAsync(buffer.AsMemory(0, read));
                }
            }
            int count = await Task.Run(() => BackupService.Restore(AppSession.Accounts, temp));
            await DisplayAlertAsync("Back-up verwerkt", $"Er zijn {count} nieuwe bestanden teruggezet. Bestaande bestanden zijn niet overschreven. Mogelijk moet je uitloggen en opnieuw inloggen om een teruggezet account te gebruiken.", "OK");
        }
        catch (InvalidDataException ex)
        {
            await DisplayAlertAsync("Back-up geweigerd", ex.Message + " Er is niets uit een ongeldig archief teruggezet.", "OK");
        }
        catch (Exception ex)
        {
            AppLog.Write(ex);
            await DisplayAlertAsync("Terugzetten mislukt", "Het bestand kon niet veilig worden teruggezet. Controleer of je de juiste MoodPress-back-up hebt gekozen.", "OK");
        }
        finally { try { if (File.Exists(temp)) File.Delete(temp); } catch { } }
    }

    async Task ExportDataAsync()
    {
        if (!await DisplayAlertAsync("Leesbaar bestand", "Het JSON-exportbestand is niet versleuteld. Iedereen die het opent kan je persoonlijke gegevens lezen. Wil je doorgaan?", "Exporteren", "Annuleren")) return;
        var path = System.IO.Path.Combine(FileSystem.CacheDirectory, $"Mijn-gegevens-{DateTime.Now:yyyy-MM-dd-HHmm}.json");
        await Task.Run(() => ExportService.ExportAll(Store, AppSession.Username, path));
        await Share.Default.RequestAsync(new ShareFileRequest { Title = "Bewaar of exporteer je MoodPress-gegevens", File = new ShareFile(path) });
    }

    void BuildProfile()
    {
        Header("Mijn profiel", "Kies welke snelle ingangen het beste bij jou passen. Je kunt dit altijd veranderen.");
        var options = new[] { "Kind", "Jongere", "Volwassene", "Algemeen" };
        var profile = AppUi.Picker("Profiel", options, options.Contains(AppSession.Settings.AudienceProfile) ? AppSession.Settings.AudienceProfile : "Algemeen");
        AddField("Mijn profiel", profile);
        AddLabel("Kind: grote gevoel-/communicatie-ingangen en een voorspelbare dag.\nJongere: stress, grenzen, school, vrienden en gesprekshulp.\nVolwassene: werk, dagbesteding, energie en persoonlijke doelen.\nAlgemeen: alle bestaande functies zonder persoonlijk voorkeursprofiel.");
        AddAsyncButton("💾 Profiel bewaren", async () => { AppSession.Settings.AudienceProfile = profile.SelectedItem?.ToString() ?? "Algemeen"; AppSession.SaveSettings(); await DisplayAlertAsync("Opgeslagen", "Je profiel is opgeslagen. Ga terug naar het startscherm voor de passende snelkoppelingen.", "OK"); });
        AddButton("⚙️ Toegankelijkheid aanpassen", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Settings)), quiet:true);
    }

    void BuildYouthSupport()
    {
        Header("Stress en grenzen", "Voor school, thuis, online of met vrienden. Deze check-in blijft privé op jouw apparaat totdat jij iets deelt.");
        var situation = AppUi.Picker("Waar gaat het over?", new[] { "School", "Thuis", "Vrienden", "Online / pesten", "Werk of dagbesteding", "Anders" }, "School");
        var need = AppUi.Picker("Wat zou nu helpen?", new[] { "Even rust", "Iemand die luistert", "Praktische hulp", "Een veilige plek", "Hulp vragen", "Ik weet het nog niet" }, "Even rust");
        var level = new Slider { Minimum=1, Maximum=5, Value=3, ThumbColor=AppUi.Accent, MinimumTrackColor=AppUi.Accent };
        var levelLabel=AppUi.Label("Stressniveau: 3 van 5");
        level.ValueChanged += (_,e)=> { levelLabel.Text=$"Stressniveau: {(int)Math.Round(e.NewValue)} van 5"; AppSession.Touch(); };
        var note=AppUi.Editor("Wat gebeurde er? Wat wil je onthouden? (optioneel)",height:110); note.MaxLength=2000;
        var status=AppUi.Label("");
        AddField("Situatie",situation); AddField("Wat heb ik nodig?",need); AddLabel("Hoeveel stress voel je?",title:true); Add(level); Add(levelLabel); AddField("Notitie (privé)",note); Add(status);
        AddAsyncButton("💾 Check-in privé opslaan",async()=> { var id=Guid.NewGuid(); var item=new YouthSupportEntry(id,DateTime.Now,situation.SelectedItem?.ToString()??"Anders",(int)Math.Round(level.Value),need.SelectedItem?.ToString()??"Ik weet het nog niet",(note.Text??"").Trim()); Store.Save("youthsupport",id,item); status.Text="Opgeslagen ✔. Dit wordt niet automatisch gedeeld."; await DisplayAlertAsync("Opgeslagen","Je check-in blijft privé op dit apparaat.","OK"); });
        AddAsyncButton("🗣️ Zinnen om mijn grens aan te geven",async()=> { var chosen=await DisplayActionSheetAsync("Kies een zin om te laten zien","Annuleren",null,"Stop, dit vind ik niet fijn.","Ik heb even tijd nodig.","Ik wil niet dat je dit doorstuurt.","Ik wil graag hulp, maar ik weet niet hoe ik moet beginnen.","Ik hoef nu geen advies, luister alsjeblieft."); if(!string.IsNullOrWhiteSpace(chosen)&&chosen!="Annuleren"){await ShowBigCard("💬",chosen); if(AppSession.Settings.ReadAloud)AppUi.Speak(chosen);} },quiet:true);
        AddLabel("Mijn stappen bij online pesten",title:true);
        var plan=Store.Load<YouthSafetyPlan>("youthplan",Guid.Empty)??new YouthSafetyPlan();
        var trusted=AppUi.Entry("Vertrouwde persoon",plan.TrustedPerson); var place=AppUi.Entry("Veilige plek",plan.SafePlace); var next=AppUi.Editor("Wat doe ik als eerste? (bijv. screenshot bewaren, blokkeren en hulp vragen)",plan.NextStep,90); var online=AppUi.Editor("Mijn afspraken voor online veiligheid",plan.OnlineSteps,90);
        AddField("Wie kan ik vertrouwen?",trusted);AddField("Waar kan ik heen?",place);AddField("Eerste stap",next);AddField("Online afspraken",online);
        AddButton("💾 Veiligheidsafspraken bewaren",()=>{Store.Save("youthplan",Guid.Empty,new YouthSafetyPlan{TrustedPerson=(trusted.Text??"").Trim(),SafePlace=(place.Text??"").Trim(),NextStep=(next.Text??"").Trim(),OnlineSteps=(online.Text??"").Trim()});status.Text="Je afspraken zijn privé opgeslagen ✔";});
        AddLabel("Als je online wordt gepest: bewaar zo nodig bewijs, reageer niet als dat de situatie erger maakt, blokkeer/meld het account en vertel het aan iemand die je vertrouwt. Je hoeft dit niet alleen op te lossen.",muted:true);
        AddButton("📥 Voorstel van begeleider bekijken",()=>Navigation.PushAsync(new ReceiveSupportPackagePage()),quiet:true);
        AddLabel("Mijn recente check-ins",title:true);
        var items=Store.All<YouthSupportEntry>("youthsupport").OrderByDescending(x=>x.Created).Take(10).ToList();
        if(items.Count==0)AddLabel("Je hebt nog geen check-ins opgeslagen.");
        foreach(var item in items){var entry=item;Add(AppUi.Card(new VerticalStackLayout{Spacing=4,Children={AppUi.Label($"{entry.Created:dd-MM-yyyy HH:mm} · {entry.Situation}",title:true),AppUi.Label($"Stress: {entry.StressLevel}/5 · Nodig: {entry.Need}"),AppUi.Label(entry.Note),AppUi.Button("🗑 Verwijderen",()=>{Store.Delete("youthsupport",entry.Id);AppSession.Touch();Build();},quiet:true)}}));}
        var recent30=Store.All<YouthSupportEntry>("youthsupport").Where(x=>x.Created.Date>=DateTime.Today.AddDays(-29)).OrderByDescending(x=>x.Created).ToList();
        AddLabel("Mijn eigen terugblik (laatste 30 dagen)",title:true);
        if(recent30.Count==0) AddLabel("Als je check-ins bewaart, kun je hier later terugzien wat je hebt ingevuld.");
        else
        {
            var avg=recent30.Average(x=>x.StressLevel);
            var common=recent30.GroupBy(x=>x.Situation).OrderByDescending(g=>g.Count()).First();
            Add(AppUi.Card(AppUi.Stack(AppUi.Label($"Je hebt {recent30.Count} check-ins bewaard."),AppUi.Label($"Gemiddeld ingevuld stressniveau: {avg:0.0}/5. Dit is alleen een samenvatting van jouw invoer, geen diagnose."),AppUi.Label($"Meest gekozen situatie: {common.Key} ({common.Count()} keer)."),AppUi.Label("Je mag je check-ins bekijken, bespreken of verwijderen. Er wordt niets automatisch gedeeld."))));
            foreach(var group in recent30.GroupBy(x=>x.Need).OrderByDescending(g=>g.Count()).Take(3)) AddLabel($"Wat je vaak aangaf nodig te hebben: {group.Key} ({group.Count()} keer)");
        }
    }

    void BuildAdultPlanning()
    {
        Header("Werk, dagbesteding en doelen", "Plan haalbare stappen voor werk, dagbesteding, school of thuis. Een doel is geen verplichting of score.");
        var editingGoal = _editingAdultGoalId is Guid editId ? Store.Load<AdultGoal>("adultgoal", editId) : null;
        if (_editingAdultGoalId is not null && editingGoal is null) _editingAdultGoalId = null;
        var areas = new[] { "Werk", "Dagbesteding", "School / opleiding", "Thuis", "Sociaal", "Gezondheid / rust", "Anders" };
        var area = AppUi.Picker("Gebied", areas, editingGoal?.Area ?? "Dagbesteding");
        var title = AppUi.Entry("Mijn kleine doel (bijv. maandag één taak afronden)", editingGoal?.Title ?? ""); title.MaxLength = 250;
        var step = AppUi.Editor("Eerste kleine stap (optioneel)", editingGoal?.FirstStep ?? "", height: 80); step.MaxLength = 1000;
        var furtherSteps = AppUi.Editor("Verdere stappen (één per regel; optioneel)", editingGoal is null ? "" : string.Join("\n", editingGoal.Steps ?? Array.Empty<string>()), height: 120); furtherSteps.MaxLength = 10000;
        var hasDueDate = new CheckBox { Color = AppUi.Accent, IsChecked = editingGoal?.TargetDate is not null };
        var due = new DatePicker { Date = editingGoal?.TargetDate?.Date ?? DateTime.Today.AddDays(7), MinimumDate = DateTime.Today.AddYears(-10), Format = "dddd d MMMM", TextColor = AppUi.Foreground, BackgroundColor = AppUi.Surface, IsEnabled = hasDueDate.IsChecked };
        hasDueDate.CheckedChanged += (_, e) => due.IsEnabled = e.Value;
        var status = AppUi.Label("");
        AddField("Gebied", area); AddField("Doel", title); AddField("Eerste stap", step); AddField("Verdere stappen", furtherSteps);
        Add(new HorizontalStackLayout { Spacing = 8, Children = { hasDueDate, AppUi.Label("Een streefdatum instellen (optioneel)") } }); AddField("Streefdatum", due); Add(status);
        var saveGoalLabel = editingGoal is null ? "🎯 Doel opslaan" : "💾 Wijzigingen opslaan";
        AddAsyncButton(saveGoalLabel, async () =>
        {
            var t = (title.Text ?? "").Trim();
            if (t.Length < 2 || t.Length > 250) { status.Text = "Vul een doel van 2 tot 250 tekens in."; return; }
            string[] steps;
            try { steps = GoalStepService.Parse(furtherSteps.Text); }
            catch (ArgumentException ex) { status.Text = ex.Message; return; }
            if ((step.Text?.Length ?? 0) > 1000) { status.Text = "De eerste stap mag maximaal 1000 tekens bevatten."; return; }
            var old = _editingAdultGoalId is Guid selectedId ? Store.Load<AdultGoal>("adultgoal", selectedId) : null;
            if (_editingAdultGoalId is not null && old is null) { status.Text = "Dit doel bestaat niet meer. Open het doel opnieuw."; _editingAdultGoalId = null; return; }
            var id = old?.Id ?? Guid.NewGuid();
            DateTime? target = hasDueDate.IsChecked ? due.Date.Date : null;
            var goal = new AdultGoal(id, old?.Created ?? DateTime.Now, area.SelectedItem?.ToString() ?? "Anders", t, (step.Text ?? "").Trim(), target, old?.Done ?? false)
            { Reflection = old?.Reflection ?? "", Steps = steps };
            Store.Save("adultgoal", id, goal);
            _editingAdultGoalId = null;
            AppSession.Touch();
            await DisplayAlertAsync("Opgeslagen", old is null ? "Je doel en stappen staan privé in MoodPress." : "Je doel is aangepast en opnieuw opgeslagen.", "OK");
            Build();
        });
        if (editingGoal is not null) AddButton("Bewerken annuleren", () => { _editingAdultGoalId = null; Build(); }, quiet: true);

        AddLabel("Energie na werk of dagbesteding", title: true);
        var context = AppUi.Picker("Moment", new[] { "Voor werk/dagbesteding", "Na werk/dagbesteding", "Na school", "Na sociale activiteit", "Thuis / algemeen" }, "Na werk/dagbesteding");
        var energy = new Slider { Minimum = 1, Maximum = 5, Value = 3, ThumbColor = AppUi.Accent, MinimumTrackColor = AppUi.Accent };
        var energyLabel = AppUi.Label("Energie: 3 van 5"); energy.ValueChanged += (_, e) => energyLabel.Text = $"Energie: {(int)Math.Round(e.NewValue)} van 5";
        var energyNote = AppUi.Entry("Korte notitie (optioneel)"); energyNote.MaxLength = 500;
        AddField("Context", context); Add(energy); Add(energyLabel); Add(energyNote);
        AddButton("⚡ Energie opslaan", () => { var id = Guid.NewGuid(); Store.Save("energy", id, new EnergyEntry(id, DateTime.Now, context.SelectedItem?.ToString() ?? "Algemeen", (int)Math.Round(energy.Value), (energyNote.Text ?? "").Trim())); status.Text = "Energiemeting opgeslagen ✔"; Build(); });

        AddLabel("Mijn doelen", title: true);
        var goals = Store.All<AdultGoal>("adultgoal").OrderBy(x => x.Done).ThenBy(x => x.TargetDate ?? DateTime.MaxValue).ThenByDescending(x => x.Created).Take(50).ToList();
        if (goals.Count == 0) AddLabel("Je hebt nog geen doelen toegevoegd.");
        foreach (var g in goals)
        {
            var local = g;
            var panel = new VerticalStackLayout { Spacing = 4, Children = { AppUi.Label($"{(local.Done ? "✅" : "🎯")} {local.Title}", title: true), AppUi.Label(local.Area + (local.TargetDate is DateTime dt ? $" · Streefdatum {dt:dd-MM-yyyy}" : "")) } };
            if (!string.IsNullOrWhiteSpace(local.FirstStep)) panel.Children.Add(AppUi.Label("Eerste stap: " + local.FirstStep));
            var stepsForDisplay = local.Steps ?? Array.Empty<string>();
            for (var index = 0; index < stepsForDisplay.Length; index++) panel.Children.Add(AppUi.Label($"{index + 2}. {stepsForDisplay[index]}"));
            if (!string.IsNullOrWhiteSpace(local.Reflection)) panel.Children.Add(AppUi.Label("Wat ik wil onthouden: " + local.Reflection));
            panel.Children.Add(AppUi.Button("✏️ Doel aanpassen", () => { _editingAdultGoalId = local.Id; Build(); }, quiet: true));
            panel.Children.Add(AppUi.AsyncButton(local.Done ? "↩️ Doel opnieuw openen" : "✅ Als afgerond markeren", async () =>
            {
                var reflection = local.Reflection;
                if (!local.Done)
                {
                    var add = await DisplayAlertAsync("Wat hielp?", "Wil je kort noteren wat jou hielp of waar je trots op bent?", "Ja", "Overslaan");
                    if (add)
                    {
                        var entered = await DisplayPromptAsync("Positieve terugblik", "Wat wil je onthouden?", "Bewaren", "Annuleren", maxLength: 500, initialValue: local.Reflection);
                        if (entered is null) return;
                        reflection = entered.Trim();
                    }
                }
                Store.Save("adultgoal", local.Id, local with { Done = !local.Done, Reflection = reflection }); Build();
            }, quiet: true));
            panel.Children.Add(AppUi.AsyncButton("🗑 Doel verwijderen", async () => { if (await DisplayAlertAsync("Doel verwijderen?", "Dit doel en de stappen worden verwijderd.", "Verwijderen", "Annuleren")) { Store.Delete("adultgoal", local.Id); if (_editingAdultGoalId == local.Id) _editingAdultGoalId = null; Build(); } }, quiet: true));
            Add(AppUi.Card(panel));
        }
        AddLabel("Energie en terugblik", title: true);
        var allEnergy = Store.All<EnergyEntry>("energy").OrderByDescending(x => x.Created).ToList();
        var last7 = allEnergy.Where(x => x.Created.Date >= DateTime.Today.AddDays(-6)).ToList(); var last30 = allEnergy.Where(x => x.Created.Date >= DateTime.Today.AddDays(-29)).ToList();
        if (allEnergy.Count == 0) AddLabel("Nog geen energiemetingen.");
        else Add(AppUi.Card(AppUi.Stack(AppUi.Label($"Laatste 7 dagen: {last7.Count} metingen; gemiddeld {(last7.Count == 0 ? 0 : last7.Average(x => x.EnergyLevel)):0.0}/5."), AppUi.Label($"Laatste 30 dagen: {last30.Count} metingen; gemiddeld {(last30.Count == 0 ? 0 : last30.Average(x => x.EnergyLevel)):0.0}/5."), AppUi.Label("Deze cijfers vatten alleen jouw invoer samen. Ze stellen geen diagnose en hoeven niet gedeeld te worden."))));
        var entries = allEnergy.Take(10).ToList();
        foreach (var e in entries) { var local = e; var panel = AppUi.Stack(AppUi.Label($"{local.Created:dd-MM HH:mm} · {local.Context}: energie {local.EnergyLevel}/5", title: true)); if (!string.IsNullOrWhiteSpace(local.Note)) panel.Children.Add(AppUi.Label(local.Note)); panel.Children.Add(AppUi.Button("🗑 Deze energiemeting verwijderen", () => { Store.Delete("energy", local.Id); Build(); }, quiet: true)); Add(AppUi.Card(panel)); }
        AddButton("📤 Mijn doelen en energieoverzicht delen…", async () => { var share = string.Join("\n", goals.Where(g => !g.Done).Select(g => $"• {g.Area}: {g.Title} (eerste stap: {g.FirstStep}; vervolgstappen: {string.Join(", ", g.Steps ?? Array.Empty<string>())})")); var last = string.Join("\n", entries.Select(e => $"• {e.Created:dd-MM}: {e.Context} — energie {e.EnergyLevel}/5")); var text = $"Mijn MoodPress-overzicht (zelf geselecteerd)\n\nDoelen:\n{share}\n\nEnergie:\n{last}"; if (await DisplayAlertAsync("Privégegevens delen?", "Dit overzicht bevat persoonlijke gegevens. Het wordt pas gedeeld als je bevestigt.", "Delen", "Annuleren")) await Share.Default.RequestAsync(new ShareTextRequest { Title = "Mijn MoodPress-overzicht", Text = text }); }, quiet: true);
        AddLabel("Energie- en doeloverzichten zijn hulpmiddelen voor eigen reflectie. Ze geven geen medische diagnose en worden niet automatisch aan een begeleider gestuurd.", muted: true);
    }

    void BuildWellbeing()
    {
        Header("Mijn welzijn", "Houd alleen bij wat jij zelf wilt: slaap, beweging, energie of een korte notitie. Dit is jouw eigen terugblik, geen medische meting.");
        var includeSleep = new Switch { IsToggled = false, OnColor = AppUi.Accent };
        var sleep = new Slider { Minimum = 1, Maximum = 5, Value = 3, ThumbColor = AppUi.Accent, MinimumTrackColor = AppUi.Accent, IsEnabled = false };
        var sleepLabel = AppUi.Label("Slaapkwaliteit overslaan");
        includeSleep.Toggled += (_, e) => { sleep.IsEnabled = e.Value; sleepLabel.Text = e.Value ? $"Slaapkwaliteit: {(int)Math.Round(sleep.Value)} van 5" : "Slaapkwaliteit overslaan"; };
        sleep.ValueChanged += (_, e) => sleepLabel.Text = $"Slaapkwaliteit: {(int)Math.Round(e.NewValue)} van 5";

        var includeMovement = new Switch { IsToggled = false, OnColor = AppUi.Accent };
        var movement = AppUi.Entry("Beweging in minuten (0 t/m 1440)", keyboard: Keyboard.Numeric);
        movement.IsEnabled = false;
        includeMovement.Toggled += (_, e) => { movement.IsEnabled = e.Value; if (!e.Value) movement.Text = ""; };

        var includeEnergy = new Switch { IsToggled = false, OnColor = AppUi.Accent };
        var energy = new Slider { Minimum = 1, Maximum = 5, Value = 3, ThumbColor = AppUi.Accent, MinimumTrackColor = AppUi.Accent, IsEnabled = false };
        var energyLabel = AppUi.Label("Energie overslaan");
        includeEnergy.Toggled += (_, e) => { energy.IsEnabled = e.Value; energyLabel.Text = e.Value ? $"Energie: {(int)Math.Round(energy.Value)} van 5" : "Energie overslaan"; };
        energy.ValueChanged += (_, e) => energyLabel.Text = $"Energie: {(int)Math.Round(e.NewValue)} van 5";

        var note = AppUi.Editor("Korte welzijnsnotitie (optioneel)", height: 90); note.MaxLength = 1000;
        var status = AppUi.Label("");
        Guid? editingId = null;
        var saveButton = AppUi.Button("💾 Welzijn opslaan", () => SaveWellbeing());

        void LoadEntry(WellbeingEntry entry)
        {
            editingId = entry.Id;
            includeSleep.IsToggled = entry.SleepQuality > 0;
            sleep.Value = Math.Clamp(entry.SleepQuality > 0 ? entry.SleepQuality : 3, 1, 5);
            includeMovement.IsToggled = entry.MovementMinutes >= 0;
            movement.Text = entry.MovementMinutes >= 0 ? entry.MovementMinutes.ToString(CultureInfo.InvariantCulture) : "";
            includeEnergy.IsToggled = entry.EnergyLevel > 0;
            energy.Value = Math.Clamp(entry.EnergyLevel > 0 ? entry.EnergyLevel : 3, 1, 5);
            note.Text = entry.Note;
            saveButton.Text = "💾 Wijzigingen opslaan";
            status.Text = $"Je past de registratie van {entry.Created:dd-MM-yyyy HH:mm} aan.";
        }

        void ResetForm()
        {
            editingId = null; includeSleep.IsToggled = false; sleep.Value = 3; includeMovement.IsToggled = false; movement.Text = ""; includeEnergy.IsToggled = false; energy.Value = 3; note.Text = ""; saveButton.Text = "💾 Welzijn opslaan"; status.Text = "Nieuwe registratie.";
        }

        void SaveWellbeing()
        {
            var movementValue = -1;
            if (includeMovement.IsToggled && (!int.TryParse(movement.Text, NumberStyles.Integer, CultureInfo.InvariantCulture, out movementValue) || movementValue is < 0 or > 1440))
            { status.Text = "Vul beweging in minuten in, van 0 tot en met 1440."; return; }
            try
            {
                var old = editingId is Guid id ? Store.Load<WellbeingEntry>("wellbeing", id) : null;
                if (editingId is not null && old is null) { status.Text = "Deze registratie bestaat niet meer. Kies een andere of begin opnieuw."; ResetForm(); return; }
                var isUpdate = editingId is not null;
                var entry = WellbeingEntryService.Create(editingId ?? Guid.NewGuid(), old?.Created ?? DateTime.Now, includeSleep.IsToggled, (int)Math.Round(sleep.Value), includeMovement.IsToggled, movementValue, includeEnergy.IsToggled, (int)Math.Round(energy.Value), note.Text);
                Store.Save("wellbeing", entry.Id, entry); AppSession.Touch();
                ResetForm(); status.Text = isUpdate ? "Wijzigingen opgeslagen." : "Welzijnsregistratie opgeslagen."; ReloadList();
            }
            catch (ArgumentException ex) { status.Text = ex.Message; }
        }

        var history = new VerticalStackLayout { Spacing = 8 };
        void ReloadList()
        {
            history.Children.Clear();
            var items = Store.All<WellbeingEntry>("wellbeing").OrderByDescending(x => x.Created).Take(30).ToList();
            if (items.Count == 0) { history.Children.Add(AppUi.Label("Er zijn nog geen welzijnsregistraties. Je hoeft niets bij te houden als je dat niet wilt.", muted: true)); return; }
            foreach (var item in items)
            {
                var summary = new List<string>();
                if (item.SleepQuality > 0) summary.Add($"slaapkwaliteit {item.SleepQuality}/5");
                if (item.MovementMinutes >= 0) summary.Add($"beweging {item.MovementMinutes} min");
                if (item.EnergyLevel > 0) summary.Add($"energie {item.EnergyLevel}/5");
                if (!string.IsNullOrWhiteSpace(item.Note)) summary.Add(item.Note);
                var card = new VerticalStackLayout { Spacing = 4, Children = { AppUi.Label(item.Created.ToString("dd-MM-yyyy HH:mm", CultureInfo.GetCultureInfo("nl-NL")), title: true), AppUi.Label(string.Join(" · ", summary)) } };
                card.Children.Add(AppUi.Button("✏️ Aanpassen", () => LoadEntry(item), quiet: true));
                card.Children.Add(AppUi.AsyncButton("🗑 Verwijderen", async () => { if (await DisplayAlertAsync("Registratie verwijderen?", "Deze welzijnsnotitie wordt definitief verwijderd.", "Verwijderen", "Annuleren")) { Store.Delete("wellbeing", item.Id); if (editingId == item.Id) ResetForm(); ReloadList(); } }, quiet: true));
                history.Children.Add(AppUi.Card(card));
            }
        }

        AddLabel("Slaapkwaliteit (1 = slecht uitgerust, 5 = goed uitgerust)", title: true);
        Add(new HorizontalStackLayout { Spacing = 8, Children = { includeSleep, AppUi.Label("Slaap bijhouden") } }); Add(sleep); Add(sleepLabel);
        Add(new HorizontalStackLayout { Spacing = 8, Children = { includeMovement, AppUi.Label("Beweging bijhouden") } }); AddField("Beweging (minuten)", movement);
        Add(new HorizontalStackLayout { Spacing = 8, Children = { includeEnergy, AppUi.Label("Energie bijhouden") } }); Add(energy); Add(energyLabel);
        AddField("Notitie", note); Add(status); Add(saveButton); AddButton("Leeg formulier", ResetForm, quiet: true);
        AddLabel("Mijn laatste registraties", title: true); Add(history); ReloadList();
    }

    void BuildHelp()
    {
        Header("Hulp", "Wat kun je doen in MoodPress?");
        AddLabel("😄 Hoe voel ik me? Kies een grote knop: blij, bedroefd, boos of bang. Bij een moeilijk gevoel zie je eenvoudige hulpknoppen.");
        AddLabel("🚦 Stoplicht: laat zien hoe het met je gaat en waarom. De app waarschuwt geen begeleiders automatisch. Je eigen routineherinneringen kunnen wel op gekozen tijden pop-ups tonen.");
        AddLabel("🗓️ Mijn dag: bekijk vandaag of morgen, plan activiteiten en gebruik een timer of stappenplan.");
        AddLabel("⏰ Routines: maak persoonlijke herinneringen met tijd, herhaling, picto en meldingsgeluid.");
        AddLabel("🌿 Rust en gevoel: ademhalen met een bewegende cirkel en optionele muziek, rusttips, prikkelmeter, lichaam en gevoelswoorden.");
        AddLabel("💬 Praten en delen: laat een kaart zien, bereid een gesprek voor, neem een spraaknotitie op of deel geselecteerde meldingen.");
        AddLabel("👥 Wie werkt er? Bekijk het weekrooster van begeleiders. Je kunt namen en foto's zelf bijhouden.");
        AddLabel("🧒 Kindprofiel: gebruik het visuele dagschema, grote gevoels- en communicatiekaarten, de voorleesknop en de eigen helpkaart.");
        AddLabel("🧑‍🎓 Jongerenprofiel: houd stress privé bij, bewaar afspraken rond online pesten, bekijk een eigen terugblik en kies zelf wat je deelt.");
        AddLabel("🧭 Volwassenenprofiel: werk met doelen, streefdata, positieve terugblik en energieoverzichten voor werk of dagbesteding.");
        AddLabel("🛟 Ouder / voogd / begeleider: op het inlogscherm staat een aparte lokale ingang met een eigen toegangscode, een ondersteuningsplan, gespreksvragen en een uitleg van het stoplicht.");
        AddLabel("🔐 Delen met ondersteuning: vink alleen de onderdelen aan die je wilt delen. Het pakket is versleuteld en blijft een momentopname; er is geen automatische online koppeling of automatische alarmmelding.");
        AddLabel("🎨 Maken en schrijven: teken, schrijf van je af of houd een dagboek bij. Je kunt uitleg laten voorlezen als dat aanstaat in Instellingen.");
        AddLabel("🔐 Privacy: gegevens staan versleuteld op dit apparaat. Maak een back-up voordat je de app verwijdert of je account wist.");
        AddLabel("Als je je heel erg slecht voelt of zorgen hebt over jezelf, praat dan met iemand die je vertrouwt, zoals een begeleider, familielid of huisarts. In Nederland kun je gratis bellen met 113 Zelfmoordpreventie: 0800-0113, dag en nacht. Is er direct gevaar? Bel 112.");
        AddButton("Mijn privacy bekijken", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Privacy)));
    }
}
