using System;
using System.Collections.Generic;
using System.Linq;

namespace MijnGevoel.AndroidApp;

public sealed record FeatureCatalogItem(FeatureKind Kind, string Label, string Icon, string Group, string Description);

/// <summary>One consistent, searchable directory for the feature menu and visibility settings.</summary>
public static class FeatureCatalog
{
    public static IReadOnlyList<FeatureCatalogItem> All { get; } = new FeatureCatalogItem[]
    {
        new(FeatureKind.DayToday, "Vandaag", "🗓️", "Mijn dag en planning", "Bekijk de planning van vandaag."),
        new(FeatureKind.DayTomorrow, "Morgen", "🌙", "Mijn dag en planning", "Bekijk wat er morgen op de planning staat."),
        new(FeatureKind.Agenda, "Agenda", "📅", "Mijn dag en planning", "Beheer afspraken en activiteiten."),
        new(FeatureKind.Timer, "Timer", "⏳", "Mijn dag en planning", "Gebruik een timer voor een activiteit of pauze."),
        new(FeatureKind.Routines, "Stappenplannen", "✅", "Mijn dag en planning", "Voer een taak stap voor stap uit."),
        new(FeatureKind.RoutineReminders, "Routines en herinneringen", "⏰", "Mijn dag en planning", "Beheer zelfgekozen routineherinneringen."),
        new(FeatureKind.ChildSchedule, "Visueel dagschema", "🧩", "Mijn dag en planning", "Bekijk een visuele, afvinkbare dagplanning."),
        new(FeatureKind.WhoWorks, "Wie werkt er?", "👥", "Mijn dag en planning", "Bekijk de door jou ingestelde informatie over ondersteuning."),

        new(FeatureKind.DailyCheckIn, "Mijn gevoel", "😊", "Mijn gevoel en rust", "Kies en registreer hoe je je voelt."),
        new(FeatureKind.MoodHistory, "Gevoelsoverzicht", "📊", "Mijn gevoel en rust", "Bekijk eerdere gevoelsregistraties."),
        new(FeatureKind.FeelingWords, "Gevoelswoorden", "📖", "Mijn gevoel en rust", "Vind woorden voor wat je ervaart."),
        new(FeatureKind.MoodCalendar, "Gevoelskalender", "🗓️", "Mijn gevoel en rust", "Bekijk je check-ins op een kalender."),
        new(FeatureKind.MoodInsights, "Mijn inzichten", "📈", "Mijn gevoel en rust", "Bekijk een overzicht van je eigen registraties."),
        new(FeatureKind.Breath, "Ademhalen", "🌬️", "Mijn gevoel en rust", "Open een rustige ademhalingsoefening."),
        new(FeatureKind.Calm, "Mijn rustplek", "🌲", "Mijn gevoel en rust", "Bekijk je persoonlijke rustopties."),
        new(FeatureKind.Sensory, "Prikkelmeter", "🎚️", "Mijn gevoel en rust", "Geef zelf aan hoeveel prikkels je ervaart."),
        new(FeatureKind.Body, "Mijn lichaam", "🧍", "Mijn gevoel en rust", "Noteer wat je in je lichaam merkt."),
        new(FeatureKind.Stoplicht, "Mijn stoplicht", "🚦", "Mijn gevoel en rust", "Gebruik je persoonlijke stoplicht."),
        new(FeatureKind.StoplichtHistory, "Stoplicht-overzicht", "📊", "Mijn gevoel en rust", "Bekijk eerdere stoplichtregistraties."),

        new(FeatureKind.Cards, "Communicatiekaarten", "💬", "Communicatie en steun", "Laat zien wat je nodig hebt met een kaart."),
        new(FeatureKind.TalkPrep, "Gesprek voorbereiden", "🗣️", "Communicatie en steun", "Bereid een gesprek voor."),
        new(FeatureKind.Share, "Delen met mijn begeleider", "📤", "Communicatie en steun", "Kies zelf welke informatie je wilt delen."),
        new(FeatureKind.SafetyPlan, "Mijn helpkaart en plan", "🆘", "Communicatie en steun", "Bekijk persoonlijke hulpopties en contactgegevens."),
        new(FeatureKind.ShareSupport, "Ondersteuningspakket delen", "🔐", "Communicatie en steun", "Maak een pakket van informatie die je bewust kiest."),
        new(FeatureKind.ReceiveSupport, "Voorstel ontvangen", "📥", "Communicatie en steun", "Bekijk een ondersteuningsvoorstel dat je ontvangt."),

        new(FeatureKind.YouthSupport, "Stress en grenzen", "🧠", "Doelen en zelfstandigheid", "Denk na over stress, grenzen en situaties."),
        new(FeatureKind.AdultPlanning, "Werk, dagbesteding en doelen", "🧭", "Doelen en zelfstandigheid", "Werk aan persoonlijke planning en doelen."),
        new(FeatureKind.Wellbeing, "Mijn welzijn", "🌱", "Doelen en zelfstandigheid", "Houd zelfgekozen welzijnsnotities bij."),
        new(FeatureKind.Profile, "Mijn profiel", "🧑", "Doelen en zelfstandigheid", "Stel je profiel en hulpmiddelen in."),

        new(FeatureKind.Draw, "Tekenen", "🎨", "Creatief en dagboek", "Maak een tekening."),
        new(FeatureKind.Gallery, "Mijn tekeningen", "🖼️", "Creatief en dagboek", "Bekijk je opgeslagen tekeningen."),
        new(FeatureKind.Notes, "Van me afschrijven", "📝", "Creatief en dagboek", "Schrijf iets voor jezelf op."),
        new(FeatureKind.Journal, "Dagboek", "📓", "Creatief en dagboek", "Bekijk en beheer je dagboeknotities."),

        new(FeatureKind.Privacy, "Mijn privacy", "🔐", "Profiel, privacy en hulp", "Lees hoe je gegevens worden gebruikt."),
        new(FeatureKind.Week, "Weekoverzicht", "🗒️", "Profiel, privacy en hulp", "Bekijk je eigen weekoverzicht."),
        new(FeatureKind.Settings, "Instellingen", "⚙️", "Profiel, privacy en hulp", "Pas weergave, toegang en voorkeuren aan."),
        new(FeatureKind.Help, "Hulp", "❓", "Profiel, privacy en hulp", "Lees uitleg over de app.")
    };

    public static FeatureCatalogItem Get(FeatureKind kind) => All.First(x => x.Kind == kind);
}
