# MoodPress Tablet 2.5.0 — release candidate

Tabletvariant van dezelfde actuele .NET MAUI/C#-broncode als MoodPress Android 2.5.0. De eigen package-id is `nl.mijngevoel.app.tablet`, zodat de tabletapp gescheiden blijft van de telefoonapp. Het Home- en Meer-raster past zich aan de beschikbare breedte aan.

Dit is broncode, nog geen door deze werkomgeving gebouwde APK. De tabletbuildworkflow moet de tests en Android-compile uitvoeren; daarna zijn fysieke tablet-, landscape-, tekstgrootte- en TalkBack-tests verplicht. Raadpleeg `docs/quality/ANDROID-ACCEPTATIETEST-2.5.0.md`.
