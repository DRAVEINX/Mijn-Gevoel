# MoodPress 2.5.0 — GitHub upload, build en release runbook

## A. Upload zonder bestaande versies te overschrijven

1. Maak (als repository-onderhoud) eerst een nieuwe commit/back-up van de huidige hoofdmap.
2. Upload `MoodPress-Android-compleet-2.5.0.zip` naar de hoofdmap van de repository.
3. Upload `MoodPress-Android-Tablet-2.5.0.zip` naar de hoofdmap van de repository.
4. Upload de vier workflows uit het geleverde uploadpakket naar `.github/workflows/`:
   - `android-apk-2.5.0.yml`
   - `android-release-2.5.0.yml`
   - `android-tablet-apk-2.5.0.yml`
   - `android-tablet-release-2.5.0.yml`
5. Laat de bestaande 2.3.0- en eerdere workflows staan. De app IDs van phone en tablet blijven verschillend: `nl.mijngevoel.app` en `nl.mijngevoel.app.tablet`.

## B. Testbuilds (eerst doen)

- Start `MoodPress 2.5.0 — Android APK` via Actions / Run workflow.
- Start `MoodPress Tablet 2.5.0 — Android APK` via Actions / Run workflow.
- Beide testworkflows gebruiken `.debug` app IDs (`nl.mijngevoel.app.debug`, `nl.mijngevoel.app.tablet.debug`) zodat ze niet met de ondertekende app-ID kunnen botsen.
- Vereist: alle Core-tests slagen, alle statische controles slagen en Debug APK bouwt met de juiste app properties.
- Download de artifacts alleen uit de bijbehorende groene run. Controleer `SHA256SUMS.txt`.

## C. Ondertekende release (pas na testbuild + acceptatie)

- Phone release: `android-release-2.5.0.yml`.
- Tablet release: `android-tablet-release-2.5.0.yml`.
- Vereiste repository secrets (gebruik bestaande secrets alleen; deel ze nooit in issues/chat): `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_PASSWORD`, `ANDROID_KEY_ALIAS`.
- De releaseworkflow test eerst Core, maakt ondertekende APK + AAB, verifieert de APK/AAB-signature waar de tools beschikbaar zijn en publiceert artifact + checksum.
- Deze workflow maakt artifacts in GitHub Actions; ze publiceert niet automatisch een GitHub Release of Google Play listing.

## D. Installatie-/rollbackplan

- Installeer een ondertekende release over de vorige app met dezelfde app ID en signing key; test dat bestaande data bewaard blijft.
- Debug APK is een aparte testapp. Gegevens in `.debug` zijn niet bedoeld om over te zetten naar productie.
- Voer account verwijderen, backup/herstel en export alleen uit met demo-data tijdens acceptatie.
- Als er crash, dataverlies, foutieve handtekening of privacyprobleem is: stop release, bewaar run-ID/logs zonder persoonlijke inhoud, ga terug naar de vorige stabiele versie, maak geen hotfix zonder opnieuw alle gates te draaien.

## E. Eerlijk releasebesluit

Build groen = compiles/testworkflow groen. Het is niet gelijk aan bewezen UX, veilige opslag op ieder toestel of AVG-goedkeuring. Voltooi de handmatige acceptatietest, documenteer apparaat/Androidversie en laat open security/privacyvragen beoordelen voordat publieke productie-uitrol plaatsvindt.
