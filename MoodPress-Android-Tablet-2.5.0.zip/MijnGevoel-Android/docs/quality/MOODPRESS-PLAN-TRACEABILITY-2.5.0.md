# MoodPress — traceability van het volledige ontwikkelplan 2.5.0

Datum: 14 oktober 2026  
Status: release candidate; code-inventarisatie, geen claim dat fysieke tests of onafhankelijke beoordelingen al zijn afgerond.

## Hoe de status gelezen moet worden

- **In code** betekent dat een implementatie in de huidige kandidaat is gevonden; het is geen bewijs dat elk apparaatgedrag klopt.
- **Automatisch te testen** betekent dat Core-tests/CI dit kunnen controleren wanneer de workflow is uitgevoerd.
- **Handmatig open** betekent dat een echte installatie, toegankelijke bediening, inhoudelijke beoordeling of onafhankelijke controle bewijs moet opleveren.
- **Niet gebouwd in deze app** betekent bewust niet geclaimd; er is aanvullende infrastructuur of beleid nodig.

## Hoofdstuk voor hoofdstuk

| Hoofdstuk uit plan | Status 2.5.0 | Code/controlepunt | Nog benodigde bewijsvoering |
|---|---|---|---|
| 1. Doel en uitgangspunten | Gedeeltelijk | Bestaande app wordt uitgebreid; Home en menu worden geordend; lokale versleutelde opslag blijft uitgangspunt; onleesbare kluisrecords leveren een niet-gevoelige foutindicator op het Home-scherm. | Herstelbare externe back-up; demonstratie van fouten en terugval; geen release vóór alle gates slagen. |
| 2. Productvisie en doelgroep | Gedeeltelijk | Profielkeuze en functies voor algemeen/kind/jongere/volwassene zijn aanwezig. | Gebruikstests met verschillende gebruikers; controle op volwassen, respectvolle taal. |
| 3. Functieoverzicht A–H | Grotendeels in code | Dag, gevoel, rust, zelfstandigheid, communicatie, welzijn, steun en profiel zijn in de featurecatalogus opgenomen. | Per functie de acceptatietest afwerken; externe contact-/hulpacties niet als noodvoorziening beschouwen. |
| 4. Schermen en routes | In code | Hoofdnavigatie Home / Dag / Gevoel / Meer; Meer is zoekbaar en groepeert per onderwerp; maximaal vier Home-snelkoppelingen zijn instelbaar. | Navigatieroutes op telefoon en tablet testen; geen dode knoppen; terugknop en sessievergrendeling testen. |
| 5. Functionele eisen | Gedeeltelijk | Gevoelsregistraties, agenda, timer, routines, doelen, rustlijst, communicatiekaarten en export-/back-upservices zijn aanwezig. | Alle CRUD-paden, leeg/ongeldig data, herstart en foutscenario's uitvoeren op de kandidaat. |
| 6. Toegankelijkheid | Gedeeltelijk | Tekstgrootte, thema, regelafstand, voorlezen, grotere aanraakvlakken, word wrap, semantische labels en responsive grids zijn in code. | TalkBack, toetsenbord/switch-access, contrastmeting, grote systeemlettergrootte en gebruikersobservatie. |
| 7. Technische keuzes | Voldoet aan bestaande keuze | .NET MAUI/C#, Android `net10.0-android`, gedeelde Core `net8.0`; geen overstap naar Flutter. | GitHub Actions moet echte restore/test/publish uitvoeren. |
| 8. Projectstructuur | Grotendeels in code | Android UI, Core-services en xUnit-tests zijn gescheiden; featurecatalogus is een centrale lijst voor menu en zichtbaarheid. | Code review op afhankelijkheden en onderhoudbaarheid na groene CI. |
| 9. Gegevensmodellen | Gedeeltelijk | Modellen voor stemming, agenda, routines, doelen, instellingen en welzijn zijn aanwezig; oudere instellingen krijgen defaults. | Schemawijzigingen/migratie op bestaande appdata testen; export-compatibiliteit controleren. |
| 10. Opslag en privacy | Gedeeltelijk | Vault-items worden met AES-GCM en binding aan soort/id bewaard; gegevensexport en accountverwijdering bestaan; buffers/tempbestanden worden beperkt. | DPIA/AVG-beoordeling, back-upherstel op echte bestanden, uitleg over export en bewaartermijnen. |
| 11. Ontwikkelfasen | Ingepland en deels geïmplementeerd | Regressietests en aparte build-workflows zijn onderdeel van dit pakket. | Elke gate per fase aftekenen; niet overslaan omdat een vorige build groen was. |
| 12. Testplan | Automatische tests voorbereid | xUnit-project bevat service- en securitytests, inclusief nieuwe tests voor snelkoppelingen, VaultStore en gebruikersnamen. | CI-resultaat ontbreekt totdat workflow is uitgevoerd; fysieke tests en gebruikersfeedback open. |
| 13. Beveiliging en verantwoord gebruik | Gedeeltelijk | Lokale encryptie, accountauthenticatie, lockout, herstelcodes, privacycover, schermcapture-optie en input-/padvalidatie. | Onafhankelijke pentest/code review; dreigingsmodel; check logs, exports, OS-back-up en misbruikscenario's. |
| 14. Release en onderhoud | Klaar als procedure, release nog niet bewezen | Aparte APK/AAB-workflows, checksums, behoud van oudere kandidaatbestanden en runbook. | Ondertekende workflows met bestaande GitHub Secrets uitvoeren; APK/AAB verifiëren; install/upgrade en rollback. |
| 15. Prioriteiten | Geordend | Kritieke betrouwbaarheid, navigatie, privacy en toegankelijkheid staan voor release-publicatie. | Openstaande prioriteiten registreren als issues en eigenaars/toetsresultaat vastleggen. |
| 16. Definition of Done | Gate-procedure toegevoegd | Iedere functie moet vindbaar zijn, invoer valideren, fouten melden, opslag respecteren en tests krijgen. | Alle gates in acceptatietest moeten expliciet PASS hebben; onbewezen punten blijven OPEN. |
| 17. Eerste programmeersessie | Ingevolgd | Bestaande broncode als basis, versieverhoging, tests, changelog en aparte releaseworkflows. | Externe commit/CI en echte apparaatfeedback uitvoeren. |
| 18. Eindchecklist | Niet volledig aftekenen vóór bewijs | Dit document maakt code/CI/handmatige eisen apart. | Release blijft NO-GO zolang build, apparaat-, toegankelijkheids- en privacygates open zijn. |

## Functiematrix (A–H uit hoofdstuk 3)

| Onderdeel | Code aanwezig | Belangrijkste check |
|---|---|---|
| A. Mijn dag | Agenda, dagscherm, routines, stappenplan, timer/reminder-service | Voeg/wijzig/verwijder; status; overgang middernacht; timer na schermwissel/reboot; weigering notificatie. |
| B. Mijn gevoel | Check-in, geschiedenis, kalender/inzichten en notities | Optionele velden overslaan; registraties wijzigen/verwijderen; geen diagnostische conclusie. |
| C. Mijn rust | Ademhaling, rustopties, prikkels/stoplicht en persoonlijke rustlijst | Stoppen op elk moment; zelfrapportage duidelijk; labels zijn niet uitsluitend kleur. |
| D. Mijn zelfstandigheid | Doelen/stappen, routines en kind/jongere/volwassen-profielen | Voortgang na herstart; taken kunnen aangepast/verwijderd; geen strafscore. |
| E. Mijn communicatie | Basis praatkaarten, gesprek voorbereiden, gekozen items delen | Kaartbetekenis duidelijk; delen alleen op actie; offline basis beschikbaar. |
| F. Mijn welzijn | Welzijnsregistraties en optionele doelen | Optioneel; wijzig/verwijder; geen medische adviezen. |
| G. Mijn steun | Contactpersonen/afspraken en expliciete supportpakketten | Geen verborgen meekijken; geen automatische noodmeldingen; expliciete selectie en begrip vóór delen. |
| H. Mijn profiel | Instellingen, zichtbare functies, Home-keuze, privacy/export/verwijderen | Voorkeuren na opnieuw starten; verbergen verwijdert niets; export en accountverwijdering getest. |

## Releasebesluit

**Voorlopig: NO-GO voor publieke productiepublicatie** totdat alle automatische en handmatige gates uit `ANDROID-ACCEPTATIETEST-2.5.0.md` zijn ingevuld. Dit betekent niet dat de app niet bruikbaar is; het voorkomt dat een statische codecheck wordt voorgesteld als volledige kwaliteitsgoedkeuring.
