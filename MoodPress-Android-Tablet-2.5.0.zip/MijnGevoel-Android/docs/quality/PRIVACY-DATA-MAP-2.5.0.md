# MoodPress 2.5.0 — privacy- en datakaart (technische inventarisatie)

Dit document beschrijft de beoogde huidige appwerking op basis van de broncode. Het is geen juridische DPIA of onafhankelijke beveiligingsverklaring.

## Gegevensstromen

| Gegeven | Verwerking/opslag | Zichtbaarheid/delen | Test/controle |
|---|---|---|---|
| Accountmetadata | Accountbestand met salt en cryptografisch ingepakte sleutelvelden; geen plaintext wachtwoord | Lokaal; inloggen vereist wachtwoord + tweede factor in huidige accountflow | Registratie, foutieve login, lockout, herstelcode, wachtwoord wijzigen/verwijderen testen |
| Dagboek, gevoelens, agenda en routines | Eigen vaultbestanden; AES-GCM; soort en record-ID worden als aanvullende authenticatiegegevens gebruikt | Alleen na openen van lokale sessie; geen standaarddeling | Integriteits-/tamper-tests, toegang na herstart, CRUD |
| Appinstellingen | Onderdeel van versleutelde account/vaultdata volgens huidige opslagflow | Lokaal | Compatibiliteit met oude instellingen wanneer velden ontbreken; reset/aanpassen |
| Exports | Expliciet door gebruiker gemaakte JSON-export | Bestand staat op doelpad dat de gebruiker kiest; na export buiten de app kan MoodPress kopieën niet meer beheren | Inhoud vergelijken, uitleg tonen, geen export naar onbedoelde map |
| Back-ups | ZIP met accountbestand en al versleutelde vaultbestanden; ZIP zelf heeft geen apart wachtwoord in deze implementatie | Gebruiker moet bestand zelf veilig bewaren en delen; kan gevoelige metadata bevatten | Ongeldige ZIP, zip-slip, te grote entries, duplicaten, schone restore, geen overschrijven |
| Geselecteerde supportpakketten | Expliciet samengesteld en versleuteld pakket met geselecteerde records en code | Alleen wanneer gebruiker actief kiest om te exporteren/delen; ontvanger moet code hebben | Onjuist/gewijzigd pakket weigeren, selectie controleren, geen onbedoelde notitie buiten versleuteling |
| Push/cloud | Geen volledige cloudsync/back-end in deze candidate bevestigd | Geen cloudsharing geclaimd | Review code/network permissions voor iedere release |
| Noodcontact | Geen automatische noodmelding geclaimd | Alleen lokaal ingestelde contactacties, indien beschikbaar | Test dat UI geen niet-bestaande hulp belooft |

## Beveiligingsgrenzen en aandacht

- AES-GCM beschermt vaultbestanden, maar is geen bewijs van volledige toestelbeveiliging, malwarebescherming of veilige OS-back-ups.
- Account-back-ups worden niet extra met een ZIP-wachtwoord versleuteld. Gebruikers moeten backupbestanden behandelen als vertrouwelijk.
- Een export kan leesbare gegevens bevatten. Toon vooraf uitleg en deel alleen geselecteerde inhoud.
- `SecureDelete` probeert overschrijven maar kan op SSD/flash en door OS-/cloudback-ups geen gegarandeerde fysieke uitwissing beloven.
- Screenshots blokkeren kan alleen de relevante Android-weergave blokkeren; het voorkomt geen externe camera of alle vormen van opname.
- Geen verborgen meekijkfunctie, geen automatische alarmmelding en geen live begeleidersportaal worden geclaimd.
- Voor gebruik met echte cliënt-/zorggegevens: voer een passende DPIA/AVG-beoordeling en onafhankelijke securityreview uit, inclusief export/backup, logs, apparaatback-up, sleutelbeheer en herstelprocedure.
