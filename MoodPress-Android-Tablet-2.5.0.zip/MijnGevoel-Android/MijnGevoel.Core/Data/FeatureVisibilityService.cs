namespace MijnGevoel.Core.Data;

/// <summary>Pure settings rule for optional feature visibility. Unknown/legacy settings keep all features visible.</summary>
public static class FeatureVisibilityService
{
    public static bool IsEnabled(UserSettings? settings, string featureKey)
    {
        if (string.IsNullOrWhiteSpace(featureKey)) return false;
        if (settings is null || !settings.FeatureVisibilityConfigured) return true;
        return settings.EnabledFeatures?.Contains(featureKey, StringComparer.Ordinal) == true;
    }

    public static List<string> NormalizeEnabled(IEnumerable<string>? selected, IEnumerable<string> known)
    {
        var allowed = known.Where(x => !string.IsNullOrWhiteSpace(x)).ToHashSet(StringComparer.Ordinal);
        return (selected ?? Array.Empty<string>())
            .Where(x => allowed.Contains(x))
            .Distinct(StringComparer.Ordinal)
            .OrderBy(x => x, StringComparer.Ordinal)
            .ToList();
    }
}
