namespace MijnGevoel.Core.Data;

/// <summary>Selection rules for accessible Home shortcuts. Pure methods are covered by unit tests.</summary>
public static class HomeShortcutService
{
    public const int MaximumShortcuts = 4;
    public const int SimplifiedMaximumShortcuts = 2;

    private static readonly string[] DefaultKeys = { "DailyCheckIn", "Calm", "Cards", "DayToday" };

    public static IReadOnlyList<string> Defaults => Array.AsReadOnly((string[])DefaultKeys.Clone());

    public static string[] Normalize(IEnumerable<string>? selected, IEnumerable<string> knownFeatureKeys)
    {
        ArgumentNullException.ThrowIfNull(knownFeatureKeys);
        var allowed = knownFeatureKeys
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .ToHashSet(StringComparer.Ordinal);

        return (selected ?? Array.Empty<string>())
            .Where(x => !string.IsNullOrWhiteSpace(x) && allowed.Contains(x))
            .Distinct(StringComparer.Ordinal)
            .Take(MaximumShortcuts)
            .ToArray();
    }

    /// <summary>Returns the saved selection, or safe defaults for settings written by older versions.</summary>
    public static IReadOnlyList<string> GetConfiguredOrDefault(UserSettings? settings, IEnumerable<string> knownFeatureKeys)
    {
        ArgumentNullException.ThrowIfNull(knownFeatureKeys);
        var known = knownFeatureKeys.Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.Ordinal).ToArray();
        var requested = settings?.HomeShortcutsConfigured == true ? settings.HomeShortcuts : DefaultKeys;
        return Array.AsReadOnly(Normalize(requested, known));
    }

    /// <summary>Applies simplified-mode limits without changing the saved full selection.</summary>
    public static IReadOnlyList<string> GetVisible(UserSettings? settings, IEnumerable<string> knownFeatureKeys)
    {
        var configured = GetConfiguredOrDefault(settings, knownFeatureKeys);
        var limit = settings?.SimplifiedMode == true ? SimplifiedMaximumShortcuts : MaximumShortcuts;
        return Array.AsReadOnly(configured.Take(limit).ToArray());
    }
}
