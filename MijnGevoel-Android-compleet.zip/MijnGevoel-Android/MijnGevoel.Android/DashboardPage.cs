using MijnGevoel.Core.Data;

namespace MijnGevoel.AndroidApp;

public enum FeatureKind
{
    Stoplicht, DayToday, DayTomorrow, Agenda, Timer, Routines,
    Breath, Calm, Sensory, Body, MoodHistory, FeelingWords,
    Cards, TalkPrep, StoplichtHistory, Share, SafetyPlan,
    Draw, Gallery, Notes, Journal, Privacy, Week, Settings, Help
}

public sealed class DashboardPage : ContentPage
{
    bool _consentPrompted;
    static readonly (string Name, string Icon, FeatureKind Kind)[][] Groups =
    {
        new[] { ("Vandaag", "🗓️", FeatureKind.DayToday), ("Morgen bekijken", "🌙", FeatureKind.DayTomorrow), ("Agenda", "📅", FeatureKind.Agenda), ("Timer", "⏳", FeatureKind.Timer), ("Stappenplannen", "✅", FeatureKind.Routines) },
        new[] { ("Ademhalen", "🫁", FeatureKind.Breath), ("Rustplek", "🛋️", FeatureKind.Calm), ("Prikkelmeter", "🎚️", FeatureKind.Sensory), ("Mijn lichaam", "🧍", FeatureKind.Body), ("Hoe voel ik me?", "📊", FeatureKind.MoodHistory), ("Gevoelswoorden", "📖", FeatureKind.FeelingWords) },
        new[] { ("Kaarten om te laten zien", "🗂️", FeatureKind.Cards), ("Gesprekskaart", "🗣️", FeatureKind.TalkPrep), ("Stoplicht-overzicht", "🚦", FeatureKind.StoplichtHistory), ("Delen met mijn begeleider", "📤", FeatureKind.Share), ("Mijn plan", "🆘", FeatureKind.SafetyPlan) },
        new[] { ("Tekenen", "✏️", FeatureKind.Draw), ("Mijn tekeningen", "🖼️", FeatureKind.Gallery), ("Van me afschrijven", "📝", FeatureKind.Notes), ("Dagboek", "📖", FeatureKind.Journal) },
        new[] { ("Mijn privacy", "🔐", FeatureKind.Privacy), ("Weekoverzicht", "🗒️", FeatureKind.Week), ("Instellingen", "⚙️", FeatureKind.Settings), ("Hulp", "❓", FeatureKind.Help) }
    };
    static readonly string[] GroupNames = { "Mijn dag", "Rust en gevoel", "Praten en delen", "Maken en schrijven", "Mijn gegevens" };

    public DashboardPage()
    {
        Title = "Mijn Gevoel";
        BackgroundColor = AppUi.Background;
        ToolbarItems.Add(new ToolbarItem("🔒 Vergrendel", null, async () => await ((App)Application.Current!).LockToLoginAsync("Je bent uitgelogd.")));
        ToolbarItems.Add(new ToolbarItem("🙈 Scherm verbergen", null, async () => await Navigation.PushAsync(new PrivacyCoverPage())));
        Build();
    }

    void Build()
    {
        var root = new VerticalStackLayout { Padding = new Thickness(16), Spacing = 12, BackgroundColor = AppUi.Background };
        root.Children.Add(AppUi.Title($"Hoi {AppSession.Username}!"));
        root.Children.Add(AppUi.Label("Hoe is het nu? Je kunt iets kiezen, opschrijven of even tot rust komen."));
        int left = AppSession.Accounts.RecoveryCodesLeft(AppSession.Username);
        if (left <= 2)
            root.Children.Add(AppUi.Card(new VerticalStackLayout { Children = { AppUi.Label($"⚠️ Je hebt nog {left} herstelcode(s). Maak nieuwe codes bij Instellingen.") } }));

        root.Children.Add(AppUi.Title("Hoe gaat het nu?"));
        root.Children.Add(AppUi.Button("🚦 Stoplicht invullen", () => Navigate(FeatureKind.Stoplicht)));
        var moods = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) }, RowDefinitions = { new RowDefinition(GridLength.Auto), new RowDefinition(GridLength.Auto) }, ColumnSpacing = 6, RowSpacing = 4 };
        var moodData = new[] { ("😄 Blij", 1), ("🙂 Goed", 2), ("😐 Gaat wel", 3), ("😟 Niet fijn", 4), ("😢 Verdrietig", 5) };
        for (int i = 0; i < moodData.Length; i++)
        {
            var (label, mood) = moodData[i];
            var button = AppUi.Button(label, () =>
            {
                var e = new JournalEntry(Guid.NewGuid(), DateTime.Now, mood, "");
                AppSession.Store!.Save("diary", e.Id, e);
                DisplayAlert("Opgeslagen", "Je gevoel is bewaard in je dagboek.", "OK");
            }, quiet: true);
            Grid.SetColumn(button, i % 3);
            Grid.SetRow(button, i / 3);
            moods.Children.Add(button);
        }
        root.Children.Add(moods);

        for (int groupIndex = 0; groupIndex < Groups.Length; groupIndex++)
        {
            root.Children.Add(AppUi.Title(GroupNames[groupIndex]));
            foreach (var item in Groups[groupIndex])
            {
                var button = AppUi.Button($"{item.Icon}  {item.Name}  →", () => Navigate(item.Kind), quiet: true);
                root.Children.Add(button);
            }
        }
        root.Children.Add(AppUi.Button("🔒 Sessie vergrendelen", async () => await ((App)Application.Current!).LockToLoginAsync(), danger: true));
        root.Children.Add(AppUi.Label("Alles staat in je privé-appopslag en wordt versleuteld. Mijn Gevoel waarschuwt niemand automatisch.", muted: true));
        Content = new ScrollView { Content = root };
    }

    void Navigate(FeatureKind kind) => Navigation.PushAsync(new FeaturePage(kind));

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        // Herbouw het dashboard na terugkeer uit Instellingen, zodat thema en tekstgrootte meteen gelden.
        if (AppSession.Store is not null) Build();
        AppSession.Touch();
        if (AppSession.Settings.Animations) { Opacity = 0; _ = FadeTo(1, 180, Easing.CubicOut); }
        if (_consentPrompted || AppSession.Store is null) return;
        if (AppSession.Store.All<ConsentRecord>("consent").Any(c => c.Version >= ConsentInfo.CurrentVersion)) { _consentPrompted = true; return; }
        _consentPrompted = true;
        const string text = "Mijn Gevoel is voor jou. Je dagboek, tekeningen, agenda en andere gegevens worden versleuteld op deze telefoon bewaard. Je begeleider ziet alleen wat jij zelf deelt. De app waarschuwt niemand en belt niemand. Je mag je gegevens meenemen of verwijderen. Vraag je begeleider wie verantwoordelijk is voor je gegevens en waar de privacyverklaring staat.";
        await DisplayAlert("Voordat je begint", text, "Ik heb dit gelezen");
        var choice = await DisplayActionSheet("Met wie gebruik je Mijn Gevoel?", "Nu niet", null, "Zelf", "Samen met mijn vertegenwoordiger of begeleider");
        if (choice == "Zelf" || choice == "Samen met mijn vertegenwoordiger of begeleider")
        {
            var consent = new ConsentRecord(Guid.NewGuid(), DateTime.Now, ConsentInfo.CurrentVersion, choice == "Zelf" ? "zelf" : "samen");
            AppSession.Store.Save("consent", consent.Id, consent);
        }
        else
        {
            await ((App)Application.Current!).LockToLoginAsync("Je kunt later toestemming geven door opnieuw in te loggen.");
        }
    }
}
