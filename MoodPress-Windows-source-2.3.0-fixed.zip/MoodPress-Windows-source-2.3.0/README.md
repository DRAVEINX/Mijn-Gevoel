# MoodPress Windows 2.3.0

Deze bronbundel voegt een afzonderlijke .NET MAUI Windows-app toe in `MoodPress.WindowsApp/`.
De Windows-app gebruikt de nieuwere MoodPress-branding, dezelfde bijgewerkte schermen en kernfuncties als de 2.3.0 MAUI-broncode, en een desktopzijbalk die de mobiele navigatiebalk vervangt.

## Nieuwe Windows-app

- Project: `MoodPress.WindowsApp/MoodPress.WindowsApp.csproj`
- Windows-identiteit: `nl.moodpress.windows` (los van de Android-app-ID's)
- App-naam en installer: MoodPress
- Installer-project: `installer/Package.wxs`
- Logo en installer-artwork: `MoodPress.WindowsApp/Resources/AppIcon/MoodPress.ico`, `installer/banner.bmp`, `installer/dialoog.bmp`
- Windows-app publiceert als self-contained `win-x64`, met een MSI-installer en een draagbare ZIP.

## Windows-gedrag

De accountgegevens en gebruikersgegevens lopen via de bestaande core- en kluiscode. Windows Hello wordt gebruikt voor de optionele onthouden-sessie-functie wanneer Windows Hello op die computer is ingesteld. Routineherinneringen worden alleen getoond terwijl MoodPress open is; er wordt geen achtergrondmelding beloofd als de app is afgesloten. Schermopname blokkeren is best-effort en hangt af van Windows en de gebruikte opnamefunctie.

## Telefoon en tablet

`MijnGevoel.Android/MijnGevoel.Android.csproj` en de oorspronkelijke Android-package-ID's blijven ongewijzigd. Deze bundel is bedoeld voor de **afzonderlijke Windows-workflow** en wordt onder de naam `MoodPress-Windows-source-2.3.0.zip` geüpload. Vervang niet de bestaande Android-bron-zip.
