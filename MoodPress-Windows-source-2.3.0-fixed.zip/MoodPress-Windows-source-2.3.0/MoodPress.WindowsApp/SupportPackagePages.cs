using System.Text;
using Microsoft.Maui.ApplicationModel.DataTransfer;
using Microsoft.Maui.Storage;
using MijnGevoel.Core.Data;

namespace MoodPress.WindowsApp;

/// <summary>Cliënt kiest exact welke categorieën meegaan in een versleuteld pakket.</summary>
public sealed class SupportPackageSharePage : ContentPage
{
    readonly List<(StoplichtEntry Item, CheckBox Check)> _lights = new();
    readonly List<(Routine Item, CheckBox Check)> _routines = new();
    readonly List<(MoodCheckInEntry Item, CheckBox Check)> _moods = new();
    readonly List<(YouthSupportEntry Item, CheckBox Check)> _youth = new();
    readonly CheckBox _planCheck = new();
    readonly Entry _recipient, _code;
    readonly Label _status;
    public SupportPackageSharePage()
    {
        Title = "Ondersteuningspakket delen"; BackgroundColor = AppUi.Background;
        _recipient=AppUi.Entry("Naam of rol ontvanger (optioneel)");
        _code=AppUi.Entry("Eigen deelcode (leeg = veilig genereren)");
        _status=AppUi.Label("");
        var root=AppUi.Stack(AppUi.Title("Wat wil je delen?"),AppUi.Label("Je bepaalt zelf welke informatie wordt meegestuurd. Je dagboek, tekeningen, spraaknotities en volledige historie worden nooit automatisch toegevoegd."),
            AppUi.Label("Ontvanger",title:true),_recipient,
            AppUi.Card(new VerticalStackLayout { Spacing=6, Children={_planCheck,AppUi.Label("Mijn ondersteunings-/helpplan delen")}}));
        _planCheck.Color=AppUi.Accent;
        _planCheck.CheckedChanged += (_,_)=>AppSession.Touch();
        var planLabel=AppUi.Label("Selecteer desgewenst het plan met helpstappen en contacten. Controleer dit eerst samen.",muted:true); root.Children.Add(planLabel);
        root.Children.Add(AppUi.Label("Stoplichtmeldingen (kies afzonderlijk)",title:true));
        var lights=AppSession.Store!.All<StoplichtEntry>("light").OrderByDescending(x=>x.Created).Take(40).ToList();
        if(lights.Count==0) root.Children.Add(AppUi.Label("Nog geen stoplichtmeldingen."));
        foreach(var item in lights) { var cb=new CheckBox{Color=AppUi.Accent}; _lights.Add((item,cb)); root.Children.Add(AppUi.Card(new HorizontalStackLayout{Spacing=8,Children={cb,AppUi.Label($"{(item.Colour=="Rood"?"🔴":item.Colour=="Oranje"?"🟠":"🟢")} {item.Colour} — {item.Created:dd-MM-yyyy HH:mm}\n{(string.Join(", ",item.Reasons??Array.Empty<string>()))}")}})); }
        root.Children.Add(AppUi.Label("Routinevoorstellen / routines (kies afzonderlijk)",title:true));
        var routines=AppSession.Store.All<Routine>("routine").OrderBy(x=>x.Title).Take(50).ToList();
        if(routines.Count==0) root.Children.Add(AppUi.Label("Nog geen stappenplannen."));
        foreach(var item in routines) { var cb=new CheckBox{Color=AppUi.Accent}; _routines.Add((item,cb)); root.Children.Add(AppUi.Card(new HorizontalStackLayout{Spacing=8,Children={cb,AppUi.Label($"{item.Icon} {item.Title} ({item.Steps?.Length??0} stappen)")}})); }
        root.Children.Add(AppUi.Label("Gevoelscheck-ins delen (alleen wat je aanvinkt)",title:true));
        var moods=AppSession.Store.All<MoodCheckInEntry>("moodcheckin").OrderByDescending(x=>x.Created).Take(20).ToList();
        if(moods.Count==0)root.Children.Add(AppUi.Label("Geen uitgebreide gevoelscheck-ins opgeslagen."));
        foreach(var item in moods){var cb=new CheckBox{Color=AppUi.Accent};_moods.Add((item,cb));root.Children.Add(AppUi.Card(new HorizontalStackLayout{Spacing=8,Children={cb,AppUi.Label($"{item.Created:dd-MM HH:mm} · {item.Feeling} ({item.Intensity}/10)\n{item.Reason}\n{item.Note}")}}));}
        root.Children.Add(AppUi.Label("Jongeren-check-ins delen (ook privé-inhoud; alleen selecteren als je dit wilt)",title:true));
        var youth=AppSession.Store.All<YouthSupportEntry>("youthsupport").OrderByDescending(x=>x.Created).Take(20).ToList();
        if(youth.Count==0)root.Children.Add(AppUi.Label("Geen stress-check-ins opgeslagen."));
        foreach(var item in youth){var cb=new CheckBox{Color=AppUi.Accent};_youth.Add((item,cb));root.Children.Add(AppUi.Card(new HorizontalStackLayout{Spacing=8,Children={cb,AppUi.Label($"{item.Created:dd-MM HH:mm} · {item.Situation} · stress {item.StressLevel}/5\nNodig: {item.Need}\n{item.Note}")}}));}
        root.Children.Add(AppUi.Label("Deelcode",title:true)); root.Children.Add(_code);
        root.Children.Add(AppUi.Label("Het pakket wordt versleuteld. Verstuur de deelcode via een ander kanaal dan het bestand. Dit is een momentopname, geen online accountkoppeling.",muted:true)); root.Children.Add(_status);
        root.Children.Add(AppUi.AsyncButton("🔒 Versleuteld pakket maken en delen",ShareAsync));
        root.Children.Add(AppUi.Button("📜 Mijn deelgeschiedenis bekijken",()=>Navigation.PushAsync(new ShareHistoryPage()),quiet:true));
        root.Children.Add(AppUi.Button("← Terug",()=>Navigation.PopAsync(),quiet:true));
        Content=AppUi.WithBottomNavigation(this, new ScrollView{Content=root}, "shares");
    }

    async Task ShareAsync()
    {
        var selectedLights=_lights.Where(x=>x.Check.IsChecked).Select(x=>x.Item).ToList();
        var selectedRoutines=_routines.Where(x=>x.Check.IsChecked).Select(x=>x.Item).ToList();
        var selectedMoods=_moods.Where(x=>x.Check.IsChecked).Select(x=>x.Item).ToList();
        var selectedYouth=_youth.Where(x=>x.Check.IsChecked).Select(x=>x.Item).ToList();
        var plan=_planCheck.IsChecked?AppSession.Store!.Load<SafetyPlan>("plan",Guid.Empty):null;
        if(plan is null && selectedLights.Count==0 && selectedRoutines.Count==0 && selectedMoods.Count==0 && selectedYouth.Count==0) { _status.Text="Kies eerst één of meer onderdelen."; return; }
        var categories=new List<string>(); if(plan is not null)categories.Add("helpplan"); if(selectedLights.Count>0)categories.Add("stoplicht"); if(selectedRoutines.Count>0)categories.Add("routines"); if(selectedMoods.Count>0)categories.Add("gevoelscheck-ins"); if(selectedYouth.Count>0)categories.Add("stresscheck-ins");
        var summary=$"Ontvanger: {(_recipient.Text?.Trim() is {Length:>0} name ? name : "niet opgegeven")}\n"+$"Helpplan: {(plan is null?"nee":"ja")}\nStoplichtmeldingen: {selectedLights.Count}\nRoutines: {selectedRoutines.Count}\nGevoelscheck-ins: {selectedMoods.Count}\nStresscheck-ins: {selectedYouth.Count}\n\nAlleen de geselecteerde gegevens gaan mee, ook persoonlijke notities als je die aanvinkt.";
        if(!await DisplayAlertAsync("Controleer vóór delen",summary,"Versleuteld delen","Annuleren"))return;
        var code=(_code.Text??"").Trim(); if(string.IsNullOrWhiteSpace(code))code=SupportShareService.NewShareCodeForUi();
        var suggestions=selectedRoutines.Select(r=>new RoutineSuggestion(Guid.NewGuid(),r.Title,r.Icon,r.Steps,DateTime.Now,AppSession.Username)).ToList();
        try
        {
            var bytes=SupportShareService.Create(AppSession.Username,plan,selectedLights,suggestions,code,selectedMoods,selectedYouth);
            var path=Path.Combine(FileSystem.CacheDirectory,$"MoodPress-ondersteuning-{DateTime.Now:yyyyMMdd-HHmmss}.mgsupport");
            await File.WriteAllBytesAsync(path,bytes);
            var selectedLabels = new List<string>();
            selectedLabels.AddRange(selectedLights.Select(x => $"Stoplicht {x.Colour} · {x.Created:dd-MM-yyyy HH:mm}"));
            selectedLabels.AddRange(selectedRoutines.Select(x => $"Routine: {x.Title}"));
            selectedLabels.AddRange(selectedMoods.Select(x => $"Gevoel: {x.Feeling} · {x.Created:dd-MM-yyyy HH:mm}"));
            selectedLabels.AddRange(selectedYouth.Select(x => $"Stress: {x.Situation} · {x.Created:dd-MM-yyyy HH:mm}"));
            if (plan is not null) selectedLabels.Add("Help-/ondersteuningsplan");
            var audit=new ShareConsentRecord(Guid.NewGuid(),DateTime.Now,(_recipient.Text??"").Trim(),categories.ToArray(),selectedLights.Count,selectedRoutines.Count)
                { MoodCheckInCount=selectedMoods.Count, YouthCheckInCount=selectedYouth.Count, SelectedItemLabels=selectedLabels.Take(250).ToArray() };
            AppSession.Store!.Save("shareconsent",audit.Id,audit);
            var log=new ShareLogEntry(Guid.NewGuid(),DateTime.Now,selectedLights.Count); AppSession.Store.Save("sharelog",log.Id,log);
            await Share.Default.RequestAsync(new ShareFileRequest{Title="Versleuteld MoodPress-ondersteuningspakket",File=new ShareFile(path)});
            await Clipboard.Default.SetTextAsync(code);
            _status.Text="Pakket aangemaakt. Deelcode gekopieerd.";
            await DisplayAlertAsync("Deelcode",$"Stuur de code apart van het bestand:\n\n{code}\n\nDit pakket wordt niet automatisch bijgewerkt of teruggekoppeld.","OK");
        }
        catch(Exception ex) { AppLog.Write(ex); _status.Text="Het pakket kon niet worden aangemaakt. Controleer de selectie en deelcode."; }
    }
}

/// <summary>Cliënt beoordeelt een voorstel; routines worden alleen opgeslagen na expliciete actie.</summary>
public sealed class ReceiveSupportPackagePage : ContentPage
{
    byte[]? _bytes; Entry _code=null!; Label _status=null!; Label _file=null!; VerticalStackLayout _root=null!;
    SupportSharePackage? _package;
    public ReceiveSupportPackagePage(){Title="Voorstel ontvangen";BackgroundColor=AppUi.Background;_code=AppUi.Entry("Deelcode",password:true);_status=AppUi.Label("");_file=AppUi.Label("Nog geen bestand gekozen.",muted:true);_root=AppUi.Stack(AppUi.Title("Een voorstel van je begeleider"),AppUi.Label("Deelname is jouw keuze. Een pakket verandert je gegevens niet totdat jij op een bewaar- of goedkeurknop drukt."),AppUi.AsyncButton("📂 Pakketbestand kiezen",PickAsync),_file,_code,_status,AppUi.AsyncButton("🔓 Pakket openen",OpenAsync),AppUi.Button("← Terug",()=>Navigation.PopAsync(),quiet:true));Content=AppUi.WithBottomNavigation(this, new ScrollView{Content=_root}, "shares");}
    async Task PickAsync(){var picked=await FilePicker.Default.PickAsync(new PickOptions{PickerTitle="Kies MoodPress .mgsupport"});if(picked is null)return;try{await using var src=await picked.OpenReadAsync();using var ms=new MemoryStream();var buf=new byte[65536];while(true){var n=await src.ReadAsync(buf.AsMemory());if(n==0)break;if(ms.Length+n>SupportShareService.MaxFileBytes){_bytes=null;_status.Text="Het bestand is te groot.";return;}ms.Write(buf,0,n);}_bytes=ms.ToArray();_file.Text=picked.FileName;_status.Text="Bestand gekozen. Voer de deelcode in.";}catch(Exception ex){AppLog.Write(ex);_bytes=null;_status.Text="Bestand kon niet worden gelezen.";}}
    async Task OpenAsync(){if(_bytes is null){_status.Text="Kies eerst een bestand.";return;}if(string.IsNullOrWhiteSpace(_code.Text)){_status.Text="Voer de deelcode in.";return;}var p=await Task.Run(()=>SupportShareService.Open(_bytes,_code.Text));if(p is null){_status.Text="Pakket openen is niet gelukt. Controleer bestand en code.";return;}_package=p;ShowPackage(p);}
    void ShowPackage(SupportSharePackage p){_root.Children.Clear();_root.Children.Add(AppUi.Title("Pakket van "+p.From));_root.Children.Add(AppUi.Label($"Gemaakt op {p.Created:dd-MM-yyyy HH:mm}. Deze inhoud wordt alleen getoond en niet automatisch opgeslagen."));
        if(p.HelpPlan is not null){var plan=p.HelpPlan;var text=$"Wat helpt: {plan.Helps}\n\nVroege signalen: {plan.EarlySigns}\n\nWat liever niet: {plan.Avoid}\n\nCommunicatie: {plan.Communication}\n\nHelpstappen: {plan.SupportSteps}\n\nDoelen: {plan.Goals}\n\nDagritme: {plan.RoutineNotes}\n\nContacten: {string.Join("; ",plan.Contacts.Select(c=>c.Name+(string.IsNullOrWhiteSpace(c.Phone)?"":" — "+c.Phone)))}";_root.Children.Add(AppUi.Card(AppUi.Stack(AppUi.Label("Ondersteuningsplan (voorstel)",title:true),AppUi.Label(text))));_root.Children.Add(AppUi.AsyncButton("✅ Dit plan opslaan als mijn helpkaart",async()=>{if(await DisplayAlertAsync("Mijn plan vervangen?","Dit vervangt de huidige helpkaart van dit account. Je kunt ook eerst alleen lezen en niets opslaan.","Vervangen","Annuleren")){AppSession.Store!.Save("plan",Guid.Empty,plan);_status.Text="Helpkaart bijgewerkt ✔";await DisplayAlertAsync("Opgeslagen","Je hebt het plan goedgekeurd en opgeslagen.","OK");}}));}
        foreach(var s in p.StoplightEntries){_root.Children.Add(AppUi.Card(AppUi.Stack(AppUi.Label($"{s.Colour} — {s.Created:dd-MM-yyyy HH:mm}",title:true),AppUi.Label("Waarom: "+string.Join(", ",s.Reasons)),AppUi.Label("Nodig: "+string.Join(", ",s.Needs)),AppUi.Label(s.Text))));}
        foreach(var m in p.MoodCheckIns){_root.Children.Add(AppUi.Card(AppUi.Stack(AppUi.Label($"Gevoelscheck-in — {m.Created:dd-MM-yyyy HH:mm}",title:true),AppUi.Label($"{m.Feeling} · intensiteit {m.Intensity}/10"),AppUi.Label(m.Reason),AppUi.Label(m.Note))));}
        foreach(var y in p.YouthCheckIns){_root.Children.Add(AppUi.Card(AppUi.Stack(AppUi.Label($"Stresscheck-in — {y.Created:dd-MM-yyyy HH:mm}",title:true),AppUi.Label($"{y.Situation} · stress {y.StressLevel}/5"),AppUi.Label("Nodig: "+y.Need),AppUi.Label(y.Note))));}
        if(p.RoutineSuggestions.Count>0){_root.Children.Add(AppUi.Title("Routinevoorstellen"));foreach(var item in p.RoutineSuggestions){var local=item;var card=AppUi.Stack(AppUi.Label($"{local.Icon} {local.Title}",title:true),AppUi.Label(string.Join("\n",local.Steps.Select((s,i)=>$"{i+1}. {s}"))),AppUi.AsyncButton("✅ Deze routine goedkeuren en toevoegen",async()=>{if(AppSession.Store!.All<Routine>("routine").Any(r=>string.Equals(r.Title,local.Title,StringComparison.OrdinalIgnoreCase))&&!await DisplayAlertAsync("Routine bestaat al","Er is al een routine met deze naam. Toch toevoegen?","Toevoegen","Annuleren"))return;var r=new Routine(Guid.NewGuid(),local.Title,local.Icon,local.Steps);AppSession.Store.Save("routine",r.Id,r);_status.Text=$"Routine '{local.Title}' toegevoegd ✔";await DisplayAlertAsync("Toegevoegd","De routine is toegevoegd aan jouw stappenplannen.","OK");},quiet:true),AppUi.Button("❌ Dit voorstel afwijzen",async()=>{await DisplayAlertAsync("Niet toegevoegd","Je hebt dit voorstel afgewezen. Er is niets opgeslagen.","OK");},quiet:true));_root.Children.Add(AppUi.Card(card));}}
        _root.Children.Add(AppUi.Label("Je kunt informatie bekijken zonder iets te bewaren. Deelbestanden zijn momentopnamen; ze maken geen automatische koppeling."));_root.Children.Add(AppUi.Button("Sluiten",()=>Navigation.PopAsync(),quiet:true));_bytes=null;_code.Text="";}
}


/// <summary>Kindvriendelijk visueel dagschema. Voortgang is privé en lokaal per dag opgeslagen.</summary>
public sealed class ChildSchedulePage : ContentPage
{
    DateTime _day = DateTime.Today;
    bool _rebuilding;
    public ChildSchedulePage() { Title = "Mijn dagschema"; BackgroundColor = AppUi.Background; Rebuild(); }

    void Rebuild()
    {
        if (_rebuilding) return;
        _rebuilding = true;
        try
        {
            var store = AppSession.Store ?? throw new InvalidOperationException("Sessie is vergrendeld.");
            var root = AppUi.Stack(AppUi.Title("🗓️ Mijn dagschema"),
                AppUi.Label("Kijk wat eerst komt en daarna. Vink een stap af als je klaar bent. Je kunt altijd pauze nemen."));
            root.Children.Add(AppUi.Button("🔊 Lees mijn dag voor", () =>
            {
                var speakAgenda = store.All<AgendaItem>("agenda").Where(x => x.Date.Date == _day.Date).OrderBy(x => string.IsNullOrWhiteSpace(x.Time) ? "99:99" : x.Time).Select(x => (string.IsNullOrWhiteSpace(x.Time) ? "" : x.Time + ". ") + x.Title).ToList();
                var routineTitles = store.All<Routine>("routine").OrderBy(x => x.Title).Select(x => x.Title).ToList();
                var message = "Mijn dagschema. " + (speakAgenda.Count == 0 ? "Er staan geen activiteiten gepland." : string.Join(". Daarna: ", speakAgenda)) + (routineTitles.Count == 0 ? "" : ". Stappenplannen: " + string.Join(", ", routineTitles));
                AppUi.Speak(message);
            }, quiet:true));
            var ownPlan = store.Load<SafetyPlan>("plan", Guid.Empty);
            if (ownPlan?.Contacts is { Count: > 0 })
            {
                var contactRoot = AppUi.Stack(AppUi.Label("👋 Wie kan mij helpen?", title:true), AppUi.Label("Je hebt zelf deze contactpersonen in je helpkaart gezet."));
                foreach (var contact in ownPlan.Contacts.Take(5)) contactRoot.Children.Add(AppUi.Label(string.IsNullOrWhiteSpace(contact.Phone) ? contact.Name : $"{contact.Name} · {contact.Phone}"));
                contactRoot.Children.Add(AppUi.Button("🆘 Toon: Ik heb hulp nodig", () => AppUi.Speak("Ik heb hulp nodig. Wil je bij me komen en rustig vragen wat ik nodig heb?"), quiet:true));
                root.Children.Add(AppUi.Card(contactRoot));
            }
            var date = new DatePicker { Date = _day, MinimumDate = DateTime.Today.AddDays(-30), MaximumDate = DateTime.Today.AddDays(180), TextColor = AppUi.Foreground, BackgroundColor = AppUi.Surface, Format = "dddd d MMMM" };
            date.DateSelected += (_, e) => { _day = e.NewDate.GetValueOrDefault(DateTime.Today).Date; Rebuild(); };
            root.Children.Add(AppUi.Label("Welke dag?", title:true)); root.Children.Add(date);
            var agenda = store.All<AgendaItem>("agenda").Where(x => x.Date.Date == _day.Date).OrderBy(x => string.IsNullOrWhiteSpace(x.Time) ? "99:99" : x.Time).ToList();
            root.Children.Add(AppUi.Title("Eerst mijn activiteiten"));
            if (agenda.Count == 0) root.Children.Add(AppUi.Label("Er staan nog geen activiteiten. Je kunt er één toevoegen via Agenda."));
            foreach (var item in agenda)
            {
                var local = item;
                var done = new CheckBox { IsChecked = local.Done, Color = AppUi.Accent, VerticalOptions = LayoutOptions.Center };
                var agendaState = AppUi.Label(local.Done ? "Klaar ✔" : "Nog te doen");
                done.CheckedChanged += (_, e) => { store.Save("agenda", local.Id, local with { Done = e.Value }); agendaState.Text = e.Value ? "Klaar ✔" : "Nog te doen"; AppSession.Touch(); };
                var info = AppUi.Stack(AppUi.Label($"{local.Icon} {(string.IsNullOrWhiteSpace(local.Time) ? "" : local.Time + " · ")}{local.Title}",title:true), agendaState);
                root.Children.Add(AppUi.Card(new HorizontalStackLayout { Spacing=10, Children={ done, info } }));
            }
            root.Children.Add(AppUi.Button("➕ Activiteit aan mijn dag toevoegen", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Agenda)), quiet:true));
            root.Children.Add(AppUi.Title("Daarna stap voor stap"));
            var routines = store.All<Routine>("routine").OrderBy(x => x.Title).Take(30).ToList();
            if (routines.Count == 0) root.Children.Add(AppUi.Label("Er staan nog geen stappenplannen."));
            foreach (var routine in routines)
            {
                var localRoutine = routine;
                var progress = store.All<RoutineProgress>("routineprogress").FirstOrDefault(x => x.RoutineId == localRoutine.Id && x.Day.Date == _day.Date);
                var completed = (progress?.CompletedSteps ?? Array.Empty<int>()).Where(i => i >= 0 && i < localRoutine.Steps.Length).ToHashSet();
                var panel = AppUi.Stack(AppUi.Label($"{localRoutine.Icon} {localRoutine.Title}", title:true));
                var progressLabel = AppUi.Label($"Afgerond: {completed.Count} van {localRoutine.Steps.Length} stappen.");
                for (int i = 0; i < localRoutine.Steps.Length; i++)
                {
                    var index = i; var step = localRoutine.Steps[i];
                    var cb = new CheckBox { IsChecked = completed.Contains(index), Color = AppUi.Accent, VerticalOptions = LayoutOptions.Center };
                    cb.CheckedChanged += (_, e) =>
                    {
                        var current = store.All<RoutineProgress>("routineprogress").FirstOrDefault(x => x.RoutineId == localRoutine.Id && x.Day.Date == _day.Date);
                        var set = (current?.CompletedSteps ?? Array.Empty<int>()).Where(v => v >= 0 && v < localRoutine.Steps.Length).ToHashSet();
                        if (e.Value) set.Add(index); else set.Remove(index);
                        var saved = new RoutineProgress(current?.Id ?? Guid.NewGuid(), _day.Date, localRoutine.Id, set.OrderBy(v => v).ToArray());
                        store.Save("routineprogress", saved.Id, saved); progressLabel.Text = $"Afgerond: {set.Count} van {localRoutine.Steps.Length} stappen."; AppSession.Touch();
                        if (set.Count == localRoutine.Steps.Length && localRoutine.Steps.Length > 0) AppUi.Speak($"Goed gedaan. {localRoutine.Title} is klaar.");
                    };
                    var label = AppUi.Label($"{i+1}. {step}"); label.LineBreakMode = LineBreakMode.WordWrap;
                    panel.Children.Add(new HorizontalStackLayout { Spacing=8, Children={ cb, label } });
                }
                panel.Children.Add(progressLabel);
                root.Children.Add(AppUi.Card(panel));
            }
            root.Children.Add(AppUi.AsyncButton("🧹 Voortgang van deze dag opnieuw instellen", async () =>
            {
                var dayRecords = store.All<RoutineProgress>("routineprogress").Where(x => x.Day.Date == _day.Date).ToList();
                var agendaRecords = store.All<AgendaItem>("agenda").Where(x => x.Date.Date == _day.Date && x.Done).ToList();
                if (dayRecords.Count == 0 && agendaRecords.Count == 0) { await DisplayAlertAsync("Niets te wissen", "Er is nog geen voortgang opgeslagen voor deze dag.", "OK"); return; }
                if (!await DisplayAlertAsync("Dagvoortgang wissen?", "Alle afgevinkte stappen en activiteiten voor deze datum worden teruggezet. Andere dagen blijven staan.", "Wissen", "Annuleren")) return;
                foreach (var record in dayRecords) store.Delete("routineprogress", record.Id);
                foreach (var item in agendaRecords) store.Save("agenda", item.Id, item with { Done = false });
                AppSession.Touch(); Rebuild();
            }, quiet:true));
            root.Children.Add(AppUi.Button("🌬️ Ik wil even rust", () => Navigation.PushAsync(new FeaturePage(FeatureKind.Breath)), quiet:true));
            root.Children.Add(AppUi.Button("🆘 Ik heb hulp nodig", () => Navigation.PushAsync(new FeaturePage(FeatureKind.SafetyPlan)), quiet:true));
            root.Children.Add(AppUi.Label("Dit dagschema deelt je voortgang niet automatisch met iemand anders." ,muted:true));
            root.Children.Add(AppUi.Button("← Terug naar MoodPress", () => Navigation.PopAsync(), quiet:true));
            Content = AppUi.WithBottomNavigation(this, new ScrollView { Content = root }, "day");
        }
        finally { _rebuilding = false; }
    }
}
