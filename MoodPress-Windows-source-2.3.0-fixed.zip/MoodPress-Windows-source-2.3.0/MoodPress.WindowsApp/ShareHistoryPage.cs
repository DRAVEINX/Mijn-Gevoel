using MijnGevoel.Core.Data;

namespace MoodPress.WindowsApp;

/// <summary>Toestemmingsgeschiedenis van gedeelde momentopnamen in de privékluis.</summary>
public sealed class ShareHistoryPage : ContentPage
{
    public ShareHistoryPage() { Title="Mijn deelgeschiedenis"; BackgroundColor=AppUi.Background; Rebuild(); }
    void Rebuild()
    {
        var store=AppSession.Store??throw new InvalidOperationException("Sessie is vergrendeld.");
        var root=AppUi.Stack(AppUi.Title("📜 Mijn deelgeschiedenis"),
            AppUi.Label("Hier zie je welke categorieën je bewust in een MoodPress-pakket hebt geselecteerd. Dit logboek staat in je eigen versleutelde gegevenskluis."),
            AppUi.Card(AppUi.Stack(AppUi.Label("Belangrijk over intrekken",title:true),AppUi.Label("Een gedeeld bestand is een momentopname. Je kunt via deze app geen bestand terughalen dat iemand al heeft ontvangen. Vraag de ontvanger het bestand en de code te verwijderen. Online gekoppelde accounts bestaan in deze offline versie niet."))));
        var records=store.All<ShareConsentRecord>("shareconsent").OrderByDescending(x=>x.Created).Take(100).ToList();
        if(records.Count==0)root.Children.Add(AppUi.Label("Nog geen deelgeschiedenis voor ondersteuningspakketten."));
        foreach(var item in records)
        {
            var local=item;
            var panel=AppUi.Stack(AppUi.Label(item.Created.ToString("dd-MM-yyyy HH:mm"),title:true),
                AppUi.Label("Ontvanger / rol: "+(string.IsNullOrWhiteSpace(item.RecipientLabel)?"niet opgegeven":item.RecipientLabel)),
                AppUi.Label("Categorieën: "+string.Join(", ",item.Categories??Array.Empty<string>())),
                AppUi.Label($"Stoplicht: {item.StoplightCount} · routines: {item.RoutineCount} · gevoelscheck-ins: {item.MoodCheckInCount} · stresscheck-ins: {item.YouthCheckInCount}"),
                AppUi.Label("Geselecteerde onderdelen: "+(item.SelectedItemLabels is { Length: > 0 } ? string.Join("; ", item.SelectedItemLabels.Take(30)) : "oude registratie bevat alleen categorieën")),
                AppUi.Button("Verwijder alleen dit lokale logboekrecord",async()=>{if(await DisplayAlertAsync("Logboekrecord verwijderen?","Dit verwijdert alleen het record uit jouw lokale geschiedenis. Het haalt geen eerder gedeeld bestand terug.","Verwijderen","Annuleren")){store.Delete("shareconsent",local.Id);AppSession.Touch();Rebuild();}},quiet:true));
            root.Children.Add(AppUi.Card(panel));
        }
        if(records.Count>0)root.Children.Add(AppUi.AsyncButton("🧹 Alle lokale deelrecords wissen",async()=>{if(await DisplayAlertAsync("Deelgeschiedenis wissen?","Alle lokale registratie-items worden verwijderd. Eerder gedeelde bestanden blijven bij de ontvanger bestaan.","Wissen","Annuleren")){foreach(var record in records)store.Delete("shareconsent",record.Id);AppSession.Touch();Rebuild();}},quiet:true,danger:true));
        root.Children.Add(AppUi.Button("← Terug",()=>Navigation.PopAsync(),quiet:true));
        Content=AppUi.WithBottomNavigation(this, new ScrollView{Content=root}, "shares");
    }
}
