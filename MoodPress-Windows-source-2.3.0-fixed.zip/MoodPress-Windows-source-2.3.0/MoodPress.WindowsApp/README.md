# MoodPress Windows app

This independent Windows MAUI project reuses the MoodPress 2.3.0 pages and core data/security project, with Windows-specific replacements for biometrics, photos, routine reminders, audio and screen privacy. It does not modify the Android project.

Build on Windows with .NET 10 and the MAUI Windows workload:

```powershell
dotnet workload install maui-windows
dotnet test ..\MijnGevoel.Tests\MijnGevoel.Tests.csproj -c Release
dotnet publish .\MoodPress.WindowsApp.csproj -f net10.0-windows10.0.19041.0 -c Release -p:RuntimeIdentifierOverride=win-x64 -p:WindowsPackageType=None -p:WindowsAppSDKSelfContained=true --self-contained true
```

Routine alerts are in-app only while MoodPress is running. Screen capture exclusion is best-effort. Windows Hello is used only when available; normal login remains available.
