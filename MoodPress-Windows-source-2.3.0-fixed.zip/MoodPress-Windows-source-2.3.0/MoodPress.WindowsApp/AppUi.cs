using Microsoft.Maui.ApplicationModel;
using Microsoft.Maui.Controls.Shapes;
using Microsoft.Maui.Media;
using Microsoft.Maui.Devices;
namespace MoodPress.WindowsApp;

internal static class AppUi
{
    static Page? ActivePage
    {
        get
        {
            var root = Application.Current?.Windows.FirstOrDefault()?.Page;
            return root is NavigationPage navigation
                ? navigation.Navigation.NavigationStack.LastOrDefault() ?? navigation
                : root;
        }
    }

    public static Color Background => AppSession.Settings.Theme switch
    {
        "Hoog contrast" => Colors.Black,
        "Donker" => Color.FromArgb("#030716"),
        _ => Color.FromArgb("#070D22")
    };
    public static Color Surface => AppSession.Settings.Theme switch
    {
        "Hoog contrast" => Colors.Black,
        "Donker" => Color.FromArgb("#0A122B"),
        _ => Color.FromArgb("#0D1B3B")
    };
    public static Color SurfaceRaised => AppSession.Settings.Theme == "Hoog contrast"
        ? Colors.Black : Color.FromArgb("#122852");
    public static Color Foreground => AppSession.Settings.Theme == "Hoog contrast"
        ? Colors.White : Color.FromArgb("#F4F7FF");
    public static Color Muted => AppSession.Settings.Theme == "Hoog contrast"
        ? Colors.White : Color.FromArgb("#A8B9DC");
    public static Color Accent => AppSession.Settings.Theme == "Hoog contrast"
        ? Colors.Yellow : Color.FromArgb("#178BFF");
    public static Color Cyan => Color.FromArgb("#21D4FD");
    public static Color Purple => Color.FromArgb("#7B4DFF");
    public static Color Border => AppSession.Settings.Theme == "Hoog contrast"
        ? Colors.White : Color.FromArgb("#244A88");
    public static double BaseFont => AppSession.Settings.TextSize switch { 0 => 16, 2 => 25, _ => 20 };
    // Keep button labels a little smaller than paragraph text, so long Dutch labels fit on mobile.
    // FontAutoScalingEnabled remains on, and word wrapping lets the button grow when needed.
    public static double ButtonFont => Math.Max(14, BaseFont * 0.78);
    public static double TitleFont => BaseFont * 1.28;
    public static string FontFamily => AppSession.Settings.FontName switch { "Georgia" => "serif", "Standaard" => "sans-serif", _ => "sans-serif" };

    public static void Speak(string text)
    {
        if (AppSession.Settings.ReadAloud && !string.IsNullOrWhiteSpace(text))
            _ = SpeakSafelyAsync(text);
    }

    static async Task SpeakSafelyAsync(string text)
    {
        try { await TextToSpeech.Default.SpeakAsync(text); }
        catch (Exception ex) { AppLog.Write(ex); }
    }

    public static Label Label(string text, bool title = false, bool muted = false)
    {
        return new Label
        {
            Text = text,
            FontSize = title ? TitleFont : BaseFont,
            FontFamily = FontFamily,
            FontAttributes = title ? FontAttributes.Bold : FontAttributes.None,
            TextColor = muted ? Muted : Foreground,
            LineBreakMode = LineBreakMode.WordWrap,
            FontAutoScalingEnabled = true,
            HorizontalOptions = LayoutOptions.Fill,
            Margin = new Thickness(0, 2, 0, 2),
            LineHeight = AppSession.Settings.WideLines ? 1.5 : 1.1
        };
    }

    public static View BrandLockup(bool compact = false)
    {
        double markSize = compact ? 64 : 148;
        double screenWidthDp;
        try { screenWidthDp = DeviceDisplay.MainDisplayInfo.Width / DeviceDisplay.MainDisplayInfo.Density; }
        catch { screenWidthDp = 360; }
        double wordSize = Math.Clamp(screenWidthDp * (compact ? 0.085 : 0.095), compact ? 25 : 30, compact ? 30 : 38);
        var brandName = new HorizontalStackLayout
        {
            Spacing = 0,
            HorizontalOptions = LayoutOptions.Center,
            Children =
            {
                new Label { Text = "Mood", FontSize = wordSize, FontFamily = "sans-serif-black", CharacterSpacing = -0.7, FontAttributes = FontAttributes.Bold, TextColor = Foreground, FontAutoScalingEnabled = false, LineBreakMode = LineBreakMode.NoWrap, VerticalTextAlignment = TextAlignment.Center },
                new Label { Text = "Press", FontSize = wordSize, FontFamily = "sans-serif-black", CharacterSpacing = -0.7, FontAttributes = FontAttributes.Bold, TextColor = Color.FromArgb("#6292FF"), FontAutoScalingEnabled = false, LineBreakMode = LineBreakMode.NoWrap, VerticalTextAlignment = TextAlignment.Center }
            }
        };
        var mark = new Image { Source = "moodpress_mark.png", WidthRequest = markSize, HeightRequest = markSize, Aspect = Aspect.AspectFit, HorizontalOptions = LayoutOptions.Center };
        var prompt = new Label
        {
            Text = "Druk op je gevoel",
            FontFamily = "sans-serif-medium",
            FontSize = compact ? 13 : 17,
            TextColor = compact ? Cyan : Foreground,
            HorizontalTextAlignment = TextAlignment.Center,
            LineBreakMode = LineBreakMode.WordWrap,
            Margin = new Thickness(0, 1, 0, compact ? 0 : 4)
        };
        var children = new List<View> { mark, brandName, prompt };
        if (!compact)
        {
            children.Add(new Label
            {
                Text = "Jouw gevoel.\nJouw verhaal.\nJouw app.",
                FontFamily = "cursive",
                FontSize = 23,
                FontAttributes = FontAttributes.Italic,
                FontAutoScalingEnabled = true,
                CharacterSpacing = 0.5,
                TextColor = Color.FromArgb("#D4DDF7"),
                HorizontalTextAlignment = TextAlignment.Center,
                LineBreakMode = LineBreakMode.WordWrap,
                HorizontalOptions = LayoutOptions.Fill,
                LineHeight = 1.16,
                Margin = new Thickness(0, 6, 0, 2)
            });
        }
        var stack = new VerticalStackLayout
        {
            Spacing = compact ? 2 : 5,
            HorizontalOptions = LayoutOptions.Center
        };
        foreach (var child in children) stack.Children.Add(child);
        return stack;
    }

    public static Entry Entry(string placeholder, string? value = null, Keyboard? keyboard = null, bool password = false)
    {
        var e = new Entry
        {
            Placeholder = placeholder,
            Text = value ?? "",
            FontSize = BaseFont,
            FontFamily = FontFamily,
            TextColor = Foreground,
            PlaceholderColor = Muted,
            BackgroundColor = Surface,
            ClearButtonVisibility = ClearButtonVisibility.WhileEditing,
            IsPassword = password,
            Keyboard = keyboard ?? Keyboard.Default,
            Margin = new Thickness(0, 2, 0, 6)
        };
        e.TextChanged += (_, _) => AppSession.Touch();
        return e;
    }

    public static Editor Editor(string placeholder, string? value = null, int height = 150)
    {
        var e = new Editor
        {
            Placeholder = placeholder,
            Text = value ?? "",
            FontSize = BaseFont,
            FontFamily = FontFamily,
            TextColor = Foreground,
            PlaceholderColor = Muted,
            BackgroundColor = Surface,
            AutoSize = EditorAutoSizeOption.TextChanges,
            MinimumHeightRequest = height,
            HorizontalOptions = LayoutOptions.Fill,
            Margin = new Thickness(0, 2, 0, 6)
        };
        e.TextChanged += (_, _) => AppSession.Touch();
        return e;
    }

    public static Button Button(string text, Action action, bool quiet = false, bool danger = false)
    {
        var b = new Button
        {
            Text = text,
            FontSize = ButtonFont,
            FontFamily = FontFamily,
            TextColor = danger ? Colors.White : quiet ? Foreground : (AppSession.Settings.Theme == "Hoog contrast" ? Colors.Black : Colors.White),
            BackgroundColor = danger ? Color.FromArgb("#B93360") : quiet ? Surface : Accent,
            BorderColor = danger ? Color.FromArgb("#FF6B9D") : quiet ? Border : Accent,
            BorderWidth = 1,
            CornerRadius = 18,
            Padding = new Thickness(14, 10),
            HorizontalOptions = LayoutOptions.Fill,
            MinimumHeightRequest = 58,
            LineBreakMode = LineBreakMode.WordWrap,
            FontAutoScalingEnabled = true,
            Margin = new Thickness(0, 2, 0, 4)
        };
        b.Clicked += (_, _) =>
        {
            AppSession.Touch();
            try { action(); }
            catch (Exception ex)
            {
                AppLog.Write(ex);
                MainThread.BeginInvokeOnMainThread(async () =>
                {
                    var page = ActivePage;
                    if (page is not null)
                        await page.DisplayAlertAsync("Er ging iets mis", "Deze actie is niet gelukt. Je gegevens zijn niet bewust gedeeld; probeer het opnieuw.", "OK");
                });
            }
        };
        return b;
    }

    public static Button AsyncButton(string text, Func<Task> action, bool quiet = false, bool danger = false)
    {
        var b = new Button
        {
            Text = text,
            FontSize = ButtonFont,
            FontFamily = FontFamily,
            TextColor = danger ? Colors.White : quiet ? Foreground : (AppSession.Settings.Theme == "Hoog contrast" ? Colors.Black : Colors.White),
            BackgroundColor = danger ? Color.FromArgb("#B93360") : quiet ? Surface : Accent,
            BorderColor = danger ? Color.FromArgb("#FF6B9D") : quiet ? Border : Accent,
            BorderWidth = 1,
            CornerRadius = 18,
            Padding = new Thickness(14, 10),
            HorizontalOptions = LayoutOptions.Fill,
            MinimumHeightRequest = 58,
            LineBreakMode = LineBreakMode.WordWrap,
            FontAutoScalingEnabled = true,
            Margin = new Thickness(0, 2, 0, 4)
        };
        b.Clicked += async (_, _) =>
        {
            AppSession.Touch(); b.IsEnabled = false;
            try { await action(); }
            catch (Exception ex)
            {
                AppLog.Write(ex);
                var page = ActivePage;
                if (page is not null)
                    await page.DisplayAlertAsync("Er ging iets mis", "De actie is niet gelukt. Controleer je invoer en probeer het opnieuw.", "OK");
            }
            finally { b.IsEnabled = true; }
        };
        return b;
    }

    public static Picker Picker(string title, IEnumerable<string> options, string? selected = null)
    {
        var p = new Picker { Title = title, FontSize = BaseFont, FontFamily = FontFamily, TextColor = Foreground, BackgroundColor = Surface, Margin = new Thickness(0, 2, 0, 6) };
        foreach (var option in options) p.Items.Add(option);
        if (selected is not null)
        {
            int ix = p.Items.IndexOf(selected);
            if (ix >= 0) p.SelectedIndex = ix;
        }
        p.SelectedIndexChanged += (_, _) => AppSession.Touch();
        return p;
    }

    public static VerticalStackLayout Stack(params View[] views)
    {
        var desktop = DeviceInfo.Platform == DevicePlatform.WinUI;
        var s = new VerticalStackLayout
        {
            Spacing = desktop ? 16 : 12,
            Padding = desktop ? new Thickness(30, 26) : new Thickness(18, 16),
            BackgroundColor = Background,
            MaximumWidthRequest = desktop ? 1100 : -1,
            HorizontalOptions = desktop ? LayoutOptions.Center : LayoutOptions.Fill
        };
        foreach (var v in views) s.Children.Add(v);
        return s;
    }

    public static Border Card(View child)
    {
        return new Border
        {
            Content = child,
            Stroke = new SolidColorBrush(Border),
            StrokeThickness = 1,
            BackgroundColor = Surface,
            Padding = 14,
            Margin = new Thickness(0, 4),
            StrokeShape = new RoundRectangle { CornerRadius = 20 }
        };
    }

    public static Grid WithBottomNavigation(Page host, View body, string active)
    {
        if (DeviceInfo.Platform == DevicePlatform.WinUI)
            return WithDesktopNavigation(host, body, active);

        var layout = new Grid
        {
            BackgroundColor = Background,
            RowSpacing = 0,
            ColumnDefinitions = { new ColumnDefinition(GridLength.Star) },
            RowDefinitions = { new RowDefinition(GridLength.Star), new RowDefinition(GridLength.Auto) }
        };
        layout.Add(body, 0, 0);

        var tabs = new Grid
        {
            Padding = new Thickness(6, 5),
            ColumnSpacing = 4,
            BackgroundColor = Color.FromArgb("#09142C"),
            ColumnDefinitions =
            {
                new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star),
                new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star)
            }
        };
        AddTab(tabs, host, "⌂\nHome", "home", active, null, 0);
        AddTab(tabs, host, "▦\nDag", "day", active, FeatureKind.DayToday, 1);
        AddTab(tabs, host, "♡\nGevoel", "feeling", active, FeatureKind.DailyCheckIn, 2);
        AddTab(tabs, host, "☰\nMeer", "more", active, FeatureKind.Settings, 3);
        layout.Add(tabs, 0, 1);
        Grid.SetRow(tabs, 1);
        return layout;
    }


    static Grid WithDesktopNavigation(Page host, View body, string active)
    {
        var layout = new Grid
        {
            BackgroundColor = Background,
            ColumnSpacing = 0,
            ColumnDefinitions = { new ColumnDefinition(new GridLength(258)), new ColumnDefinition(GridLength.Star) }
        };
        var sidebar = new Grid
        {
            BackgroundColor = Color.FromArgb("#08142E"),
            Padding = new Thickness(18, 24),
            RowSpacing = 0,
            RowDefinitions = { new RowDefinition(GridLength.Auto), new RowDefinition(GridLength.Star), new RowDefinition(GridLength.Auto) }
        };
        var brandRow = new HorizontalStackLayout
        {
            Spacing = 10,
            Padding = new Thickness(2, 0, 2, 22),
            VerticalOptions = LayoutOptions.Start,
            Children =
            {
                new Image { Source = "moodpress_mark.png", WidthRequest = 52, HeightRequest = 52, Aspect = Aspect.AspectFit, VerticalOptions = LayoutOptions.Center },
                new VerticalStackLayout { Spacing = 0, VerticalOptions = LayoutOptions.Center, Children =
                {
                    new Label { Text = "MoodPress", FontSize = 21, FontAttributes = FontAttributes.Bold, TextColor = Colors.White, LineBreakMode = LineBreakMode.NoWrap },
                    new Label { Text = "Jouw gevoel. Jouw verhaal.", FontSize = 10, TextColor = Color.FromArgb("#94AADB"), LineBreakMode = LineBreakMode.WordWrap }
                }}
            }
        };
        sidebar.Add(brandRow, 0, 0);
        var menu = new VerticalStackLayout { Spacing = 6 };
        menu.Children.Add(DesktopNavButton(host, "⌂", "Startpagina", "home", active, Color.FromArgb("#233D78")));
        menu.Children.Add(DesktopNavButton(host, "▦", "Mijn dag", "day", active));
        menu.Children.Add(DesktopNavButton(host, "♡", "Mijn gevoel", "feeling", active));
        menu.Children.Add(DesktopNavButton(host, "👥", "Wie werkt er?", "who", active));
        menu.Children.Add(DesktopNavButton(host, "🧩", "Visueel dagschema", "schedule", active));
        menu.Children.Add(DesktopNavButton(host, "🔐", "Deelgeschiedenis", "shares", active));
        menu.Children.Add(DesktopNavButton(host, "☰", "Meer functies", "more", active));
        menu.Children.Add(DesktopNavButton(host, "🧑‍🤝‍🧑", "Ondersteuner", "support", active));
        sidebar.Add(new ScrollView { Content = menu, VerticalOptions = LayoutOptions.Fill }, 0, 1);
        var bottom = new VerticalStackLayout { Spacing = 6, Padding = new Thickness(0, 18, 0, 0) };
        bottom.Children.Add(new BoxView { HeightRequest = 1, Color = Color.FromArgb("#23365C"), Margin = new Thickness(0, 0, 0, 8) });
        bottom.Children.Add(DesktopNavButton(host, "🙈", "Scherm verbergen", "privacy", active));
        bottom.Children.Add(DesktopNavButton(host, "🔒", "Sessie vergrendelen", "lock", active));
        bottom.Children.Add(new Label { Text = "LOKAAL · PRIVÉ · VERSLEUTELD", FontSize = 9, CharacterSpacing = 0.7, TextColor = Color.FromArgb("#6F86B7"), Margin = new Thickness(4, 8, 0, 0), LineBreakMode = LineBreakMode.WordWrap });
        sidebar.Add(bottom, 0, 2);
        layout.Add(sidebar, 0, 0);

        var contentHost = new Grid { BackgroundColor = Background, Padding = new Thickness(18, 12), RowDefinitions = { new RowDefinition(GridLength.Star) } };
        body.HorizontalOptions = LayoutOptions.Fill;
        body.VerticalOptions = LayoutOptions.Fill;
        body.MaximumWidthRequest = 1320;
        contentHost.Add(body, 0, 0);
        layout.Add(contentHost, 1, 0);
        return layout;
    }

    static Button DesktopNavButton(Page host, string glyph, string title, string target, string active, Color? accent = null)
    {
        bool selected = target == active || (target == "home" && active == "home");
        var button = new Button
        {
            Text = glyph + "    " + title,
            FontSize = 14,
            FontAttributes = selected ? FontAttributes.Bold : FontAttributes.None,
            TextColor = selected ? Colors.White : Color.FromArgb("#BDCAE9"),
            BackgroundColor = selected ? accent ?? Color.FromArgb("#172B55") : Color.FromArgb("#08142E"),
            BorderColor = selected ? Color.FromArgb("#2B65CF") : Color.FromArgb("#08142E"),
            BorderWidth = selected ? 1 : 0,
            CornerRadius = 12,
            Padding = new Thickness(14, 12),
            MinimumHeightRequest = 46,
            HorizontalOptions = LayoutOptions.Fill,
            Margin = new Thickness(0, 1)
        };
        button.Clicked += async (_, _) =>
        {
            AppSession.Touch();
            try
            {
                if (target == "privacy") { await host.Navigation.PushAsync(new PrivacyCoverPage()); return; }
                if (target == "lock") { await ((App)Application.Current!).LockToLoginAsync("Je sessie is vergrendeld."); return; }
                var navigation = host.Navigation;
                var dashboard = navigation.NavigationStack.FirstOrDefault(page => page is DashboardPage);
                if (dashboard is not null)
                {
                    while (navigation.NavigationStack.Count > 0 && navigation.NavigationStack.Last() != dashboard)
                        await navigation.PopAsync(false);
                    if (target == "home") return;
                }
                else if (target == "home") { await navigation.PushAsync(new DashboardPage()); return; }
                switch (target)
                {
                    case "day": await navigation.PushAsync(new FeaturePage(FeatureKind.DayToday), false); break;
                    case "feeling": await navigation.PushAsync(new FeaturePage(FeatureKind.DailyCheckIn), false); break;
                    case "who": await navigation.PushAsync(new WieWerktErPage(), false); break;
                    case "schedule": await navigation.PushAsync(new ChildSchedulePage(), false); break;
                    case "shares": await navigation.PushAsync(new ShareHistoryPage(), false); break;
                    case "support": await navigation.PushAsync(new SupporterCenterPage(), false); break;
                    case "more": await navigation.PushAsync(new FeaturePage(FeatureKind.Settings), false); break;
                }
            }
            catch (Exception ex) { AppLog.Write(ex); }
        };
        return button;
    }

    static void AddTab(Grid tabs, Page host, string text, string target, string active, FeatureKind? destination, int column)
    {
        var selected = target == active;
        var b = new Button
        {
            Text = text,
            FontSize = 12,
            FontFamily = FontFamily,
            TextColor = selected ? Color.FromArgb("#3DD6FF") : Color.FromArgb("#A8B9DC"),
            BackgroundColor = selected ? Color.FromArgb("#172F69") : Color.FromArgb("#09142C"),
            BorderColor = selected ? Color.FromArgb("#395DF5") : Color.FromArgb("#09142C"),
            BorderWidth = selected ? 1 : 0,
            CornerRadius = 14,
            Padding = new Thickness(3, 4),
            MinimumHeightRequest = 62,
            LineBreakMode = LineBreakMode.WordWrap,
            FontAutoScalingEnabled = true,
            Margin = new Thickness(0)
        };
        b.Clicked += async (_, _) =>
        {
            AppSession.Touch();
            try
            {
                var navigation = host.Navigation;
                var dashboard = navigation.NavigationStack.FirstOrDefault(p => p is DashboardPage);
                if (dashboard is not null)
                {
                    while (navigation.NavigationStack.Count > 0 && navigation.NavigationStack.Last() != dashboard)
                        await navigation.PopAsync(false);
                }
                if (destination is null) return;
                if (destination == FeatureKind.Settings && host is FeaturePage fp && fp.CurrentKind == FeatureKind.Settings)
                    return;
                await navigation.PushAsync(new FeaturePage(destination.Value), false);
            }
            catch (Exception ex) { AppLog.Write(ex); }
        };
        tabs.Add(b, column, 0);
    }

    public static Label Title(string title) => Label(title, title: true);

    public static Label Copyright()
    {
        var label = Label("© 2026 Jordy Ham. Alle rechten voorbehouden.", muted: true);
        label.HorizontalTextAlignment = TextAlignment.Center;
        label.FontSize = Math.Max(12, BaseFont * 0.72);
        label.Margin = new Thickness(0, 14, 0, 8);
        return label;
    }
}
