using System.Globalization;
using MijnGevoel.Core.Data;

namespace MoodPress.WindowsApp;

/// <summary>
/// Windows-only in-app routine reminders. They are shown while MoodPress is running;
/// Windows background notifications are deliberately not claimed by this implementation.
/// </summary>
internal static class RoutineReminderNotifications
{
    static readonly HashSet<string> ShownThisDay = new(StringComparer.Ordinal);
    static DateOnly _shownDate = DateOnly.MinValue;

    public static Task<bool> EnsurePermissionAsync() => Task.FromResult(true);
    public static void Sync(IEnumerable<RoutineReminder> reminders) { /* Stored routines remain the source of truth. */ }

    public static IReadOnlyList<RoutineReminder> TakeDue(IEnumerable<RoutineReminder> reminders, DateTime now)
    {
        var today = DateOnly.FromDateTime(now);
        if (_shownDate != today) { ShownThisDay.Clear(); _shownDate = today; }
        var currentTime = now.ToString("HH:mm", CultureInfo.InvariantCulture);
        int dayBit = 1 << (int)now.DayOfWeek;
        var due = new List<RoutineReminder>();
        foreach (var item in reminders)
        {
            if (!item.Enabled || (item.DaysMask & dayBit) == 0 || !string.Equals(item.Time, currentTime, StringComparison.Ordinal)) continue;
            if (ShownThisDay.Add(item.Id.ToString("N") + ":" + today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)))
                due.Add(item);
        }
        return due;
    }

    public static async Task ShowAsync(RoutineReminder reminder)
    {
        try
        {
            if (reminder.SoundEnabled)
            {
                try { System.Media.SystemSounds.Asterisk.Play(); }
                catch (Exception ex) { AppLog.Write(ex); }
            }
            var page = Application.Current?.Windows.FirstOrDefault()?.Page;
            if (page is NavigationPage nav) page = nav.Navigation.NavigationStack.LastOrDefault() ?? nav;
            if (page is not null)
                await page.DisplayAlertAsync($"{reminder.Icon} {reminder.Title}", "Het is tijd voor jouw routine. Open MoodPress om deze te bekijken.", "OK");
        }
        catch (Exception ex) { AppLog.Write(ex); }
    }
}
