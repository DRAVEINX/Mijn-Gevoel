using Windows.Security.Credentials.UI;

namespace MoodPress.WindowsApp;

/// <summary>Windows Hello verification for the optional remembered-session flow.</summary>
internal static class BiometricUnlock
{
    public static async Task<bool> AuthenticateAsync()
    {
        try
        {
            var availability = await UserConsentVerifier.CheckAvailabilityAsync();
            if (availability != UserConsentVerifierAvailability.Available) return false;
            var result = await UserConsentVerifier.RequestVerificationAsync("Ontgrendel MoodPress");
            return result == UserConsentVerificationResult.Verified;
        }
        catch (Exception ex)
        {
            AppLog.Write(ex);
            return false;
        }
    }
}
