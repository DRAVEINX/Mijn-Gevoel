using Microsoft.Maui.Storage;
using System.Globalization;
using System.Security.Cryptography;
using MijnGevoel.Core.Data;
using MijnGevoel.Core.Security;

namespace MoodPress.WindowsApp;

/// <summary>Beheert de actieve sessie. De optionele herstelsleutel wordt uitsluitend via MAUI SecureStorage opgeslagen.</summary>
public static class AppSession
{
    static AccountService? _accounts;
    static DateTime _lastRememberWriteUtc = DateTime.MinValue;
    const string RememberPreference = "mg.keep-signed-in";
    const string RememberUsernameKey = "mg.remember.username";
    const string RememberVaultKey = "mg.remember.vault-key";
    const string RememberActivityKey = "mg.remember.last-activity";
    const string RememberAutoLockKey = "mg.remember.auto-lock-minutes";

    public static AccountService Accounts => _accounts ??= new AccountService(Path.Combine(FileSystem.AppDataDirectory, "accounts"));
    public static VaultStore? Store { get; private set; }
    public static string Username { get; private set; } = "";
    public static UserSettings Settings { get; private set; } = new();
    public static DateTime LastActivityUtc { get; private set; } = DateTime.UtcNow;
    public static bool IsUnlocked => Store is not null;
    public static bool KeepSignedIn => Preferences.Default.Get(RememberPreference, false);

    public static void Start(string username, byte[] vaultKey)
    {
        End();
        Username = username;
        // VaultStore owns its key array and wipes it when the session ends.
        Store = new VaultStore((byte[])vaultKey.Clone(), Accounts.DataFolder(username));
        CryptographicOperations.ZeroMemory(vaultKey);
        Settings = Store.Load<UserSettings>("settings", Guid.Empty) ?? new UserSettings();
        LastActivityUtc = DateTime.UtcNow;
        _lastRememberWriteUtc = DateTime.MinValue;
        ScreenPrivacy.Apply(Settings.BlockCapture);
    }

    /// <summary>Bewaar alleen de reeds geverifieerde vaultsleutel in SecureStorage; nooit wachtwoord of authenticatorcode.</summary>
    public static async Task<bool> SaveRememberedSessionAsync(string username, byte[] vaultKey)
    {
        if (vaultKey is null || vaultKey.Length != Crypto.KeySize) return false;
        try
        {
            await SecureStorage.Default.SetAsync(RememberUsernameKey, username);
            await SecureStorage.Default.SetAsync(RememberVaultKey, Convert.ToBase64String(vaultKey));
            await SecureStorage.Default.SetAsync(RememberActivityKey, DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture));
            await SecureStorage.Default.SetAsync(RememberAutoLockKey, "5");
            Preferences.Default.Set(RememberPreference, true);
            _lastRememberWriteUtc = DateTime.UtcNow;
            return true;
        }
        catch
        {
            await ClearRememberedSessionAsync();
            return false;
        }
    }

    public static async Task UpdateRememberedSessionPolicyAsync()
    {
        if (!KeepSignedIn || Store is null) return;
        try
        {
            await SecureStorage.Default.SetAsync(RememberAutoLockKey, Math.Clamp(Settings.AutoLockMinutes, 1, 30).ToString(CultureInfo.InvariantCulture));
            await PersistRememberedActivityAsync(force: true);
        }
        catch
        {
            await ClearRememberedSessionAsync();
        }
    }

    /// <summary>Controleert of er een versleutelde sessie klaarstaat. Wordt gebruikt voordat de biometrische prompt verschijnt.</summary>
    public static async Task<bool> HasRememberedSessionAsync()
    {
        if (!KeepSignedIn) return false;
        try
        {
            var username = await SecureStorage.Default.GetAsync(RememberUsernameKey);
            var encodedKey = await SecureStorage.Default.GetAsync(RememberVaultKey);
            return !string.IsNullOrWhiteSpace(username) && !string.IsNullOrWhiteSpace(encodedKey);
        }
        catch { return false; }
    }

    /// <summary>Herstelt de reeds geverifieerde sessie. LoginPage roept deze methode pas aan nadat de biometrische prompt geslaagd is.</summary>
    public static async Task<bool> TryRestoreRememberedSessionAsync()
    {
        if (!KeepSignedIn) return false;
        byte[]? key = null;
        try
        {
            var username = await SecureStorage.Default.GetAsync(RememberUsernameKey);
            var encodedKey = await SecureStorage.Default.GetAsync(RememberVaultKey);
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(encodedKey))
            {
                await ClearRememberedSessionAsync();
                return false;
            }

            key = Convert.FromBase64String(encodedKey);
            if (key.Length != Crypto.KeySize)
            {
                CryptographicOperations.ZeroMemory(key);
                key = null;
                await ClearRememberedSessionAsync();
                return false;
            }

            Start(username, key); // Start maakt een eigen kopie en wist de buffer.
            key = null;
            Touch();
            await UpdateRememberedSessionPolicyAsync();
            return Store is not null;
        }
        catch (Exception ex)
        {
            if (key is not null) CryptographicOperations.ZeroMemory(key);
            End();
            AppLog.Write(ex);
            await ClearRememberedSessionAsync();
            return false;
        }
    }

    public static async Task ClearRememberedSessionAsync()
    {
        try
        {
            SecureStorage.Default.Remove(RememberUsernameKey);
            SecureStorage.Default.Remove(RememberVaultKey);
            SecureStorage.Default.Remove(RememberActivityKey);
            SecureStorage.Default.Remove(RememberAutoLockKey);
        }
        catch { /* Als SecureStorage al door het besturingssysteem is gewist, is de sessie alsnog niet herstelbaar. */ }
        try { Preferences.Default.Set(RememberPreference, false); } catch { }
        _lastRememberWriteUtc = DateTime.MinValue;
        await Task.CompletedTask;
    }

    public static Task PersistRememberedActivityAsync(bool force = false)
    {
        if (!KeepSignedIn) return Task.CompletedTask;
        var now = DateTime.UtcNow;
        if (!force && now - _lastRememberWriteUtc < TimeSpan.FromSeconds(30)) return Task.CompletedTask;
        return PersistCoreAsync();

        async Task PersistCoreAsync()
        {
            try
            {
                await SecureStorage.Default.SetAsync(RememberActivityKey, LastActivityUtc.ToString("O", CultureInfo.InvariantCulture));
                _lastRememberWriteUtc = DateTime.UtcNow;
            }
            catch { await ClearRememberedSessionAsync(); }
        }
    }

    public static void SaveSettings() => Store?.Save("settings", Guid.Empty, Settings);

    public static void Touch()
    {
        LastActivityUtc = DateTime.UtcNow;
        if (KeepSignedIn) _ = PersistRememberedActivityAsync();
    }

    public static void End()
    {
        Store?.Dispose();
        Store = null;
        Username = "";
        Settings = new UserSettings();
        LastActivityUtc = DateTime.UtcNow;
        ScreenPrivacy.Apply(false);
    }
}

public static class ScreenPrivacy
{
#if WINDOWS
    [System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
    static extern bool SetWindowDisplayAffinity(IntPtr hWnd, uint dwAffinity);
#endif
    public static void Apply(bool enabled)
    {
#if ANDROID
        try
        {
            var activity = Microsoft.Maui.ApplicationModel.Platform.CurrentActivity;
            var window = activity?.Window;
            if (window is null) return;
            if (enabled) window.AddFlags(Android.Views.WindowManagerFlags.Secure);
            else window.ClearFlags(Android.Views.WindowManagerFlags.Secure);
        }
        catch { /* platform privacy setting must not crash the app */ }
#elif WINDOWS
        try
        {
            var platformWindow = Application.Current?.Windows.FirstOrDefault()?.Handler?.PlatformView as Microsoft.UI.Xaml.Window;
            if (platformWindow is null) return;
            var hwnd = WinRT.Interop.WindowNative.GetWindowHandle(platformWindow);
            // WDA_EXCLUDEFROMCAPTURE is best-effort and depends on the Windows version and capture API.
            SetWindowDisplayAffinity(hwnd, enabled ? 0x00000011u : 0u);
        }
        catch { /* Privacy controls should never crash the application. */ }
#endif
    }
}
