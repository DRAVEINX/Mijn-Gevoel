using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Maui.Storage;
using MijnGevoel.Core.Data;

namespace MoodPress.WindowsApp;

/// <summary>Apparaat-lokale ondersteunerdata in MAUI SecureStorage (besturingssysteem-beveiligde opslag).</summary>
public static class SupporterLocalStore
{
    const string PinKey = "moodpress.supporter.pin.v1";
    const string PlanKey = "moodpress.supporter.plan.v1";
    const string AuditKey = "moodpress.supporter.audit.v1";
    const int Iterations = 250_000;
    sealed record PinEnvelope(string Salt, string Hash, int Iterations);

    public static async Task<bool> HasPinAsync()
    {
        try { return !string.IsNullOrWhiteSpace(await SecureStorage.Default.GetAsync(PinKey)); }
        catch { return false; }
    }

    public static async Task SetPinAsync(string pin)
    {
        if (string.IsNullOrWhiteSpace(pin) || pin.Trim().Length < 8 || pin.Length > 200)
            throw new ArgumentException("Gebruik een lokale toegangscode van minimaal 8 tekens.");
        var salt = RandomNumberGenerator.GetBytes(16);
        var bytes = Encoding.UTF8.GetBytes(pin.Normalize(NormalizationForm.FormKC));
        byte[]? hash = null;
        try
        {
            hash = Rfc2898DeriveBytes.Pbkdf2(bytes, salt, Iterations, HashAlgorithmName.SHA256, 32);
            var envelope = new PinEnvelope(Convert.ToBase64String(salt), Convert.ToBase64String(hash), Iterations);
            await SecureStorage.Default.SetAsync(PinKey, JsonSerializer.Serialize(envelope));
        }
        finally
        {
            CryptographicOperations.ZeroMemory(bytes);
            if (hash is not null) CryptographicOperations.ZeroMemory(hash);
            CryptographicOperations.ZeroMemory(salt);
        }
    }

    public static async Task<bool> VerifyPinAsync(string pin)
    {
        string? json;
        try { json = await SecureStorage.Default.GetAsync(PinKey); } catch { return false; }
        if (string.IsNullOrWhiteSpace(json) || string.IsNullOrWhiteSpace(pin) || pin.Length > 200) return false;
        byte[]? salt = null, expected = null, bytes = null, actual = null;
        try
        {
            var envelope = JsonSerializer.Deserialize<PinEnvelope>(json);
            if (envelope is null || envelope.Iterations is < 100_000 or > 1_000_000) return false;
            salt = Convert.FromBase64String(envelope.Salt); expected = Convert.FromBase64String(envelope.Hash);
            if (salt.Length != 16 || expected.Length != 32) return false;
            bytes = Encoding.UTF8.GetBytes(pin.Normalize(NormalizationForm.FormKC));
            actual = Rfc2898DeriveBytes.Pbkdf2(bytes, salt, envelope.Iterations, HashAlgorithmName.SHA256, 32);
            return CryptographicOperations.FixedTimeEquals(expected, actual);
        }
        catch (Exception ex) when (ex is JsonException or FormatException or CryptographicException or ArgumentException) { return false; }
        finally
        {
            if (salt is not null) CryptographicOperations.ZeroMemory(salt);
            if (expected is not null) CryptographicOperations.ZeroMemory(expected);
            if (bytes is not null) CryptographicOperations.ZeroMemory(bytes);
            if (actual is not null) CryptographicOperations.ZeroMemory(actual);
        }
    }

    public static async Task<SafetyPlan> LoadPlanAsync()
    {
        try { var json = await SecureStorage.Default.GetAsync(PlanKey); return string.IsNullOrWhiteSpace(json) ? new SafetyPlan() : JsonSerializer.Deserialize<SafetyPlan>(json) ?? new SafetyPlan(); }
        catch { return new SafetyPlan(); }
    }

    public static async Task SavePlanAsync(SafetyPlan plan)
    {
        static string Clean(string? value, int max)
        {
            var trimmed = (value ?? string.Empty).Trim();
            return trimmed.Length > max ? trimmed[..max] : trimmed;
        }
        plan.PersonName = Clean(plan.PersonName, 200);
        plan.Helps = Clean(plan.Helps, 8000); plan.EarlySigns = Clean(plan.EarlySigns, 8000); plan.Avoid = Clean(plan.Avoid, 8000);
        plan.Communication = Clean(plan.Communication, 8000); plan.SupportSteps = Clean(plan.SupportSteps, 8000);
        plan.Goals = Clean(plan.Goals, 8000); plan.RoutineNotes = Clean(plan.RoutineNotes, 8000);
        plan.Contacts = (plan.Contacts ?? new()).Take(100).Select(c => new ContactPerson(Clean(c.Name, 200), Clean(c.Phone, 100))).ToList();
        plan.HelpOptions = (plan.HelpOptions ?? new()).Where(x => !string.IsNullOrWhiteSpace(x)).Take(50).Select(x => Clean(x, 100)).ToList();
        await SecureStorage.Default.SetAsync(PlanKey, JsonSerializer.Serialize(plan));
    }

    public static async Task AddAuditAsync(string action, string summary)
    {
        List<SupportAuditEntry> items;
        try { items = JsonSerializer.Deserialize<List<SupportAuditEntry>>(await SecureStorage.Default.GetAsync(AuditKey) ?? "[]") ?? new(); }
        catch { items = new(); }
        items.Add(new SupportAuditEntry(Guid.NewGuid(), DateTime.Now, (action ?? "Gebeurtenis")[..Math.Min((action ?? "Gebeurtenis").Length, 120)], (summary ?? string.Empty)[..Math.Min((summary ?? string.Empty).Length, 400)]));
        items = items.OrderByDescending(x => x.Created).Take(50).ToList();
        await SecureStorage.Default.SetAsync(AuditKey, JsonSerializer.Serialize(items));
    }

    public static async Task<List<SupportAuditEntry>> GetAuditAsync()
    {
        try { return (JsonSerializer.Deserialize<List<SupportAuditEntry>>(await SecureStorage.Default.GetAsync(AuditKey) ?? "[]") ?? new()).OrderByDescending(x => x.Created).Take(50).ToList(); }
        catch { return new(); }
    }

    /// <summary>Reset wis alleen lokale ondersteunerdata; kan de gegevenskluis van de cliënt niet openen.</summary>
    public static void ResetLocalData()
    {
        try { SecureStorage.Default.Remove(PinKey); } catch { }
        try { SecureStorage.Default.Remove(PlanKey); } catch { }
        try { SecureStorage.Default.Remove(AuditKey); } catch { }
    }
}
